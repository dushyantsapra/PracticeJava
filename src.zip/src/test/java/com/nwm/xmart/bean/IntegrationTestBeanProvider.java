package com.nwm.xmart.bean;

import com.google.inject.Module;
import com.nwm.xmart.bean.rdx.XmartRdxInstrumentModule;
import com.nwm.xmart.processor.JobType;

/**
 * Created by aslammh on 19/09/17.
 * Provides the binding of bean specific to ODC.
 */
public class IntegrationTestBeanProvider extends AbstractBeanProvider {
    @Override
    public Module[] getModules(JobType jobType) {

        Module jobModule = null;

        switch (jobType) {
        case BDX_RDX_INSTRUMENT_LOAD:
            jobModule = new XmartRdxInstrumentModule();
            break;
        case BDX_TRANSACTION_LOAD:
            jobModule = new XmartOdcTransactionModule();
            break;
        default:
            throw new IllegalArgumentException("The job type is not recognised : " + jobType);
        }

        return new Module[] { new IntegrationTestModule(), jobModule };
    }
}
