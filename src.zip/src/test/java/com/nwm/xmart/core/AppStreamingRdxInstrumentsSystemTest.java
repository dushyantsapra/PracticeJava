package com.nwm.xmart.core;

import com.nwm.xmart.bean.BeanProvider;
import com.nwm.xmart.bean.SystemTestBeanProvider;
import com.nwm.xmart.processor.RdxInstrumentIntegrationTestProcessor;
import com.nwm.xmart.streaming.common.job.StreamJob;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Tag("IntegrationTest")
public class AppStreamingRdxInstrumentsSystemTest {

    private static final Logger logger = LoggerFactory.getLogger(AppStreamingRdxInstrumentsSystemTest.class);
    String args[] = { "src\\test\\resources\\TestRdxInstrumentFlinkJob.properties" };

    @Tag("SystemTest")
    @Test
    public void rdxInstrumentIntegrationTest() throws Exception {

        BeanProvider beanProvider = new SystemTestBeanProvider();
        StreamJob streamJob = new XmartStreamingJob(beanProvider, RdxInstrumentIntegrationTestProcessor.class);
        try {
//            streamJob.run(args);
        } catch (Exception e) {
            Assertions.fail("System Test Failed" + e.getMessage());
            e.printStackTrace();
        }
    }
}
