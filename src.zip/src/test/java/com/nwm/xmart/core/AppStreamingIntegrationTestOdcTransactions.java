package com.nwm.xmart.core;

import com.nwm.xmart.bean.BeanProvider;
import com.nwm.xmart.bean.IntegrationTestBeanProvider;
import com.nwm.xmart.processor.OdcTransactionIntegrationTestProcessor;
import com.nwm.xmart.streaming.common.job.StreamJob;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Tag("IntegrationTest")
public class AppStreamingIntegrationTestOdcTransactions {

    private static final Logger logger = LoggerFactory.getLogger(AppStreamingIntegrationTestOdcTransactions.class);
    String args[] = { "src\\test\\resources\\TestOdcTransactionFlinkJob.properties" };

    @Tag("IntegrationTest")
    @Test
    public void odcTransactionIntegrationTest() throws Exception {

        BeanProvider beanProvider = new IntegrationTestBeanProvider();
        StreamJob streamJob = new XmartStreamingJob(beanProvider, OdcTransactionIntegrationTestProcessor.class);
        try {
            streamJob.run(args);
        } catch (Exception e) {
            Assertions.fail("Integration Test Failed" + e.getMessage());
            e.printStackTrace();
        }
    }
}
