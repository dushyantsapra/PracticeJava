package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestInterestRateLeg implements InterestRateLeg {
    // for ease of verification
    private String legIdentifier;
    private BigDecimal interestRate;
    private InterestRateType fixedOrFloatingRateType;
    private CompoundingMethodScheme compoundingMethod;
    private String varyingNotionalRateSource;
    private RoundingDirection roundingDirection;
    private NegativeInterestRateTreatmentScheme negativeRateTreatment;
    private BigDecimal rateMultiplier;
    private FraDiscountingTypeScheme discountingType;
    private String quotationStyle;
    private Integer roundingPrecision;
    private BigDecimal calcPeriodNumOfDays;

    public TestInterestRateLeg(String legIdentifier) {
        this();
        this.legIdentifier = legIdentifier;
    }

    public TestInterestRateLeg() {

        interestRate = new BigDecimal(getRndDouble());
        varyingNotionalRateSource = getRandomString();
        rateMultiplier = new BigDecimal(getRndDouble());
        quotationStyle = getRandomString();
        roundingPrecision = getRndInt();
        calcPeriodNumOfDays = new BigDecimal(getRndDouble());

        try {
            fixedOrFloatingRateType = InterestRateType.valueOf(getRndInt() % InterestRateType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            fixedOrFloatingRateType = InterestRateType.NULL;
        }
        try {
            compoundingMethod = CompoundingMethodScheme
                    .valueOf(getRndInt() % CompoundingMethodScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            compoundingMethod = CompoundingMethodScheme.NULL;
        }
        try {
            roundingDirection = RoundingDirection.valueOf(getRndInt() % RoundingDirection.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            roundingDirection = RoundingDirection.NULL;
        }
        try {
            negativeRateTreatment = NegativeInterestRateTreatmentScheme
                    .valueOf(getRndInt() % NegativeInterestRateTreatmentScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            negativeRateTreatment = NegativeInterestRateTreatmentScheme.NULL;
        }
        try {
            discountingType = FraDiscountingTypeScheme
                    .valueOf(getRndInt() % FraDiscountingTypeScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            discountingType = FraDiscountingTypeScheme.NULL;
        }
    }

    @Override
    public BigDecimal getInterestRate() {
        return interestRate;
    }

    @Override
    public InterestRateType getFixedOrFloatingRateType() {
        return fixedOrFloatingRateType;
    }

    @Override
    public CompoundingMethodScheme getCompoundingMethod() {
        return compoundingMethod;
    }

    @Override
    public String getVaryingNotionalRateSource() {
        return varyingNotionalRateSource;
    }

    @Override
    public RoundingDirection getRoundingDirection() {
        return roundingDirection;
    }

    @Override
    public NegativeInterestRateTreatmentScheme getNegativeRateTreatment() {
        return negativeRateTreatment;
    }

    @Override
    public BigDecimal getRateMultiplier() {
        return rateMultiplier;
    }

    @Override
    public FraDiscountingTypeScheme getDiscountingType() {
        return discountingType;
    }

    @Override
    public String getQuotationStyle() {
        return quotationStyle;
    }

    @Override
    public Integer getRoundingPrecision() {
        return roundingPrecision;
    }

    @Override
    public BigDecimal getCalcPeriodNumOfDays() {
        return calcPeriodNumOfDays;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }
}
