package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.BusinessDate;
import com.rbs.odc.access.domain.Currency;
import com.rbs.odc.access.domain.CurrencyId;
import com.rbs.odc.access.domain.IncomeStream;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestIncomeStream implements IncomeStream {
    private String outstandingInstrumentId;
    private String facilityInstrumentId;
    private String lxrefInstrumentId;
    private String dealInstrumentId;
    private String outstandingInstrumentName;
    private String facilityInstrumentName;
    private String lxrefInstrumentName;
    private String dealInstrumentName;
    Currency instrumentCurrency;
    private BusinessDate maturityDate;
    private BusinessDate creditAgreementDate;
    private String tranche;
    private CurrencyId instrumentCurrencyId;

    TestIncomeStream() {

        this.maturityDate = new TestBusinessDate();
        creditAgreementDate = new TestBusinessDate();
        tranche = getRandomString();
        outstandingInstrumentId = getRandomString();

        facilityInstrumentId = getRandomString();

        lxrefInstrumentId = getRandomString();
        dealInstrumentId = getRandomString();
        outstandingInstrumentName = getRandomString();
        facilityInstrumentName = getRandomString();
        lxrefInstrumentName = getRandomString();
        dealInstrumentName = getRandomString();

        instrumentCurrencyId = new TestCurrencyId();
    }

    @Override
    public String getOutstandingInstrumentId() {
        return outstandingInstrumentId;
    }

    @Override
    public String getFacilityInstrumentId() {
        return facilityInstrumentId;
    }

    @Override
    public String getLxrefInstrumentId() {
        return lxrefInstrumentId;
    }

    @Override
    public String getDealInstrumentId() {
        return dealInstrumentId;
    }

    @Override
    public String getOutstandingInstrumentName() {
        return outstandingInstrumentName;
    }

    @Override
    public String getFacilityInstrumentName() {
        return facilityInstrumentName;
    }

    @Override
    public String getLxrefInstrumentName() {
        return lxrefInstrumentName;
    }

    @Override
    public String getDealInstrumentName() {
        return dealInstrumentName;
    }

    @Override
    public Currency getInstrumentCurrency() {
        return null;
    }

    @Override
    public BusinessDate getMaturityDate() {
        return maturityDate;
    }

    @Override
    public BusinessDate getCreditAgreementDate() {
        return creditAgreementDate;
    }

    @Override
    public String getTranche() {
        return tranche;
    }

    @Override
    public CurrencyId getInstrumentCurrencyId() {
        return instrumentCurrencyId;
    }
}
