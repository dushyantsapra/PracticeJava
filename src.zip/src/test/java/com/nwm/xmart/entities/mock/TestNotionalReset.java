package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Amount;
import com.rbs.odc.access.domain.NotionalReset;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestNotionalReset implements NotionalReset {
    private String legIdentifier;
    private Amount resetAmount;

    public TestNotionalReset() {
        legIdentifier = getRandomString();
        resetAmount = new TestAmount();
    }

    @Override
    public String getLegIdentifier() {
        return legIdentifier;
    }

    @Override
    public Amount getResetAmount() {
        return resetAmount;
    }
}
