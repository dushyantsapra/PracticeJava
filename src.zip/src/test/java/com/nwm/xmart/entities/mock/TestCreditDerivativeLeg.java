package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestCreditDerivativeLeg implements CreditDerivativeLeg {
    private Amount defaultRequirement;
    private Amount failureToPay;
    private Amount protectionAmount;
    private BigDecimal recoveryRate;
    private Boolean allGuarantees, bankruptcyApplicable, failureToPayApplicable, fixedSettlement,
            governmentalInterventionApp, interestShortFallComp, obligationAccelerationApplicable,
            obligationDefaultApplicable, obligationListed, obligationNotContingent, obligationNotDomesticIssue,
            obligationNotDomesticLaw, obligationNotSovereignLend, obligationNotSubordinated, otherCreditEventApplicable,
            physicalSettlementEscrow, repudiationMoratoriumApplicable, restructuringApplicable,
            restructuringMultipleHolder, securedListApp, stepUpProvisionsApp, wacCapInterestProvisionApp;
    private Collection<CreditDerivativeAdditionalTerm> creditDerivativeAdditionalTerms = new ArrayList<>();
    private Collection<CreditEventPublicSource> creditEventPublicSources = new ArrayList<>();
    private Collection<DeliverableObligations> deliverableObligations = new ArrayList<>();
    private Collection<RelatedCurrency> relatedCurrencies = new ArrayList<>();
    private CreditEventNotice creditEventNotice;
    private Currency obligationCurrency;
    private CurrencyId obligationCurrencyId;
    private DayType gracePeriodDayType;
    private Integer gracePeriodMultiplier, mthToDefault, nthToDefault, physSettlementBusDays, physSettlementCalDays,
            physSettlementMaxBusDays;
    private ObligationCategoryScheme deliverableAssetCategory, protectionTermsCategory;
    private ObligationLiabilityScheme obligationLiabilityScheme;
    private Party referenceEntity;
    private PartyId referenceEntityId;
    private Period gracePeriodScheme;
    private RestructuringType restructuringType;
    private String interestShortFallCapApp, obligationCharacteristic, obligationExcluded, obligationOtherCategory,
            settlementCurrencyDesc;

    public TestCreditDerivativeLeg() {
        defaultRequirement = new TestAmount();
        failureToPay = new TestAmount();
        protectionAmount = new TestAmount();
        recoveryRate = new BigDecimal(getRndDouble());
        allGuarantees = getRndInt() % 2 == 1;
        bankruptcyApplicable = getRndInt() % 2 == 1;
        failureToPayApplicable = getRndInt() % 2 == 1;
        fixedSettlement = getRndInt() % 2 == 1;
        governmentalInterventionApp = getRndInt() % 2 == 1;
        interestShortFallComp = getRndInt() % 2 == 1;
        obligationAccelerationApplicable = getRndInt() % 2 == 1;
        obligationDefaultApplicable = getRndInt() % 2 == 1;
        obligationListed = getRndInt() % 2 == 1;
        obligationNotContingent = getRndInt() % 2 == 1;
        obligationNotDomesticIssue = getRndInt() % 2 == 1;
        obligationNotDomesticLaw = getRndInt() % 2 == 1;
        obligationNotSovereignLend = getRndInt() % 2 == 1;
        obligationNotSubordinated = getRndInt() % 2 == 1;
        otherCreditEventApplicable = getRndInt() % 2 == 1;
        physicalSettlementEscrow = getRndInt() % 2 == 1;
        repudiationMoratoriumApplicable = getRndInt() % 2 == 1;
        restructuringApplicable = getRndInt() % 2 == 1;
        restructuringMultipleHolder = getRndInt() % 2 == 1;
        securedListApp = getRndInt() % 2 == 1;
        stepUpProvisionsApp = getRndInt() % 2 == 1;
        wacCapInterestProvisionApp = getRndInt() % 2 == 1;

        creditEventNotice = new TestCreditEventNotice();
        obligationCurrency = new TestCurrency();
        obligationCurrencyId = new TestCurrencyId();

        try {
            gracePeriodDayType = DayType.valueOf(getRndInt() % DayType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            gracePeriodDayType = DayType.NULL;
        }

        try {
            deliverableAssetCategory = ObligationCategoryScheme
                    .valueOf(getRndInt() % ObligationCategoryScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            deliverableAssetCategory = ObligationCategoryScheme.NULL;
        }
        try {
            protectionTermsCategory = ObligationCategoryScheme
                    .valueOf(getRndInt() % ObligationCategoryScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            protectionTermsCategory = ObligationCategoryScheme.NULL;
        }
        try {
            obligationLiabilityScheme = ObligationLiabilityScheme
                    .valueOf(getRndInt() % ObligationLiabilityScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            obligationLiabilityScheme = ObligationLiabilityScheme.NULL;
        }

        gracePeriodMultiplier = getRndInt();
        mthToDefault = getRndInt();
        nthToDefault = getRndInt();
        physSettlementBusDays = getRndInt();
        physSettlementCalDays = getRndInt();
        physSettlementMaxBusDays = getRndInt();
        interestShortFallCapApp = getRandomString();
        obligationCharacteristic = getRandomString();
        obligationExcluded = getRandomString();
        obligationOtherCategory = getRandomString();
        settlementCurrencyDesc = getRandomString();

        referenceEntityId = new TestPartyId();
        creditDerivativeAdditionalTerms.add(new TestCreditDerivativeAdditionalTerm());
        creditDerivativeAdditionalTerms.add(new TestCreditDerivativeAdditionalTerm());
        creditEventPublicSources.add(new TestCreditEventPublicSource());
        creditEventPublicSources.add(new TestCreditEventPublicSource());
        deliverableObligations.add(new TestDeliverableObligations());
        deliverableObligations.add(new TestDeliverableObligations());

        relatedCurrencies.add(new TestRelatedCurrency());
        relatedCurrencies.add(new TestRelatedCurrency());

        try {
            gracePeriodScheme = Period.valueOf(getRndInt() % Period.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            gracePeriodScheme = Period.NULL;
        }

        try {
            restructuringType = RestructuringType.valueOf(getRndInt() % RestructuringType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            restructuringType = RestructuringType.NULL;
        }
    }

    @Override
    public Boolean isAllGuarantees() {
        return allGuarantees;
    }

    @Override
    public Integer getGracePeriodMultiplier() {
        return gracePeriodMultiplier;
    }

    @Override
    public Period getGracePeriodScheme() {
        return gracePeriodScheme;
    }

    @Override
    public DayType getGracePeriodDayType() {
        return gracePeriodDayType;
    }

    @Override
    public RestructuringType getRestructuringType() {
        return restructuringType;
    }

    @Override
    public String getSettlementCurrencyDesc() {
        return settlementCurrencyDesc;
    }

    @Override
    public ObligationCategoryScheme getDeliverableAssetCategory() {
        return deliverableAssetCategory;
    }

    @Override
    public PartyId getReferenceEntityId() {
        return referenceEntityId;
    }

    @Override
    public Party getReferenceEntity() {
        //Not used
        return null;
    }

    @Override
    public ObligationCategoryScheme getProtectionTermsCategory() {
        return protectionTermsCategory;
    }

    @Override
    public boolean isBankruptcyApplicable() {
        return bankruptcyApplicable;
    }

    @Override
    public boolean isFailureToPayApplicable() {
        return failureToPayApplicable;
    }

    @Override
    public boolean isObligationAccelerationApplicable() {
        return obligationAccelerationApplicable;
    }

    @Override
    public boolean isObligationDefaultApplicable() {
        return obligationDefaultApplicable;
    }

    @Override
    public boolean isRepudiationMoratoriumApplicable() {
        return repudiationMoratoriumApplicable;
    }

    @Override
    public boolean isRestructuringApplicable() {
        return restructuringApplicable;
    }

    @Override
    public boolean isOtherCreditEventApplicable() {
        return otherCreditEventApplicable;
    }

    @Override
    public Amount getDefaultRequirement() {
        return defaultRequirement;
    }

    @Override
    public String getObligationExcluded() {
        return obligationExcluded;
    }

    @Override
    public String getObligationOtherCategory() {
        return obligationOtherCategory;
    }

    @Override
    public CurrencyId getObligationCurrencyId() {
        return obligationCurrencyId;
    }

    @Override
    public Currency getObligationCurrency() {
        return obligationCurrency;
    }

    @Override
    public String getObligationCharacteristic() {
        return obligationCharacteristic;
    }

    @Override
    public Boolean getRestructuringMultipleHolder() {
        return restructuringMultipleHolder;
    }

    @Override
    public ObligationLiabilityScheme getObligationLiabilityScheme() {
        return obligationLiabilityScheme;
    }

    @Override
    public Boolean getObligationNotSubordinated() {
        return obligationNotSubordinated;
    }

    @Override
    public Boolean getObligationNotSovereignLend() {
        return obligationNotSovereignLend;
    }

    @Override
    public Boolean getObligationNotDomesticLaw() {
        return obligationNotDomesticLaw;
    }

    @Override
    public Boolean getObligationNotDomesticIssue() {
        return obligationNotDomesticIssue;
    }

    @Override
    public Boolean getObligationListed() {
        return obligationListed;
    }

    @Override
    public Boolean getObligationNotContingent() {
        return obligationNotContingent;
    }

    @Override
    public Integer getPhysSettlementBusDays() {
        return physSettlementBusDays;
    }

    @Override
    public Integer getPhysSettlementMaxBusDays() {
        return physSettlementMaxBusDays;
    }

    @Override
    public Boolean getPhysicalSettlementEscrow() {
        return physicalSettlementEscrow;
    }

    @Override
    public Collection<CreditEventPublicSource> getCreditEventPublicSources() {
        return creditEventPublicSources;
    }

    @Override
    public Collection<CreditDerivativeAdditionalTerm> getCreditDerivativeAdditionalTerms() {
        return creditDerivativeAdditionalTerms;
    }

    @Override
    public Collection<RelatedCurrency> getRelatedCurrencies() {
        return relatedCurrencies;
    }

    @Override
    public Collection<DeliverableObligations> getDeliverableObligations() {
        return deliverableObligations;
    }

    @Override
    public Amount getFailureToPay() {
        return failureToPay;
    }

    @Override
    public CreditEventNotice getCreditEventNotice() {
        return creditEventNotice;
    }

    @Override
    public BigDecimal getRecoveryRate() {
        return recoveryRate;
    }

    @Override
    public Integer getPhysSettlementCalDays() {
        return physSettlementCalDays;
    }

    @Override
    public Boolean isGovernmentalInterventionApp() {
        return governmentalInterventionApp;
    }

    public Boolean getGovernmentalInterventionApp() {
        return governmentalInterventionApp;
    }

    @Override
    public Amount getProtectionAmount() {
        return protectionAmount;
    }

    @Override
    public Boolean getFixedSettlement() {
        return fixedSettlement;
    }

    @Override
    public String getInterestShortFallCapApp() {
        return interestShortFallCapApp;
    }

    @Override
    public Boolean getSecuredListApp() {
        return securedListApp;
    }

    @Override
    public Boolean getInterestShortFallComp() {
        return interestShortFallComp;
    }

    @Override
    public Boolean getStepUpProvisionsApp() {
        return stepUpProvisionsApp;
    }

    @Override
    public Boolean getWacCapInterestProvisionApp() {
        return wacCapInterestProvisionApp;
    }

    @Override
    public Integer getNthToDefault() {
        return nthToDefault;
    }

    @Override
    public Integer getMthToDefault() {
        return mthToDefault;
    }
}
