package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.CollateralLeg;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndDouble;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestCollateralLeg implements CollateralLeg {

    private BigDecimal couponReinvestmentRate = new BigDecimal(getRndDouble());
    private boolean deliveryByValueIndicator = getRndInt() % 2 == 1;
    private boolean deliveryByValue = getRndInt() % 2 == 1;

    @Override
    public boolean getDeliveryByValueIndicator() {
        return deliveryByValueIndicator;
    }

    @Override
    public boolean isDeliveryByValue() {
        return deliveryByValue;
    }

    @Override
    public BigDecimal getCouponReinvestmentRate() {
        return couponReinvestmentRate;
    }
}
