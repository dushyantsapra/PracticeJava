package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestTransactionLink implements TransactionLink {

    private SystemInstanceId linkSourceSystemId;
    private String linkTransactionId;
    private String linkTransactionVersion;
    private String linkTransactionLegId;
    private TransactionId transactionId;
    private LinkageReasonScheme linkageReasonScheme;
    private TradeIdClassificationScheme tradeIdClassification;

    public TestTransactionLink() {
        linkTransactionId = getRandomString();
        linkTransactionVersion = getRandomString();
        linkTransactionLegId = getRandomString();
        transactionId = new TestTransactionId();

        try {
            linkSourceSystemId = SystemInstanceId.valueOf(getRndInt() % DayType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            linkSourceSystemId = SystemInstanceId.NULL;
        }
        try {
            linkageReasonScheme = LinkageReasonScheme.valueOf(getRndInt() % DayType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            linkageReasonScheme = LinkageReasonScheme.NULL;
        }

        try {
            tradeIdClassification = TradeIdClassificationScheme.valueOf(getRndInt() % DayType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            tradeIdClassification = TradeIdClassificationScheme.NULL;
        }
    }

    @Override
    public SystemInstanceId getLinkSourceSystemId() {
        return linkSourceSystemId;
    }

    @Override
    public String getLinkTransactionId() {
        return linkTransactionId;
    }

    @Override
    public String getLinkTransactionVersion() {
        return linkTransactionVersion;
    }

    @Override
    public String getLinkTransactionLegId() {
        return linkTransactionLegId;
    }

    @Override
    public TransactionId asTransactionId() {
        return transactionId;
    }

    @Override
    public LinkageReasonScheme getLinkageReasonScheme() {
        return linkageReasonScheme;
    }

    @Override
    public TradeIdClassificationScheme getTradeIdClassification() {
        return tradeIdClassification;
    }
}
