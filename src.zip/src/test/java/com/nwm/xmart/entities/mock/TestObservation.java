package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Observation;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestObservation implements Observation {
    private BigDecimal observedValue;
    private String businessCentre;
    private String legIdentifier;

    public TestObservation() {
        observedValue = new BigDecimal(getRndInt());
        businessCentre = getRandomString();
        legIdentifier = getRandomString();
    }

    @Override
    public BigDecimal getObservedValue() {
        return observedValue;
    }

    @Override
    public String getBusinessCentre() {
        return businessCentre;
    }

    @Override
    public String getLegIdentifier() {
        return legIdentifier;
    }
}
