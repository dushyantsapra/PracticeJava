package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.EmployeeIdEntry;
import com.rbs.odc.access.domain.PersonIdScheme;
import com.rbs.odc.access.domain.SystemInstanceId;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestEmployeeIdEntry implements EmployeeIdEntry {
    private SystemInstanceId employeeSourceSystemId;
    private String employeeIdentifier;
    private PersonIdScheme personIdScheme;

    public TestEmployeeIdEntry() {
        try {
            employeeSourceSystemId = SystemInstanceId.valueOf(getRndInt() % SystemInstanceId.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            employeeSourceSystemId = SystemInstanceId.NULL;
        }

        employeeIdentifier = getRandomString();
        try {
            personIdScheme = PersonIdScheme.valueOf(getRndInt() % PersonIdScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            personIdScheme = PersonIdScheme.NULL;
        }
    }

    @Override
    public SystemInstanceId getEmployeeSourceSystemId() {
        return employeeSourceSystemId;
    }

    @Override
    public String getEmployeeIdentifier() {
        return employeeIdentifier;
    }

    @Override
    public PersonIdScheme getPersonIdScheme() {
        return personIdScheme;
    }
}
