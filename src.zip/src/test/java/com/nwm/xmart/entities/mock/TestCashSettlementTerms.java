package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;
import com.rbs.odc.core.domain.CashSettlementTermsImpl;

import java.util.Date;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestCashSettlementTerms extends CashSettlementTermsImpl {

    private QuotationRateTypeScheme quotationRateType;
    private CashSettlementValuationMethodScheme cashValuationMethod;
    private boolean cashIncludeAccruedInterest, partialSettlementAllowed, partialAssignableLoans,
            partialLoanParticipations;
    private Amount quotationAmount;
    private Integer businessDays;
    private Date paymentDate;
    private BusinessCentreTime valuationTime;
    private String currency, rateSource, rateSourcePage;
    private Date valuationDateTime = getRandomDate();

    TestCashSettlementTerms() {
        try {
            quotationRateType = QuotationRateTypeScheme
                    .valueOf(getRndInt() % QuotationRateTypeScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            quotationRateType = QuotationRateTypeScheme.NULL;
        }

        try {
            cashValuationMethod = CashSettlementValuationMethodScheme
                    .valueOf(getRndInt() % CashSettlementValuationMethodScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            cashValuationMethod = CashSettlementValuationMethodScheme.NULL;
        }

        cashIncludeAccruedInterest = getRndInt() % 2 == 1;
        partialSettlementAllowed = getRndInt() % 2 == 1;
        partialAssignableLoans = getRndInt() % 2 == 1;
        partialLoanParticipations = getRndInt() % 2 == 1;
        quotationAmount = new TestAmount();
        businessDays = getRndInt();
        currency = getRandomString();
        paymentDate = getRandomDate();
        valuationTime = new TestBusinessCentreTime();
        rateSource = getRandomString();
        rateSourcePage = getRandomString();
    }

    @Override
    public Date getValuationDateTime() {
        return valuationDateTime;
    }

    @Override
    public QuotationRateTypeScheme getQuotationRateType() {
        return quotationRateType;
    }

    @Override
    public CashSettlementValuationMethodScheme getCashValuationMethod() {
        return cashValuationMethod;
    }

    @Override
    public boolean getCashIncludeAccruedInterest() {
        return cashIncludeAccruedInterest;
    }

    @Override
    public boolean getPartialSettlementAllowed() {
        return partialSettlementAllowed;
    }

    @Override
    public boolean getPartialAssignableLoans() {
        return partialAssignableLoans;
    }

    @Override
    public boolean getPartialLoanParticipations() {
        return partialLoanParticipations;
    }

    @Override
    public Amount getQuotationAmount() {
        return quotationAmount;
    }

    @Override
    public Integer getBusinessDays() {
        return businessDays;
    }

    @Override
    public String getCurrency() {
        return currency;
    }

    @Override
    public Date getPaymentDate() {
        return paymentDate;
    }

    @Override
    public BusinessCentreTime getValuationTime() {
        return valuationTime;
    }

    @Override
    public String getRateSource() {
        return rateSource;
    }

    @Override
    public String getRateSourcePage() {
        return rateSourcePage;
    }
}
