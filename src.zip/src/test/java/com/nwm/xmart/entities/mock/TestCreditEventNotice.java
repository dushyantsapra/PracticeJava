package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.CreditEventNotice;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestCreditEventNotice implements CreditEventNotice {

    private boolean useIsdaStdPublicSources;
    private Integer publicationSpecifiedNumber;
    private boolean physicalSettlementNotice;
    private String otherConditionToPayment;

    TestCreditEventNotice() {
        useIsdaStdPublicSources = getRndInt() % 2 == 1;
        publicationSpecifiedNumber = getRndInt();
        physicalSettlementNotice = getRndInt() % 2 == 1;
        otherConditionToPayment = getRandomString();
    }

    public boolean getUseIsdaStdPublicSources() {
        return useIsdaStdPublicSources;
    }

    @Override
    public Integer getPublicationSpecifiedNumber() {
        return publicationSpecifiedNumber;
    }

    public boolean getPhysicalSettlementNotice() {
        return physicalSettlementNotice;
    }

    @Override
    public String getOtherConditionToPayment() {
        return otherConditionToPayment;
    }
}
