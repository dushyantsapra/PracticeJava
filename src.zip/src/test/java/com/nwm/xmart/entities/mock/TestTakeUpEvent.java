package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Amount;
import com.rbs.odc.access.domain.TakeUpEvent;

public class TestTakeUpEvent implements TakeUpEvent {
    private Amount payAmount;
    private Amount receiveAmount;

    public TestTakeUpEvent() {
        payAmount = new TestAmount();
        receiveAmount = new TestAmount();
    }

    @Override
    public Amount getPayAmount() {
        return payAmount;
    }

    @Override
    public Amount getReceiveAmount() {
        return receiveAmount;
    }
}
