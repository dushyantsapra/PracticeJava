package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Curve;
import com.rbs.odc.access.domain.SystemInstanceId;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestCurve implements Curve {
    private String curveId;
    private SystemInstanceId curveSystemId;

    public TestCurve() {
        curveId = getRandomString();

        try {
            curveSystemId = SystemInstanceId.valueOf(getRndInt() % SystemInstanceId.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("SystemInstanceId creation failed Using default value" + e.getMessage());
            curveSystemId = SystemInstanceId.NULL;
        }
    }

    @Override
    public String getCurveId() {
        return curveId;
    }

    @Override
    public SystemInstanceId getCurveSystemId() {
        return curveSystemId;
    }
}
