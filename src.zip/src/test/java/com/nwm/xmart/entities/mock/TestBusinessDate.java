package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.BusinessDate;

import java.util.Date;
import java.util.TimeZone;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomDate;

public class TestBusinessDate implements BusinessDate {

    Date date;

    public TestBusinessDate() {
        this.date = getRandomDate();
    }

    @Override
    public Date asMidnightUKDate() {
        return date;
    }

    @Override
    public String format(String s) {
        return null;
    }

    @Override
    public boolean after(BusinessDate businessDate) {
        return false;
    }

    @Override
    public boolean before(BusinessDate businessDate) {
        return false;
    }

    @Override
    public BusinessDate addDays(int i) {
        return null;
    }

    @Override
    public Date asMidnightInTimezone(TimeZone timeZone) {
        return null;
    }

    @Override
    public BusinessDate addDaysSkipWeekends(int i) {
        return null;
    }

    @Override
    public int compareTo(BusinessDate o) {
        return 0;
    }
}
