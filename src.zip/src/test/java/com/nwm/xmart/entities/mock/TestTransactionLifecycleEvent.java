package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestTransactionLifecycleEvent implements TransactionLifecycleEvent {
    private TransactionState status;
    private Date effectiveDateTime;
    private BusinessDate effectiveDate;
    private String publisherSourceSystemId;
    private BigDecimal triggerRate;
    private BigDecimal adjustedTriggerRate;
    private BusinessDate cancellationDate;
    private TakeUpEvent takeUpEvent;
    private BigDecimal fixingRate;
    private Collection<PrincipalMovementEvent> principalMovementEvents;
    private Observation observation;
    private RateReset rateReset;
    private FXFixingEvent fxFixingEvent;
    private FixedIncomePositionLiquidation fixedIncomePositionLiquidation;
    private QuantityMovement quantityMovement;
    private TradeNovation tradeNovation;
    private UnitPrice eventPrice;
    private BusinessDate tradeEventDate;
    private TransactionLifecycleEventType eventType;
    private String sourceSystemEventId;
    private Date eventDateTime;
    private Collection<NotionalReset> notionalResets;
    private String legId;
    private String underlierId;

    public TestTransactionLifecycleEvent() {
        try {
            status = TransactionState.valueOf(getRndInt() % TransactionState.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("TransactionState creation failed Using default value" + e.getMessage());
            status = TransactionState.NULL;
        }

        effectiveDateTime = getRandomDate();
        effectiveDate = new TestBusinessDate();
        publisherSourceSystemId = getRandomString();
        triggerRate = new BigDecimal(getRndInt());
        adjustedTriggerRate = new BigDecimal(getRndInt());
        cancellationDate = new TestBusinessDate();
        takeUpEvent = new TestTakeUpEvent();
        fixingRate = new BigDecimal(getRndInt());
        principalMovementEvents = Arrays.asList(new TestPrincipalMovementEvent(), new TestPrincipalMovementEvent());
        observation = new TestObservation();
        rateReset = new TestRateReset();
        fxFixingEvent = new TestFXFixingEvent();
        fixedIncomePositionLiquidation = new TestFixedIncomePositionLiquidation();
        quantityMovement = new TestQuantityMovement();
        tradeNovation = new TestTradeNovation();
        eventPrice = new TestUnitPrice();
        tradeEventDate = new TestBusinessDate();

        try {
            eventType = TransactionLifecycleEventType
                    .valueOf(getRndInt() % TransactionLifecycleEventType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("TransactionLifecycleEventType creation failed Using default value" + e.getMessage());
            eventType = TransactionLifecycleEventType.NULL;
        }
        sourceSystemEventId = getRandomString();
        eventDateTime = getRandomDate();
        notionalResets = Arrays.asList(new TestNotionalReset(), new TestNotionalReset());
        legId = getRandomString();
        underlierId = getRandomString();
    }

    @Override
    public TransactionState getStatus() {
        return status;
    }

    @Override
    public Date getEffectiveDateTime() {
        return effectiveDateTime;
    }

    @Override
    public BusinessDate getEffectiveDate() {
        return effectiveDate;
    }

    @Override
    public String getPublisherSourceSystemId() {
        return publisherSourceSystemId;
    }

    @Override
    public BigDecimal getTriggerRate() {
        return triggerRate;
    }

    @Override
    public BigDecimal getAdjustedTriggerRate() {
        return adjustedTriggerRate;
    }

    @Override
    public BusinessDate getCancellationDate() {
        return cancellationDate;
    }

    @Override
    public TakeUpEvent getTakeUpEvent() {
        return takeUpEvent;
    }

    @Override
    public BigDecimal getFixingRate() {
        return fixingRate;
    }

    @Override
    public Collection<PrincipalMovementEvent> getPrincipalMovementEvents() {
        return principalMovementEvents;
    }

    @Override
    public Observation getObservation() {
        return observation;
    }

    @Override
    public RateReset getRateReset() {
        return rateReset;
    }

    @Override
    public FXFixingEvent getFxFixingEvent() {
        return fxFixingEvent;
    }

    @Override
    public FixedIncomePositionLiquidation getFixedIncomePositionLiquidation() {
        return fixedIncomePositionLiquidation;
    }

    @Override
    public QuantityMovement getQuantityMovement() {
        return quantityMovement;
    }

    @Override
    public TradeNovation getTradeNovation() {
        return tradeNovation;
    }

    @Override
    public UnitPrice getEventPrice() {
        return eventPrice;
    }

    @Override
    public BusinessDate getTradeEventDate() {
        return tradeEventDate;
    }

    @Override
    public TransactionLifecycleEventType getEventType() {
        return eventType;
    }

    @Override
    public String getSourceSystemEventId() {
        return sourceSystemEventId;
    }

    @Override
    public Date getEventDateTime() {
        return eventDateTime;
    }

    @Override
    public Collection<NotionalReset> getNotionalResets() {
        return notionalResets;
    }

    @Override
    public String getLegId() {
        return legId;
    }

    @Override
    public String getUnderlierId() {
        return underlierId;
    }
}
