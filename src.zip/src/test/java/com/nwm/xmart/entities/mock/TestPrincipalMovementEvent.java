package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestPrincipalMovementEvent implements PrincipalMovementEvent {
    private String legIdentifier;
    private BigDecimal stepAmount;
    private PrincipalMovementType stepDirection;
    private PrincipalType principalType;
    private Amount resultantAmount;
    private Boolean interestRecapitalized;

    public TestPrincipalMovementEvent() {
        legIdentifier = getRandomString();
        stepAmount = new BigDecimal(getRndInt());
        try {
            stepDirection = PrincipalMovementType.valueOf(getRndInt() % PrincipalMovementType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("PrincipalMovementType creation failed Using default value" + e.getMessage());
            stepDirection = PrincipalMovementType.NULL;
        }

        try {
            principalType = PrincipalType.valueOf(getRndInt() % PrincipalType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("PrincipalType creation failed Using default value" + e.getMessage());
            principalType = PrincipalType.NULL;
        }

        resultantAmount = new TestAmount();
        interestRecapitalized = getRndInt() % 2 == 0;
    }

    @Override
    public String getLegIdentifier() {
        return legIdentifier;
    }

    @Override
    public BigDecimal getStepAmount() {
        return stepAmount;
    }

    @Override
    public PrincipalMovementType getStepDirection() {
        return stepDirection;
    }

    @Override
    public PrincipalType getPrincipalType() {
        return principalType;
    }

    @Override
    public Amount getResultantAmount() {
        return resultantAmount;
    }

    @Override
    public Boolean getIsInterestRecapitalized() {
        return interestRecapitalized;
    }
}
