package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestReportableUnderlyingInstrument implements ReportableUnderlyingInstrument {
    private String instrumentId;
    private SecurityInstrumentIdentifierClassificationScheme instrumentScheme;
    private String instrumentName;
    private String instrumentClassification;
    private BigDecimal priceMultiplier;
    private OptionType optionType;
    private OptionExerciseStyle optionExerciseStyle;
    private BusinessDate maturityDate;
    private BusinessDate expiryDate;
    private SettlementTypeScheme settlementType;

    public TestReportableUnderlyingInstrument() {
        instrumentId = getRandomString();

        try {
            instrumentScheme = SecurityInstrumentIdentifierClassificationScheme
                    .valueOf(getRndInt() % SecurityInstrumentIdentifierClassificationScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("SecurityInstrumentIdentifierClassificationScheme creation failed Using default value" + e
                    .getMessage());
            instrumentScheme = SecurityInstrumentIdentifierClassificationScheme.NULL;
        }

        instrumentName = getRandomString();
        instrumentClassification = getRandomString();
        priceMultiplier = new BigDecimal(getRndInt());

        try {
            optionType = OptionType.valueOf(getRndInt() % OptionType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("OptionType creation failed Using default value" + e.getMessage());
            optionType = OptionType.NULL;
        }

        try {
            optionExerciseStyle = OptionExerciseStyle.valueOf(getRndInt() % OptionExerciseStyle.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("OptionExerciseStyle creation failed Using default value" + e.getMessage());
            optionExerciseStyle = OptionExerciseStyle.NULL;
        }

        maturityDate = new TestBusinessDate();
        expiryDate = new TestBusinessDate();

        try {
            settlementType = SettlementTypeScheme.valueOf(getRndInt() % SettlementTypeScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("SettlementTypeScheme creation failed Using default value" + e.getMessage());
            settlementType = SettlementTypeScheme.NULL;
        }
    }

    @Override
    public String getInstrumentId() {
        return instrumentId;
    }

    @Override
    public SecurityInstrumentIdentifierClassificationScheme getInstrumentScheme() {
        return instrumentScheme;
    }

    @Override
    public String getInstrumentName() {
        return instrumentName;
    }

    @Override
    public String getInstrumentClassification() {
        return instrumentClassification;
    }

    @Override
    public BigDecimal getPriceMultiplier() {
        return priceMultiplier;
    }

    @Override
    public OptionType getOptionType() {
        return optionType;
    }

    @Override
    public OptionExerciseStyle getOptionExerciseStyle() {
        return optionExerciseStyle;
    }

    @Override
    public BusinessDate getMaturityDate() {
        return maturityDate;
    }

    @Override
    public BusinessDate getExpiryDate() {
        return expiryDate;
    }

    @Override
    public SettlementTypeScheme getSettlementType() {
        return settlementType;
    }
}
