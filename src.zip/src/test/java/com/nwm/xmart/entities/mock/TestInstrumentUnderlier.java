package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestInstrumentUnderlier implements InstrumentUnderlier {
    private InstrumentId instrumentId;
    private Instrument instrument;
    private BasketWeight basketWeight;
    private ReferenceObligation referenceObligation;
    private Boolean isWithholdingTaxApplicable;

    public TestInstrumentUnderlier() {
        this.instrumentId = new TestInstrumentId();
        this.basketWeight = new TestBasketWeight();
        this.referenceObligation = new TestReferenceObligation();
        this.isWithholdingTaxApplicable = getRndInt() % 2 == 0;
    }

    @Override
    public InstrumentId getInstrumentId() {
        return instrumentId;
    }

    @Override
    public Instrument getInstrument() {
        return instrument;
    }

    @Override
    public BasketWeight getBasketWeight() {
        return basketWeight;
    }

    @Override
    public ReferenceObligation getReferenceObligation() {
        return referenceObligation;
    }

    @Override
    public Boolean isWithholdingTaxApplicable() {
        return isWithholdingTaxApplicable;
    }
}
