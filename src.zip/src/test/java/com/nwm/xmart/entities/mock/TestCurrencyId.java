package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.CurrencyId;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestCurrencyId implements CurrencyId {

    private String currencyCode = getRandomString();

    @Override
    public String getCurrencyCode() {
        return currencyCode;
    }

    @Override
    public int compareTo(CurrencyId o) {
        return 0;
    }
}
