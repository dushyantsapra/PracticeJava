package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.MarginType;
import com.rbs.odc.access.domain.PayOrReceiveScheme;
import com.rbs.odc.access.domain.TransactionRegulatoryMarginImpact;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestTransactionRegulatoryMarginImpact implements TransactionRegulatoryMarginImpact {
    private String regulatoryAuthority;
    private MarginType marginType;
    private PayOrReceiveScheme payOrReceiveType;

    public TestTransactionRegulatoryMarginImpact() {
        regulatoryAuthority = getRandomString();

        try {
            marginType = MarginType.valueOf(getRndInt() % MarginType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("MarginType creation failed Using default value" + e.getMessage());
            marginType = MarginType.NULL;
        }

        try {
            payOrReceiveType = PayOrReceiveScheme.valueOf(getRndInt() % PayOrReceiveScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("PayOrReceiveScheme creation failed Using default value" + e.getMessage());
            payOrReceiveType = PayOrReceiveScheme.NULL;
        }
    }

    @Override
    public String getRegulatoryAuthority() {
        return regulatoryAuthority;
    }

    @Override
    public MarginType getMarginType() {
        return marginType;
    }

    @Override
    public PayOrReceiveScheme getPayOrReceiveType() {
        return payOrReceiveType;
    }
}
