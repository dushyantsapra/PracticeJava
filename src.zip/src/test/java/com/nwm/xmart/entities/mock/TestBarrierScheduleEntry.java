package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.BarrierLevel;
import com.rbs.odc.access.domain.BarrierScheduleEntry;
import com.rbs.odc.access.domain.BarrierType;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestBarrierScheduleEntry implements BarrierScheduleEntry {
    private BarrierType barrierType;
    private BarrierLevel lower;
    private BarrierLevel upper;

    public TestBarrierScheduleEntry() {
        try {
            barrierType = BarrierType.valueOf(getRndInt() % BarrierType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            barrierType = BarrierType.NULL;
        }
        this.lower = new TestBarrierLevel();
        this.upper = new TestBarrierLevel();
    }

    @Override
    public BarrierType getBarrierType() {
        return barrierType;
    }

    @Override
    public BarrierLevel getLower() {
        return lower;
    }

    @Override
    public BarrierLevel getUpper() {
        return upper;
    }
}
