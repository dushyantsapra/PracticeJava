package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.logger;

public class TestRelatedCurrency implements RelatedCurrency {

    private Currency currency;
    private CurrencyId currencyId;
    private ObligationScheme obligationScheme;
    private Boolean notDomesticCurrency;

    public TestRelatedCurrency() {
        currency = new TestCurrency();
        currencyId = new TestCurrencyId();
        try {
            obligationScheme = ObligationScheme.valueOf(getRndInt() % ObligationScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            obligationScheme = ObligationScheme.NULL;
        }
        notDomesticCurrency = getRndInt() % 2 == 1;
    }

    @Override
    public Currency getCurrency() {
        return currency;
    }

    @Override
    public CurrencyId getCurrencyId() {
        return currencyId;
    }

    @Override
    public ObligationScheme getObligationScheme() {
        return obligationScheme;
    }

    @Override
    public Boolean getNotDomesticCurrency() {
        return notDomesticCurrency;
    }
}
