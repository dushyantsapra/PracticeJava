package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.util.ArrayList;
import java.util.Collection;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.logger;

public class TestTransactionMarginElection implements TransactionMarginElection {
    Collection<TransactionMarginJurisdiction> transactionMarginJurisdictions = new ArrayList<>();
    private MarginGroupType marginType;
    private MarginAgreementLinkage marginAgreementLinkage;
    private MarginAgreementLinkageId marginAgreementLinkageId;

    public TestTransactionMarginElection() {
        try {
            marginType = MarginGroupType.valueOf(getRndInt() % MarginGroupType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("MarginGroupType creation failed Using default value" + e.getMessage());
            marginType = MarginGroupType.NULL;
        }

        marginAgreementLinkageId = new TestMarginAgreementLinkageId();
        transactionMarginJurisdictions.add(new TestTransactionMarginJurisdiction());
        transactionMarginJurisdictions.add(new TestTransactionMarginJurisdiction());
    }

    @Override
    public MarginGroupType getMarginType() {
        return marginType;
    }

    @Override
    public MarginAgreementLinkage getMarginAgreementLinkage() {
        return null;
    }

    @Override
    public MarginAgreementLinkageId getMarginAgreementLinkageId() {
        return marginAgreementLinkageId;
    }

    @Override
    public Collection<? extends TransactionMarginJurisdiction> getTransactionMarginJurisdiction() {
        return transactionMarginJurisdictions;
    }
}
