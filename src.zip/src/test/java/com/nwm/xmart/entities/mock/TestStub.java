package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Stub;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndDouble;

public class TestStub implements Stub {
    String primaryRateReference = getRandomString();
    String secondaryRateReference = getRandomString();
    BigDecimal spread = new BigDecimal(getRndDouble());
    BigDecimal rate = new BigDecimal(getRndDouble());

    @Override
    public String getPrimaryRateReference() {
        return primaryRateReference;
    }

    @Override
    public String getSecondaryRateReference() {
        return secondaryRateReference;
    }

    @Override
    public BigDecimal getSpread() {
        return spread;
    }

    @Override
    public BigDecimal getRate() {
        return rate;
    }
}
