package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.MarginAgreementLinkageId;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestMarginAgreementLinkageId implements MarginAgreementLinkageId {
    private Long marginId;

    public TestMarginAgreementLinkageId() {
        this.marginId = new Long(getRndInt());
    }

    @Override
    public Long getMarginId() {
        return marginId;
    }

    @Override
    public int compareTo(MarginAgreementLinkageId o) {
        return 0;
    }
}
