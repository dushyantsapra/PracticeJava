package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.BusinessCentreTime;
import com.rbs.odc.access.domain.BusinessTime;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestBusinessCentreTime implements BusinessCentreTime {

    BusinessTime time = new TestBusinessTime();
    private String centre = getRandomString();

    @Override
    public BusinessTime getTime() {
        return time;
    }

    @Override
    public String getCentre() {
        return centre;
    }

    @Override
    public int compareTo(BusinessCentreTime o) {
        return 0;
    }
}
