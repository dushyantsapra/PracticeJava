package com.nwm.xmart.entities.crm;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.crm.entity.accountCoverage.AccountCoverage;
import com.nwm.xmart.streaming.source.crm.entity.accountCoverage.CoverageRegion;
import com.nwm.xmart.streaming.source.crm.entity.common.Account;
import com.nwm.xmart.streaming.source.crm.entity.common.Employee;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEventType;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.when;

public class CRMAccountCoverageTest {
    @Mock
    CRMSourceEvent crmSourceEvent;

    private MappingNode mappingHierarchy;

    private AccountCoverage accountCoverage;

    private XmartGenericSet xmartSet;

    private int topicId = getRndInt();

    private void setUpCrmAccountCoverage() {
        accountCoverage = new AccountCoverage();

        Account account = new Account();
        account.setExternalAccountNumber(getRandomString());
        accountCoverage.setAccount(account);

        accountCoverage.setCallOrderNumber(getRndInt());

        CoverageRegion coverageRegion = new CoverageRegion();
        coverageRegion.setName(getRandomString());
        accountCoverage.setCoverageRegion(coverageRegion);

        accountCoverage.setCreatedById(getRandomString());
        accountCoverage.setCreatedDate(getRandomString());
        accountCoverage.setDesk(getRandomString());
        accountCoverage.setDivision(getRandomString());

        Employee employee = new Employee();
        employee.setECDId(getRandomString());
        employee.setUser(getRandomString());
        accountCoverage.setEmployee(employee);

        accountCoverage.setEmployeeEmail(getRandomString());
        accountCoverage.setEndDate(getRandomString());
        accountCoverage.setId(getRandomString());
        accountCoverage.setInactive(getRndInt() % 2 == 0);
        accountCoverage.setInactiveMisMatch(getRndInt() % 2 == 0);
        accountCoverage.setIsBackup(getRndInt() % 2 == 0);
        accountCoverage.setIsMyCoverage(getRndInt() % 2 == 0);
        accountCoverage.setLastModifiedById(getRandomString());
        accountCoverage.setLastModifiedDate(getRandomString());
        accountCoverage.setName(getRandomString());
        accountCoverage.setRole(getRandomString());
        accountCoverage.setRank(getRandomString());
        accountCoverage.setStartDate(getRandomString());
        accountCoverage.setStatus(getRandomString());
        accountCoverage.setSystemModstamp(getRandomString());
        accountCoverage.setToBeProcessed(getRndInt() % 2 == 0);
        accountCoverage.setUniqueId(getRandomString());
    }

    /*
    Update
    @expectedMatchCount
    if more Attribute check condition is been added
    * */

    private void verifyCrmUserRoleMapping(List<XmartMappedEntity> xmartCrmUserRoleEntities) {
        XmartMappedEntity xmartMappedEntity = xmartCrmUserRoleEntities.get(0);
        final AtomicInteger count = new AtomicInteger();

        int expectedMatchCount = 18;

        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {
            if ("accountCoverageId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("name".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getCreatedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getCreatedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getLastModifiedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getLastModifiedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("systemModstamp".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getSystemModstamp(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("externalAccountNumber".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getAccount().getExternalAccountNumber(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            /*if ("coverageRegionName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getCoverageRegion().getName(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/

            if ("desk".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getDesk(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            /*if ("division".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getDivision(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/

            if ("ecdId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getEmployee().getECDId(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            /*if ("userId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getEmployee().getUser(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/

            if ("email".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getEmployeeEmail(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("endDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getEndDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("inactive".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getInactive(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("isBackup".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getIsBackup(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("isMyCoverage".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getIsMyCoverage(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            /*if ("rank".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getRank(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
            if ("role".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getRole(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("startDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getStartDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("status".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountCoverage.getStatus(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
        });

        if (count.get() != expectedMatchCount) {
            Assert.fail("Count doesn't match the Expected Count");
        }
    }

    @BeforeEach
    void setUp() throws XmartException {
        MockitoAnnotations.initMocks(this);
        mappingHierarchy = MappingNodeFactory.ReadResourceFile("/mapping_config/CRM-event.csv");
        setUpCrmAccountCoverage();
        when(crmSourceEvent.getCrmSourceEventType()).thenReturn(CRMSourceEventType.AccountCoverage);
        when(crmSourceEvent.getAccountCoverage()).thenReturn(accountCoverage);
    }

    @Test
    void testCRMAccountCoverage() throws XmartException {
        xmartSet = new XmartCRMSourceEventSet();
        xmartSet.addStreamEvent(crmSourceEvent, topicId, mappingHierarchy);

        List<XmartMappedEntity> xmartCrmUserRoleEntities = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmAccountCoverages");
        verifyCrmUserRoleMapping(xmartCrmUserRoleEntities);
    }
}
