package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndDouble;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestBarrierLevel implements BarrierLevel {
    private BarrierDirection barrierDirectionType;
    private BigDecimal barrierTriggerLevel;
    private BigDecimal adjustedTriggerLevel;
    private BarrierType knockConditionType;

    public TestBarrierLevel() {
        try {
            barrierDirectionType = BarrierDirection.valueOf(getRndInt() % BarrierDirection.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            barrierDirectionType = BarrierDirection.NULL;
        }
        this.barrierTriggerLevel = new BigDecimal(getRndDouble());
        this.adjustedTriggerLevel = new BigDecimal(getRndDouble());
        try {
            knockConditionType = BarrierType.valueOf(getRndInt() % BarrierType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            knockConditionType = BarrierType.NULL;
        }
    }

    @Override
    public BarrierDirection getBarrierDirectionType() {
        return barrierDirectionType;
    }

    @Override
    public BigDecimal getBarrierTriggerLevel() {
        return barrierTriggerLevel;
    }

    @Override
    public BigDecimal getAdjustedTriggerLevel() {
        return adjustedTriggerLevel;
    }

    @Override
    public BarrierType getKnockConditionType() {
        return knockConditionType;
    }
}
