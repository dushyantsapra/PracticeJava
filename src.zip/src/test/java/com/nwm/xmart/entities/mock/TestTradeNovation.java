package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Amount;
import com.rbs.odc.access.domain.BusinessDate;
import com.rbs.odc.access.domain.TradeNovation;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestTradeNovation implements TradeNovation {
    private Boolean fullFirstCoupon;
    private BusinessDate originalTradeDate;
    private BusinessDate originalEffectiveDate;
    private BusinessDate originalTerminationDate;
    private Amount originalPrincipal;
    private Amount assignmentNotional;

    public TestTradeNovation() {
        fullFirstCoupon = getRndInt() % 2 == 0;
        originalTradeDate = new TestBusinessDate();
        originalEffectiveDate = new TestBusinessDate();
        originalTerminationDate = new TestBusinessDate();
        originalPrincipal = new TestAmount();
        assignmentNotional = new TestAmount();
    }

    @Override
    public Boolean getFullFirstCoupon() {
        return fullFirstCoupon;
    }

    @Override
    public BusinessDate getOriginalTradeDate() {
        return originalTradeDate;
    }

    @Override
    public BusinessDate getOriginalEffectiveDate() {
        return originalEffectiveDate;
    }

    @Override
    public BusinessDate getOriginalTerminationDate() {
        return originalTerminationDate;
    }

    @Override
    public Amount getOriginalPrincipal() {
        return originalPrincipal;
    }

    @Override
    public Amount getAssignmentNotional() {
        return assignmentNotional;
    }
}
