package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestInstrumentLeg implements InstrumentLeg {

    private InitialPrice initialPrice = new TestInitialPrice();
    private InitialPriceMethod initialPriceMethod;
    private ShortSellingClassificationTypeScheme shortSellingClassification;
    private BigDecimal quantoExchangeRate = new BigDecimal(getRndDouble());
    private Amount settlementAmount = new TestAmount();

    public TestInstrumentLeg() {

        try {
            initialPriceMethod = InitialPriceMethod.valueOf(getRndInt() % InitialPriceMethod.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            initialPriceMethod = InitialPriceMethod.NULL;
        }
        try {
            shortSellingClassification = ShortSellingClassificationTypeScheme
                    .valueOf(getRndInt() % ShortSellingClassificationTypeScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            shortSellingClassification = ShortSellingClassificationTypeScheme.NULL;
        }
    }

    @Override
    public BigDecimal getQuantoExchangeRate() {
        return quantoExchangeRate;
    }

    @Override
    public InitialPrice getInitialPrice() {
        return initialPrice;
    }

    @Override
    public InitialPriceMethod getInitialPriceMethod() {
        return initialPriceMethod;
    }

    @Override
    public ShortSellingClassificationTypeScheme getShortSellingClassification() {
        return shortSellingClassification;
    }

    @Override
    public Amount getSettlementAmount() {
        return settlementAmount;
    }
}
