package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.TransactionRegimeImpactTypes;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestTransactionRegimeImpactTypes implements TransactionRegimeImpactTypes {
    private String regimeImpactType;
    private String reportableTransactionState;

    public TestTransactionRegimeImpactTypes() {
        regimeImpactType = getRandomString();
        reportableTransactionState = getRandomString();
    }

    @Override
    public String getRegimeImpactType() {
        return regimeImpactType;
    }

    @Override
    public String getReportableTransactionState() {
        return reportableTransactionState;
    }
}
