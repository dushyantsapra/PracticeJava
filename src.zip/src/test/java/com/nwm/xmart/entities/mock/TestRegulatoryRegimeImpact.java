package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;
import com.rbs.odc.core.domain.RegulatoryRegimeImpactImpl;
import com.rbs.odc.core.domain.ReportingWaiverImpl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestRegulatoryRegimeImpact extends RegulatoryRegimeImpactImpl {
    private Boolean regimeImpact;
    private String regimeImpactId;
    private String regulatoryAuthority;
    private RegimeImpactType regimeImpactType;
    private TransactionClearingImpact transactionClearingImpact;
    private String legIdentifier;
    private String id;
    private NotionalChangeType notionalChangeType;
    private NotionalChange notionalChange;
    private Amount aggregatedUpfrontFeeAmount;
    private PackageDetails packageDetails;
    private BigDecimal tradedQuantity;
    private String reportableTransactionReference;
    private ReportingWaiverImpl reportingWaiverOld;

    private Collection<RegimeBookRole> regimeBookRoles = new ArrayList<>();
    private Collection<RegimePartyRole> regimePartyRoles = new ArrayList<>();
    private Collection<RegulatoryAuthority> regulatoryAuthorities = new ArrayList<>();
    private Collection<TransactionRegimeImpactTypes> transactionRegimeImpactTypes;
    private Collection<ReportingWaiver> reportingWaivers = new ArrayList<>();

    private Collection<ReportableUnderlyingInstrument> reportableUnderlyingInstruments = new ArrayList<>();

    private Collection<PostTradeClassification> postTradeClassification = new ArrayList<>();
    private Collection<ReportableIndex> reportableIndexes = new ArrayList<>();
    private Amount reportableCostsAndChargesAmount;
    private String reportableOrderType;
    private ReportablePriceDetails reportablePriceDetails;

    public TestRegulatoryRegimeImpact() {
        regimeImpact = getRndInt() % 2 == 0;
        regimeImpactId = getRandomString();
        regulatoryAuthority = getRandomString();

        try {
            regimeImpactType = RegimeImpactType.valueOf(getRndInt() % RegimeImpactType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("RegimeImpactType creation failed Using default value" + e.getMessage());
            regimeImpactType = RegimeImpactType.NULL;
        }

        transactionClearingImpact = new TestTransactionClearingImpact();

        id = getRandomString();

        try {
            notionalChangeType = NotionalChangeType.valueOf(getRndInt() % NotionalChangeType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("NotionalChangeType creation failed Using default value" + e.getMessage());
            notionalChangeType = NotionalChangeType.NULL;
        }
        tradedQuantity = new BigDecimal(getRndDouble());
        reportableTransactionReference = getRandomString();

        notionalChange = new TestNotionalChange();
        aggregatedUpfrontFeeAmount = new TestAmount();
        packageDetails = new TestPackageDetails();

        reportingWaiverOld = new ReportingWaiverImpl();
        ReportingWaiverTypeScheme reportingWaiverTypeSchemeType;
        try {
            reportingWaiverTypeSchemeType = ReportingWaiverTypeScheme
                    .valueOf(getRndInt() % ReportingWaiverTypeScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("ReportingWaiverTypeScheme creation failed Using default value" + e.getMessage());
            reportingWaiverTypeSchemeType = ReportingWaiverTypeScheme.NULL;
        }

        reportingWaiverOld.setReportingWaiverType(reportingWaiverTypeSchemeType);

        regimeBookRoles.add(new TestRegimeBookRole());
        regimeBookRoles.add(new TestRegimeBookRole());

        regimePartyRoles.add(new TestRegimePartyRole());
        regimePartyRoles.add(new TestRegimePartyRole());

        regulatoryAuthorities.add(new TestRegulatoryAuthority());
        regulatoryAuthorities.add(new TestRegulatoryAuthority());

        transactionRegimeImpactTypes = Arrays
                .asList(new TestTransactionRegimeImpactTypes(), new TestTransactionRegimeImpactTypes());

        reportingWaivers = Arrays.asList(new TestReportingWaiver(), new TestReportingWaiver());

        reportableUnderlyingInstruments = Arrays
                .asList(new TestReportableUnderlyingInstrument(), new TestReportableUnderlyingInstrument());

        postTradeClassification = Arrays.asList(new TestPostTradeClassification(), new TestPostTradeClassification());
        reportableIndexes = Arrays.asList(new TestReportableIndex(), new TestReportableIndex());
        reportableCostsAndChargesAmount = new TestAmount();
        reportableOrderType = getRandomString();

        reportablePriceDetails = new TestReportablePriceDetails();
    }

    public TestRegulatoryRegimeImpact(String legIdentifier) {
        this();
        this.legIdentifier = legIdentifier;
    }

    @Override
    public Boolean getRegimeImpact() {
        return regimeImpact;
    }

    @Override
    public String getRegimeImpactId() {
        return regimeImpactId;
    }

    @Override
    public String getRegulatoryAuthority() {
        return regulatoryAuthority;
    }

    @Override
    public Collection<RegimePartyRole> getRegimePartyRoles() {
        return regimePartyRoles;
    }

    @Override
    public Collection<RegimeBookRole> getRegimeBookRoles() {
        return regimeBookRoles;
    }

    @Override
    public Collection<RegulatoryAuthority> getRegulatoryAuthorities() {
        return regulatoryAuthorities;
    }

    @Override
    public RegimeImpactType getRegimeImpactType() {
        return regimeImpactType;
    }

    @Override
    public TransactionClearingImpact getTransactionClearingImpact() {
        return transactionClearingImpact;
    }

    @Override
    public Boolean isOrderTransmissionConditionsNotSatisfied() {
        return false;
    }

    @Override
    public Collection<PostTradeClassification> getPostTradeClassification() {
        return postTradeClassification;
    }

    @Override
    public Collection<ReportingWaiver> getReportingWaiver() {
        return reportingWaivers;
    }

    @Override
    public Collection<ReportableIndex> getReportableIndexes() {
        return reportableIndexes;
    }

    @Override
    public Collection<ReportableInstrument> getReportableInstruments() {
        //Not Used
        return null;
    }

    @Override
    public Collection<ReportableUnderlyingInstrument> getReportableUnderlyingInstruments() {
        return reportableUnderlyingInstruments;
    }

    @Override
    public String getLegIdentifier() {
        return legIdentifier;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public NotionalChangeType getNotionalChangeType() {
        return notionalChangeType;
    }

    @Override
    public Collection<TransactionRegimeImpactTypes> getTransactionRegimeImpactTypes() {
        return transactionRegimeImpactTypes;
    }

    @Override
    public Boolean isCommodityDerivativeIndicator() {
        return false;
    }

    @Override
    public NotionalChange getNotionalChange() {
        return notionalChange;
    }

    @Override
    public Amount getAggregatedUpfrontFeeAmount() {
        return aggregatedUpfrontFeeAmount;
    }

    @Override
    public PackageDetails getPackageDetails() {
        return packageDetails;
    }

    @Override
    public BigDecimal getTradedQuantity() {
        return tradedQuantity;
    }

    @Override
    public String getReportableTransactionReference() {
        return reportableTransactionReference;
    }

    @Override
    public Amount getReportableCostsAndChargesAmount() {
        return reportableCostsAndChargesAmount;
    }

    @Override
    public String getReportableOrderType() {
        return reportableOrderType;
    }

    @Override
    public ReportingWaiverImpl getReportingWaiverOld() {
        return reportingWaiverOld;
    }

    @Override
    public ReportablePriceDetails getReportablePriceDetails() {
        return reportablePriceDetails;
    }
}

