package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;
import java.util.Date;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestFXLeg implements FXLeg {
    String legIdentifier;

    BusinessDate exchangeRateDate;
    FXLegType fxlegType;
    BigDecimal forwardVolatility;
    ForwardVolatilityBasis forwardVolatilityBasis;
    VolatilitySwapType volatilitySwapModelBasis;
    FXLegSubType fxLegSubType;
    BusinessDate firstDrawdownDate;
    Date forwardFixingDateTime;
    BusinessDate forwardFixingDate;
    boolean legType;
    CurrencyId fixedCurrencyId;

    String instrumentClass1;
    String instrumentClass2;
    Boolean isMeanSubtractionApplies;
    Boolean isHistoricRollRateIndicator;

    public TestFXLeg() {
        this.exchangeRateDate = new TestBusinessDate();
        try {
            fxlegType = FXLegType.valueOf(getRndInt() % FXLegType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("FXLegType creation failed Using default value" + e.getMessage());
            fxlegType = FXLegType.NULL;
        }
        this.forwardVolatility = new BigDecimal(getRndDouble());
        try {
            forwardVolatilityBasis = ForwardVolatilityBasis
                    .valueOf(getRndInt() % ForwardVolatilityBasis.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("ForwardVolatilityBasis creation failed Using default value" + e.getMessage());
            forwardVolatilityBasis = ForwardVolatilityBasis.NULL;
        }
        try {
            volatilitySwapModelBasis = VolatilitySwapType.valueOf(getRndInt() % VolatilitySwapType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("VolatilitySwapType creation failed Using default value" + e.getMessage());
            volatilitySwapModelBasis = VolatilitySwapType.NULL;
        }
        try {
            fxLegSubType = FXLegSubType.valueOf(getRndInt() % FXLegSubType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("FXLegSubType creation failed Using default value" + e.getMessage());
            fxLegSubType = FXLegSubType.NULL;
        }
        firstDrawdownDate = new TestBusinessDate();
        forwardFixingDateTime = getRandomDate();
        forwardFixingDate = new TestBusinessDate();
        fixedCurrencyId = new TestCurrencyId();
        this.instrumentClass1 = getRandomString();
        this.instrumentClass2 = getRandomString();
    }

    public TestFXLeg(String legIdentifier) {
        this();
        this.legIdentifier = legIdentifier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    @Override
    public BusinessDate getExchangeRateDate() {
        return exchangeRateDate;
    }

    @Override
    public FXLegType getLegType() {
        return fxlegType;
    }

    @Override
    public BigDecimal getForwardVolatility() {
        return forwardVolatility;
    }

    @Override
    public ForwardVolatilityBasis getForwardVolatilityBasis() {
        return forwardVolatilityBasis;
    }

    @Override
    public VolatilitySwapType getVolatilitySwapModelBasis() {
        return volatilitySwapModelBasis;
    }

    @Override
    public FXLegSubType getFxLegSubType() {
        return fxLegSubType;
    }

    @Override
    public BusinessDate getFirstDrawdownDate() {
        return firstDrawdownDate;
    }

    @Override
    public Date getForwardFixingDateTime() {
        return forwardFixingDateTime;
    }

    @Override
    public BusinessDate getForwardFixingDate() {
        return forwardFixingDate;
    }

    @Override
    public boolean isLegType(FXLegType fxLegType) {
        return false;
    }

    @Override
    public CurrencyId getFixedCurrencyId() {
        return fixedCurrencyId;
    }

    @Override
    public Currency getFixedCurrency() {
        return null;
    }

    @Override
    public String getInstrumentClass1() {
        return instrumentClass1;
    }

    @Override
    public String getInstrumentClass2() {
        return instrumentClass2;
    }

    @Override
    public Boolean isMeanSubtractionApplies() {
        return isMeanSubtractionApplies;
    }

    @Override
    public Boolean isHistoricRollRateIndicator() {
        return isHistoricRollRateIndicator;
    }
}
