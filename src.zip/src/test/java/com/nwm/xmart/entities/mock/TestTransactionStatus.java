package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.util.Date;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestTransactionStatus implements TransactionStatus {
    private TransactionState transactionState;
    private Date effectiveDateTime;
    private BusinessDate effectiveDate;
    private SystemInstanceId transactionStateSystemId;
    private TransactionStateScheme transactionStateScheme;

    public TestTransactionStatus(BusinessDate effectiveDate) {
        effectiveDateTime = getRandomDate();
        this.effectiveDate = effectiveDate;

        try {
            transactionState = TransactionState.valueOf(getRndInt() % TransactionState.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            transactionState = TransactionState.NULL;
        }
        try {
            transactionStateSystemId = SystemInstanceId.valueOf(getRndInt() % SystemInstanceId.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            transactionStateSystemId = SystemInstanceId.NULL;
        }
        try {
            transactionStateScheme = TransactionStateScheme
                    .valueOf(getRndInt() % TransactionStateScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            transactionStateScheme = TransactionStateScheme.NULL;
        }
    }

    @Override
    public TransactionState getTransactionState() {
        return transactionState;
    }

    @Override
    public Date getEffectiveDateTime() {
        return effectiveDateTime;
    }

    @Override
    public BusinessDate getEffectiveDate() {
        return effectiveDate;
    }

    @Override
    public SystemInstanceId getTransactionStateSystemId() {
        return transactionStateSystemId;
    }

    @Override
    public TransactionStateScheme getTransactionStateScheme() {
        return transactionStateScheme;
    }
}
