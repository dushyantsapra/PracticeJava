package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.OptionalEarlyTermination;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestOptionalEarlyTermination implements OptionalEarlyTermination {

    String calculationAgent = getRandomString();

    @Override
    public String getCalculationAgent() {
        return calculationAgent;
    }
}
