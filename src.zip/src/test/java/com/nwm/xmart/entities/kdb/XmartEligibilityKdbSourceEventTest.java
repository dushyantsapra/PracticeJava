package com.nwm.xmart.entities.kdb;

import com.nwm.xmart.entities.XmartEntitiesBaseTest;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.entities.kdb.mock.TradeEligibiltyKdbSourceEventWrapper;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.kdb.event.KDBSourceEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

import java.util.Collection;

public class XmartEligibilityKdbSourceEventTest extends XmartEntitiesBaseTest {

    TradeEligibiltyKdbSourceEventWrapper tradeEligibiltyKdbSourceEventWrapper;
    MappingNode mappingNode;

    @BeforeEach
    void setUp() throws XmartException {
        MockitoAnnotations.initMocks(this);
        tradeEligibiltyKdbSourceEventWrapper = new TradeEligibiltyKdbSourceEventWrapper();
        //mappingNode = MappingNodeFactory.ReadResourceFile("mapping_config/kdb-fx-inquiries.csv");
        mappingNode = MappingNodeFactory.ReadResourceFile("/mapping_config/kdb-fx-inquiries.csv");
    }

    private static void verifyMappings(KDBSourceEvent kdbSourceEvent,Collection<XmartMappedEntity> requiredEntities){
        String [] names = kdbSourceEvent.getColumnNames();
        Object [] data = kdbSourceEvent.getRecordData();




    }

    @Tag("UnitTest")
    @Test
    void testAllFields() throws XmartException {
        logger.info("Test");
        XmartKdbEventSet xmartKdbEventSet = new XmartKdbEventSet();
        xmartKdbEventSet.addStreamEvent(tradeEligibiltyKdbSourceEventWrapper.getKdbSourceEvent(), 101, mappingNode);
        logger.info(xmartKdbEventSet.getXmlEntities("XmartFactInquiryBestExecEligibilities"));

    }
}
