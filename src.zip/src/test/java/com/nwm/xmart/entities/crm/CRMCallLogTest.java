package com.nwm.xmart.entities.crm;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.crm.entity.callLog.CallLog;
import com.nwm.xmart.streaming.source.crm.entity.callLog.CallLogParticipant;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEventType;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.when;

public class CRMCallLogTest {
    @Mock
    CRMSourceEvent crmSourceEvent;

    private MappingNode mappingHierarchy;

    private CallLog callLog;

    private List<CallLogParticipant> callLogParticipants;

    private XmartGenericSet xmartSet;

    private int topicId = getRndInt();

    private void setUpCrmCallLog() {
        callLog = new CallLog();

        callLog.setId(getRandomString());
        callLog.setCallId(getRandomString());
        callLog.setCallSeq(new Long(getRndInt()));
        callLog.setCallClassification(getRandomString());
        callLog.setState(getRandomString());
        callLog.setStartedOn(getRandomString());
        callLog.setEndedOn(getRandomString());
        callLog.setDuration(new Long(getRndInt()));

        callLogParticipants = new ArrayList<>();
        callLog.setCallLogParticipants(callLogParticipants);

        CallLogParticipant callLogParticipant = null;

        callLogParticipant = new CallLogParticipant();
        callLogParticipant.setCallLogId(getRandomString());
        callLogParticipant.setDirection(getRandomString());
        callLogParticipant.setName(getRandomString());
        callLogParticipant.setNumber(getRandomString());
        callLogParticipant.setStartTime(getRandomString());
        callLogParticipant.setEndTime(getRandomString());
        callLogParticipant.setDuration(new Long(getRndInt()));
        callLogParticipant.setParticipantSeq(new Long(getRndInt()));
        callLogParticipant.setContactId(getRandomString());
        callLogParticipant.setUserId(getRandomString());
        callLogParticipants.add(callLogParticipant);

        callLog.setCallLogParticipants(callLogParticipants);
    }

    /*
    Update
    @expectedMatchCount
    if more Attribute check condition is been added
    * */

    private void verifyCrmCallLogMapping(List<XmartMappedEntity> xmartCrmCallLogsEntities,
            List<XmartMappedEntity> xmartCrmCallLogParticipants) {
        XmartMappedEntity xmartMappedEntity = null;
        xmartMappedEntity = xmartCrmCallLogsEntities.get(0);

        int expectedMatchCount = 8;

        final AtomicInteger countCallLog = new AtomicInteger();
        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {
            if ("callId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLog.getId(), (String) xmartMappedAttribute.getAttributeValue());
                countCallLog.incrementAndGet();
                return;
            }
            if ("callLogId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLog.getCallId(), (String) xmartMappedAttribute.getAttributeValue());
                countCallLog.incrementAndGet();
                return;
            }
            if ("callSeq".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLog.getCallSeq(), (Long) xmartMappedAttribute.getAttributeValue());
                countCallLog.incrementAndGet();
                return;
            }
            if ("callClassification".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLog.getCallClassification(), (String) xmartMappedAttribute.getAttributeValue());
                countCallLog.incrementAndGet();
                return;
            }
            if ("state".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLog.getState(), (String) xmartMappedAttribute.getAttributeValue());
                countCallLog.incrementAndGet();
                return;
            }
            if ("startedOn".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLog.getStartedOn(), (String) xmartMappedAttribute.getAttributeValue());
                countCallLog.incrementAndGet();
                return;
            }
            if ("endedOn".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLog.getEndedOn(), (String) xmartMappedAttribute.getAttributeValue());
                countCallLog.incrementAndGet();
                return;
            }
            if ("duration".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLog.getDuration(), (Long) xmartMappedAttribute.getAttributeValue());
                countCallLog.incrementAndGet();
                return;
            }
        });

        if (countCallLog.get() != expectedMatchCount) {
            Assert.fail("Call Log Count doesn't match the Expected Count");
        }

        xmartMappedEntity = xmartCrmCallLogParticipants.get(0);

        expectedMatchCount = 8;

        final AtomicInteger countCallLogParticipants = new AtomicInteger();
        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {
            if ("callLogId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLogParticipants.get(0).getCallLogId(),
                        (String) xmartMappedAttribute.getAttributeValue());
                countCallLogParticipants.incrementAndGet();
                return;
            }
            if ("direction".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLogParticipants.get(0).getDirection(),
                        (String) xmartMappedAttribute.getAttributeValue());
                countCallLogParticipants.incrementAndGet();
                return;
            }
            if ("name".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLogParticipants.get(0).getName(), (String) xmartMappedAttribute.getAttributeValue());
                countCallLogParticipants.incrementAndGet();
                return;
            }
            if ("number".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLogParticipants.get(0).getNumber(), (String) xmartMappedAttribute.getAttributeValue());
                countCallLogParticipants.incrementAndGet();
                return;
            }
            if ("startTime".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLogParticipants.get(0).getStartTime(),
                        (String) xmartMappedAttribute.getAttributeValue());
                countCallLogParticipants.incrementAndGet();
                return;
            }
            if ("endTime".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLogParticipants.get(0).getEndTime(),
                        (String) xmartMappedAttribute.getAttributeValue());
                countCallLogParticipants.incrementAndGet();
                return;
            }
            if ("duration".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLogParticipants.get(0).getDuration(), (Long) xmartMappedAttribute.getAttributeValue());
                countCallLogParticipants.incrementAndGet();
                return;
            }
            /*if ("participantSeq".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLogParticipants.get(0).getParticipantSeq(),
                        (Long) xmartMappedAttribute.getAttributeValue());
                countCallLogParticipants.incrementAndGet();
                return;
            }*/
            if ("userId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(callLogParticipants.get(0).getUserId(), (String) xmartMappedAttribute.getAttributeValue());
                countCallLogParticipants.incrementAndGet();
                return;
            }
        });
        if (countCallLogParticipants.get() != expectedMatchCount) {
            Assert.fail("Call Log Participants Count doesn't match the Expected Count");
        }
    }

    @BeforeEach
    void setUp() throws XmartException {
        MockitoAnnotations.initMocks(this);
        mappingHierarchy = MappingNodeFactory.ReadResourceFile("/mapping_config/CRM-event.csv");
        setUpCrmCallLog();
        when(crmSourceEvent.getCrmSourceEventType()).thenReturn(CRMSourceEventType.CallLog);
        when(crmSourceEvent.getCallLog()).thenReturn(callLog);
    }

    @Test
    public void testCRMCallLog() throws XmartException {
        xmartSet = new XmartCRMSourceEventSet();
        xmartSet.addStreamEvent(crmSourceEvent, topicId, mappingHierarchy);

        List<XmartMappedEntity> xmartCrmCallLogsEntities = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmCallLogs");
        List<XmartMappedEntity> xmartCrmCallLogParticipantsEntities = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmCallLogParticipants");
        verifyCrmCallLogMapping(xmartCrmCallLogsEntities, xmartCrmCallLogParticipantsEntities);
    }
}
