package com.nwm.xmart.entities.crm;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.crm.entity.common.Account;
import com.nwm.xmart.streaming.source.crm.entity.user.Profile;
import com.nwm.xmart.streaming.source.crm.entity.user.User;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEventType;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.when;

public class CRMUserTest {
    @Mock
    CRMSourceEvent crmSourceEvent;

    private MappingNode mappingHierarchy;

    private User user;

    private XmartGenericSet xmartSet;

    private int topicId = getRndInt();

    private void setUpCrmUser() {
        user = new User();
        Account account = new Account();
        account.setExternalAccountNumber(getRandomString());
        user.setAccount(account);

        user.setAlias(getRandomString());
        user.setAnalyst(getRndInt() % 2 == 0);
        user.setBadgeText(getRandomString());
        user.setBannerPhotoUrl(getRandomString());
        user.setCallCenterId(getRandomString());
        user.setCity(getRandomString());
        user.setCommunityNickname(getRandomString());
        user.setCompanyName(getRandomString());
        user.setContactId(getRandomString());
        user.setCountry(getRandomString());
        user.setCreatedById(getRandomString());
        user.setCreatedDate(getRandomString());
        user.setCreateDataAgainstCoverage(getRndInt() % 2 == 0);
        user.setDefaultGroupNotificationFrequency(getRandomString());
        user.setDepartment(getRandomString());
        user.setDigestFrequency(getRandomString());
        user.setDivision(getRandomString());
        user.setECDId(getRandomString());
        user.setECDURL(getRandomString());
        user.setEmail(getRandomString());
        user.setEmailEncodingKey(getRandomString());
        user.setEmailPreferencesAutoBcc(getRndInt() % 2 == 0);
        user.setEmailPreferencesAutoBccStayInTouch(getRndInt() % 2 == 0);
        user.setEmailPreferencesStayInTouchReminder(getRndInt() % 2 == 0);
        user.setEmployeeNumber(getRandomString());
        user.setExtension(getRandomString());
        user.setId(getRandomString());
        user.setFax(getRandomString());
        user.setFirstName(getRandomString());
        user.setForecastEnabled(getRndInt() % 2 == 0);
        user.setFullPhotoUrl(getRandomString());
        user.setId18(getRandomString());
        user.setIsActive(getRndInt() % 2 == 0);
        user.setIsProfilePhotoActive(getRndInt() % 2 == 0);
        user.setLanguageLocaleKey(getRandomString());
        user.setLastLoginDate(getRandomString());
        user.setLastModifiedById(getRandomString());
        user.setLastModifiedDate(getRandomString());
        user.setLastName(getRandomString());
        user.setLastPasswordChangeDate(getRandomString());
        user.setLocaleSidKey(getRandomString());
        user.setManagerId(getRandomString());
        user.setMiddleName(getRandomString());
        user.setMobilePhone(getRandomString());
        user.setName(getRandomString());
        user.setPhone(getRandomString());
        user.setPostalCode(getRandomString());

        Profile profile = new Profile();
        profile.setId(getRandomString());
        profile.setName(getRandomString());
        user.setProfile(profile);

        user.setReceivesAdminInfoEmails(getRndInt() % 2 == 0);
        user.setReceivesInfoEmails(getRndInt() % 2 == 0);
        user.setSenderEmail(getRandomString());
        user.setSenderName(getRandomString());
        user.setState(getRandomString());
        user.setStreet(getRandomString());
        user.setSystemModstamp(getRandomString());
        user.setCreateNewEmployee(getRndInt() % 2 == 0);
        user.setEmployeeId(getRandomString());
        user.setUserEmplActiveStatusMismatch(getRndInt() % 2 == 0);
        user.setTimeZoneSidKey(getRandomString());
        user.setTitle(getRandomString());
        user.setUsername(getRandomString());
        user.setUserRoleId(getRandomString());
        user.setUserType(getRandomString());
    }

    /*
    Update
    @expectedMatchCount
    if more Attribute check condition is been added
    * */
    private void verifyCrmUserMapping(List<XmartMappedEntity> xmartCrmUserEntities) {
        XmartMappedEntity xmartMappedEntity = xmartCrmUserEntities.get(0);
        final AtomicInteger count = new AtomicInteger();
        int expectedMatchCount = 39;

        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {
            /*if ("externalAccountNumber".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getAccount().getExternalAccountNumber(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/

            /*if ("callCenterId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getCallCenterId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
            if ("city".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getCity(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("companyName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getCompanyName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            /*if ("contactId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getContactId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
            if ("country".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getCountry(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getCreatedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getCreatedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("department".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getDepartment(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("division".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getDivision(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("ecdId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getECDId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("ecdUrl".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getECDURL(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("email".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getEmail(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("employeeNumber".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getEmployeeNumber(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("extension".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getExtension(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("userId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("fax".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getFax(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("firstName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getFirstName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("fullPhotoUrl".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getFullPhotoUrl(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("id18".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getId18(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("isActive".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getIsActive(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastLoginDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getLastLoginDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getLastModifiedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getLastModifiedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getLastName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("managerId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getManagerId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("middleName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getMiddleName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("mobilePhone".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getMobilePhone(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("name".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("phone".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getPhone(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("postalCode".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getPostalCode(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("profileId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getProfile().getId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("profileName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getProfile().getName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            /*if ("senderEmail".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getSenderEmail(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
            if ("senderName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getSenderName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("state".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getState(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("street".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getStreet(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("systemModstamp".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getSystemModstamp(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("employeeId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getEmployeeId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("title".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getTitle(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("username".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getUsername(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("userRoleId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getUserRoleId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("userType".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(user.getUserType(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
        });
        if (count.get() != expectedMatchCount) {
            Assert.fail("Count doesn't match the Expected Count");
        }
    }

    @BeforeEach
    void setUp() throws XmartException {
        MockitoAnnotations.initMocks(this);
        setUpCrmUser();
        mappingHierarchy = MappingNodeFactory.ReadResourceFile("/mapping_config/CRM-event.csv");
        when(crmSourceEvent.getCrmSourceEventType()).thenReturn(CRMSourceEventType.User);
        when(crmSourceEvent.getUser()).thenReturn(user);
    }

    @Test
    void testCRMUser() throws XmartException {
        xmartSet = new XmartCRMSourceEventSet();
        xmartSet.addStreamEvent(crmSourceEvent, topicId, mappingHierarchy);

        List<XmartMappedEntity> xmartCrmUserEntities = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmUsers");
        verifyCrmUserMapping(xmartCrmUserEntities);
    }
}
