package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Discounting;
import com.rbs.odc.access.domain.DiscountingType;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestDiscounting implements Discounting {
    private DiscountingType discountingType;
    private BigDecimal discountRate = new BigDecimal(getRndDouble());
    private String rateDayCount = getRandomString();

    TestDiscounting() {
        try {
            discountingType = DiscountingType.valueOf(getRndInt() % DiscountingType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            discountingType = DiscountingType.NULL;
        }
    }

    @Override
    public DiscountingType getDiscountingType() {
        return discountingType;
    }

    @Override
    public BigDecimal getDiscountRate() {
        return discountRate;
    }

    @Override
    public String getRateDayCount() {
        return rateDayCount;
    }
}
