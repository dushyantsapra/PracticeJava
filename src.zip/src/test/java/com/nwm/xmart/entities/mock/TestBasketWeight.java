package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Amount;
import com.rbs.odc.access.domain.BasketWeight;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestBasketWeight implements BasketWeight {
    private BigDecimal openUnits;
    private BigDecimal percentage;
    private Amount amount;

    public TestBasketWeight() {
        this.openUnits = new BigDecimal(getRndInt());
        this.percentage = new BigDecimal(getRndInt());
        amount = new TestAmount();
    }

    @Override
    public BigDecimal getOpenUnits() {
        return openUnits;
    }

    @Override
    public BigDecimal getPercentage() {
        return percentage;
    }

    @Override
    public Amount getAmount() {
        return amount;
    }
}
