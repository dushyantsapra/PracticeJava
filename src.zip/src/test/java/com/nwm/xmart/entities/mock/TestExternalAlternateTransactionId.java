package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestExternalAlternateTransactionId implements ExternalAlternateTransactionId {

    private static final long serialVersionUID = 3210100439598585450L;
    private String alternateTransactionId;
    private AlternateTransactionClassificationScheme alternateIdDescription;
    private TradingCounterpartyId tradingCounterpartyId;
    private TradingCounterparty tradingCounterparty;

    public TestExternalAlternateTransactionId() {
        alternateTransactionId = getRandomString();
        try {
            alternateIdDescription = AlternateTransactionClassificationScheme
                    .valueOf(getRndInt() % AlternateTransactionClassificationScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            alternateIdDescription = AlternateTransactionClassificationScheme.NULL;
        }

        tradingCounterpartyId = new TestTradingCounterpartyId();
    }

    @Override
    public String getAlternateTransactionId() {
        return alternateTransactionId;
    }

    @Override
    public AlternateTransactionClassificationScheme getAlternateIdDescription() {
        return alternateIdDescription;
    }

    @Override
    public TradingCounterpartyId getTradingCounterpartyId() {
        return tradingCounterpartyId;
    }

    @Override
    public TradingCounterparty getTradingCounterparty() {
        return tradingCounterparty;//not used for this test
    }
}
