package com.nwm.xmart.entities.crm;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.crm.entity.common.Account;
import com.nwm.xmart.streaming.source.crm.entity.contact.Contact;
import com.nwm.xmart.streaming.source.crm.entity.contact.MailingAddress;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEventType;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.when;

public class CRMContactTest {
    @Mock
    CRMSourceEvent crmSourceEvent;

    private MappingNode mappingHierarchy;

    private Contact contact;

    private XmartGenericSet xmartSet;

    private int topicId = getRndInt();

    private void setUpCrmContact() {
        contact = new Contact();

        Account account = new Account();
        account.setExternalAccountNumber(getRandomString());
        contact.setAccount(account);

        contact.setAccountType(getRandomString());
        contact.setAllMarketingOptOut(getRndInt() % 2 == 0);
        contact.setAssistantName(getRandomString());
        contact.setAssistantPhone(getRandomString());
        contact.setAssistantEmailAddress(getRandomString());
        contact.setBloombergEmailAddress(getRandomString());
        contact.setBusinessEmailAddress(getRandomString());
        contact.setBusinessPhone(getRandomString());
        contact.setChatOptOut(getRndInt() % 2 == 0);
        contact.setCountry(getRandomString());
        contact.setCreatedById(getRandomString());
        contact.setCreatedDate(getRandomString());
        contact.setCTIAssistantPhone(getRandomString());
        contact.setCTIBusinessPhone(getRandomString());
        contact.setCTIMobilePhone(getRandomString());
        contact.setCTIOtherPhoneNumber(getRandomString());
        contact.setDeactivatedBy(getRandomString());
        contact.setDeactivationDate(getRandomString());
        contact.setDepartment(getRandomString());
        contact.setId(getRandomString());
        contact.setDescription(getRandomString());
        contact.setDeskStrategyOptOut(getRndInt() % 2 == 0);
        contact.setDivision(getRandomString());
        contact.setDoNotCall(getRndInt() % 2 == 0);
        contact.setECDId(getRandomString());
        contact.setEmail(getRandomString());
        contact.setFirstName(getRandomString());
        contact.setGreenwichVoter(getRndInt() % 2 == 0);
        contact.setHasOptedOutOfEmail(getRndInt() % 2 == 0);
        contact.setHomeEmail(getRandomString());
        contact.setHomePhone(getRandomString());
        contact.setIncomingCallNumber(getRandomString());
        contact.setIsEmailBounced(getRndInt() % 2 == 0);
        contact.setIsMyCoverage(getRndInt() % 2 == 0);
        contact.setJobRole(getRandomString());
        contact.setLastModifiedById(getRandomString());
        contact.setLastModifiedDate(getRandomString());
        contact.setLastName(getRandomString());

        MailingAddress mailingAddress = null;

        mailingAddress = new MailingAddress();
        mailingAddress.setCity(getRandomString());
        mailingAddress.setCountry(getRandomString());
        mailingAddress.setGeocodeAccuracy(getRandomString());
        mailingAddress.setLatitude(getRandomString());
        mailingAddress.setLongitude(getRandomString());
        mailingAddress.setPostalCode(getRandomString());
        mailingAddress.setState(getRandomString());
        mailingAddress.setStreet(getRandomString());
        contact.setMailingAddress(mailingAddress);

        contact.setMarketingOptOut(getRndInt() % 2 == 0);
        contact.setMiddleName(getRandomString());
        contact.setMobilePhone(getRandomString());
        contact.setName(getRandomString());

        mailingAddress = new MailingAddress();
        mailingAddress.setCity(getRandomString());
        mailingAddress.setCountry(getRandomString());
        mailingAddress.setGeocodeAccuracy(getRandomString());
        mailingAddress.setLatitude(getRandomString());
        mailingAddress.setLongitude(getRandomString());
        mailingAddress.setPostalCode(getRandomString());
        mailingAddress.setState(getRandomString());
        mailingAddress.setStreet(getRandomString());
        contact.setOtherAddress(mailingAddress);

        contact.setOtherBusinessEmailAddress(getRandomString());
        contact.setOtherPhoneNumber(getRandomString());
        contact.setOwnerId(getRandomString());
        contact.setPEPPO(getRndInt() % 2 == 0);
        contact.setPhone(getRandomString());
        contact.setPostalOptOut(getRndInt() % 2 == 0);
        contact.setRoadshowAndEventsOptOut(getRndInt() % 2 == 0);
        contact.setRole(getRandomString());
        contact.setSalutation(getRandomString());
        contact.setSystemModstamp(getRandomString());
        contact.setBVMOptOut(getRndInt() % 2 == 0);
        contact.setHasPriorityCoverage(getRndInt() % 2 == 0);
        contact.setInactiveComments(getRandomString());
        contact.setInactive(getRndInt() % 2 == 0);
        contact.setInteractionExists(getRndInt() % 2 == 0);
        contact.setIsAway(getRndInt() % 2 == 0);
        contact.setJobFunction(getRandomString());
        contact.setNumberOfPhoneNumbers(getRndInt());
        contact.setNumberOfPriorityRelationships(getRndInt());
        contact.setUser(getRandomString());
        contact.setMobileActivityScore(getRndInt());
        contact.setTitle(getRandomString());
        contact.setUSPersons(getRndInt() % 2 == 0);
    }

    /*
    Update
    @expectedMatchCount
    if more Attribute check condition is been added
    * */
    private void verifyCrmContactMapping(List<XmartMappedEntity> xmartCrmUserRoleEntities) {
        XmartMappedEntity xmartMappedEntity = xmartCrmUserRoleEntities.get(0);
        final AtomicInteger count = new AtomicInteger();

        int expectedMatchCount = 76;

        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {

            if ("accountType".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getAccountType(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("allMarketingOptOut".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getAllMarketingOptOut(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("assistantName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getAssistantName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("assistantPhone".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getAssistantPhone(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("assistantEmailAddress".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getAssistantEmailAddress(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("bloombergEmailAddress".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getBloombergEmailAddress(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("businessEmailAddress".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getBusinessEmailAddress(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("businessPhone".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getBusinessPhone(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("chatOptOut".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getChatOptOut(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("country".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getCountry(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getCreatedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getCreatedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("cTIAssistantPhone".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getCTIAssistantPhone(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("cTIBusinessPhone".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getCTIBusinessPhone(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("cTIMobilePhone".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getCTIMobilePhone(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("cTIOtherPhoneNumber".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getCTIOtherPhoneNumber(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("deactivatedBy".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getDeactivatedBy(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("deactivationDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getDeactivationDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("department".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getDepartment(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("contactDescription".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getDescription(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("deskStrategyOptOut".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getDeskStrategyOptOut(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("contactId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("division".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getDivision(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("doNotCall".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getDoNotCall(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("ecdId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getECDId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("email".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getEmail(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("firstName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getFirstName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("greenwichVoter".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getGreenwichVoter(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("hasOptedOutOfEmail".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getHasOptedOutOfEmail(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("homeEmail".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getHomeEmail(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("homePhone".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getHomePhone(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("incomingCallNumber".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getIncomingCallNumber(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("isEmailBounced".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getIsEmailBounced(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("isMyCoverage".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getIsMyCoverage(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("jobRole".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getJobRole(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getLastModifiedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getLastModifiedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getLastName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("marketingOptOut".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getMarketingOptOut(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("middleName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getMiddleName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("mobilePhone".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getMobilePhone(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("name".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("otherBusinessEmailAddress".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getOtherBusinessEmailAddress(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("otherPhoneNumber".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getOtherPhoneNumber(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("ownerId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getOwnerId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("phone".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getPhone(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("postalOptOut".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getPostalOptOut(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("roadshowAndEventsOptOut".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getRoadshowAndEventsOptOut(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("role".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getRole(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("salutation".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getSalutation(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("systemModstamp".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getSystemModstamp(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("bVMOptOut".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getBVMOptOut(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("hasPriorityCoverage".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getHasPriorityCoverage(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("inactiveComments".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getInactiveComments(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("inactive".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getInactive(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("interactionExists".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getInteractionExists(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("isAway".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getIsAway(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("jobFunction".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getJobFunction(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("userId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getUser(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("title".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getTitle(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("uSPersons".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getUSPersons(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("externalAccountNumber".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getAccount().getExternalAccountNumber(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("mailingAddressCity".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getMailingAddress().getCity(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("mailingAddressCountry".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getMailingAddress().getCountry(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            /*if ("mailingAddressGeocodeAccuracy".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getMailingAddress().getGeocodeAccuracy(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
            if ("mailingAddressLatitude".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getMailingAddress().getLatitude(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("mailingAddressLongitude".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getMailingAddress().getLongitude(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("mailingAddressPostalCode".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getMailingAddress().getPostalCode(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("mailingAddressState".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getMailingAddress().getState(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("mailingAddressStreet".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getMailingAddress().getStreet(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("otherAddressCity".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getOtherAddress().getCity(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("otherAddressCountry".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getOtherAddress().getCountry(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            /*if ("otherAddressGeocodeAccuracy".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getOtherAddress().getGeocodeAccuracy(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
            if ("otherAddressLatitude".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getOtherAddress().getLatitude(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("otherAddressLongitude".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getOtherAddress().getLongitude(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("otherAddressPostalCode".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getOtherAddress().getPostalCode(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("otherAddressState".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getOtherAddress().getState(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("otherAddressStreet".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(contact.getOtherAddress().getStreet(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
        });

        if (count.get() != expectedMatchCount) {
            Assert.fail("Count doesn't match the Expected Count");
        }
    }

    @BeforeEach
    void setUp() throws XmartException {
        MockitoAnnotations.initMocks(this);
        mappingHierarchy = MappingNodeFactory.ReadResourceFile("/mapping_config/CRM-event.csv");
        setUpCrmContact();
        when(crmSourceEvent.getCrmSourceEventType()).thenReturn(CRMSourceEventType.Contact);
        when(crmSourceEvent.getContact()).thenReturn(contact);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Test
    void testCRMContact() throws XmartException {
        xmartSet = new XmartCRMSourceEventSet();
        xmartSet.addStreamEvent(crmSourceEvent, topicId, mappingHierarchy);

        List<XmartMappedEntity> xmartCrmContactEntities = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmContacts");
        verifyCrmContactMapping(xmartCrmContactEntities);
    }
}
