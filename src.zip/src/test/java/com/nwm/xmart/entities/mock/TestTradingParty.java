package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

public class TestTradingParty implements TradingParty {

    SourceBookId sourceBookId = new TestSourceBookId();
    TradingCounterpartyId tradingCounterpartyId = new TestTradingCounterpartyId();

    @Override
    public SourceBookId getSourceBookId() {
        return sourceBookId;
    }

    @Override
    public TradingCounterpartyId getTradingCounterpartyId() {
        return tradingCounterpartyId;
    }

    @Override
    public HCSEntity getHCSEntity() {
        return null;
    }

    @Override
    public Party getParty() {
        return null;
    }

    @Override
    public boolean isBookCounterparty() {
        return true;
    }

    @Override
    public SourceBook getSourceBook() {
        return null;
    }

    @Override
    public TradingCounterparty getTradingCounterparty() {
        return null;
    }

    @Override
    public String getNucleusId() {
        return null;
    }
}
