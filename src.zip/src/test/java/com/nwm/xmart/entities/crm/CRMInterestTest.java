package com.nwm.xmart.entities.crm;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.crm.entity.common.Account;
import com.nwm.xmart.streaming.source.crm.entity.interest.Interest;
import com.nwm.xmart.streaming.source.crm.entity.interest.InterestSubject;
import com.nwm.xmart.streaming.source.crm.entity.interest.InterestSubjectType;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEventType;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.when;

public class CRMInterestTest {
    @Mock
    CRMSourceEvent crmSourceEvent;

    private MappingNode mappingHierarchy;

    private Interest interest;

    private XmartGenericSet xmartSet;

    private int topicId = getRndInt();

    private void setUpCrmInterest() {
        interest = new Interest();

        interest.setBudgetRate(getRndInt());
        interest.setCreatedById(getRandomString());
        interest.setCreatedDate(getRandomString());
        interest.setId(getRandomString());
        interest.setLastModifiedById(getRandomString());
        interest.setLastModifiedDate(getRandomString());
        interest.setName(getRandomString());
        interest.setOwnerId(getRandomString());
        interest.setSystemModstamp(getRandomString());
        interest.setAccountMismatch(getRndInt() % 2 == 0);

        Account account = new Account();
        account.setExternalAccountNumber(getRandomString());
        interest.setAccount(account);

        interest.setAsOfDate(getRandomString());
        interest.setContact(getRandomString());
        interest.setExpiredModifiedDate(getRandomString());
        interest.setExpired(getRndInt() % 2 == 0);

        InterestSubject interestSubject = new InterestSubject();
        interestSubject.setId(getRandomString());
        interestSubject.setName(getRandomString());

        InterestSubjectType interestSubjectType = new InterestSubjectType();
        interestSubjectType.setName(getRandomString());
        interestSubjectType.setId(getRandomString());

        interestSubject.setInterestSubjectType(interestSubjectType);
        interest.setInterestSubject(interestSubject);

        interest.setIsDisinterest(getRndInt() % 2 == 0);
        interest.setLabel(getRandomString());
        interest.setLastDiscussed(getRandomString());
        interest.setNote(getRandomString());
        interest.setReason(getRandomString());
        interest.setSource(getRandomString());
    }

    /*
    Update
    @expectedMatchCount
    if more Attribute check condition is been added
    * */
    private void verifyCrmInterestMapping(List<XmartMappedEntity> xmartCrmUserRoleEntities) {
        XmartMappedEntity xmartMappedEntity = xmartCrmUserRoleEntities.get(0);
        final AtomicInteger count = new AtomicInteger();

        int expectedMatchCount = 22;

        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {
            /*if ("budgetRate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getBudgetRate(), (Integer) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
            if ("createdById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getCreatedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("createdDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getCreatedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("interestId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getLastModifiedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getLastModifiedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("name".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("ownerId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getOwnerId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("systemModstamp".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getSystemModstamp(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("externalAccountNumber".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getAccount().getExternalAccountNumber(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("asOfDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getAsOfDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("contactId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getContact(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("expiredModifiedDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getExpiredModifiedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("expired".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getExpired(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("subjectId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getInterestSubject().getId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("subjectName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getInterestSubject().getName(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("subjectTypeId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getInterestSubject().getInterestSubjectType().getId(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("subjectTypeName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getInterestSubject().getInterestSubjectType().getName(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("isDisinterest".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getIsDisinterest(), (Boolean) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            /*if ("label".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getLabel(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }*/
            if ("lastDiscussed".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getLastDiscussed(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("note".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getNote(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("reason".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getReason(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("source".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(interest.getSource(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
        });

        if (count.get() != expectedMatchCount) {
            Assert.fail("Count doesn't match the Expected Count");
        }
    }

    @BeforeEach
    void setUp() throws XmartException {
        MockitoAnnotations.initMocks(this);
        mappingHierarchy = MappingNodeFactory.ReadResourceFile("/mapping_config/CRM-event.csv");
        setUpCrmInterest();
        when(crmSourceEvent.getCrmSourceEventType()).thenReturn(CRMSourceEventType.Interest);
        when(crmSourceEvent.getInterest()).thenReturn(interest);
    }

    @Test
    void testCRMInterest() throws XmartException {
        xmartSet = new XmartCRMSourceEventSet();
        xmartSet.addStreamEvent(crmSourceEvent, topicId, mappingHierarchy);

        List<XmartMappedEntity> xmartMappedEntities = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmInterests");
        verifyCrmInterestMapping(xmartMappedEntities);
    }
}
