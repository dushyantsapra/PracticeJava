package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.BookReportObligation;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestBookReportObligation implements BookReportObligation {

    String regulatoryReportName = getRandomString();

    @Override
    public String getRegulatoryReportName() {
        return regulatoryReportName;
    }
}
