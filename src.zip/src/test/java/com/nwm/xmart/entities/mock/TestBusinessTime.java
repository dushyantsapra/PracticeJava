package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.BusinessTime;
import org.joda.time.LocalTime;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomDate;

public class TestBusinessTime implements BusinessTime {

    LocalTime localTime = new LocalTime(getRandomDate());

    @Override
    public LocalTime localTime() {
        return localTime;
    }

    @Override
    public String toPlainString() {
        return localTime.toString();
    }

    @Override
    public String getTime() {
        return null;
    }

    @Override
    public LocalTime getLocalTime() {
        return localTime;
    }

    @Override
    public int compareTo(BusinessTime businessTime) {
        return 0;
    }
}
