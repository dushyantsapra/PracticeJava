package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.BusinessDate;
import com.rbs.odc.access.domain.CalculationPeriodScheduleEntry;

import java.math.BigDecimal;
import java.util.Date;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestCalculationPeriodScheduleEntry implements CalculationPeriodScheduleEntry {
    private String nonStandardPeriodComment;
    private BusinessDate fixingDate;
    private Date fixingDateTime;
    private BigDecimal rate;
    private BigDecimal spread;
    private BigDecimal digitalPayoutRate;
    private Boolean nonStandardPeriod;

    public TestCalculationPeriodScheduleEntry() {
        this.nonStandardPeriodComment = getRandomString();
        this.fixingDate = new TestBusinessDate();
        this.fixingDateTime = getRandomDate();
        this.rate = new BigDecimal(getRndInt());
        this.spread = new BigDecimal(getRndInt());
        this.digitalPayoutRate = new BigDecimal(getRndInt());
        this.nonStandardPeriod = getRndInt() % 2 == 1;
    }

    @Override
    public BusinessDate getFixingDate() {
        return fixingDate;
    }

    @Override
    public Date getFixingDateTime() {
        return fixingDateTime;
    }

    @Override
    public BigDecimal getRate() {
        return rate;
    }

    @Override
    public BigDecimal getSpread() {
        return spread;
    }

    @Override
    public BigDecimal getDigitalPayoutRate() {
        return digitalPayoutRate;
    }

    @Override
    public Boolean getNonStandardPeriod() {
        return nonStandardPeriod;
    }

    @Override
    public String getNonStandardPeriodComment() {
        return nonStandardPeriodComment;
    }
}
