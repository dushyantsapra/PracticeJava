package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Amount;
import com.rbs.odc.access.domain.Brokerage;

public class TestBrokerage implements Brokerage {

    private Amount rcAmount = new TestAmount();

    @Override
    public Amount getRcAmount() {
        return rcAmount;
    }
}
