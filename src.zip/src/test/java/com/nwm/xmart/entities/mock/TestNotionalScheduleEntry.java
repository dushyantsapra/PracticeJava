package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Amount;
import com.rbs.odc.access.domain.IncreaseDecreaseScheme;
import com.rbs.odc.access.domain.NotionalScheduleEntry;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestNotionalScheduleEntry implements NotionalScheduleEntry {
    private IncreaseDecreaseScheme stepDirection;
    private Amount stepAmount = new TestAmount();

    public TestNotionalScheduleEntry() {

        try {
            stepDirection = IncreaseDecreaseScheme.valueOf(getRndInt() % IncreaseDecreaseScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            stepDirection = IncreaseDecreaseScheme.NULL;
        }
    }

    @Override
    public Amount getStepAmount() {
        return stepAmount;
    }

    @Override
    public IncreaseDecreaseScheme getStepDirection() {
        return stepDirection;
    }
}
