package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Location;
import com.rbs.odc.access.domain.SystemRoleScheme;
import com.rbs.odc.access.domain.TransactionSourceSystem;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestTransactionSourceSystem implements TransactionSourceSystem {
    String systemId;
    Location location;
    SystemRoleScheme sourceSystemRole;

    public TestTransactionSourceSystem() {

        systemId = getRandomString();

        try {
            this.location = Location.valueOf(getRndInt() % Location.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Location creation failed Using default value" + e.getMessage());
            this.location = Location.NULL;
        }

        try {
            this.sourceSystemRole = SystemRoleScheme.valueOf(getRndInt() % SystemRoleScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Location creation failed Using default value" + e.getMessage());
            this.sourceSystemRole = SystemRoleScheme.NULL;
        }
    }

    @Override
    public String getSystemId() {
        return systemId;
    }

    @Override
    public Location getLocation() {
        return location;
    }

    @Override
    public SystemRoleScheme getSourceSystemRole() {
        return sourceSystemRole;
    }
}
