package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.RoutingAttribute;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestRoutingAttribute implements RoutingAttribute {
    private String id;
    private String name;
    private String value;

    public TestRoutingAttribute() {
        id = getRandomString();
        name = getRandomString();
        value = getRandomString();
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public int compareTo(RoutingAttribute o) {
        return 0;
    }
}
