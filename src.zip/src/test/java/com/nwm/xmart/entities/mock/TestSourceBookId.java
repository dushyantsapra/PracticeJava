package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.SourceBookId;
import com.rbs.odc.access.domain.SystemInstanceId;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestSourceBookId implements SourceBookId {
    private String sourceSystemBookId;
    private SystemInstanceId bookSourceSystemId;

    public TestSourceBookId() {
        sourceSystemBookId = getRandomString();
        try {
            bookSourceSystemId = SystemInstanceId.valueOf(getRndInt() % SystemInstanceId.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            bookSourceSystemId = SystemInstanceId.NULL;
        }
    }

    @Override
    public String getSourceSystemBookId() {
        return sourceSystemBookId;
    }

    @Override
    public SystemInstanceId getBookSourceSystemId() {
        return bookSourceSystemId;
    }
}
