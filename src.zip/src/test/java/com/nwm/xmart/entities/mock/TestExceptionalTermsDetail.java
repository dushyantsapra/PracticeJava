package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.ExceptionalTermsDetail;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestExceptionalTermsDetail implements ExceptionalTermsDetail {

    private static final long serialVersionUID = 3668854096944046526L;
    String exceptionalTermsDetail = getRandomString();

    @Override
    public String getExceptionalTermsDetail() {
        return exceptionalTermsDetail;
    }
}
