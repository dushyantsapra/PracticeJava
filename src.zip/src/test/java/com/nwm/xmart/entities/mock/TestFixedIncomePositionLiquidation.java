package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Amount;
import com.rbs.odc.access.domain.FixedIncomePositionLiquidation;
import com.rbs.odc.access.domain.Quantity;

public class TestFixedIncomePositionLiquidation implements FixedIncomePositionLiquidation {
    private Quantity liquidatedQuantity;
    private Amount realisedPnl;
    private Amount earnedInterest;
    private Amount liquidatedCost;
    private Amount realAccAmount;

    public TestFixedIncomePositionLiquidation() {
        liquidatedQuantity = new TestQuantity();
        realisedPnl = new TestAmount();
        earnedInterest = new TestAmount();
        liquidatedCost = new TestAmount();
        realAccAmount = new TestAmount();
    }

    @Override
    public Quantity getLiquidatedQuantity() {
        return liquidatedQuantity;
    }

    @Override
    public Amount getRealisedPnl() {
        return realisedPnl;
    }

    @Override
    public Amount getEarnedInterest() {
        return earnedInterest;
    }

    @Override
    public Amount getLiquidatedCost() {
        return liquidatedCost;
    }

    @Override
    public Amount getRealAccAmount() {
        return realAccAmount;
    }
}
