package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestTransactionSalesCreditComponent implements TransactionSalesCreditComponent {
    private ContributionTypeScheme type;
    private BigDecimal componentPercentage;
    private Amount componentAmount;
    private ContributionComponentTypeScheme componentType;
    private String riskCommissionAdjustment;
    private BigDecimal points;

    public TestTransactionSalesCreditComponent() {
        try {
            type = ContributionTypeScheme.valueOf(getRndInt() % ContributionTypeScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("ContributionTypeScheme creation failed Using default value" + e.getMessage());
            type = ContributionTypeScheme.NULL;
        }

        componentPercentage = new BigDecimal(getRndInt());
        componentAmount = new TestAmount();

        try {
            componentType = ContributionComponentTypeScheme
                    .valueOf(getRndInt() % ContributionComponentTypeScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("ContributionComponentTypeScheme creation failed Using default value" + e.getMessage());
            componentType = ContributionComponentTypeScheme.NULL;
        }

        riskCommissionAdjustment = getRandomString();
        points = new BigDecimal(getRndInt());
    }

    @Override
    public ContributionTypeScheme getType() {
        return type;
    }

    @Override
    public BigDecimal getComponentPercentage() {
        return componentPercentage;
    }

    @Override
    public Amount getComponentAmount() {
        return componentAmount;
    }

    @Override
    public ContributionComponentTypeScheme getComponentType() {
        return componentType;
    }

    @Override
    public String getRiskCommissionAdjustment() {
        return riskCommissionAdjustment;
    }

    @Override
    public BigDecimal getPoints() {
        return points;
    }
}
