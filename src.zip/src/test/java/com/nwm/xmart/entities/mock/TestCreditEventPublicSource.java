package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.CreditEventPublicSource;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;

public class TestCreditEventPublicSource implements CreditEventPublicSource {
    String publicSourceName = getRandomString();

    @Override
    public String getPublicSourceName() {
        return publicSourceName;
    }
}
