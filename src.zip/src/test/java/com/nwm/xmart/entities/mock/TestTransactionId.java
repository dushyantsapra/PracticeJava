package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.DayType;
import com.rbs.odc.access.domain.SystemInstanceId;
import com.rbs.odc.access.domain.TransactionId;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestTransactionId implements TransactionId {
    private SystemInstanceId sourceSystemId;
    private String sourceSystemTransactionId;

    public TestTransactionId() {
        try {
            sourceSystemId = SystemInstanceId.valueOf(getRndInt() % DayType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            sourceSystemId = SystemInstanceId.NULL;
        }

        sourceSystemTransactionId = getRandomString();
    }

    @Override
    public SystemInstanceId getSourceSystemId() {
        return sourceSystemId;
    }

    @Override
    public String getSourceSystemTransactionId() {
        return sourceSystemTransactionId;
    }

    @Override
    public int compareTo(TransactionId o) {
        return 0;
    }
}
