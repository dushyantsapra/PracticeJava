package com.nwm.xmart.entities.cashflows;

import com.nwm.xmart.entities.XmartEntitiesBaseTest;
import com.nwm.xmart.entities.mock.TestCashFlow;
import com.nwm.xmart.entities.mock.TestTransactionId;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.XmlUtil;
import com.rbs.odc.access.domain.Cashflow;
import com.rbs.odc.access.domain.Cashflows;
import com.rbs.odc.access.domain.TransactionId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.slf4j.Logger;

import java.util.Collection;
import java.util.Iterator;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.XmartOdcUtil.getCurrencyCode;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.reflect.Whitebox.setInternalState;

class XmartCashFlowsTest extends XmartEntitiesBaseTest {
    private static Long odcVersion = Long.valueOf(getRndInt());
    @Mock
    private Cashflows cashflows;
    @Mock
    private Collection<Cashflow> cashflowCollection;
    @Mock
    private Iterator<Cashflow> cashflowIterator;
    @Spy
    private Cashflow cashflow1 = new TestCashFlow(), cashflow2 = new TestCashFlow();
    @Spy
    private TransactionId transactionId = new TestTransactionId();
    private XmartCashFlows xmartCashFlows;
    @Mock
    private Logger mockLog;

    private static void verifyMappings(XmartCashFlows xmartCashFlows, TransactionId transactionId,
            Cashflow... cashflows) {

        int match = 0;

        for (XmartCashFlow xmartCashFlow : nullCollToEmpty(xmartCashFlows.getXmartEntities())) {
            if (!areEqual(xmartCashFlow.getOdcVersion(), odcVersion)) {
                continue;
            }
            for (Cashflow cashflow : cashflows) {
                if (!areEqual(xmartCashFlow.getSourceSystemTransactionId(),
                        transactionId.getSourceSystemTransactionId())) {
                    continue;
                }

                if (!areEqual(xmartCashFlow.getSourceSystemId(), getStr(transactionId.getSourceSystemId()))) {
                    continue;
                }

                if (nonNull(cashflow.getAmount())) {
                    if (!areEqual(xmartCashFlow.getCashflowAmountCurrencyCode(),
                            getCurrencyCode(cashflow.getAmount().getCurrencyId()))) {
                        continue;
                    }
                    if (!areEqual(xmartCashFlow.getCashflowAmountValue(), cashflow.getAmount().getValue())) {
                        continue;
                    }
                }

                if (!areEqual(xmartCashFlow.getEffectiveDate(), convertBusinessDate(cashflow.getEffectiveDate()))) {
                    continue;
                }

                if (nonNull(cashflow.getEffectiveDt())) {
                    if (!areEqual(xmartCashFlow.getEffectiveDtAdjustedDate(),
                            convertBusinessDate(cashflow.getEffectiveDt().getAdjustedDate()))) {
                        continue;
                    }
                    if (!areEqual(xmartCashFlow.getEffectiveDtAdjustedDate(),
                            convertBusinessDate(cashflow.getEffectiveDt().getUnadjustedDate()))) {
                        continue;
                    }
                }

                if (!areEqual(xmartCashFlow.getEventDateTime(), cashflow.getEventDateTime())) {
                    continue;
                }

                if (!areEqual(xmartCashFlow.isEstimated(), cashflow.getIsEstimated())) {
                    continue;
                }

                if (!areEqual(xmartCashFlow.getLegIdentifier(), cashflow.getLegIdentifier())) {
                    continue;
                }

                if (nonNull(cashflow.getPayer())) {
                    if (nonNull(cashflow.getPayer().getSourceBookId())) {
                        if (!areEqual(xmartCashFlow.getPayerSourceSystemBookId(),
                                cashflow.getPayer().getSourceBookId().getSourceSystemBookId())) {
                            continue;
                        }
                        if (!areEqual(xmartCashFlow.getPayerBookSourceSystemId(),
                                getStr(cashflow.getPayer().getSourceBookId().getBookSourceSystemId()))) {
                            continue;
                        }
                    }
                    if (nonNull(cashflow.getPayer().getTradingCounterpartyId())) {
                        if (!areEqual(xmartCashFlow.getPayerPartyClassification(),
                                getStr(cashflow.getPayer().getTradingCounterpartyId().getPartyClassification()))) {
                            continue;
                        }
                        if (!areEqual(xmartCashFlow.getPayerPartyReference(),
                                cashflow.getPayer().getTradingCounterpartyId().getPartyReference())) {
                            continue;
                        }
                    }
                }

                if (!areEqual(xmartCashFlow.getPaymentType(), getStr(cashflow.getPaymentType()))) {
                    continue;
                }

                if (nonNull(cashflow.getReceiver())) {
                    if (nonNull(cashflow.getReceiver().getSourceBookId())) {
                        if (!areEqual(xmartCashFlow.getReceiverSourceSystemBookId(),
                                cashflow.getReceiver().getSourceBookId().getSourceSystemBookId())) {
                            continue;
                        }
                        if (!areEqual(xmartCashFlow.getReceiverBookSourceSystemId(),
                                getStr(cashflow.getReceiver().getSourceBookId().getBookSourceSystemId()))) {
                            continue;
                        }
                    }

                    if (nonNull(cashflow.getReceiver().getTradingCounterpartyId())) {
                        if (!areEqual(xmartCashFlow.getReceiverPartyClassification(),
                                getStr(cashflow.getReceiver().getTradingCounterpartyId().getPartyClassification()))) {
                            continue;
                        }
                        if (!areEqual(xmartCashFlow.getReceiverPartyReference(),
                                cashflow.getReceiver().getTradingCounterpartyId().getPartyReference())) {
                            continue;
                        }
                    }
                }

                if (!areEqual(xmartCashFlow.getSourceSystemEventId(), cashflow.getSourceSystemEventId())) {
                    continue;
                }
                if (!areEqual(xmartCashFlow.getSettlementMessageRequired(), cashflow.getSettlementMessageRequired())) {
                    continue;
                }

                if (nonNull(cashflow.getBrokerage()) && nonNull(cashflow.getBrokerage().getRcAmount())) {
                    if (!areEqual(xmartCashFlow.getRcAmountValue(), cashflow.getBrokerage().getRcAmount().getValue())) {
                        continue;
                    }
                    if (!areEqual(xmartCashFlow.getRcAmountCurrencyCode(),
                            getCurrencyCode(cashflow.getBrokerage().getRcAmount().getCurrencyId()))) {
                        continue;
                    }
                }

                match++;
            }
        }
        assertEquals(xmartCashFlows.getXmartEntities().size(), match, "XmartCashFlows and CashfLows Did not match");
    }

    private void create() throws XmartException {
        xmartCashFlows = (XmartCashFlows) new XmartCashFlows(documentKey, cashflows, odcVersion).build();
    }

    void mock() {
        when(cashflows.getTransactionId()).thenReturn(transactionId);
        when(cashflows.getCashflows()).thenReturn(cashflowCollection);
        when(cashflowCollection.iterator()).thenReturn(cashflowIterator);
        when(cashflowIterator.hasNext()).thenReturn(true).thenReturn(true).thenReturn(false);
        when(cashflowIterator.next()).thenReturn(cashflow1).thenReturn(cashflow2);
    }

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Tag("UnitTest")
    @Test
    void all() throws XmartException {
        mock();
        create();
        verifyMappings(xmartCashFlows, transactionId, cashflow1, cashflow2);
        xmlCheck(xmartCashFlows);
    }

    @Tag("UnitTest")
    @Test
    void allNull() throws XmartException {
        mock();
        when(cashflows.getCashflows()).thenReturn(null);
        create();
        verifyMappings(xmartCashFlows, transactionId, cashflow1, cashflow2);
        xmlCheck(xmartCashFlows);
    }

    @Tag("UnitTest")
    @Test
    void nullSourceSystemId() {
        mock();
        when(transactionId.getSourceSystemId()).thenReturn(null);
        //assertThrows(XmartMandatoryAttributeMissingException.class, () -> create());
    }

    @Tag("UnitTest")
    @Test
    void nullSourceSystemTransactionId() throws XmartException {
        mock();
        when(transactionId.getSourceSystemTransactionId()).thenReturn(null);
        setInternalState(XmlUtil.class, "logger", mockLog);
        //assertThrows(XmartMandatoryAttributeMissingException.class, () -> create());
        //        verify(mockLog, times(1)).warn(Mockito.anyString());
    }

    @Tag("UnitTest")
    @Test
    void nullLegIdentifier() {
        mock();
        when(cashflow1.getLegIdentifier()).thenReturn(null);
        //assertThrows(XmartMandatoryAttributeMissingException.class, () -> create());
    }
}
