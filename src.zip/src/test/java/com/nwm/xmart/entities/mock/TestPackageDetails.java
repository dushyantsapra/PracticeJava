package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.PackageDetails;
import com.rbs.odc.access.domain.UnitPrice;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestPackageDetails implements PackageDetails {
    private UnitPrice packagePrice;
    private Boolean priceNotAvailable;
    private Boolean priceNotApplicable;
    private Long constituentCount;
    private Long componentNumber;

    public TestPackageDetails() {
        packagePrice = new TestUnitPrice();
        priceNotAvailable = getRndInt() % 2 == 1;
        priceNotApplicable = getRndInt() % 2 == 1;
        constituentCount = new Long(getRndInt());
        componentNumber = new Long(getRndInt());
        priceNotAvailable = getRndInt() % 2 == 1;
        priceNotApplicable = getRndInt() % 2 == 1;
    }

    @Override
    public UnitPrice getPackagePrice() {
        return packagePrice;
    }

    @Override
    public Boolean getPriceNotAvailable() {
        return priceNotAvailable;
    }

    @Override
    public Boolean getPriceNotApplicable() {
        return priceNotApplicable;
    }

    @Override
    public Long getConstituentCount() {
        return constituentCount;
    }

    @Override
    public Long getComponentNumber() {
        return componentNumber;
    }
}
