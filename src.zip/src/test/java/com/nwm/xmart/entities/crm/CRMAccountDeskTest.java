package com.nwm.xmart.entities.crm;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.crm.entity.accountDesk.AccountDesk;
import com.nwm.xmart.streaming.source.crm.entity.common.Account;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEventType;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.when;

public class CRMAccountDeskTest {
    @Mock
    CRMSourceEvent crmSourceEvent;

    private MappingNode mappingHierarchy;

    private AccountDesk accountDesk;

    private XmartGenericSet xmartSet;

    private int topicId = getRndInt();

    private void setUpCrmAccountDesk() {
        accountDesk = new AccountDesk();

        Account account = new Account();
        account.setExternalAccountNumber(getRandomString());
        accountDesk.setAccount(account);

        accountDesk.setDeskDescription(getRandomString());
        accountDesk.setDirectLineID(getRandomString());
        accountDesk.setId(getRandomString());
        accountDesk.setLastModifiedDate(getRandomString());
    }

    @BeforeEach
    void setUp() throws XmartException {
        MockitoAnnotations.initMocks(this);
        mappingHierarchy = MappingNodeFactory.ReadResourceFile("/mapping_config/CRM-event.csv");
        setUpCrmAccountDesk();
        when(crmSourceEvent.getCrmSourceEventType()).thenReturn(CRMSourceEventType.AccountDesk);
        when(crmSourceEvent.getAccountDesk()).thenReturn(accountDesk);
    }

    private void verifyCrmAccountDeskMapping(List<XmartMappedEntity> xmartCrmAccountDeskEntities) {
        XmartMappedEntity xmartMappedEntity = xmartCrmAccountDeskEntities.get(0);
        final AtomicInteger count = new AtomicInteger();

        int expectedMatchCount = 5;

        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {
            if ("externalAccountNumber".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountDesk.getAccount().getExternalAccountNumber(),
                        (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("deskDescription".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountDesk.getDeskDescription(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("directLineId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountDesk.getDirectLineID(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("accountDeskId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountDesk.getId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(accountDesk.getLastModifiedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
        });

        if (count.get() != expectedMatchCount) {
            Assert.fail("Count doesn't match the Expected Count");
        }
    }

    @Test
    void testCRMAccountDesk() throws XmartException {
        xmartSet = new XmartCRMSourceEventSet();
//        XmartCRMSourceEvent xmartCRMSourceEvent = new XmartCRMSourceEvent(crmSourceEvent, topicId);
        xmartSet.addStreamEvent(crmSourceEvent, topicId, mappingHierarchy);

        List<XmartMappedEntity> xmartCrmAccountDeskEntities = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmAccountDesks");
        verifyCrmAccountDeskMapping(xmartCrmAccountDeskEntities);
    }
}
