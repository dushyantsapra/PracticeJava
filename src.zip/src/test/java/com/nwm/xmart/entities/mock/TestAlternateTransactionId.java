package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.AlternateTransactionClassificationScheme;
import com.rbs.odc.access.domain.AlternateTransactionId;
import com.rbs.odc.access.domain.SystemInstanceId;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestAlternateTransactionId implements AlternateTransactionId {
    private static final Logger logger = LoggerFactory.getLogger(TestAlternateTransactionId.class);
    String alternateTransactionId;
    SystemInstanceId alternateIdSourceSystemId;
    AlternateTransactionClassificationScheme alternateIdDescription;
    boolean uniqueScheme;

    public TestAlternateTransactionId() {
        alternateTransactionId = getRandomString();
        try {
            alternateIdSourceSystemId = SystemInstanceId.valueOf(getRndInt() % SystemInstanceId.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            alternateIdSourceSystemId = SystemInstanceId.NULL;
        }

        try {
            alternateIdDescription = AlternateTransactionClassificationScheme
                    .valueOf(getRndInt() % AlternateTransactionClassificationScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            alternateIdDescription = AlternateTransactionClassificationScheme.NULL;
        }
    }

    @Override
    public String getAlternateTransactionId() {
        return alternateTransactionId;
    }

    @Override
    public SystemInstanceId getAlternateIdSourceSystemId() {
        return alternateIdSourceSystemId;
    }

    @Override
    public AlternateTransactionClassificationScheme getAlternateIdDescription() {
        return alternateIdDescription;
    }

    @Override
    public boolean hasUniqueScheme() {
        return uniqueScheme;
    }
}
