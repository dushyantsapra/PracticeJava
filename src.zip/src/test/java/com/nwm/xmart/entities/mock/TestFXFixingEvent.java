package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestFXFixingEvent implements FXFixingEvent {
    private CurrencyId currency1Id;
    private CurrencyId currency2Id;
    private Currency currency1;
    private Currency currency2;
    private QuoteBasis currencyQuoteBasis;
    private String legIdentifier;
    private BigDecimal fxRate;

    public TestFXFixingEvent() {
        currency1Id = new TestCurrencyId();
        currency2Id = new TestCurrencyId();
        currency1 = new TestCurrency();
        currency2 = new TestCurrency();
        try {
            currencyQuoteBasis = QuoteBasis.valueOf(getRndInt() % QuoteBasis.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("QuoteBasis creation failed Using default value" + e.getMessage());
            currencyQuoteBasis = QuoteBasis.NULL;
        }
        legIdentifier = getRandomString();
        fxRate = new BigDecimal(getRndInt());
    }

    @Override
    public CurrencyId getCurrency1Id() {
        return currency1Id;
    }

    @Override
    public CurrencyId getCurrency2Id() {
        return currency2Id;
    }

    @Override
    public Currency getCurrency1() {
        return currency1;
    }

    @Override
    public Currency getCurrency2() {
        return currency2;
    }

    @Override
    public QuoteBasis getCurrencyQuoteBasis() {
        return currencyQuoteBasis;
    }

    @Override
    public String getLegIdentifier() {
        return legIdentifier;
    }

    @Override
    public BigDecimal getFxRate() {
        return fxRate;
    }
}
