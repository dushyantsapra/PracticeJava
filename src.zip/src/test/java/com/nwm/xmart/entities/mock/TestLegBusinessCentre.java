package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.BusinessCentreRole;
import com.rbs.odc.access.domain.DayCountConvention;
import com.rbs.odc.access.domain.LegBusinessCentre;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestLegBusinessCentre implements LegBusinessCentre {

    private String businessCentre;
    private BusinessCentreRole businessCentreRole;
    private DayCountConvention businessDayConvention;

    public TestLegBusinessCentre() {
        businessCentre = getRandomString();

        try {
            businessCentreRole = BusinessCentreRole.valueOf(getRndInt() % BusinessCentreRole.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            businessCentreRole = BusinessCentreRole.NULL;
        }
        try {
            businessDayConvention = DayCountConvention.valueOf(getRndInt() % DayCountConvention.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            businessDayConvention = DayCountConvention.NULL;
        }
    }

    @Override
    public String getBusinessCentre() {
        return businessCentre;
    }

    @Override
    public BusinessCentreRole getBusinessCentreRole() {
        return businessCentreRole;
    }

    @Override
    public DayCountConvention getBusinessDayConvention() {
        return businessDayConvention;
    }

    @Override
    public int compareTo(LegBusinessCentre o) {
        return 0;
    }
}
