package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.CompoundUnderlier;
import com.rbs.odc.access.domain.CompoundUnderlierMember;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndDouble;

public class TestCompoundUnderlier implements CompoundUnderlier {
    BigDecimal attachmentPoint = new BigDecimal(getRndDouble());
    BigDecimal exhaustionPoint = new BigDecimal(getRndDouble());
    private Collection<CompoundUnderlierMember> compoundUnderlierMembers = new ArrayList<>();

    public TestCompoundUnderlier() {
        compoundUnderlierMembers.add(new TestCompoundUnderlierMember());
        compoundUnderlierMembers.add(new TestCompoundUnderlierMember());
    }

    @Override
    public Collection<CompoundUnderlierMember> getCompoundUnderlierMembers() {
        return compoundUnderlierMembers;
    }

    @Override
    public BigDecimal getAttachmentPoint() {
        return attachmentPoint;
    }

    @Override
    public BigDecimal getExhaustionPoint() {
        return exhaustionPoint;
    }
}
