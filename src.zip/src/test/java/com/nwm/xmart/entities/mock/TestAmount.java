package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Amount;
import com.rbs.odc.access.domain.Currency;
import com.rbs.odc.access.domain.CurrencyId;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndDouble;

public class TestAmount implements Amount {

    BigDecimal value = new BigDecimal(getRndDouble());
    private CurrencyId currencyId = new TestCurrencyId();

    @Override
    public Currency getCurrency() {
        return null;
    }

    @Override
    public BigDecimal getValue() {
        return value;
    }

    @Override
    public CurrencyId getCurrencyId() {
        return currencyId;
    }

    @Override
    public Amount add(Amount amount) {
        return null;
    }

    @Override
    public boolean isMixedCurrency() {
        return false;
    }

    @Override
    public Amount negate() {
        return null;
    }

    @Override
    public boolean isNegative() {
        return false;
    }

    @Override
    public Amount absolute() {
        return null;
    }

    @Override
    public boolean isZero() {
        return false;
    }
}
