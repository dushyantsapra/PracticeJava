package com.nwm.xmart.entities.crm;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.crm.entity.userRole.UserRole;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEventType;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRandomString;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.when;

public class CRMUserRoleTest {
    @Mock
    CRMSourceEvent crmSourceEvent;

    private MappingNode mappingHierarchy;

    private UserRole userRole;

    private XmartGenericSet xmartSet;

    private int topicId = getRndInt();

    private void setUpCrmUserRole() {
        userRole = new UserRole();
        userRole.setCaseAccessForAccountOwner(getRandomString());
        userRole.setContactAccessForAccountOwner(getRandomString());
        userRole.setDeveloperName(getRandomString());
        userRole.setId(getRandomString());
        userRole.setLastModifiedById(getRandomString());
        userRole.setLastModifiedDate(getRandomString());
        userRole.setMayForecastManagerShare(getRndInt() % 2 == 0);
        userRole.setName(getRandomString());
        userRole.setOpportunityAccessForAccountOwner(getRandomString());
        userRole.setParentRoleId(getRandomString());
        userRole.setPortalType(getRandomString());
        userRole.setRollupDescription(getRandomString());
        userRole.setSystemModstamp(getRandomString());
    }

    /*
    Update
    @expectedMatchCount
    if more Attribute check condition is been added
    * */

    private void verifyCrmUserRoleMapping(List<XmartMappedEntity> xmartCrmUserRoleEntities) {
        XmartMappedEntity xmartMappedEntity = xmartCrmUserRoleEntities.get(0);
        final AtomicInteger count = new AtomicInteger();

        int expectedMatchCount = 8;

        xmartMappedEntity.getAttributes().forEach(xmartMappedAttribute -> {
            if ("developerName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(userRole.getDeveloperName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("roleId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(userRole.getId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedById".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(userRole.getLastModifiedById(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("lastModifiedDate".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(userRole.getLastModifiedDate(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }

            if ("roleName".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(userRole.getName(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("parentRoleId".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(userRole.getParentRoleId(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("rollupDescription".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(userRole.getRollupDescription(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
            if ("systemModstamp".equals(xmartMappedAttribute.getAttributeName())) {
                assertEquals(userRole.getSystemModstamp(), (String) xmartMappedAttribute.getAttributeValue());
                count.incrementAndGet();
                return;
            }
        });

        if (count.get() != expectedMatchCount) {
            Assert.fail("Count doesn't match the Expected Count");
        }
    }

    @BeforeEach
    void setUp() throws XmartException {
        MockitoAnnotations.initMocks(this);
        mappingHierarchy = MappingNodeFactory.ReadResourceFile("/mapping_config/CRM-event.csv");
        setUpCrmUserRole();
        when(crmSourceEvent.getCrmSourceEventType()).thenReturn(CRMSourceEventType.UserRole);
        when(crmSourceEvent.getUserRole()).thenReturn(userRole);
    }

    @Test
    void testCRMUserRole() throws XmartException {
        xmartSet = new XmartCRMSourceEventSet();
        xmartSet.addStreamEvent(crmSourceEvent, topicId, mappingHierarchy);

        List<XmartMappedEntity> xmartCrmUserRoleEntities = (List<XmartMappedEntity>) xmartSet
                .getRequiredEntities("XmartCrmUserRoles");
        verifyCrmUserRoleMapping(xmartCrmUserRoleEntities);
    }
}
