package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.Currency;
import com.rbs.odc.access.domain.CurrencyId;
import com.rbs.odc.access.domain.Dividend;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndDouble;

public class TestDividend implements Dividend {
    private BigDecimal percentage = new BigDecimal(getRndDouble());
    private Currency currency;
    private CurrencyId currencyId = new TestCurrencyId();

    @Override
    public BigDecimal getPercentage() {
        return percentage;
    }

    @Override
    public Currency getCurrency() {
        return currency;
    }

    @Override
    public CurrencyId getCurrencyId() {
        return currencyId;
    }
}
