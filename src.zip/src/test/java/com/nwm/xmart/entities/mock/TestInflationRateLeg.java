package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestInflationRateLeg implements InflationRateLeg {
    private String inflationIndexLevel;
    private String interpolationMethod;
    private String inflationRateSource;
    private BusinessDate baseIndexDate;
    private BigDecimal inflationRate;
    private String rpiProductIdentifier;
    private RoundingDirection roundingDirection;
    private Integer roundingPrecision;
    private NegativeInterestRateTreatmentScheme negativeRateTreatment;
    private String mainRatePublication;
    private BigDecimal rateMultiplier;

    public TestInflationRateLeg() {
        inflationIndexLevel = getRandomString();
        interpolationMethod = getRandomString();
        inflationRateSource = getRandomString();
        baseIndexDate = new TestBusinessDate();
        inflationRate = new BigDecimal(getRndInt());
        rpiProductIdentifier = getRandomString();
        try {
            roundingDirection = RoundingDirection.valueOf(getRndInt() % RoundingDirection.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            roundingDirection = RoundingDirection.NULL;
        }
        roundingPrecision = getRndInt();

        try {
            negativeRateTreatment = NegativeInterestRateTreatmentScheme
                    .valueOf(getRndInt() % NegativeInterestRateTreatmentScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            negativeRateTreatment = NegativeInterestRateTreatmentScheme.NULL;
        }
        mainRatePublication = getRandomString();
        rateMultiplier = new BigDecimal(getRndInt());
    }

    @Override
    public String getInflationIndexLevel() {
        return inflationIndexLevel;
    }

    @Override
    public String getInterpolationMethod() {
        return interpolationMethod;
    }

    @Override
    public String getInflationRateSource() {
        return inflationRateSource;
    }

    @Override
    public BusinessDate getBaseIndexDate() {
        return baseIndexDate;
    }

    @Override
    public BigDecimal getInflationRate() {
        return inflationRate;
    }

    @Override
    public String getRpiProductIdentifier() {
        return rpiProductIdentifier;
    }

    @Override
    public RoundingDirection getRoundingDirection() {
        return roundingDirection;
    }

    @Override
    public Integer getRoundingPrecision() {
        return roundingPrecision;
    }

    @Override
    public NegativeInterestRateTreatmentScheme getNegativeRateTreatment() {
        return negativeRateTreatment;
    }

    @Override
    public String getMainRatePublication() {
        return mainRatePublication;
    }

    @Override
    public BigDecimal getRateMultiplier() {
        return rateMultiplier;
    }
}
