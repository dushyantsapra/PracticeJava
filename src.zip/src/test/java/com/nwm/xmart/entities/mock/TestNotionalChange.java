package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.util.Date;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestNotionalChange implements NotionalChange {
    private Date agreementDateTime;
    private Amount changeAmount;
    private BusinessDate agreementDate;
    private AmountType amountType;

    public TestNotionalChange() {
        changeAmount = new TestAmount();
        agreementDateTime = getRandomDate();
        agreementDate = new TestBusinessDate();

        try {
            amountType = AmountType.valueOf(getRndInt() % AmountType.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("TestNotionalChange creation failed Using default value" + e.getMessage());
            amountType = AmountType.NULL;
        }
    }

    @Override
    public Date getAgreementDateTime() {
        return agreementDateTime;
    }

    @Override
    public BusinessDate getAgreementDate() {
        return agreementDate;
    }

    @Override
    public Amount getChangeAmount() {
        return changeAmount;
    }

    @Override
    public AmountType getAmountType() {
        return amountType;
    }
}
