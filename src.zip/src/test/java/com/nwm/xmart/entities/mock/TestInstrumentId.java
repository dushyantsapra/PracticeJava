package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.InstrumentId;
import com.rbs.odc.access.domain.SecurityInstrumentIdentifierClassificationScheme;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestInstrumentId implements InstrumentId {
    private SecurityInstrumentIdentifierClassificationScheme instrumentScheme;
    private String instrumentId = getRandomString();

    TestInstrumentId() {
        try {
            instrumentScheme = SecurityInstrumentIdentifierClassificationScheme
                    .valueOf(getRndInt() % SecurityInstrumentIdentifierClassificationScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            instrumentScheme = SecurityInstrumentIdentifierClassificationScheme.NULL;
        }
    }

    @Override
    public SecurityInstrumentIdentifierClassificationScheme getInstrumentScheme() {
        return instrumentScheme;
    }

    @Override
    public String getInstrumentId() {
        return instrumentId;
    }

    @Override
    public int compareTo(InstrumentId o) {
        return 0;
    }
}
