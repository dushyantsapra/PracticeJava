package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.IncreaseDecreaseScheme;
import com.rbs.odc.access.domain.QuantityMovement;
import com.rbs.odc.access.domain.QuantityUnitOfMeasure;
import com.rbs.odc.access.domain.UnknownEnumerationValueException;

import java.math.BigDecimal;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestQuantityMovement implements QuantityMovement {
    private String legIdentifier;
    private BigDecimal resultantQuantity;
    private BigDecimal stepQuantity;
    private QuantityUnitOfMeasure quantityUnitOfMeasure;
    private IncreaseDecreaseScheme stepDirection;

    public TestQuantityMovement() {
        legIdentifier = getRandomString();
        resultantQuantity = new BigDecimal(getRndInt());
        stepQuantity = new BigDecimal(getRndInt());
        try {
            quantityUnitOfMeasure = QuantityUnitOfMeasure
                    .valueOf(getRndInt() % QuantityUnitOfMeasure.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("QuantityUnitOfMeasure creation failed Using default value" + e.getMessage());
            quantityUnitOfMeasure = QuantityUnitOfMeasure.NULL;
        }
        try {
            stepDirection = IncreaseDecreaseScheme.valueOf(getRndInt() % IncreaseDecreaseScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("IncreaseDecreaseScheme creation failed Using default value" + e.getMessage());
            stepDirection = IncreaseDecreaseScheme.NULL;
        }
    }

    @Override
    public String getLegIdentifier() {
        return legIdentifier;
    }

    @Override
    public BigDecimal getResultantQuantity() {
        return resultantQuantity;
    }

    @Override
    public BigDecimal getStepQuantity() {
        return stepQuantity;
    }

    @Override
    public QuantityUnitOfMeasure getQuantityUnitOfMeasure() {
        return quantityUnitOfMeasure;
    }

    @Override
    public IncreaseDecreaseScheme getStepDirection() {
        return stepDirection;
    }
}
