package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.BasketWeight;
import com.rbs.odc.access.domain.CompoundUnderlierMember;
import com.rbs.odc.access.domain.Instrument;
import com.rbs.odc.access.domain.InstrumentId;

public class TestCompoundUnderlierMember implements CompoundUnderlierMember {

    InstrumentId instrumentId;
    BasketWeight basketWeight;

    public TestCompoundUnderlierMember() {
        instrumentId = new TestInstrumentId();
        basketWeight = new TestBasketWeight();
    }

    @Override
    public InstrumentId getInstrumentId() {
        return instrumentId;
    }

    @Override
    public Instrument getInstrument() {
        return null;
    }

    @Override
    public BasketWeight getBasketWeight() {
        return basketWeight;
    }
}
