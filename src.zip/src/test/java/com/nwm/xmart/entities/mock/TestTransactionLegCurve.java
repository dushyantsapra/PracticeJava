package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;
import com.rbs.odc.core.domain.TransactionLegCurveImpl;

import java.util.Date;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestTransactionLegCurve extends TransactionLegCurveImpl {
    private Curve curve;
    private String curveId;
    private String curveName;
    private CurveRole curveRole;
    private CurrencyId curveCurrencyId;
    private CurrencyId curveCcyId;
    private String projectionType;
    private Currency curveCurrency;
    private String curveOverrideReason;
    private String curveOverrideApprover;
    private Date curveOverrideApprovalDateTime;
    private String curveOverrideApprovalComments;

    public TestTransactionLegCurve() {
        this.curve = new TestCurve();
        curveId = getRandomString();
        curveName = getRandomString();

        try {
            curveRole = CurveRole.valueOf(getRndInt() % CurveRole.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("CurveRole creation failed Using default value" + e.getMessage());
            curveRole = CurveRole.NULL;
        }
        curveCurrencyId = new TestCurrencyId();
        curveCcyId = new TestCurrencyId();
        projectionType = getRandomString();
        curveOverrideReason = getRandomString();
        curveOverrideApprover = getRandomString();
        curveOverrideApprovalDateTime = getRandomDate();
        curveOverrideApprovalComments = getRandomString();
    }

    public CurrencyId getCurveCcyId() {
        return curveCcyId;
    }

    @Override
    public Curve getCurve() {
        return curve;
    }

    @Override
    public String getCurveId() {
        return curveId;
    }

    @Override
    public String getCurveName() {
        return curveName;
    }

    @Override
    public CurveRole getCurveRole() {
        return curveRole;
    }

    @Override
    public CurrencyId getCurveCurrencyId() {
        return curveCurrencyId;
    }

    @Override
    public String getProjectionType() {
        return projectionType;
    }

    @Override
    public Currency getCurveCurrency() {
        return curveCurrency;
    }

    @Override
    public String getCurveOverrideReason() {
        return curveOverrideReason;
    }

    @Override
    public String getCurveOverrideApprover() {
        return curveOverrideApprover;
    }

    @Override
    public Date getCurveOverrideApprovalDateTime() {
        return curveOverrideApprovalDateTime;
    }

    @Override
    public String getCurveOverrideApprovalComments() {
        return curveOverrideApprovalComments;
    }
}
