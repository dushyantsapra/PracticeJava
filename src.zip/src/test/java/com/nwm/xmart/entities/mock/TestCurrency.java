package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.*;

public class TestCurrency implements Currency {
    private String name;
    private Integer decimalPrecision;
    private StaleReferenceDataState staleReferenceDataState;
    private boolean active;
    private boolean hierarchicallyBad;
    private BusinessDate effectiveDate;
    private CurrencyId id;

    TestCurrency() {
        name = getRandomString();
        decimalPrecision = getRndInt();
        active = getRndInt() % 2 == 1;
        hierarchicallyBad = getRndInt() % 2 == 1;
        effectiveDate = new TestBusinessDate();
        id = new TestCurrencyId();

        try {
            staleReferenceDataState = StaleReferenceDataState
                    .valueOf(getRndInt() % StaleReferenceDataState.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("creation failed Using default value" + e.getMessage());
            staleReferenceDataState = StaleReferenceDataState.NULL;
        }
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public Integer getDecimalPrecision() {
        return decimalPrecision;
    }

    @Override
    public StaleReferenceDataState getStaleReferenceDataState() {
        return staleReferenceDataState;
    }

    @Override
    public boolean isActive() {
        return active;
    }

    @Override
    public boolean isHierarchicallyBad() {
        return hierarchicallyBad;
    }

    @Override
    public BusinessDate getEffectiveDate() {
        return effectiveDate;
    }

    @Override
    public CurrencyId getId() {
        return id;
    }
}
