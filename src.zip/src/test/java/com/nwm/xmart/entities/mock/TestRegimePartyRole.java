package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.*;

import java.util.ArrayList;
import java.util.Collection;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.logger;

public class TestRegimePartyRole implements RegimePartyRole {
    private TradingCounterpartyId tradingCounterpartyId;
    private TradingCounterparty tradingCounterparty;
    private TransactionRoleScheme reportingRoleScheme;
    private Collection<PartyReportObligation> partyReportObligations = new ArrayList<>();
    private TradingCapacityScheme tradingCapacity;
    private TransactionRoleScheme reportableTradingRole;

    public TestRegimePartyRole() {
        tradingCounterpartyId = new TestTradingCounterpartyId();
        try {
            tradingCapacity = TradingCapacityScheme.valueOf(getRndInt() % TradingCapacityScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            tradingCapacity = TradingCapacityScheme.Any_Other_Capacity;
        }
        try {
            reportingRoleScheme = TransactionRoleScheme
                    .valueOf(getRndInt() % TransactionRoleScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            reportingRoleScheme = TransactionRoleScheme.NULL;
        }

        partyReportObligations.add(new TestPartyReportObligation());
        partyReportObligations.add(new TestPartyReportObligation());

        try {
            reportableTradingRole = TransactionRoleScheme
                    .valueOf(getRndInt() % TransactionRoleScheme.values().size() - 1);
        } catch (UnknownEnumerationValueException e) {
            logger.warn("Object creation failed Using default value" + e.getMessage());
            reportableTradingRole = TransactionRoleScheme.NULL;
        }
    }

    @Override
    public TradingCounterpartyId getTradingCounterpartyId() {
        return tradingCounterpartyId;
    }

    @Override
    public TradingCounterparty getTradingCounterparty() {
        return tradingCounterparty;
    }

    @Override
    public TransactionRoleScheme getReportingRoleScheme() {
        return reportingRoleScheme;
    }

    @Override
    public Collection<PartyReportObligation> getPartyReportObligations() {
        return partyReportObligations;
    }

    @Override
    public TradingCapacityScheme getTradingCapacity() {
        return tradingCapacity;
    }

    @Override
    public TransactionRoleScheme getReportableTradingRole() {
        return reportableTradingRole;
    }
}
