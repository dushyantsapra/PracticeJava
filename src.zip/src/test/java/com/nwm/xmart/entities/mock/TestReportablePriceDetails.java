package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.ReportablePriceDetails;
import com.rbs.odc.access.domain.UnitPrice;

public class TestReportablePriceDetails implements ReportablePriceDetails {
    private UnitPrice reportablePrice;
    private Boolean priceNotAvailable;
    private Boolean priceNotApplicable;

    TestReportablePriceDetails() {
        reportablePrice = new TestUnitPrice();
        priceNotAvailable = false;
        priceNotApplicable = false;
    }


    @Override
    public UnitPrice getReportablePrice() {
        return reportablePrice;
    }

    @Override
    public Boolean isPriceNotApplicable() {
        return priceNotApplicable;
    }

    @Override
    public Boolean isPriceNotAvailable() {
        return priceNotAvailable;
    }
}
