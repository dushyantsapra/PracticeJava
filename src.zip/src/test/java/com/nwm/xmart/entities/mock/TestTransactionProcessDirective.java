package com.nwm.xmart.entities.mock;

import com.rbs.odc.access.domain.TransactionProcessDirective;
import com.rbs.odc.access.domain.TransactionProcessRolePlayer;

import java.util.Arrays;
import java.util.Collection;

import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndDouble;
import static com.nwm.xmart.entities.XmartEntitiesBaseTest.getRndInt;

public class TestTransactionProcessDirective implements TransactionProcessDirective {
    private String processDirectiveType;
    private String additionalComments;
    private Boolean isConfirmationRequired;
    private Boolean isFoConfirmationReviewRequired;
    private Boolean isManualConfirmationRequired;
    private Collection<TransactionProcessRolePlayer> transactionProcessRolePlayers;
    private Boolean isConfirmLegsIndividually;

    public TestTransactionProcessDirective() {
        processDirectiveType = "" + getRndInt() + getRndDouble();
        additionalComments = "" + getRndInt() + getRndDouble();
        isConfirmationRequired = getRndInt() % 2 == 2;
        isFoConfirmationReviewRequired = getRndInt() % 2 == 2;
        isManualConfirmationRequired = getRndInt() % 2 == 2;
        transactionProcessRolePlayers = Arrays
                .asList(new TestTransactionProcessRolePlayer(), new TestTransactionProcessRolePlayer());
        isConfirmLegsIndividually = getRndInt() % 2 == 2;
    }

    @Override
    public String getProcessDirectiveType() {
        return processDirectiveType;
    }

    @Override
    public String getAdditionalComments() {
        return additionalComments;
    }

    @Override
    public Boolean isConfirmationRequired() {
        return isConfirmationRequired;
    }

    @Override
    public Boolean isFoConfirmationReviewRequired() {
        return isFoConfirmationReviewRequired;
    }

    @Override
    public Boolean isManualConfirmationRequired() {
        return isManualConfirmationRequired;
    }

    @Override
    public Collection<TransactionProcessRolePlayer> getTransactionProcessRolePlayers() {
        return transactionProcessRolePlayers;
    }

    @Override
    public Boolean isConfirmLegsIndividually() {
        return isConfirmLegsIndividually;
    }

    @Override
    public int compareTo(TransactionProcessDirective o) {
        return 0;
    }
}
