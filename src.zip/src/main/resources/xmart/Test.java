package com.nwm.xmart;

public class Test {
    public static void main(String[] args) {
        String abc = "Hello";

        abc[2] = (int)abc.charAt(2) + 2;
        System.out.println(abc);
    }
}
