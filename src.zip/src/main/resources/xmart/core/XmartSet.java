package com.nwm.xmart.core;

public interface XmartSet extends BindObject {
    /**
     * To get the window key for windowing done by flink.
     * Implementing classes should provide key based on the implementation.
     *
     * @return key to be used for windowing
     */
    Long getWindowKey();
}
