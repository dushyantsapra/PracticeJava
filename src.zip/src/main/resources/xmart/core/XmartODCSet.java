package com.nwm.xmart.core;

import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.nwm.xmart.streaming.source.df.event.StreamEvent;
import com.rbs.odc.access.domain.HasId;
import com.rbs.odc.access.domain.Id;
import com.rbs.odc.core.domain.ODCValue;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoField;

/**
 * Super class providing core functionality for data received from ODC thorugh kafka
 *
 * @param <IdType>           {@link Id} type viz. {@link com.rbs.odc.access.domain.TransactionId} {@link com.rbs.odc.access.domain.CashflowsId}
 * @param <DomainObjectType> Implementing type of the ODC attribute viz. {{@link com.rbs.odc.access.domain.Transaction}} {{@link com.rbs.odc.access.domain.Cashflows}}
 */
public abstract class XmartODCSet<IdType extends Id, DomainObjectType extends HasId<? extends IdType>>
        implements XmartSet {

    /**
     * Simplified version of the {XmartODCSet{@link #addOdcAttribute(String, int, int, long, long, HasId, DataFabricStreamEvent, Long)}}
     * method. This does not need as much parameters. Can derive attritbutes from the supplied dfStreamEvent
     *
     * @param dfStreamEvent {@link DataFabricStreamEvent} for error monitoring
     * @param sourceTopicId ID of the source topic that this record was read from
     * @param domainObject  The ODC object to map to {@link com.nwm.xmart.entities.common.XmartEntity}
     *
     * @throws XmartException because every other method does, so this should not feel deprived.
     */
    public void addOdcAttribute(DataFabricStreamEvent<ODCValue<IdType, DomainObjectType>> dfStreamEvent,
            int sourceTopicId, DomainObjectType domainObject, Long odcVersion) throws XmartException {
        addOdcAttribute(dfStreamEvent.getTopic(), dfStreamEvent.getPartition(), sourceTopicId,
                dfStreamEvent.getStreamPosition(), dfStreamEvent.getTimestamp(), domainObject, dfStreamEvent,
                odcVersion);
    }

    /**
     * Method called during the ODC => Xmart mapper process to extract the required attributes.
     * <br>Extending classes provide their custom implementation.
     *
     * @param sourceTopic
     * @param sourcePartition
     * @param sourceTopicId
     * @param sourcePosition
     * @param sourceTimestamp
     * @param domainObject
     * @param dfStreamEvent
     *
     * @throws XmartException
     */
    //TODO Sending six parameters from dfStreamEvent and the event
    public abstract void addOdcAttribute(String sourceTopic, int sourcePartition, int sourceTopicId,
            long sourcePosition, long sourceTimestamp, DomainObjectType domainObject,
            DataFabricStreamEvent<ODCValue<IdType, DomainObjectType>> dfStreamEvent, Long odcVersion)
            throws XmartException;

    /**
     * Creates document key to be used in the different mapping
     *
     * @param sourcePartition Source partition of kafka
     * @param sourceTopicId   Source topic id of kafka
     * @param sourcePosition  Source postition of this message kafka
     * @param sourceTimestamp timestamp of this message kafka
     *
     * @return documetn key
     *
     * <p>
     * Document Key Format :
     * YY – 2 digits for Year
     * DOY - 3 digits for Day of the year
     * TTT – 3 digit for identifying the job (used as the last three digits of the JOB Name)
     * PP – 2 digits from Kafka partition
     * Offset - 9 digits from the offset ID
     * </p>
     */
    protected long generateDocumentKey(int sourcePartition, int sourceTopicId, long sourcePosition,
            long sourceTimestamp) {
        StringBuilder docKeyStr = new StringBuilder(19);
        String docKeyComp;
        LocalDateTime consumeTime = LocalDateTime
                .ofInstant(Instant.ofEpochMilli(sourceTimestamp), ZoneId.systemDefault());
        docKeyStr.setLength(0);
        docKeyComp = String.format("%02d", consumeTime.get(ChronoField.YEAR));
        docKeyStr.insert(0, docKeyComp.substring(docKeyComp.length() - 2));
        docKeyComp = String.format("%03d", consumeTime.getDayOfYear());
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 3));
        docKeyComp = String.format("%03d", sourceTopicId);
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 3));
        docKeyComp = String.format("%02d", sourcePartition);
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 2));
        docKeyComp = String.format("%09d", sourcePosition);
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 9));
        return Long.parseLong(docKeyStr.toString());
    }
}
