package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;

public class XmartPrincipalMovementEvent extends XmartEntity {

    private static final long serialVersionUID = -4538532824405786808L;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String sourceSystemEventId;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String eventType;

    @XmartAttribute
    private Boolean isInterestRecapitalized;

    @XmartAttribute
    private BigDecimal resultantAmountValue;

    @XmartAttribute
    private BigDecimal stepAmount;

    @XmartAttribute
    private String legIdentifier;

    @XmartAttribute
    private String resultantAmountCurrencyCode;

    @XmartAttribute
    private String principalType;

    @XmartAttribute
    private String stepDirection;

    public XmartPrincipalMovementEvent(long documentKey, String sourceSystemEventId, String eventType)
            throws XmartException {
        super(documentKey);
        this.sourceSystemEventId = sourceSystemEventId;
        this.eventType = eventType;
    }

    public Boolean getInterestRecapitalized() {
        return isInterestRecapitalized;
    }

    public void setInterestRecapitalized(Boolean interestRecapitalized) {
        isInterestRecapitalized = interestRecapitalized;
    }

    public BigDecimal getResultantAmountValue() {
        return resultantAmountValue;
    }

    public void setResultantAmountValue(BigDecimal resultantAmountValue) {
        this.resultantAmountValue = resultantAmountValue;
    }

    public BigDecimal getStepAmount() {
        return stepAmount;
    }

    public void setStepAmount(BigDecimal stepAmount) {
        this.stepAmount = stepAmount;
    }

    public String getSourceSystemEventId() {
        return sourceSystemEventId;
    }

    public String getEventType() {
        return eventType;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public void setLegIdentifier(String legIdentifier) {
        this.legIdentifier = legIdentifier;
    }

    public String getResultantAmountCurrencyCode() {
        return resultantAmountCurrencyCode;
    }

    public void setResultantAmountCurrencyCode(String resultantAmountCurrencyCode) {
        this.resultantAmountCurrencyCode = resultantAmountCurrencyCode;
    }

    public String getPrincipalType() {
        return principalType;
    }

    public void setPrincipalType(String principalType) {
        this.principalType = principalType;
    }

    public String getStepDirection() {
        return stepDirection;
    }

    public void setStepDirection(String stepDirection) {
        this.stepDirection = stepDirection;
    }
}
