package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.AgreementTransactionContext;
import com.rbs.odc.access.domain.ExceptionalTermsDetail;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static java.util.Objects.nonNull;

public class XmartExceptionalTermsDetails
        extends XmartOdcEntityCollection<Transaction, AgreementTransactionContext, XmartExceptionalTermsDetail> {
    private static final long serialVersionUID = 6599132844429859903L;
    private static final Logger logger = LoggerFactory.getLogger(XmartExceptionalTermsDetails.class);

    public XmartExceptionalTermsDetails(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<AgreementTransactionContext> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getAgreementTransactionContext(), logger,
                "AgreementTransactionContexts not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(AgreementTransactionContext agreementTransactionContext) throws XmartException {

        for (ExceptionalTermsDetail exceptionalTermsDetail : nullCollToEmpty(
                agreementTransactionContext.getExceptionalTermsDetail())) {
            XmartExceptionalTermsDetail xmartExceptionalTermsDetail = new XmartExceptionalTermsDetail(getDocumentKey());
            xmartExceptionalTermsDetail.setAgreementTransactionContextId(agreementTransactionContext.getId());
            if (nonNull(exceptionalTermsDetail)) {
                xmartExceptionalTermsDetail
                        .setExceptionalTermsDetail(exceptionalTermsDetail.getExceptionalTermsDetail());
            }

            addEntity(xmartExceptionalTermsDetail);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
