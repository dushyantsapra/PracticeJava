package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;

public class XmartForwardFeature extends XmartEntity {

    private static final long serialVersionUID = 2548939953462242268L;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String legIdentifier;
    @XmartAttribute
    private String optionType;
    @XmartAttribute
    private String strikePriceCurrencyCode;
    @XmartAttribute
    private String accumulatorType;
    @XmartAttribute
    private BigDecimal strikePriceValue;
    @XmartAttribute
    private BigDecimal gearingFactor;
    @XmartAttribute
    private BigDecimal knockOutTriggerLevel;
    @XmartAttribute
    private Integer maximumNumberOfTradingDays;
    @XmartAttribute
    private Integer numberOfDailyShares;

    protected XmartForwardFeature(Long documentKey, String legIdentifier) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getOptionType() {
        return optionType;
    }

    public void setOptionType(String optionType) {
        this.optionType = optionType;
    }

    public String getStrikePriceCurrencyCode() {
        return strikePriceCurrencyCode;
    }

    public void setStrikePriceCurrencyCode(String strikePriceCurrencyCode) {
        this.strikePriceCurrencyCode = strikePriceCurrencyCode;
    }

    public String getAccumulatorType() {
        return accumulatorType;
    }

    public void setAccumulatorType(String accumulatorType) {
        this.accumulatorType = accumulatorType;
    }

    public BigDecimal getStrikePriceValue() {
        return strikePriceValue;
    }

    public void setStrikePriceValue(BigDecimal strikePriceValue) {
        this.strikePriceValue = strikePriceValue;
    }

    public BigDecimal getGearingFactor() {
        return gearingFactor;
    }

    public void setGearingFactor(BigDecimal gearingFactor) {
        this.gearingFactor = gearingFactor;
    }

    public BigDecimal getKnockOutTriggerLevel() {
        return knockOutTriggerLevel;
    }

    public void setKnockOutTriggerLevel(BigDecimal knockOutTriggerLevel) {
        this.knockOutTriggerLevel = knockOutTriggerLevel;
    }

    public Integer getMaximumNumberOfTradingDays() {
        return maximumNumberOfTradingDays;
    }

    public void setMaximumNumberOfTradingDays(Integer maximumNumberOfTradingDays) {
        this.maximumNumberOfTradingDays = maximumNumberOfTradingDays;
    }

    public Integer getNumberOfDailyShares() {
        return numberOfDailyShares;
    }

    public void setNumberOfDailyShares(Integer numberOfDailyShares) {
        this.numberOfDailyShares = numberOfDailyShares;
    }
}
