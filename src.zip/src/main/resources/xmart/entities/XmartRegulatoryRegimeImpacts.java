package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.*;
import com.rbs.odc.core.domain.RegulatoryRegimeImpactImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.XmartOdcUtil.getCurrencyCode;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

/**
 * <p>
 * This class provides an Entity Collection of Regulatory Regime Impacts extending the XmartOdcEntityCollection class
 * </p>
 * <p>
 * The class provides the mechanism to map ODC RegulatoryRegimeImpact objects into XmartRegulatoryRegimeImpact class and
 * holds the mapped XMart object in the entity collection.
 * </p>
 *
 * @author aslammh on 21/11/17.
 */
public class XmartRegulatoryRegimeImpacts
        extends XmartOdcEntityCollection<Transaction, RegulatoryRegimeImpact, XmartRegulatoryRegimeImpact> {

    private static final long serialVersionUID = -4762844845180934933L;
    private static final Logger logger = LoggerFactory.getLogger(XmartRegulatoryRegimeImpacts.class);

    public XmartRegulatoryRegimeImpacts(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<RegulatoryRegimeImpact> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getRegulatoryRegimeImpact(), logger,
                "RegulatoryRegimeImpact not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(RegulatoryRegimeImpact regulatoryRegimeImpact) throws XmartException {

        XmartRegulatoryRegimeImpact xmartRegulatoryRegimeImpact = new XmartRegulatoryRegimeImpact(getDocumentKey());

        xmartRegulatoryRegimeImpact.setRegimeImpact(regulatoryRegimeImpact.getRegimeImpact());
        xmartRegulatoryRegimeImpact.setRegimeImpactId(regulatoryRegimeImpact.getRegimeImpactId());
        xmartRegulatoryRegimeImpact.setRegulatoryAuthority(regulatoryRegimeImpact.getRegulatoryAuthority());
        xmartRegulatoryRegimeImpact.setRegimeImpactType(getRegimeImpactType(regulatoryRegimeImpact));
        xmartRegulatoryRegimeImpact.setOrderTransmissionConditionsNotSatisfied(
                regulatoryRegimeImpact.isOrderTransmissionConditionsNotSatisfied());
        xmartRegulatoryRegimeImpact
                .setCommodityDerivativeIndicator(regulatoryRegimeImpact.isCommodityDerivativeIndicator());
        Amount upFrontFeeAmount = regulatoryRegimeImpact.getAggregatedUpfrontFeeAmount();
        if (nonNull(upFrontFeeAmount)) {
            xmartRegulatoryRegimeImpact
                    .setAggregatedUpfrontFeeAmountCurrencyCode(getCurrencyCode(upFrontFeeAmount.getCurrencyId()));
            xmartRegulatoryRegimeImpact.setAggregatedUpfrontFeeAmountValue(upFrontFeeAmount.getValue());
        }

        xmartRegulatoryRegimeImpact.setRegulatoryRegimeImpactId(regulatoryRegimeImpact.getId());
        xmartRegulatoryRegimeImpact.setLegIdentifier(regulatoryRegimeImpact.getLegIdentifier());

        NotionalChange notionalChange = regulatoryRegimeImpact.getNotionalChange();
        if (nonNull(notionalChange)) {
            xmartRegulatoryRegimeImpact.setAgreementDate(convertBusinessDate(notionalChange.getAgreementDate()));
            xmartRegulatoryRegimeImpact.setAgreementDateTime(notionalChange.getAgreementDateTime());
            xmartRegulatoryRegimeImpact.setNotionalChangeAmountType(getStr(notionalChange.getAmountType()));
            Amount changeAmount = notionalChange.getChangeAmount();
            if (nonNull(changeAmount)) {
                xmartRegulatoryRegimeImpact
                        .setNotionalChangeCurrencyCode(getCurrencyCode(changeAmount.getCurrencyId()));
                xmartRegulatoryRegimeImpact.setNotionalChangeValue(changeAmount.getValue());
            }
        }

        xmartRegulatoryRegimeImpact.setNotionalChangeType(getStr(regulatoryRegimeImpact.getNotionalChangeType()));

        PackageDetails packageDetails = regulatoryRegimeImpact.getPackageDetails();
        if (nonNull(packageDetails)) {
            xmartRegulatoryRegimeImpact.setComponentNumber(packageDetails.getComponentNumber());
            xmartRegulatoryRegimeImpact.setConstituentCount(packageDetails.getConstituentCount());

            UnitPrice packagePrice = packageDetails.getPackagePrice();
            if (nonNull(packagePrice)) {
                Amount amount = packagePrice.getAmount();
                if (nonNull(amount)) {
                    xmartRegulatoryRegimeImpact.setPackagePriceCurrencyCode(getCurrencyCode(amount.getCurrencyId()));
                    xmartRegulatoryRegimeImpact.setPackagePriceValue(amount.getValue());
                }

                xmartRegulatoryRegimeImpact.setPackagePricePercentage(packagePrice.getPercentage());
                xmartRegulatoryRegimeImpact.setPackagePriceType(getStr(packagePrice.getType()));
                xmartRegulatoryRegimeImpact.setPackagePricePrice(packagePrice.getPrice());
                xmartRegulatoryRegimeImpact.setPackagePriceCurrency(packagePrice.getCurrency());
            }

            xmartRegulatoryRegimeImpact.setPackageDetailsPriceNotApplicable(packageDetails.getPriceNotApplicable());
            xmartRegulatoryRegimeImpact.setPackageDetailsPriceNotAvailable(packageDetails.getPriceNotAvailable());
        }

        xmartRegulatoryRegimeImpact
                .setReportableTransactionReference(regulatoryRegimeImpact.getReportableTransactionReference());

        // this down casting is needed as getReportingWaiverOld is not exposed via its interface.
        ReportingWaiver reportingWaiver = ((RegulatoryRegimeImpactImpl) regulatoryRegimeImpact).getReportingWaiverOld();
        if (nonNull(reportingWaiver)) {
            xmartRegulatoryRegimeImpact.setReportingWaiverType(getStr(reportingWaiver.getReportingWaiverType()));
        }

        xmartRegulatoryRegimeImpact.setTradedQuantity(regulatoryRegimeImpact.getTradedQuantity());
        TransactionClearingImpact clearingImpact = regulatoryRegimeImpact.getTransactionClearingImpact();
        if (nonNull(clearingImpact)) {
            xmartRegulatoryRegimeImpact
                    .setClearingExemptionOverrideReason(clearingImpact.getClearingExemptionOverrideReason());
            xmartRegulatoryRegimeImpact.setFrontLoadingCategory(getStr(clearingImpact.getFrontLoadingCategory()));
            xmartRegulatoryRegimeImpact.setMandatoryClearingException(clearingImpact.getMandatoryClearingException());
        }

        Amount reportableCostsAndChargesAmount = regulatoryRegimeImpact.getReportableCostsAndChargesAmount();
        if (nonNull(reportableCostsAndChargesAmount)) {
            if (nonNull(reportableCostsAndChargesAmount.getCurrencyId())) {
                xmartRegulatoryRegimeImpact.setReportableCostsAndChargesCurrencyCode(
                        reportableCostsAndChargesAmount.getCurrencyId().getCurrencyCode());
            }
            xmartRegulatoryRegimeImpact.setReportableCostsAndChargesValue(reportableCostsAndChargesAmount.getValue());
        }

        xmartRegulatoryRegimeImpact.setReportableOrderType(regulatoryRegimeImpact.getReportableOrderType());

        ReportablePriceDetails reportablePriceDetails = regulatoryRegimeImpact.getReportablePriceDetails();

        if (nonNull(reportablePriceDetails)) {

            UnitPrice reportablePrice = reportablePriceDetails.getReportablePrice();
            if (nonNull(reportablePrice)) {
                Amount reportablePriceAmount = reportablePrice.getAmount();
                if (nonNull(reportablePriceAmount)) {
                    xmartRegulatoryRegimeImpact
                            .setReportablePriceCurrencyCode(getCurrencyCode(reportablePriceAmount.getCurrencyId()));
                    xmartRegulatoryRegimeImpact.setReportablePriceValue(reportablePriceAmount.getValue());
                }

                xmartRegulatoryRegimeImpact.setReportablePricePercentage(reportablePrice.getPercentage());
                xmartRegulatoryRegimeImpact.setReportablePriceType(getStr(reportablePrice.getType()));
                xmartRegulatoryRegimeImpact.setReportablePricePrice(reportablePrice.getPrice());
                xmartRegulatoryRegimeImpact.setReportablePriceCurrency(reportablePrice.getCurrency());
            }

            xmartRegulatoryRegimeImpact
                    .setReportablePriceDetailsPriceNotApplicable(reportablePriceDetails.isPriceNotApplicable());
            xmartRegulatoryRegimeImpact
                    .setReportablePriceDetailsPriceNotAvailable(reportablePriceDetails.isPriceNotAvailable());
        }

        Integer reportableTransactionValueRange = regulatoryRegimeImpact.getReportableTransactionValueRange();
        if (nonNull(reportableTransactionValueRange)) {
            xmartRegulatoryRegimeImpact.setReportableTransactionValueRange(reportableTransactionValueRange);
        }

        if (nonNull(regulatoryRegimeImpact.getReportableTransactionGranularity())) {
            xmartRegulatoryRegimeImpact.setReportableTransactionGranularity(getStr(regulatoryRegimeImpact.getReportableTransactionGranularity()));
        }

        addEntity(xmartRegulatoryRegimeImpact);
    }

    // point release ( FROBI-7184)
    private String getRegimeImpactType(RegulatoryRegimeImpact regulatoryRegimeImpact) {
        // 1. First try to fetch the value from RegimeImpactType tag.
        // 2. If not available in step-1, then try to get from the 0th index of TransactionRegimeImpactTypes.
        // 3. If not available in step-2, then set the value as NULL otherwise, value fetched in step-1 is to be taken.
        String regimeImpactType = getStr(regulatoryRegimeImpact.getRegimeImpactType());

        return regimeImpactType;
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
