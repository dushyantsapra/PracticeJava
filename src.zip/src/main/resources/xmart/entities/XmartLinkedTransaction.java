package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartLinkedTransaction extends XmartEntity {
    private static final long serialVersionUID = 3646543593658817684L;

    @XmartAttribute
    private String linkageReasonScheme;

    @XmartAttribute
    private String linkSourceSystemId;

    @XmartAttribute
    private String linkTransactionId;

    @XmartAttribute
    private String linkTransactionLegId;

    @XmartAttribute
    private String linkTransactionVersion;

    @XmartAttribute
    private String tradeIdClassification;

    XmartLinkedTransaction(Long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getLinkageReasonScheme() {
        return linkageReasonScheme;
    }

    void setLinkageReasonScheme(String linkageReasonScheme) {
        this.linkageReasonScheme = linkageReasonScheme;
    }

    public String getLinkSourceSystemId() {
        return linkSourceSystemId;
    }

    void setLinkSourceSystemId(String linkSourceSystemId) {
        this.linkSourceSystemId = linkSourceSystemId;
    }

    public String getLinkTransactionId() {
        return linkTransactionId;
    }

    void setLinkTransactionId(String linkTransactionId) {
        this.linkTransactionId = linkTransactionId;
    }

    public String getLinkTransactionLegId() {
        return linkTransactionLegId;
    }

    void setLinkTransactionLegId(String linkTransactionLegId) {
        this.linkTransactionLegId = linkTransactionLegId;
    }

    public String getLinkTransactionVersion() {
        return linkTransactionVersion;
    }

    void setLinkTransactionVersion(String linkTransactionVersion) {
        this.linkTransactionVersion = linkTransactionVersion;
    }

    public String getTradeIdClassification() {
        return tradeIdClassification;
    }

    void setTradeIdClassification(String tradeIdClassification) {
        this.tradeIdClassification = tradeIdClassification;
    }
}
