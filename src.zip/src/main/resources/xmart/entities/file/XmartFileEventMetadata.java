package com.nwm.xmart.entities.file;

import com.nwm.xmart.core.XmartSourceEventMetadata;

import java.util.Date;

public class XmartFileEventMetadata implements XmartSourceEventMetadata {
    private final String fileName;
    private final String filePath;
    private final String fileHandler;
    private final long recordCount;
    private final int auditId;
    private final Date businessDate;

    /**
     * @param fileName     Name of the file being processed
     * @param filePath     Path the file was picked up from
     * @param fileHandler  the handler DB will use to process the payload supplied.
     * @param recordCount  Total number of records in the file.
     * @param auditId      Audit id that was received with the call to the audit proc
     * @param businessDate Modified date of file whose records are in process.
     */
    public XmartFileEventMetadata(String fileName, String filePath, String fileHandler, long recordCount, int auditId,
            Date businessDate) {
        this.fileName = fileName;
        this.filePath = filePath;
        this.fileHandler = fileHandler;
        this.recordCount = recordCount;
        this.auditId = auditId;
        this.businessDate = businessDate;
    }

    public String getFileName() {
        return fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getFileHandler() {
        return fileHandler;
    }

    public long getRecordCount() {
        return recordCount;
    }

    public int getAuditId() {
        return auditId;
    }

    public Date getBusinessDate() {
        return new Date(businessDate.getTime());
    }
}
