package com.nwm.xmart.entities.file;

import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.source.file.event.FileEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;

import static java.util.Objects.isNull;

public class XmartFileEvent extends XmartEntity {
    private static final Logger logger = LoggerFactory.getLogger(XmartFileEvent.class);

    private static final long serialVersionUID = 7845851523286650033L;
    long documentKey = 0;
    private FileEvent fileEvent;

    public XmartFileEvent(int jobId, FileEvent fileEvent) throws XmartException {
        super();

        if (isNull(fileEvent)) {
            throw new XmartException("NULL source record provided to XmartMdxDocumentEvent.");
        }

        this.fileEvent = fileEvent;
        documentKey = generateDoucumentKey(fileEvent, jobId);
    }

    /*
    YY – Year in 2 digit
    DDD - Day of the year
    TTT – 3 digit Flink Job Id identifying the job and data flow (for instance for an MDX flow with 4 sources, we would see JOB IDs of 401, 402, 403 and 404)
    SID - 1 digit for source Type
    HHMISS – the time the record was processed by the Flink source function
    NNNN - 4 digits numeric identifier of an individual record - taken the last five digits of a sequential counter
    generated and incremented in the MDX source and restarted at 0 with each rerun of the job
    */
    private long generateDoucumentKey(FileEvent fileEvent, int jobId) {
        StringBuilder docKeyStr = new StringBuilder(19);
        String docKeyComp;
        LocalDateTime localDateTime = LocalDateTime.now();
        docKeyStr.setLength(0);

        //Year 1
        docKeyStr.insert(0, String.format("%02d", localDateTime.getYear() % 100));

        //DDD
        docKeyComp = String.format("%03d", localDateTime.getDayOfYear());
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 3));

        //JOb id 3
        docKeyComp = String.format("%03d", jobId);
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 3));

        //file event type from the enum , id as defined
        docKeyComp = String.format("%03d", fileEvent.getEventType().getId());
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 3));

        //record numkber
        docKeyComp = String.format("%08d", fileEvent.getRecordNumber());
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 8));

        return Long.parseLong(docKeyStr.toString());
    }

    public FileEvent getFileEvent() {
        return fileEvent;
    }

    public long getDocumentKey() {
        return documentKey;
    }

    public Object getMapValue(String key) {
        return fileEvent.getMappedValue(key);
    }
}
