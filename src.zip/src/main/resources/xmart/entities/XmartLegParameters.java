package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Map;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.CollectionsUtil.nullMapToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class XmartLegParameters extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartLegParameter> {
    private static final Logger logger = LoggerFactory.getLogger(XmartLegParameters.class);

    public XmartLegParameters(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "transactionLegs not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        for (Map.Entry<LegPeriodType, TransactionLegParameter> legParameterEntry : nullMapToEmpty(
                transactionLeg.getLegParameters()).entrySet()) {
            if (isNull(legParameterEntry)) {
                //ignore and continue if the current item is null
                continue;
            }

            XmartLegParameter xmartLegParameter = new XmartLegParameter(getDocumentKey(),
                    transactionLeg.getLegIdentifier());

            if (nonNull(legParameterEntry.getKey())) {
                xmartLegParameter.setLegPeriodType(getStr(legParameterEntry.getKey()));
            }

            if (nonNull(legParameterEntry.getValue())) {
                TransactionLegParameter legParameter = legParameterEntry.getValue();
                xmartLegParameter.setPeriodRelativeTo(legParameter.getPeriodRelativeTo());
                xmartLegParameter.setDayType(getStr(legParameter.getDayType()));
                if (nonNull(legParameter.getPeriod())) {
                    Interval interval = legParameter.getPeriod();
                    xmartLegParameter.setPeriodMultiplier(interval.getPeriodMultiplier());
                    xmartLegParameter.setPeriodScheme(getStr(interval.getPeriodScheme()));
                }
            }
            addEntity(xmartLegParameter);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}





















