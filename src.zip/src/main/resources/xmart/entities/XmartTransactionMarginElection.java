package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartTransactionMarginElection extends XmartEntity {
    private static final long serialVersionUID = -6456016182137897896L;

    @XmartAttribute(usedInJoin = true, mandatory = false, xmlTrigger = false)
    private final Integer agreementTransactionContextId;
    @XmartAttribute(usedInJoin = true, mandatory = false, xmlTrigger = true)
    private final String marginType;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private Long marginId;

    protected XmartTransactionMarginElection(Long documentKey, Integer agreementTransactionContextId, String marginType)
            throws XmartException {
        super(documentKey);
        this.agreementTransactionContextId = agreementTransactionContextId;
        this.marginType = marginType;
    }

    public Integer getAgreementTransactionContextId() {
        return agreementTransactionContextId;
    }

    public String getMarginType() {
        return marginType;
    }

    public Long getMarginId() {
        return marginId;
    }

    public void setMarginId(Long marginId) {
        this.marginId = marginId;
    }
}
