package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionRegulatoryMarginImpact;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;

public class XmartTransactionRegulatoryMarginImpacts extends
                                                     XmartOdcEntityCollection<Transaction, TransactionRegulatoryMarginImpact, XmartTransactionRegulatoryMarginImpact> {
    private static final long serialVersionUID = 6916799123176577094L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionRegulatoryMarginImpacts.class);

    public XmartTransactionRegulatoryMarginImpacts(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionRegulatoryMarginImpact> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionRegulatoryMarginImpact());
    }

    @Override
    public void createAndAddEntity(TransactionRegulatoryMarginImpact transactionRegulatoryMarginImpact)
            throws XmartException {
        XmartTransactionRegulatoryMarginImpact xmartTransactionRegulatoryMarginImpact
                = new XmartTransactionRegulatoryMarginImpact(getDocumentKey());

        xmartTransactionRegulatoryMarginImpact
                .setRegulatoryAuthority(transactionRegulatoryMarginImpact.getRegulatoryAuthority());
        xmartTransactionRegulatoryMarginImpact.setMarginType(getStr(transactionRegulatoryMarginImpact.getMarginType()));
        xmartTransactionRegulatoryMarginImpact
                .setPayOrReceiveType(getStr(transactionRegulatoryMarginImpact.getPayOrReceiveType()));

        addEntity(xmartTransactionRegulatoryMarginImpact);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
