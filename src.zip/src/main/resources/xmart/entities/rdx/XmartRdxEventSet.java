package com.nwm.xmart.entities.rdx;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.util.CollectionsUtil;
import com.nwm.xmart.streaming.source.rdx.event.RDXSourceEvent;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by aslammh on 08/08/17.
 */
public class XmartRdxEventSet extends XmartGenericSet<RDXSourceEvent> {

    private static final long serialVersionUID = -2957788404037807712L;

    private Long documentKey;

    public XmartRdxEventSet() {
        // Nothing in default constructor
    }

    @Override
    public void addStreamEvent(RDXSourceEvent streamEvent, int sourceTopicId, MappingNode mappingHierarchy)
            throws XmartException {

        XmartRdxSourceEvent xmartRdxSourceEvent = new XmartRdxSourceEvent(sourceTopicId, streamEvent);

        documentKey = xmartRdxSourceEvent.getDocumentKey();

        xmartMappedEntities.addAll(mappingHierarchy.mapSourceObject("rdxBond", xmartRdxSourceEvent, null));
    }

    @Override
    public Long getWindowKey() {
        return documentKey;
    }

    public Long getDocumentKey() {
        return documentKey;
    }

    public List<XmartMappedEntity> getXmartMappedEntities() {
        return xmartMappedEntities;
    }

    public Collection<XmartMappedEntity> getRequiredEntities(String requiredEntityCollectionName) {
        return xmartMappedEntities.stream().filter(child -> child.isMatchingXmlEntity(requiredEntityCollectionName))
                                  .collect(Collectors.toList());
    }

    public String getXmlEntities(String requiredEntityCollectionName) {

        Collection<XmartMappedEntity> requiredEntities = getRequiredEntities(requiredEntityCollectionName);

        if (CollectionsUtil.isEmptyOrNull(requiredEntities)) {
            return null;
        }

        StringBuilder builder = new StringBuilder();

        for (XmartMappedEntity entity : requiredEntities) {
            builder.append(entity.toString());
        }

        return builder.toString();
    }

    @Override
    public String toString() {
        return "XmartTransactionSet [" + documentKey + "]";
    }
}
