package com.nwm.xmart.entities.rdx;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.rdx.event.RDXSourceEvent;
import com.nwm.xmart.streaming.source.rdx.json.RdxFixedIncome;
import rbs.gbm.dx.webService.impl.DxValuationDate;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by heskets on 13/11/2017.
 */
public class RdxEventBuilder {

    private final RdxFixedIncome rdxFixedIncome;

    //    private final File jsonFile = new File(RdxEventBuilder.class.getClassLoader().getResource("rdx/RdxEvent.json").getFile());

    public RdxEventBuilder() throws XmartException {

        ObjectMapper jsonMapper = new ObjectMapper();

        ClassLoader classloader = Thread.currentThread().getContextClassLoader();

        InputStream jsonStream = classloader.getResourceAsStream("rdx/RdxEvent.json");

        try {
            rdxFixedIncome = jsonMapper.readerFor(RdxFixedIncome.class).readValue(jsonStream);
        } catch (IOException e) {
            throw new XmartException("Failed to deserialise rdxBond");
        }
    }

    RDXSourceEvent getRdxInstrumentStreamEvent(int recordCount) {

        return new RDXSourceEvent(rdxFixedIncome, recordCount, "5T45-C0BYT-2", "2,", new DxValuationDate("2018-01-01"),
                0, null, 1);
    }
}
