package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.Amount;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionSalesCreditComponent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartOdcUtil.getCurrencyCode;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartSalesCreditComponents
        extends XmartOdcEntityCollection<Transaction, TransactionSalesCreditComponent, XmartSalesCreditComponent> {
    private static final long serialVersionUID = -5248371672724141930L;

    private static final Logger logger = LoggerFactory.getLogger(XmartSalesCreditComponents.class);

    public XmartSalesCreditComponents(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionSalesCreditComponent> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getSalesCreditComponents(), logger,
                "TransactionSalesCreditComponent not received for document key " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionSalesCreditComponent transactionSalesCreditComponent)
            throws XmartException {

        XmartSalesCreditComponent xmartSalesCreditComponent = new XmartSalesCreditComponent(getDocumentKey());

        Amount componentAmount = transactionSalesCreditComponent.getComponentAmount();
        if (nonNull(componentAmount)) {
            xmartSalesCreditComponent.setComponentAmountValue(componentAmount.getValue());
            xmartSalesCreditComponent.setComponentAmountCurrencyCode(getCurrencyCode(componentAmount.getCurrencyId()));
        }

        xmartSalesCreditComponent.setComponentPercentage(transactionSalesCreditComponent.getComponentPercentage());
        xmartSalesCreditComponent.setComponentType(getStr(transactionSalesCreditComponent.getComponentType()));
        xmartSalesCreditComponent.setPoints(transactionSalesCreditComponent.getPoints());
        xmartSalesCreditComponent
                .setRiskCommissionAdjustment(transactionSalesCreditComponent.getRiskCommissionAdjustment());
        xmartSalesCreditComponent.setSalesCreditComponentType(getStr(transactionSalesCreditComponent.getType()));

        addEntity(xmartSalesCreditComponent);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
