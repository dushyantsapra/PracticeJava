package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.SettlementSystemMigrationData;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;

public class XmartSettlementSystemMigrationDatas extends
                                                 XmartOdcEntityCollection<Transaction, SettlementSystemMigrationData, XmartSettlementSystemMigrationData> {
    private static final long serialVersionUID = 1488513428064791341L;
    private static final Logger logger = LoggerFactory.getLogger(XmartSettlementSystemMigrationDatas.class);

    public XmartSettlementSystemMigrationDatas(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<SettlementSystemMigrationData> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getSettlementSystemMigrationData(), logger,
                "SettlementSystemMigrationData not received for document key " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(SettlementSystemMigrationData settlementSystemMigrationData) throws XmartException {
        XmartSettlementSystemMigrationData xmartSettlementSystemMigrationData = new XmartSettlementSystemMigrationData(
                getDocumentKey());
        xmartSettlementSystemMigrationData.setMigrationType(getStr(settlementSystemMigrationData.getMigrationType()));
        xmartSettlementSystemMigrationData.setEffectiveDate(settlementSystemMigrationData.getEffectiveDate());
        addEntity(xmartSettlementSystemMigrationData);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
