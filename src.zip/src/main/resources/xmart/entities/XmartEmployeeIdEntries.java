package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.CollectionsUtil.nullMapToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartEmployeeIdEntries
        extends XmartOdcEntityCollection<Transaction, Map<EmployeeRoleScheme, Employee>, XmartEmployeeIdEntry> {
    private static final Logger logger = LoggerFactory.getLogger(XmartEmployeeIdEntries.class);

    private static final long serialVersionUID = 6455082138802145900L;

    public XmartEmployeeIdEntries(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<Map<EmployeeRoleScheme, Employee>> getFromEntities(Transaction transaction) {
        return Collections.singletonList(nullMapToEmpty(transaction.getEmployees(), logger,
                "Employees Map not received for document key : " + getDocumentKey()));
    }

    @Override
    public void createAndAddEntity(Map<EmployeeRoleScheme, Employee> employeeRoleSchemeEmployeeMap)
            throws XmartException {
        for (Map.Entry<EmployeeRoleScheme, Employee> employeeEntry : nullCollToEmpty(
                employeeRoleSchemeEmployeeMap.entrySet())) {
            boolean foundEmployeeIdEntry = false;

            if (nonNull(employeeEntry) && nonNull(employeeEntry.getValue())) {
                EmployeeRoleScheme employeeRoleScheme = employeeEntry.getKey();
                Employee employee = employeeEntry.getValue();

                for (EmployeeIdEntry employeeIdEntry : nullCollToEmpty(employee.getIdEntry())) {
                    //Found the employeeIdEntry
                    foundEmployeeIdEntry = true;
                    if (nonNull(employeeIdEntry)) {
                        addXmartEmployeeIdEntry(employeeRoleScheme, employeeIdEntry.getEmployeeIdentifier(),
                                employeeIdEntry.getEmployeeSourceSystemId(), employeeIdEntry.getPersonIdScheme());
                    }
                }

                if (foundEmployeeIdEntry) {
                    logger.debug("EmployeeIdEntry found, not going for id {}");
                    continue;
                }

                logger.debug("EmployeeIdEntry not found, going for id {}");
                if (nonNull(employee.getId())) {
                    addXmartEmployeeIdEntry(employeeRoleScheme, employee.getId().getEmployeeIdentifier(),
                            employee.getId().getEmployeeSourceSystemId(), employee.getId().getPersonIdScheme());
                }
            }
        }
    }

    private void addXmartEmployeeIdEntry(EmployeeRoleScheme employeeRoleScheme, String employeeIdentifier,
            SystemInstanceId employeeSourceSystemId, PersonIdScheme personIdScheme) throws XmartException {
        XmartEmployeeIdEntry xmartEmployeeIdEntry = new XmartEmployeeIdEntry(getDocumentKey());
        xmartEmployeeIdEntry.setEmployeeRoleScheme(getStr(employeeRoleScheme));
        xmartEmployeeIdEntry.setEmployeeIdentifier(employeeIdentifier);
        xmartEmployeeIdEntry.setEmployeeSourceSystemId(getStr(employeeSourceSystemId));
        xmartEmployeeIdEntry.setPersonIdScheme(getStr(personIdScheme));

        addEntity(xmartEmployeeIdEntry);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
