package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.InterestRateLeg;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLeg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;

/**
 * Created by aslammh on 17/11/17.
 */
public class XmartInterestRateLegs extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartInterestRateLeg> {

    private static final long serialVersionUID = -1920241634490979033L;
    private static final Logger logger = LoggerFactory.getLogger(XmartInterestRateLegs.class);

    public XmartInterestRateLegs(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "Transaction legs not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        InterestRateLeg interestRateLeg = transactionLeg.getInterestRateLeg();
        if (isNull(interestRateLeg)) {
            // This is possible when legType of this transactionLeg is not of type Interest_Rate_leg
            return;
        }

        XmartInterestRateLeg xmartInterestRateLeg = new XmartInterestRateLeg(getDocumentKey(),
                transactionLeg.getLegIdentifier());
        xmartInterestRateLeg.setInterestRate(interestRateLeg.getInterestRate());
        xmartInterestRateLeg.setFixedOrFloatingRateType(getStr(interestRateLeg.getFixedOrFloatingRateType()));
        xmartInterestRateLeg.setVaryingNotionalRateSource(interestRateLeg.getVaryingNotionalRateSource());
        xmartInterestRateLeg.setRoundingDirection(getStr(interestRateLeg.getRoundingDirection()));
        xmartInterestRateLeg.setNegativeRateTreatment(getStr(interestRateLeg.getNegativeRateTreatment()));
        xmartInterestRateLeg.setCompoundingMethod(getStr(interestRateLeg.getCompoundingMethod()));
        xmartInterestRateLeg.setRateMultiplier(interestRateLeg.getRateMultiplier());
        xmartInterestRateLeg.setDiscountingType(getStr(interestRateLeg.getDiscountingType()));
        xmartInterestRateLeg.setQuotationStyle(interestRateLeg.getQuotationStyle());
        xmartInterestRateLeg.setRoundingPrecision(interestRateLeg.getRoundingPrecision());
        xmartInterestRateLeg.setCalcPeriodNumOfDays(interestRateLeg.getCalcPeriodNumOfDays());

        addEntity(xmartInterestRateLeg);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
