package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartLegParameter extends XmartEntity {
    private static final long serialVersionUID = -2134437134995313353L;

    @XmartAttribute(xmlTrigger = false, usedInJoin = true)
    private String legIdentifier;
    @XmartAttribute
    private String legPeriodType;
    @XmartAttribute
    private String periodRelativeTo;
    @XmartAttribute
    private String dayType;
    @XmartAttribute
    private Integer periodMultiplier;
    @XmartAttribute
    private String periodScheme;

    XmartLegParameter(Long documentKey, String legIdentifier) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getLegPeriodType() {
        return legPeriodType;
    }

    public void setLegPeriodType(String legPeriodType) {
        this.legPeriodType = legPeriodType;
    }

    public String getPeriodRelativeTo() {
        return periodRelativeTo;
    }

    public void setPeriodRelativeTo(String periodRelativeTo) {
        this.periodRelativeTo = periodRelativeTo;
    }

    public String getDayType() {
        return dayType;
    }

    public void setDayType(String dayType) {
        this.dayType = dayType;
    }

    public Integer getPeriodMultiplier() {
        return periodMultiplier;
    }

    public void setPeriodMultiplier(Integer periodMultiplier) {
        this.periodMultiplier = periodMultiplier;
    }

    public String getPeriodScheme() {
        return periodScheme;
    }

    public void setPeriodScheme(String periodScheme) {
        this.periodScheme = periodScheme;
    }
}
