package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by aslammh on 13/11/17.
 */
public class XmartTransactionLegalEntity extends XmartEntity {

    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionLegalEntity.class);
    private static final long serialVersionUID = 2863501554303065434L;

    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String transactionRoleScheme;

    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String partyIdClassification;

    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String partyId;

    public XmartTransactionLegalEntity(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getTransactionRoleScheme() {
        return transactionRoleScheme;
    }

    public void setTransactionRoleScheme(String transactionRoleScheme) {
        this.transactionRoleScheme = transactionRoleScheme;
    }

    public String getPartyIdClassification() {
        return partyIdClassification;
    }

    public void setPartyIdClassification(String partyIdClassification) {
        this.partyIdClassification = partyIdClassification;
    }

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }
}
