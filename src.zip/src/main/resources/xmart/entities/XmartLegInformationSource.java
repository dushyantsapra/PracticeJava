package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

/**
 * Created by aslammh on 13/11/17.
 */
public class XmartLegInformationSource extends XmartEntity {

    private static final long serialVersionUID = 4867586998022192203L;
    @XmartAttribute(xmlTrigger = false, usedInJoin = true)
    private final String legIdentifier;
    @XmartAttribute
    private String informationSourceId;
    @XmartAttribute
    private String informationSourceSystemId;
    @XmartAttribute
    private String informationSource;
    @XmartAttribute
    private String informationSourcePage;

    public XmartLegInformationSource(String legIdentifier, long documentKey) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getInformationSourceId() {
        return informationSourceId;
    }

    public void setInformationSourceId(String informationSourceId) {
        this.informationSourceId = informationSourceId;
    }

    public String getInformationSourceSystemId() {
        return informationSourceSystemId;
    }

    public void setInformationSourceSystemId(String informationSourceSystemId) {
        this.informationSourceSystemId = informationSourceSystemId;
    }

    public String getInformationSource() {
        return informationSource;
    }

    public void setInformationSource(String informationSource) {
        this.informationSource = informationSource;
    }

    public String getInformationSourcePage() {
        return informationSourcePage;
    }

    public void setInformationSourcePage(String informationSourcePage) {
        this.informationSourcePage = informationSourcePage;
    }
}
