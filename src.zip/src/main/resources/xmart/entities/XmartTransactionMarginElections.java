package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.AgreementTransactionContext;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionMarginElection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class XmartTransactionMarginElections
        extends XmartOdcEntityCollection<Transaction, AgreementTransactionContext, XmartTransactionMarginElection> {
    private static final long serialVersionUID = 7135512588572749976L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionMarginElections.class);

    public XmartTransactionMarginElections(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<AgreementTransactionContext> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getAgreementTransactionContext(), logger,
                "AgreementTransactionContexts not received for document key " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(AgreementTransactionContext agreementTransactionContext) throws XmartException {
        if (isNull(agreementTransactionContext)) {
            return;
        }

        Collection<TransactionMarginElection> txnMarginElections = nullCollToEmpty(
                agreementTransactionContext.getTransactionMarginElection(), logger,
                "TransactionMarginElection not received for document key " + getDocumentKey());

        for (TransactionMarginElection txnMarginElection : txnMarginElections) {
            if (isNull(txnMarginElection)) {
                continue;
            }

            XmartTransactionMarginElection xmartTransactionMarginElection = new XmartTransactionMarginElection(
                    getDocumentKey(), agreementTransactionContext.getId(), getStr(txnMarginElection.getMarginType()));

            if (nonNull(txnMarginElection.getMarginAgreementLinkageId())) {
                xmartTransactionMarginElection
                        .setMarginId(txnMarginElection.getMarginAgreementLinkageId().getMarginId());
            }

            addEntity(xmartTransactionMarginElection);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
