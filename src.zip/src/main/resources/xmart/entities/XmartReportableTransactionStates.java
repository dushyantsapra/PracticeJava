package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.ReportableTransactionState;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;

public class XmartReportableTransactionStates
        extends XmartOdcEntityCollection<Transaction, ReportableTransactionState, XmartReportableTransactionState> {
    private static final long serialVersionUID = -4892337651919953316L;
    private static final Logger logger = LoggerFactory.getLogger(XmartReportableTransactionStates.class);

    public XmartReportableTransactionStates(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<ReportableTransactionState> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getReportableTransactionStates(), logger,
                "ReportableTransactionStates not received for documentKey : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(ReportableTransactionState reportableTransactionState) throws XmartException {
        addEntity(new XmartReportableTransactionState(getDocumentKey(),
                getStr(reportableTransactionState.getRegimeImpactType()),
                reportableTransactionState.getReportableTransactionReference(),
                getStr(reportableTransactionState.getReportableTransactionState())));
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
