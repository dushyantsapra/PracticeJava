package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartExceptionalTermsDetail extends XmartEntity {

    private static final long serialVersionUID = -1179204645983253884L;
    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private Integer agreementTransactionContextId;
    @XmartAttribute
    private String exceptionalTermsDetail;

    public XmartExceptionalTermsDetail(long documentKey) throws XmartException {
        super(documentKey);
    }

    public Integer getAgreementTransactionContextId() {
        return agreementTransactionContextId;
    }

    public void setAgreementTransactionContextId(Integer agreementTransactionContextId) {
        this.agreementTransactionContextId = agreementTransactionContextId;
    }

    public String getExceptionalTermsDetail() {
        return exceptionalTermsDetail;
    }

    public void setExceptionalTermsDetail(String exceptionalTermsDetail) {
        this.exceptionalTermsDetail = exceptionalTermsDetail;
    }
}
