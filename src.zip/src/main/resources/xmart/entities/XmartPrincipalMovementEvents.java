package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.PrincipalMovementEvent;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLifecycleEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.isNotNull;
import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartOdcUtil.getCurrencyCode;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartPrincipalMovementEvents
        extends XmartOdcEntityCollection<Transaction, TransactionLifecycleEvent, XmartPrincipalMovementEvent> {

    private static final long serialVersionUID = 4281116463097733530L;
    private static final Logger logger = LoggerFactory.getLogger(XmartPrincipalMovementEvents.class);

    public XmartPrincipalMovementEvents(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLifecycleEvent> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLifecycleEvents(), logger,
                "TransactionLifecycleEvents not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLifecycleEvent transactionLifecycleEvent) throws XmartException {
        for (PrincipalMovementEvent principalMovementEvent : nullCollToEmpty(
                transactionLifecycleEvent.getPrincipalMovementEvents())) {

            XmartPrincipalMovementEvent xmartPrincipalMovementEvent = new XmartPrincipalMovementEvent(getDocumentKey(),
                    transactionLifecycleEvent.getSourceSystemEventId(),
                    getStr(transactionLifecycleEvent.getEventType()));

            if (isNotNull(principalMovementEvent)) {

                //TODO find alternative of deprecated method
                xmartPrincipalMovementEvent.setLegIdentifier(principalMovementEvent.getLegIdentifier());
                xmartPrincipalMovementEvent.setPrincipalType(getStr(principalMovementEvent.getPrincipalType()));
                xmartPrincipalMovementEvent.setStepAmount(principalMovementEvent.getStepAmount());
                xmartPrincipalMovementEvent.setStepDirection(getStr(principalMovementEvent.getStepDirection()));
                xmartPrincipalMovementEvent
                        .setInterestRecapitalized(principalMovementEvent.getIsInterestRecapitalized());

                if (nonNull(principalMovementEvent.getResultantAmount())) {
                    xmartPrincipalMovementEvent
                            .setResultantAmountValue(principalMovementEvent.getResultantAmount().getValue());
                    xmartPrincipalMovementEvent.setResultantAmountCurrencyCode(
                            getCurrencyCode(principalMovementEvent.getResultantAmount().getCurrencyId()));
                }
            }

            addEntity(xmartPrincipalMovementEvent);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
