package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.InflationRateLeg;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLeg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;

public class XmartInflationRateLegs
        extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartInflationRateLeg> {

    private static final Logger logger = LoggerFactory.getLogger(XmartInflationRateLegs.class);

    public XmartInflationRateLegs(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "Transaction Legs not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        if (isNull(transactionLeg.getInflationRateLeg())) {
            return;
        }

        InflationRateLeg inflationRateLeg = transactionLeg.getInflationRateLeg();
        XmartInflationRateLeg xmartInflationRateLeg = new XmartInflationRateLeg(getDocumentKey(),
                transactionLeg.getLegIdentifier());

        xmartInflationRateLeg.setInflationIndexLevel(inflationRateLeg.getInflationIndexLevel());
        xmartInflationRateLeg.setInterpolationMethod(inflationRateLeg.getInterpolationMethod());
        xmartInflationRateLeg.setInflationRateSource(inflationRateLeg.getInflationRateSource());
        xmartInflationRateLeg.setBaseIndexDate(convertBusinessDate(inflationRateLeg.getBaseIndexDate()));
        xmartInflationRateLeg.setInflationRate(inflationRateLeg.getInflationRate());
        xmartInflationRateLeg.setRpiProductIdentifier(inflationRateLeg.getRpiProductIdentifier());
        xmartInflationRateLeg.setRoundingDirection(getStr(inflationRateLeg.getRoundingDirection()));
        xmartInflationRateLeg.setRoundingPrecision(inflationRateLeg.getRoundingPrecision());
        xmartInflationRateLeg.setNegativeRateTreatment(getStr(inflationRateLeg.getNegativeRateTreatment()));
        xmartInflationRateLeg.setMainRatePublication(inflationRateLeg.getMainRatePublication());
        xmartInflationRateLeg.setRateMultiplier(inflationRateLeg.getRateMultiplier());

        addEntity(xmartInflationRateLeg);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
