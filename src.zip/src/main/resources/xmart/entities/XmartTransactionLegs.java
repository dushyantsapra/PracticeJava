package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.CollectionsUtil;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLeg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

/**
 * Created by aslammh on 08/08/17.
 */
public class XmartTransactionLegs extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartTransactionLeg> {
    private static final long serialVersionUID = -7176528258545706780L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionLegs.class);

    public XmartTransactionLegs(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        Collection<TransactionLeg> legCollection = CollectionsUtil.nullCollToEmpty(transaction.getTransactionLegs());
        return legCollection;
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        XmartTransactionLeg xmartTransactionLeg = new XmartTransactionLeg(getDocumentKey());
        xmartTransactionLeg.setOdcTransactionLeg(transactionLeg, getDocumentKey());
        addEntity(xmartTransactionLeg);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
