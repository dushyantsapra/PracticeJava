package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartPostTradeClassification extends XmartEntity {
    private static final long serialVersionUID = 3600713264130619485L;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private Boolean regimeImpact;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String regimeImpactId;

    @XmartAttribute
    private String postTradeClassification;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String regulatoryRegimeImpactId;

    public XmartPostTradeClassification(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getRegulatoryRegimeImpactId() {
        return regulatoryRegimeImpactId;
    }

    public void setRegulatoryRegimeImpactId(String regulatoryRegimeImpactId) {
        this.regulatoryRegimeImpactId = regulatoryRegimeImpactId;
    }

    public Boolean getRegimeImpact() {
        return regimeImpact;
    }

    public void setRegimeImpact(Boolean regimeImpact) {
        this.regimeImpact = regimeImpact;
    }

    public String getRegimeImpactId() {
        return regimeImpactId;
    }

    public void setRegimeImpactId(String regimeImpactId) {
        this.regimeImpactId = regimeImpactId;
    }

    public String getPostTradeClassification() {
        return postTradeClassification;
    }

    public void setPostTradeClassification(String postTradeClassification) {
        this.postTradeClassification = postTradeClassification;
    }
}
