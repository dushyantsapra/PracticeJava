package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.RegimeBookRole;
import com.rbs.odc.access.domain.RegulatoryRegimeImpact;
import com.rbs.odc.access.domain.SourceBookId;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

/**
 * Created by aslammh on 17/11/17.
 */
public class XmartRegimeBookRoles
        extends XmartOdcEntityCollection<Transaction, RegulatoryRegimeImpact, XmartRegimeBookRole> {

    private static final long serialVersionUID = 1995023486782426442L;
    private static final Logger logger = LoggerFactory.getLogger(XmartRegimeBookRoles.class);

    public XmartRegimeBookRoles(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<RegulatoryRegimeImpact> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getRegulatoryRegimeImpact(), logger,
                "RegulatoryRegimeImpact not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(RegulatoryRegimeImpact regulatoryRegimeImpact) throws XmartException {
        for (RegimeBookRole regimeBookRole : nullCollToEmpty(regulatoryRegimeImpact.getRegimeBookRoles())) {

            XmartRegimeBookRole xmartRegimeBookRole = new XmartRegimeBookRole(getDocumentKey());
            xmartRegimeBookRole.setRegimeImpact(regulatoryRegimeImpact.getRegimeImpact());
            xmartRegimeBookRole.setRegimeImpactId(regulatoryRegimeImpact.getRegimeImpactId());
            xmartRegimeBookRole.setRegulatoryRegimeImpactId(regulatoryRegimeImpact.getId());
            if (nonNull(regimeBookRole)) {
                xmartRegimeBookRole.setReportingRoleScheme(getStr(regimeBookRole.getReportingRoleScheme()));
                xmartRegimeBookRole.setTradingCapacity(getStr(regimeBookRole.getTradingCapacity()));
                SourceBookId sourceBookId = regimeBookRole.getSourceBookId();
                if (nonNull(sourceBookId)) {
                    xmartRegimeBookRole.setSourceSystemBookId(sourceBookId.getSourceSystemBookId());
                    xmartRegimeBookRole.setBookSourceSystemId(getStr(sourceBookId.getBookSourceSystemId()));
                }
                xmartRegimeBookRole.setReportableTradingRole(getStr(regimeBookRole.getReportableTradingRole()));
            }
            addEntity(xmartRegimeBookRole);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}



