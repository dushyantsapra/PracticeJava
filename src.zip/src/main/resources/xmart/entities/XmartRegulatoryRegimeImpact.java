package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * This class provides an Xmart view of Regulatory Regime Impacts extending the XmartEntity class
 * </p>
 * <p>
 * The class holds the class attributes for the flattened view of this data structure as well as getters and setters
 * for these attributes.
 * </p>
 *
 * @author aslammh on 21/11/17.
 */
public class XmartRegulatoryRegimeImpact extends XmartEntity {

    private static final long serialVersionUID = 4234294370069880186L;

    @XmartAttribute(usedInJoin = true)
    private Boolean regimeImpact;

    @XmartAttribute(usedInJoin = true)
    private String regimeImpactId;

    @XmartAttribute
    private String regulatoryAuthority;

    @XmartAttribute
    private String regimeImpactType;

    @XmartAttribute
    private Boolean orderTransmissionConditionsNotSatisfied;

    @XmartAttribute
    private Boolean commodityDerivativeIndicator;

    @XmartAttribute
    private String aggregatedUpfrontFeeAmountCurrencyCode;

    @XmartAttribute
    private BigDecimal aggregatedUpfrontFeeAmountValue;

    @XmartAttribute
    private String regulatoryRegimeImpactId;

    @XmartAttribute
    private String legIdentifier;

    @XmartAttribute
    private Date agreementDate;

    @XmartAttribute
    private Date agreementDateTime;

    @XmartAttribute
    private String notionalChangeAmountType;

    @XmartAttribute
    private String notionalChangeCurrencyCode;

    @XmartAttribute
    private BigDecimal notionalChangeValue;

    @XmartAttribute
    private String notionalChangeType;

    @XmartAttribute
    private Long componentNumber;

    @XmartAttribute
    private Long constituentCount;

    @XmartAttribute
    private String packagePriceCurrencyCode;

    @XmartAttribute
    private BigDecimal packagePriceValue;

    @XmartAttribute
    private BigDecimal packagePricePercentage;

    @XmartAttribute
    private String packagePriceType;

    @XmartAttribute
    private BigDecimal packagePricePrice;

    @XmartAttribute
    private String packagePriceCurrency;

    @XmartAttribute
    private Boolean packageDetailsPriceNotApplicable;

    @XmartAttribute
    private Boolean packageDetailsPriceNotAvailable;

    @XmartAttribute
    private String reportableTransactionReference;

    @XmartAttribute
    private String reportingWaiverType;

    @XmartAttribute
    private BigDecimal tradedQuantity;

    @XmartAttribute
    private String clearingExemptionOverrideReason;

    @XmartAttribute
    private String frontLoadingCategory;

    @XmartAttribute
    private String mandatoryClearingException;

    //FROBI-7860 and FROBI-7861
    @XmartAttribute
    private String reportableCostsAndChargesCurrencyCode;

    @XmartAttribute
    private BigDecimal reportableCostsAndChargesValue;

    @XmartAttribute
    private String reportableOrderType;

    //FROBI-8087

    @XmartAttribute
    private String reportablePriceCurrencyCode;

    @XmartAttribute
    private BigDecimal reportablePriceValue;

    @XmartAttribute
    private BigDecimal reportablePricePercentage;

    @XmartAttribute
    private String reportablePriceType;

    @XmartAttribute
    private BigDecimal reportablePricePrice;

    @XmartAttribute
    private String reportablePriceCurrency;

    @XmartAttribute
    private Boolean reportablePriceDetailsPriceNotApplicable;

    @XmartAttribute
    private Boolean reportablePriceDetailsPriceNotAvailable;

    @XmartAttribute
    private Integer reportableTransactionValueRange;
    //FROBI-11165--ODC3.15
    @XmartAttribute
    private String reportableTransactionGranularity;

    public XmartRegulatoryRegimeImpact(long documentKey) throws XmartException {
        super(documentKey);
    }

    public Boolean getRegimeImpact() {
        return regimeImpact;
    }

    public void setRegimeImpact(Boolean regimeImpact) {
        this.regimeImpact = regimeImpact;
    }

    public String getRegimeImpactId() {
        return regimeImpactId;
    }

    public void setRegimeImpactId(String regimeImpactId) {
        this.regimeImpactId = regimeImpactId;
    }

    public String getRegulatoryAuthority() {
        return regulatoryAuthority;
    }

    public void setRegulatoryAuthority(String regulatoryAuthority) {
        this.regulatoryAuthority = regulatoryAuthority;
    }

    public String getRegimeImpactType() {
        return regimeImpactType;
    }

    public void setRegimeImpactType(String regimeImpactType) {
        this.regimeImpactType = regimeImpactType;
    }

    public Boolean getOrderTransmissionConditionsNotSatisfied() {
        return orderTransmissionConditionsNotSatisfied;
    }

    public void setOrderTransmissionConditionsNotSatisfied(Boolean orderTransmissionConditionsNotSatisfied) {
        this.orderTransmissionConditionsNotSatisfied = orderTransmissionConditionsNotSatisfied;
    }

    public Boolean getCommodityDerivativeIndicator() {
        return commodityDerivativeIndicator;
    }

    public void setCommodityDerivativeIndicator(Boolean commodityDerivativeIndicator) {
        this.commodityDerivativeIndicator = commodityDerivativeIndicator;
    }

    public String getAggregatedUpfrontFeeAmountCurrencyCode() {
        return aggregatedUpfrontFeeAmountCurrencyCode;
    }

    public void setAggregatedUpfrontFeeAmountCurrencyCode(String aggregatedUpfrontFeeAmountCurrencyCode) {
        this.aggregatedUpfrontFeeAmountCurrencyCode = aggregatedUpfrontFeeAmountCurrencyCode;
    }

    public BigDecimal getAggregatedUpfrontFeeAmountValue() {
        return aggregatedUpfrontFeeAmountValue;
    }

    public void setAggregatedUpfrontFeeAmountValue(BigDecimal aggregatedUpfrontFeeAmountValue) {
        this.aggregatedUpfrontFeeAmountValue = aggregatedUpfrontFeeAmountValue;
    }

    public String getRegulatoryRegimeImpactId() {
        return regulatoryRegimeImpactId;
    }

    public void setRegulatoryRegimeImpactId(String regulatoryRegimeImpactId) {
        this.regulatoryRegimeImpactId = regulatoryRegimeImpactId;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public void setLegIdentifier(String legIdentifier) {
        this.legIdentifier = legIdentifier;
    }

    public Date getAgreementDate() {
        return agreementDate;
    }

    public void setAgreementDate(Date agreementDate) {
        this.agreementDate = agreementDate;
    }

    public Date getAgreementDateTime() {
        return agreementDateTime;
    }

    public void setAgreementDateTime(Date agreementDateTime) {
        this.agreementDateTime = agreementDateTime;
    }

    public String getNotionalChangeAmountType() {
        return notionalChangeAmountType;
    }

    public void setNotionalChangeAmountType(String notionalChangeAmountType) {
        this.notionalChangeAmountType = notionalChangeAmountType;
    }

    public String getNotionalChangeCurrencyCode() {
        return notionalChangeCurrencyCode;
    }

    public void setNotionalChangeCurrencyCode(String notionalChangeCurrencyCode) {
        this.notionalChangeCurrencyCode = notionalChangeCurrencyCode;
    }

    public BigDecimal getNotionalChangeValue() {
        return notionalChangeValue;
    }

    public void setNotionalChangeValue(BigDecimal notionalChangeValue) {
        this.notionalChangeValue = notionalChangeValue;
    }

    public String getNotionalChangeType() {
        return notionalChangeType;
    }

    public void setNotionalChangeType(String notionalChangeType) {
        this.notionalChangeType = notionalChangeType;
    }

    public Long getComponentNumber() {
        return componentNumber;
    }

    public void setComponentNumber(Long componentNumber) {
        this.componentNumber = componentNumber;
    }

    public Long getConstituentCount() {
        return constituentCount;
    }

    public void setConstituentCount(Long constituentCount) {
        this.constituentCount = constituentCount;
    }

    public String getPackagePriceCurrencyCode() {
        return packagePriceCurrencyCode;
    }

    public void setPackagePriceCurrencyCode(String packagePriceCurrencyCode) {
        this.packagePriceCurrencyCode = packagePriceCurrencyCode;
    }

    public BigDecimal getPackagePriceValue() {
        return packagePriceValue;
    }

    public void setPackagePriceValue(BigDecimal packagePriceValue) {
        this.packagePriceValue = packagePriceValue;
    }

    public BigDecimal getPackagePricePercentage() {
        return packagePricePercentage;
    }

    public void setPackagePricePercentage(BigDecimal packagePricePercentage) {
        this.packagePricePercentage = packagePricePercentage;
    }

    public String getPackagePriceType() {
        return packagePriceType;
    }

    public void setPackagePriceType(String packagePriceType) {
        this.packagePriceType = packagePriceType;
    }

    public BigDecimal getPackagePricePrice() {
        return packagePricePrice;
    }

    public void setPackagePricePrice(BigDecimal packagePricePrice) {
        this.packagePricePrice = packagePricePrice;
    }

    public String getPackagePriceCurrency() {
        return packagePriceCurrency;
    }

    public void setPackagePriceCurrency(String packagePriceCurrency) {
        this.packagePriceCurrency = packagePriceCurrency;
    }

    public Boolean getPackageDetailsPriceNotApplicable() {
        return packageDetailsPriceNotApplicable;
    }

    public void setPackageDetailsPriceNotApplicable(Boolean packageDetailsPriceNotApplicable) {
        this.packageDetailsPriceNotApplicable = packageDetailsPriceNotApplicable;
    }

    public Boolean getPackageDetailsPriceNotAvailable() {
        return packageDetailsPriceNotAvailable;
    }

    public void setPackageDetailsPriceNotAvailable(Boolean packageDetailsPriceNotAvailable) {
        this.packageDetailsPriceNotAvailable = packageDetailsPriceNotAvailable;
    }

    public String getReportableTransactionReference() {
        return reportableTransactionReference;
    }

    public void setReportableTransactionReference(String reportableTransactionReference) {
        this.reportableTransactionReference = reportableTransactionReference;
    }

    public String getReportingWaiverType() {
        return reportingWaiverType;
    }

    public void setReportingWaiverType(String reportingWaiverType) {
        this.reportingWaiverType = reportingWaiverType;
    }

    public BigDecimal getTradedQuantity() {
        return tradedQuantity;
    }

    public void setTradedQuantity(BigDecimal tradedQuantity) {
        this.tradedQuantity = tradedQuantity;
    }

    public String getClearingExemptionOverrideReason() {
        return clearingExemptionOverrideReason;
    }

    public void setClearingExemptionOverrideReason(String clearingExemptionOverrideReason) {
        this.clearingExemptionOverrideReason = clearingExemptionOverrideReason;
    }

    public String getFrontLoadingCategory() {
        return frontLoadingCategory;
    }

    public void setFrontLoadingCategory(String frontLoadingCategory) {
        this.frontLoadingCategory = frontLoadingCategory;
    }

    public String getMandatoryClearingException() {
        return mandatoryClearingException;
    }

    public void setMandatoryClearingException(String mandatoryClearingException) {
        this.mandatoryClearingException = mandatoryClearingException;
    }

    public String getReportableCostsAndChargesCurrencyCode() {
        return reportableCostsAndChargesCurrencyCode;
    }

    public void setReportableCostsAndChargesCurrencyCode(String reportableCostsAndChargesCurrencyCode) {
        this.reportableCostsAndChargesCurrencyCode = reportableCostsAndChargesCurrencyCode;
    }

    public BigDecimal getReportableCostsAndChargesValue() {
        return reportableCostsAndChargesValue;
    }

    public void setReportableCostsAndChargesValue(BigDecimal reportableCostsAndChargesValue) {
        this.reportableCostsAndChargesValue = reportableCostsAndChargesValue;
    }

    public String getReportableOrderType() {
        return reportableOrderType;
    }

    public void setReportableOrderType(String reportableOrderType) {
        this.reportableOrderType = reportableOrderType;
    }

    public String getReportablePriceCurrencyCode() {
        return reportablePriceCurrencyCode;
    }

    public void setReportablePriceCurrencyCode(String reportablePriceCurrencyCode) {
        this.reportablePriceCurrencyCode = reportablePriceCurrencyCode;
    }

    public BigDecimal getReportablePriceValue() {
        return reportablePriceValue;
    }

    public void setReportablePriceValue(BigDecimal reportablePriceValue) {
        this.reportablePriceValue = reportablePriceValue;
    }

    public BigDecimal getReportablePricePercentage() {
        return reportablePricePercentage;
    }

    public void setReportablePricePercentage(BigDecimal reportablePricePercentage) {
        this.reportablePricePercentage = reportablePricePercentage;
    }

    public String getReportablePriceType() {
        return reportablePriceType;
    }

    public void setReportablePriceType(String reportablePriceType) {
        this.reportablePriceType = reportablePriceType;
    }

    public BigDecimal getReportablePricePrice() {
        return reportablePricePrice;
    }

    public void setReportablePricePrice(BigDecimal reportablePricePrice) {
        this.reportablePricePrice = reportablePricePrice;
    }

    public String getReportablePriceCurrency() {
        return reportablePriceCurrency;
    }

    public void setReportablePriceCurrency(String reportablePriceCurrency) {
        this.reportablePriceCurrency = reportablePriceCurrency;
    }

    public Boolean getReportablePriceDetailsPriceNotApplicable() {
        return reportablePriceDetailsPriceNotApplicable;
    }

    public void setReportablePriceDetailsPriceNotApplicable(Boolean reportablePriceDetailsPriceNotApplicable) {
        this.reportablePriceDetailsPriceNotApplicable = reportablePriceDetailsPriceNotApplicable;
    }

    public Boolean getReportablePriceDetailsPriceNotAvailable() {
        return reportablePriceDetailsPriceNotAvailable;
    }

    public void setReportablePriceDetailsPriceNotAvailable(Boolean reportablePriceDetailsPriceNotAvailable) {
        this.reportablePriceDetailsPriceNotAvailable = reportablePriceDetailsPriceNotAvailable;
    }

    public Integer getReportableTransactionValueRange() {
        return reportableTransactionValueRange;
    }

    public void setReportableTransactionValueRange(Integer reportableTransactionValueRange) {
        this.reportableTransactionValueRange = reportableTransactionValueRange;
    }

    public String getReportableTransactionGranularity() {
        return reportableTransactionGranularity;
    }

    public void setReportableTransactionGranularity(String reportableTransactionGranularity) {
        this.reportableTransactionGranularity = reportableTransactionGranularity;
    }
}
