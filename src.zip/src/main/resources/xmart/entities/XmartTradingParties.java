package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.TradingPartyAliasId;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionPartyAliasRole;
import com.rbs.odc.access.domain.TransactionRoleScheme;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Collection;
import java.util.Map;

import static com.nwm.xmart.util.CollectionsUtil.nullMapToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartTradingParties extends
                                 XmartOdcEntityCollection<Transaction, Map<TransactionRoleScheme, TransactionPartyAliasRole>, XmartTradingParty> {
    private static final long serialVersionUID = -3009248574871435375L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTradingParties.class);

    public XmartTradingParties(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<Map<TransactionRoleScheme, TransactionPartyAliasRole>> getFromEntities(Transaction transaction) {
        return Arrays.asList(nullMapToEmpty(transaction.getTradingParties(), logger,
                "TradingParties not received for document key : " + getDocumentKey()));
    }

    @Override
    public void createAndAddEntity(
            Map<TransactionRoleScheme, TransactionPartyAliasRole> transactionRoleSchemeTransactionPartyAliasRoleMap)
            throws XmartException {
        for (Map.Entry<TransactionRoleScheme, TransactionPartyAliasRole> entry : transactionRoleSchemeTransactionPartyAliasRoleMap
                .entrySet()) {

            XmartTradingParty xmartTradingParty = new XmartTradingParty(getDocumentKey());

            if (nonNull(entry)) {

                if (nonNull(entry.getKey())) {
                    xmartTradingParty.setTransactionRoleScheme(getStr(entry.getKey()));
                }
                if (nonNull(entry.getValue()) && nonNull(entry.getValue().getTradingCounterpartyAliasId())) {
                    TradingPartyAliasId tradingCounterpartyAliasId = entry.getValue().getTradingCounterpartyAliasId();
                    xmartTradingParty.setTradingPartyId(tradingCounterpartyAliasId.getTradingPartyId());
                    xmartTradingParty
                            .setTradingPartySystemId(getStr(tradingCounterpartyAliasId.getTradingPartySystemId()));
                }
            }

            addEntity(xmartTradingParty);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}

