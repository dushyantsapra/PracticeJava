package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLifecycleEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.XmartOdcUtil.getCurrencyCode;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartTransactionLifecycleEvents
        extends XmartOdcEntityCollection<Transaction, TransactionLifecycleEvent, XmartTransactionLifecycleEvent> {
    private static final long serialVersionUID = 1256198288384900213L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionLifecycleEvents.class);

    public XmartTransactionLifecycleEvents(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLifecycleEvent> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLifecycleEvents(), logger,
                "TransactionLifecycleEvents not received for document key " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLifecycleEvent transactionLifecycleEvent) throws XmartException {

        XmartTransactionLifecycleEvent xmartTransactionLifecycleEvent = new XmartTransactionLifecycleEvent(
                getDocumentKey());
        xmartTransactionLifecycleEvent.setSourceSystemEventId(transactionLifecycleEvent.getSourceSystemEventId());
        xmartTransactionLifecycleEvent
                .setTransactionLifecycleEventsEventType(getStr(transactionLifecycleEvent.getEventType()));

        xmartTransactionLifecycleEvent
                .setTransactionLifecycleEventsEventDateTime(transactionLifecycleEvent.getEventDateTime());
        xmartTransactionLifecycleEvent
                .setTransactionLifecycleEventsStatus(getStr(transactionLifecycleEvent.getStatus()));
        xmartTransactionLifecycleEvent.setTransactionLifecycleEventsEffectiveDate(
                convertBusinessDate(transactionLifecycleEvent.getEffectiveDate()));
        xmartTransactionLifecycleEvent
                .setTransactionLifecycleEventsEffectiveDateTime(transactionLifecycleEvent.getEffectiveDateTime());
        xmartTransactionLifecycleEvent
                .setPublisherSourceSystemId(transactionLifecycleEvent.getPublisherSourceSystemId());
        xmartTransactionLifecycleEvent.setTriggerRate(transactionLifecycleEvent.getTriggerRate());
        xmartTransactionLifecycleEvent.setAdjustedTriggerRate(transactionLifecycleEvent.getAdjustedTriggerRate());
        xmartTransactionLifecycleEvent.setFixingRate(transactionLifecycleEvent.getFixingRate());
        xmartTransactionLifecycleEvent
                .setCancellationDate(convertBusinessDate(transactionLifecycleEvent.getCancellationDate()));

        if (nonNull(transactionLifecycleEvent.getTakeUpEvent())) {
            if (nonNull(transactionLifecycleEvent.getTakeUpEvent().getPayAmount())) {
                xmartTransactionLifecycleEvent.setPayAmountCurrencyCode(
                        getCurrencyCode(transactionLifecycleEvent.getTakeUpEvent().getPayAmount().getCurrencyId()));
                xmartTransactionLifecycleEvent
                        .setPayAmountValue(transactionLifecycleEvent.getTakeUpEvent().getPayAmount().getValue());
            }
            if (nonNull(transactionLifecycleEvent.getTakeUpEvent().getReceiveAmount())) {
                xmartTransactionLifecycleEvent.setReceiveAmountCurrencyCode(
                        getCurrencyCode(transactionLifecycleEvent.getTakeUpEvent().getReceiveAmount().getCurrencyId()));
                xmartTransactionLifecycleEvent.setReceiveAmountValue(
                        transactionLifecycleEvent.getTakeUpEvent().getReceiveAmount().getValue());
            }
        }

        if (nonNull(transactionLifecycleEvent.getObservation())) {
            xmartTransactionLifecycleEvent
                    .setObservedValue(transactionLifecycleEvent.getObservation().getObservedValue());
            xmartTransactionLifecycleEvent
                    .setBusinessCentre(transactionLifecycleEvent.getObservation().getBusinessCentre());
            xmartTransactionLifecycleEvent
                    .setObservationLegIdentifier(transactionLifecycleEvent.getObservation().getLegIdentifier());
        }

        if (nonNull(transactionLifecycleEvent.getRateReset())) {
            xmartTransactionLifecycleEvent
                    .setRateResetLegIdentifier(transactionLifecycleEvent.getRateReset().getLegIdentifier());
            xmartTransactionLifecycleEvent.setResetRate(transactionLifecycleEvent.getRateReset().getResetRate());
        }

        if (nonNull(transactionLifecycleEvent.getQuantityMovement())) {
            xmartTransactionLifecycleEvent.setQuantityMovementLegIdentifier(
                    transactionLifecycleEvent.getQuantityMovement().getLegIdentifier());
            xmartTransactionLifecycleEvent
                    .setStepDirection(getStr(transactionLifecycleEvent.getQuantityMovement().getStepDirection()));
            xmartTransactionLifecycleEvent.setQuantityUnitOfMeasure(
                    getStr(transactionLifecycleEvent.getQuantityMovement().getQuantityUnitOfMeasure()));
            xmartTransactionLifecycleEvent
                    .setStepQuantity(transactionLifecycleEvent.getQuantityMovement().getStepQuantity());
            xmartTransactionLifecycleEvent
                    .setResultantQuantity(transactionLifecycleEvent.getQuantityMovement().getResultantQuantity());
        }

        if (nonNull(transactionLifecycleEvent.getFxFixingEvent())) {
            xmartTransactionLifecycleEvent
                    .setFxFixingEventLegIdentifier(transactionLifecycleEvent.getFxFixingEvent().getLegIdentifier());
            xmartTransactionLifecycleEvent
                    .setFxFixingEventFxRate(transactionLifecycleEvent.getFxFixingEvent().getFxRate());
            xmartTransactionLifecycleEvent.setCurrency1IdCurrencyCode(
                    getCurrencyCode(transactionLifecycleEvent.getFxFixingEvent().getCurrency1Id()));
            xmartTransactionLifecycleEvent.setCurrency2IdCurrencyCode(
                    getCurrencyCode(transactionLifecycleEvent.getFxFixingEvent().getCurrency2Id()));
            xmartTransactionLifecycleEvent.setCurrencyQuoteBasis(
                    getStr(transactionLifecycleEvent.getFxFixingEvent().getCurrencyQuoteBasis()));
        }

        if (nonNull(transactionLifecycleEvent.getEventPrice())) {
            if (nonNull(transactionLifecycleEvent.getEventPrice().getAmount())) {
                xmartTransactionLifecycleEvent.setEventPriceCurrencyCode(
                        getCurrencyCode(transactionLifecycleEvent.getEventPrice().getAmount().getCurrencyId()));
                xmartTransactionLifecycleEvent
                        .setEventPriceValue(transactionLifecycleEvent.getEventPrice().getAmount().getValue());
            }

            xmartTransactionLifecycleEvent
                    .setEventPricePercentage(transactionLifecycleEvent.getEventPrice().getPercentage());
            xmartTransactionLifecycleEvent
                    .setEventPriceType(getStr(transactionLifecycleEvent.getEventPrice().getType()));
            xmartTransactionLifecycleEvent.setEventPricePrice(transactionLifecycleEvent.getEventPrice().getPrice());
            xmartTransactionLifecycleEvent
                    .setEventPriceCurrency(transactionLifecycleEvent.getEventPrice().getCurrency());
        }

        xmartTransactionLifecycleEvent
                .setTradeEventDate(convertBusinessDate(transactionLifecycleEvent.getTradeEventDate()));

        if (nonNull(transactionLifecycleEvent.getTradeNovation())) {
            xmartTransactionLifecycleEvent
                    .setFullFirstCoupon(transactionLifecycleEvent.getTradeNovation().getFullFirstCoupon());
            xmartTransactionLifecycleEvent.setOriginalTradeDate(
                    convertBusinessDate(transactionLifecycleEvent.getTradeNovation().getOriginalTradeDate()));
            xmartTransactionLifecycleEvent.setOriginalEffectiveDate(
                    convertBusinessDate(transactionLifecycleEvent.getTradeNovation().getOriginalEffectiveDate()));
            xmartTransactionLifecycleEvent.setOriginalTerminationDate(
                    convertBusinessDate(transactionLifecycleEvent.getTradeNovation().getOriginalTerminationDate()));

            if (nonNull(transactionLifecycleEvent.getTradeNovation().getOriginalPrincipal())) {
                xmartTransactionLifecycleEvent.setOriginalPrincipalCurrencyCode(getCurrencyCode(
                        transactionLifecycleEvent.getTradeNovation().getOriginalPrincipal().getCurrencyId()));
                xmartTransactionLifecycleEvent.setOriginalPrincipalValue(
                        transactionLifecycleEvent.getTradeNovation().getOriginalPrincipal().getValue());
            }

            if (nonNull(transactionLifecycleEvent.getTradeNovation().getAssignmentNotional())) {
                if (nonNull(transactionLifecycleEvent.getTradeNovation().getAssignmentNotional().getCurrencyId())) {
                    xmartTransactionLifecycleEvent.setAssignmentNotionalCurrencyCode(getCurrencyCode(
                            transactionLifecycleEvent.getTradeNovation().getAssignmentNotional().getCurrencyId()));
                }
                xmartTransactionLifecycleEvent.setAssignmentNotionalValue(
                        transactionLifecycleEvent.getTradeNovation().getAssignmentNotional().getValue());
            }
        }

        xmartTransactionLifecycleEvent.setLegId(transactionLifecycleEvent.getLegId());
        xmartTransactionLifecycleEvent.setUnderlierId(transactionLifecycleEvent.getUnderlierId());

        if (nonNull(transactionLifecycleEvent.getFixedIncomePositionLiquidation())) {
            if (nonNull(transactionLifecycleEvent.getFixedIncomePositionLiquidation().getLiquidatedQuantity())) {
                xmartTransactionLifecycleEvent.setLiquidatedQuantityType(
                        getStr(transactionLifecycleEvent.getFixedIncomePositionLiquidation().getLiquidatedQuantity()
                                                        .getType()));
                xmartTransactionLifecycleEvent.setLiquidatedQuantityValue(
                        transactionLifecycleEvent.getFixedIncomePositionLiquidation().getLiquidatedQuantity()
                                                 .getValue());
            }

            if (nonNull(transactionLifecycleEvent.getFixedIncomePositionLiquidation().getRealisedPnl())) {
                xmartTransactionLifecycleEvent.setRealisedPnLCurrencyCode(getCurrencyCode(
                        transactionLifecycleEvent.getFixedIncomePositionLiquidation().getRealisedPnl()
                                                 .getCurrencyId()));
                xmartTransactionLifecycleEvent.setRealisedPnLValue(
                        transactionLifecycleEvent.getFixedIncomePositionLiquidation().getRealisedPnl().getValue());
            }

            if (nonNull(transactionLifecycleEvent.getFixedIncomePositionLiquidation().getEarnedInterest())) {
                xmartTransactionLifecycleEvent.setEarnedInterestCurrencyCode(getCurrencyCode(
                        transactionLifecycleEvent.getFixedIncomePositionLiquidation().getEarnedInterest()
                                                 .getCurrencyId()));
                xmartTransactionLifecycleEvent.setEarnedInterestValue(
                        transactionLifecycleEvent.getFixedIncomePositionLiquidation().getEarnedInterest().getValue());
            }

            if (nonNull(transactionLifecycleEvent.getFixedIncomePositionLiquidation().getLiquidatedCost())) {
                xmartTransactionLifecycleEvent.setLiquidatedCostCurrencyCode(getCurrencyCode(
                        transactionLifecycleEvent.getFixedIncomePositionLiquidation().getLiquidatedCost()
                                                 .getCurrencyId()));
                xmartTransactionLifecycleEvent.setLiquidatedCostValue(
                        transactionLifecycleEvent.getFixedIncomePositionLiquidation().getLiquidatedCost().getValue());
            }

            if (nonNull(transactionLifecycleEvent.getFixedIncomePositionLiquidation().getRealAccAmount())) {
                xmartTransactionLifecycleEvent.setRealAccAmountCurrencyCode(getCurrencyCode(
                        transactionLifecycleEvent.getFixedIncomePositionLiquidation().getRealAccAmount()
                                                 .getCurrencyId()));
                xmartTransactionLifecycleEvent.setRealAccAmountValue(
                        transactionLifecycleEvent.getFixedIncomePositionLiquidation().getRealAccAmount().getValue());
            }
        }

        xmartTransactionLifecycleEvent
                .setTransactionLifecycleEventsEventDate(transactionLifecycleEvent.getEventDateTime());
        addEntity(xmartTransactionLifecycleEvent);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
