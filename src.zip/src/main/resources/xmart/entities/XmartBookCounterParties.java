package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.BookCounterparty;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionRoleScheme;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Collection;
import java.util.Map;

import static com.nwm.xmart.util.CollectionsUtil.nullMapToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartBookCounterParties extends
                                     XmartOdcEntityCollection<Transaction, Map<TransactionRoleScheme, BookCounterparty>, XmartBookCounterparty> {
    private static final long serialVersionUID = -7859129951493889648L;
    private static final Logger logger = LoggerFactory.getLogger(XmartBookCounterParties.class);

    public XmartBookCounterParties(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<Map<TransactionRoleScheme, BookCounterparty>> getFromEntities(Transaction transaction) {
        return Arrays.asList(nullMapToEmpty(transaction.getBookCounterparties(), logger,
                "Book Counter Parties not received for document key : " + getDocumentKey()));
    }

    @Override
    public void createAndAddEntity(Map<TransactionRoleScheme, BookCounterparty> map) throws XmartException {
        for (Map.Entry<TransactionRoleScheme, BookCounterparty> entry : map.entrySet()) {

            XmartBookCounterparty xmartBookCounterparty = new XmartBookCounterparty(getDocumentKey());

            if (nonNull(entry)) {
                if (nonNull(entry.getKey())) {
                    xmartBookCounterparty.setTransactionRoleScheme(getStr(entry.getKey()));
                }

                BookCounterparty bookCounterparty = entry.getValue();
                if (nonNull(bookCounterparty) && nonNull(bookCounterparty.getSourceBookId())) {
                    xmartBookCounterparty
                            .setSourceSystemBookId(bookCounterparty.getSourceBookId().getSourceSystemBookId());
                    xmartBookCounterparty
                            .setBookSourceSystemId(getStr(bookCounterparty.getSourceBookId().getBookSourceSystemId()));
                }
            }
            addEntity(xmartBookCounterparty);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}

