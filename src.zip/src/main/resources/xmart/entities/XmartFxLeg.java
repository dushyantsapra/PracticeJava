package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;
import java.util.Date;

public class XmartFxLeg extends XmartEntity {
    private static final long serialVersionUID = 7517195656069241639L;
    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private final String legIdentifier;
    @XmartAttribute
    private Date exchangeRateDate;
    @XmartAttribute
    private String legType;
    @XmartAttribute
    private String volatilitySwapModelBasis;
    @XmartAttribute
    private String forwardVolatilityBasis;
    @XmartAttribute
    private BigDecimal forwardVolatility;
    @XmartAttribute
    private Date firstDrawdownDate;
    @XmartAttribute
    private String fixedCurrencyIdCurrencyCode;
    @XmartAttribute
    private Date forwardFixingDate;
    @XmartAttribute
    private Date forwardFixingDateTime;
    @XmartAttribute
    private String instrumentClass1;
    @XmartAttribute
    private String instrumentClass2;
    @XmartAttribute
    private String fxLegSubType;
    @XmartAttribute
    private Boolean meanSubtractionApplies;
    @XmartAttribute
    private Boolean historicRollRateIndicator;

    public XmartFxLeg(long documentKey, String legIdentifier) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public Date getExchangeRateDate() {
        return exchangeRateDate;
    }

    public void setExchangeRateDate(Date exchangeRateDate) {
        this.exchangeRateDate = exchangeRateDate;
    }

    public String getLegType() {
        return legType;
    }

    public void setLegType(String legType) {
        this.legType = legType;
    }

    public String getVolatilitySwapModelBasis() {
        return volatilitySwapModelBasis;
    }

    public void setVolatilitySwapModelBasis(String volatilitySwapModelBasis) {
        this.volatilitySwapModelBasis = volatilitySwapModelBasis;
    }

    public String getForwardVolatilityBasis() {
        return forwardVolatilityBasis;
    }

    public void setForwardVolatilityBasis(String forwardVolatilityBasis) {
        this.forwardVolatilityBasis = forwardVolatilityBasis;
    }

    public BigDecimal getForwardVolatility() {
        return forwardVolatility;
    }

    public void setForwardVolatility(BigDecimal forwardVolatility) {
        this.forwardVolatility = forwardVolatility;
    }

    public Date getFirstDrawdownDate() {
        return firstDrawdownDate;
    }

    public void setFirstDrawdownDate(Date firstDrawdownDate) {
        this.firstDrawdownDate = firstDrawdownDate;
    }

    public String getFixedCurrencyIdCurrencyCode() {
        return fixedCurrencyIdCurrencyCode;
    }

    public void setFixedCurrencyIdCurrencyCode(String fixedCurrencyIdCurrencyCode) {
        this.fixedCurrencyIdCurrencyCode = fixedCurrencyIdCurrencyCode;
    }

    public Date getForwardFixingDate() {
        return forwardFixingDate;
    }

    public void setForwardFixingDate(Date forwardFixingDate) {
        this.forwardFixingDate = forwardFixingDate;
    }

    public Date getForwardFixingDateTime() {
        return forwardFixingDateTime;
    }

    public void setForwardFixingDateTime(Date forwardFixingDateTime) {
        this.forwardFixingDateTime = forwardFixingDateTime;
    }

    public String getInstrumentClass1() {
        return instrumentClass1;
    }

    public void setInstrumentClass1(String instrumentClass1) {
        this.instrumentClass1 = instrumentClass1;
    }

    public String getInstrumentClass2() {
        return instrumentClass2;
    }

    public void setInstrumentClass2(String instrumentClass2) {
        this.instrumentClass2 = instrumentClass2;
    }

    public String getFxLegSubType() {
        return fxLegSubType;
    }

    public void setFxLegSubType(String fxLegSubType) {
        this.fxLegSubType = fxLegSubType;
    }

    public Boolean getMeanSubtractionApplies() {
        return meanSubtractionApplies;
    }

    public void setMeanSubtractionApplies(Boolean meanSubtractionApplies) {
        this.meanSubtractionApplies = meanSubtractionApplies;
    }

    public Boolean getHistoricRollRateIndicator() {
        return historicRollRateIndicator;
    }

    public void setHistoricRollRateIndicator(Boolean historicRollRateIndicator) {
        this.historicRollRateIndicator = historicRollRateIndicator;
    }
}
