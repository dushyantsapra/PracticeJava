package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionProcessDirective;
import com.rbs.odc.access.domain.TransactionProcessRolePlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.isNotNull;
import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;

public class XmartTransactionProcessRolePlayers
        extends XmartOdcEntityCollection<Transaction, TransactionProcessDirective, XmartTransactionProcessRolePlayer> {
    private static final long serialVersionUID = 3506790148688518009L;
    private Logger logger = LoggerFactory.getLogger(XmartTransactionProcessRolePlayers.class);

    public XmartTransactionProcessRolePlayers(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionProcessDirective> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionProcessDirectives(), logger,
                "TransactionProcessDirectives not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionProcessDirective transactionProcessDirective) throws XmartException {

        for (TransactionProcessRolePlayer processRolePlayer : nullCollToEmpty(
                transactionProcessDirective.getTransactionProcessRolePlayers())) {
            if (isNotNull(processRolePlayer)) {
                XmartTransactionProcessRolePlayer xmartTransactionProcessRolePlayer
                        = new XmartTransactionProcessRolePlayer(getDocumentKey(),
                        transactionProcessDirective.getProcessDirectiveType());

                xmartTransactionProcessRolePlayer
                        .setProcessRolePlayerType(processRolePlayer.getProcessRolePlayerType());
                xmartTransactionProcessRolePlayer.setStatus(processRolePlayer.getStatus());
                xmartTransactionProcessRolePlayer.setAdditionalComments(processRolePlayer.getAdditionalComments());

                if (isNotNull(processRolePlayer.getEmployeeId())) {
                    xmartTransactionProcessRolePlayer
                            .setEmployeeIdentifier(processRolePlayer.getEmployeeId().getEmployeeIdentifier());
                    xmartTransactionProcessRolePlayer.setEmployeeSourceSystemId(
                            getStr(processRolePlayer.getEmployeeId().getEmployeeSourceSystemId()));
                    xmartTransactionProcessRolePlayer
                            .setPersonIdScheme(getStr(processRolePlayer.getEmployeeId().getPersonIdScheme()));
                }
                addEntity(xmartTransactionProcessRolePlayer);
            }
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
