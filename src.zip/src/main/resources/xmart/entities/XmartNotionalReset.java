package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;

public class XmartNotionalReset extends XmartEntity {

    @XmartAttribute
    private String legIdentifier;
    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String sourceSystemEventId;
    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String eventType;
    @XmartAttribute
    private String resetAmountCurrencyCode;
    @XmartAttribute
    private BigDecimal resetAmountValue;

    public XmartNotionalReset(Long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getSourceSystemEventId() {
        return sourceSystemEventId;
    }

    public void setSourceSystemEventId(String sourceSystemEventId) {
        this.sourceSystemEventId = sourceSystemEventId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public void setLegIdentifier(String legIdentifier) {
        this.legIdentifier = legIdentifier;
    }

    public String getResetAmountCurrencyCode() {
        return resetAmountCurrencyCode;
    }

    public void setResetAmountCurrencyCode(String resetAmountCurrencyCode) {
        this.resetAmountCurrencyCode = resetAmountCurrencyCode;
    }

    public BigDecimal getResetAmountValue() {
        return resetAmountValue;
    }

    public void setResetAmountValue(BigDecimal resetAmountValue) {
        this.resetAmountValue = resetAmountValue;
    }
}
