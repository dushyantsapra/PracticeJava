package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;
import java.util.Date;

public class XmartReportableInstrument extends XmartEntity {
    private static final long serialVersionUID = -7347853696897783636L;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private Boolean regimeImpact;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String regimeImpactId;

    @XmartAttribute
    private String instrumentId;

    @XmartAttribute
    private String instrumentScheme;

    @XmartAttribute
    private String instrumentName;

    @XmartAttribute
    private String instrumentClassification;

    @XmartAttribute
    private BigDecimal priceMultiplier;

    @XmartAttribute
    private String optionType;

    @XmartAttribute
    private String optionExerciseStyle;

    @XmartAttribute
    private Date maturityDate;

    @XmartAttribute
    private Date expiryDate;

    @XmartAttribute
    private String settlementType;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String regulatoryRegimeImpactId;

    public XmartReportableInstrument(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getRegulatoryRegimeImpactId() {
        return regulatoryRegimeImpactId;
    }

    public void setRegulatoryRegimeImpactId(String regulatoryRegimeImpactId) {
        this.regulatoryRegimeImpactId = regulatoryRegimeImpactId;
    }

    public String getInstrumentId() {
        return instrumentId;
    }

    public void setInstrumentId(String instrumentId) {
        this.instrumentId = instrumentId;
    }

    public String getInstrumentScheme() {
        return instrumentScheme;
    }

    public void setInstrumentScheme(String instrumentScheme) {
        this.instrumentScheme = instrumentScheme;
    }

    public String getInstrumentName() {
        return instrumentName;
    }

    public void setInstrumentName(String instrumentName) {
        this.instrumentName = instrumentName;
    }

    public String getInstrumentClassification() {
        return instrumentClassification;
    }

    public void setInstrumentClassification(String instrumentClassification) {
        this.instrumentClassification = instrumentClassification;
    }

    public BigDecimal getPriceMultiplier() {
        return priceMultiplier;
    }

    public void setPriceMultiplier(BigDecimal priceMultiplier) {
        this.priceMultiplier = priceMultiplier;
    }

    public String getOptionType() {
        return optionType;
    }

    public void setOptionType(String optionType) {
        this.optionType = optionType;
    }

    public String getOptionExerciseStyle() {
        return optionExerciseStyle;
    }

    public void setOptionExerciseStyle(String optionExerciseStyle) {
        this.optionExerciseStyle = optionExerciseStyle;
    }

    public Date getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(Date maturityDate) {
        this.maturityDate = maturityDate;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getSettlementType() {
        return settlementType;
    }

    public void setSettlementType(String settlementType) {
        this.settlementType = settlementType;
    }

    public Boolean getRegimeImpact() {
        return regimeImpact;
    }

    public void setRegimeImpact(Boolean regimeImpact) {
        this.regimeImpact = regimeImpact;
    }

    public String getRegimeImpactId() {
        return regimeImpactId;
    }

    public void setRegimeImpactId(String regimeImpactId) {
        this.regimeImpactId = regimeImpactId;
    }
}
