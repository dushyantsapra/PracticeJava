package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.CollectionsUtil;
import com.rbs.odc.access.domain.Amount;
import com.rbs.odc.access.domain.ForwardFeature;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLeg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartForwardFeatures extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartForwardFeature> {
    private static final Logger logger = LoggerFactory.getLogger(XmartForwardFeatures.class);
    private static final long serialVersionUID = -7581230372711601629L;

    public XmartForwardFeatures(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return CollectionsUtil.nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "No TransactionLeg received for documentkey :" + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        XmartForwardFeature xmartForwardFeature = new XmartForwardFeature(getDocumentKey(),
                transactionLeg.getLegIdentifier());

        ForwardFeature forwardFeature = transactionLeg.getForwardFeature();

        if (nonNull(forwardFeature)) {

            xmartForwardFeature.setOptionType(getStr(forwardFeature.getOptionType()));
            xmartForwardFeature.setAccumulatorType(forwardFeature.getAccumulatorType());
            xmartForwardFeature.setGearingFactor(forwardFeature.getGearingFactor());
            xmartForwardFeature.setKnockOutTriggerLevel(forwardFeature.getKnockOutTriggerLevel());
            xmartForwardFeature.setMaximumNumberOfTradingDays(forwardFeature.getMaximumNumberOfTradingDays());
            xmartForwardFeature.setNumberOfDailyShares(forwardFeature.getNumberOfDailyShares());

            Amount strikePrice = forwardFeature.getStrikePrice();
            if (strikePrice != null) {
                xmartForwardFeature.setStrikePriceValue(strikePrice.getValue());
                if (strikePrice.getCurrencyId() != null) {
                    xmartForwardFeature.setStrikePriceCurrencyCode(strikePrice.getCurrencyId().getCurrencyCode());
                }
            }
        }

        addEntity(xmartForwardFeature);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
