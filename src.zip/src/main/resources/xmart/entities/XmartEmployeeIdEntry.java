package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartEmployeeIdEntry extends XmartEntity {

    private static final long serialVersionUID = -2684648855396414509L;

    @XmartAttribute
    private String employeeRoleScheme;

    @XmartAttribute
    private String employeeIdentifier;

    @XmartAttribute
    private String employeeSourceSystemId;

    @XmartAttribute
    private String personIdScheme;

    public XmartEmployeeIdEntry(Long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getEmployeeRoleScheme() {
        return employeeRoleScheme;
    }

    public void setEmployeeRoleScheme(String employeeRoleScheme) {
        this.employeeRoleScheme = employeeRoleScheme;
    }

    public String getEmployeeIdentifier() {
        return employeeIdentifier;
    }

    public void setEmployeeIdentifier(String employeeIdentifier) {
        this.employeeIdentifier = employeeIdentifier;
    }

    public String getEmployeeSourceSystemId() {
        return employeeSourceSystemId;
    }

    public void setEmployeeSourceSystemId(String employeeSourceSystemId) {
        this.employeeSourceSystemId = employeeSourceSystemId;
    }

    public String getPersonIdScheme() {
        return personIdScheme;
    }

    public void setPersonIdScheme(String personIdScheme) {
        this.personIdScheme = personIdScheme;
    }
}
