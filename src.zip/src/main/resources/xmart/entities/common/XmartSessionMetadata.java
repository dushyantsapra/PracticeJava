package com.nwm.xmart.entities.common;

import com.nwm.xmart.core.XmartSourceEventMetadata;
import com.nwm.xmart.streaming.database.session.XmartSession;

public class XmartSessionMetadata implements XmartSourceEventMetadata {
    private final XmartSession xmartSession;

    public XmartSessionMetadata(XmartSession xmartSession) {
        this.xmartSession = xmartSession;
    }

    public XmartSession getXmartSession() {
        return xmartSession;
    }
}
