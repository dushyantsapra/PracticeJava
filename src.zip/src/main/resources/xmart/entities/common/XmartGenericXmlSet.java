package com.nwm.xmart.entities.common;

import com.nwm.xmart.core.XmartSourceEventMetadata;
import com.nwm.xmart.core.BindObject;
import com.nwm.xmart.core.XmartSet;

import java.util.*;

import static com.nwm.xmart.util.XmlUtil.getXmlDocument;
import static java.util.Objects.isNull;

public class XmartGenericXmlSet implements BindObject {

    /**
     * Property to control if the XML should be outputted to the logs
     */
    protected Boolean logXML;
    private Map<String, String> xmlEntityMap = new LinkedHashMap<>();
    /**
     * Map for the metadata pertaining to the entity collection name.
     */
    private Map<String, XmartSourceEventMetadata> metadataMap = new HashMap<>();

    /**
     * Utility constructor to provide if the XML generated here should be logged to the log files.
     *
     * @param logXML {@link Boolean} {@code true}: Log XML to file, {@code false}: Do not log it
     */
    public XmartGenericXmlSet(Boolean logXML) {
        this.logXML = logXML;
    }

    /**
     * Method to add the {@link XmartSet} object to the XML set for further processing.
     *
     * @param xmartSet the pojo set whose constituents' xml are to be stored in the xml set
     */
    public void add(XmartGenericSet xmartSet) {

        Collection<String> entityNames = xmartSet.getXmartMappedEntityCollectionNames();

        if (isNull(entityNames) || entityNames.size() == 0) {
            return;
        }

        for (String entity : entityNames) {
            addEntities(entity, xmartSet);
        }
    }

    private void addEntities(String entityCollectionName, XmartGenericSet xmartSet) {
        String xmlEntities = xmartSet.getXmlEntities(entityCollectionName);
        if (!isNull(xmlEntities)) {
            xmlEntityMap.merge(entityCollectionName, xmlEntities, String::concat);
            metadataMap.put(entityCollectionName, xmartSet.getMetadata());
        }
    }

    public String getEntityXml(String requiredEntityName) {
        return getXmlDocument(requiredEntityName, xmlEntityMap.get(requiredEntityName), logXML);
    }

    public XmartSourceEventMetadata getMetadata(String entityCollectionName) {
        return metadataMap.get(entityCollectionName);
    }

    public Map<String, String> getXmlEntityMap() {
        return xmlEntityMap;
    }

    private Set<String> getEntityCollectionsName() {
        return xmlEntityMap.keySet();
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (String collection : getEntityCollectionsName()) {
            builder.append(getEntityXml(collection));
        }
        return builder.toString();
    }
}
