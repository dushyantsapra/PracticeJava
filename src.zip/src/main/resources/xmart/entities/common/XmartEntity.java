package com.nwm.xmart.entities.common;

import com.nwm.xmart.core.BindObject;
import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.XmartUtil;

import javax.xml.bind.annotation.XmlAttribute;

import static com.nwm.xmart.util.XmlUtil.getXml;

/**
 * Created by aslammh on 01/12/17.
 */
public class XmartEntity implements BindObject {
    private static final long serialVersionUID = 1487139785036974960L;

    @XmlAttribute(required = true, name = "documentKey")
    @XmartAttribute(usedInJoin = true, mandatory = true, xmlTrigger = false, name = "documentKey")
    private long documentKey;

    protected XmartEntity(long documentKey) throws XmartException {

        if (XmartUtil.isNotValidDocumentKey(documentKey)) {
            throw new XmartException("Invalid document key passed as : " + documentKey);
        }
        this.documentKey = documentKey;
    }

    protected XmartEntity() throws XmartException {

    }

    public long getDocumentKey() {
        return documentKey;
    }

    public void setDocumentKey(long documentKey) throws XmartException {
        if (XmartUtil.isNotValidDocumentKey(documentKey)) {
            throw new XmartException("Invalid document key passed as : " + documentKey);
        }
        this.documentKey = documentKey;
    }

    /**
     * This method returns the xml representation of the underlying entity. Entities are required to include {@link XmlAttribute} annotation
     * at the members to be included in the xml. Any entity desiring to use other syntax or representation can override this method.
     * <br> This uses {@link com.nwm.xmart.util.XmlUtil#getXml(Object)} method to generate the xml representation.
     *
     * @return XML representation of the supplied object.
     */
    @Override
    public String toString() {
        return getXml(this);
    }
}
