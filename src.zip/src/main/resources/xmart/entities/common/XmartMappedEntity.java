package com.nwm.xmart.entities.common;

import com.nwm.xmart.core.BindObject;
import com.nwm.xmart.exception.XmartException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;

import static com.nwm.xmart.util.XmlUtil.getXmlElement;
import static java.util.Objects.isNull;

/**
 * Created by aslammh on 01/12/17.
 */
public final class XmartMappedEntity implements BindObject {

    private static final long serialVersionUID = 1487139785036974960L;
    private static final Logger logger = LoggerFactory.getLogger(XmartMappedEntity.class);

    private final String entityCollectionName;
    private final String entityName;
    private final List<XmartMappedAttribute> xmartAttributes = new ArrayList<>();
    private Boolean triggerXml;

    public XmartMappedEntity(String entityCollectionName, String entityName) throws XmartException {

        this.entityCollectionName = entityCollectionName;
        this.entityName = entityName;
        this.triggerXml = false;
    }

    public XmartMappedEntity(XmartMappedEntity entityToCopy) throws XmartException {

        this.entityCollectionName = entityToCopy.getEntityCollectionName();
        this.entityName = entityToCopy.getEntityName();
        this.triggerXml = entityToCopy.isTriggered();

        this.xmartAttributes.addAll(entityToCopy.getAttributes());
    }

    public void addAttribute(XmartMappedAttribute attribute) {

        if (existsAttribute(attribute.getAttributeName())) {
            logger.warn("Atribute already present in mapped entity: {}", attribute.getAttributeName());
        }

        if (attribute.isTrigger())
            triggerXml = true;

        xmartAttributes.add(attribute);
    }

    public Boolean isTriggered() {
        return triggerXml;
    }

    public Boolean isMatchingXmlEntity(String entityCollectionName) {

        return (isTriggered() && !isNull(this.entityCollectionName) && this.entityCollectionName
                .equals(entityCollectionName));
    }

    public String getEntityName() {
        return entityName;
    }

    public String getEntityCollectionName() {
        return entityCollectionName;
    }

    public List<XmartMappedAttribute> getAttributes() {
        return xmartAttributes;
    }

    public XmartMappedAttribute getAttribute(String attributeName) {
        for (XmartMappedAttribute attribute : xmartAttributes) {
            if (attributeName.equals(attribute.getAttributeName())) {
                return attribute;
            }
        }
        return null;
    }

    public Object getAttributeValue(String attributeName) {
        for (XmartMappedAttribute attribute : xmartAttributes) {
            if (attributeName.equals(attribute.getAttributeName())) {
                return attribute.getAttributeValue();
            }
        }

        return null;
    }

    private boolean existsAttribute(String attributeName) {
        for (XmartMappedAttribute attribute : xmartAttributes) {
            if (attributeName.equals(attribute.getAttributeName())) {
                return true;
            }
        }
        return false;
    }

    /**
     * This method returns the xml representation of the underlying entity. Entities are required to include {@link XmlAttribute} annotation
     * at the members to be included in the xml. Any entity desiring to use other syntax or representation can override this method.
     * <br> This uses {@link com.nwm.xmart.util.XmlUtil#getXml(Object)} method to generate the xml representation.
     *
     * @return XML representation of the supplied object.
     */
    @Override
    public String toString() {

        if (isTriggered()) {

            StringBuilder stringBuilder = new StringBuilder();

            for (XmartMappedAttribute attribute : xmartAttributes) {
                if (attribute.isOutput()) {
                    if (attribute.isOutput())
                        stringBuilder.append(attribute.toString());
                }
            }

            return getXmlElement(getEntityName(), stringBuilder.toString());
        } else {

            return null;
        }
    }
}
