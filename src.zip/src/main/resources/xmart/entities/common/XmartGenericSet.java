package com.nwm.xmart.entities.common;

import com.nwm.xmart.core.XmartSourceEventMetadata;
import com.nwm.xmart.core.BindObject;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.util.CollectionsUtil;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Super class providing core functionality.
 */
public abstract class XmartGenericSet<T> implements BindObject {

    protected List<XmartMappedEntity> xmartMappedEntities = new ArrayList<>();

    /**
     * This object contains any metadat required to be passed on from source event to sink,
     * different extending classes can use this to place any metadata that they need to be pe propogated down.
     * introduced for the design breaking requirement from DB for including file metadata in the stored proc call.
     * This in not an enhancement, but a w/a to fit misfits in an existing design.
     * <p>
     * Implementors should provide their own class type to sttore in the metadata; could have been in the type definition
     * but not included intentionally
     */
    private XmartSourceEventMetadata metadata;

    /**
     * @return metadata stored for further access
     * //TODO make this abstract and implement in the extending classes
     */
    XmartSourceEventMetadata getMetadata() {
        return metadata;
    }

    /**
     * Store metadata object here
     *
     * @param metadata //TODO make this abstract and implement in the extending classes
     */
    public void setMetadata(XmartSourceEventMetadata metadata) {
        this.metadata = metadata;
    }

    public abstract void addStreamEvent(T streamEvent, int sourceTopicId, MappingNode mappingHierarchy)
            throws XmartException;

    /**
     * To get the window key for windowing done by flink.
     * Implementing classes should provide key based on the implementation.
     *
     * @return key to be used for windowing
     */
    public abstract Long getWindowKey();

    public String getXmlEntities(String requiredEntityCollectionName) {

        Collection<XmartMappedEntity> requiredEntities = getRequiredEntities(requiredEntityCollectionName);

        if (CollectionsUtil.isEmptyOrNull(requiredEntities)) {
            return null;
        }

        StringBuilder builder = new StringBuilder();

        for (XmartMappedEntity entity : requiredEntities) {
            builder.append(entity.toString());
        }

        return builder.toString();
    }

    public Collection<XmartMappedEntity> getRequiredEntities(String requiredEntityCollectionName) {
        return xmartMappedEntities.stream().filter(child -> child.isMatchingXmlEntity(requiredEntityCollectionName))
                                  .collect(Collectors.toList());
    }

    public List<XmartMappedEntity> getXmartMappedEntities() {
        return xmartMappedEntities;
    }

    Collection<String> getXmartMappedEntityCollectionNames() {

        return xmartMappedEntities.stream().map(XmartMappedEntity::getEntityCollectionName).distinct()
                                  .collect(Collectors.toList());
    }
}

