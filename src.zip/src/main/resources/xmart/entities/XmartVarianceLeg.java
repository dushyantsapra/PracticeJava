package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;

public class XmartVarianceLeg extends XmartEntity {
    private static final long serialVersionUID = -5018355441355166464L;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private final String legIdentifier;
    @XmartAttribute
    private BigDecimal strikeLevel, varianceAmountValue;
    @XmartAttribute
    private String strikeOffMethod, varianceAmountCurrencyCode;

    public XmartVarianceLeg(long documentKey, String legIdentifier) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public BigDecimal getStrikeLevel() {
        return strikeLevel;
    }

    public void setStrikeLevel(BigDecimal strikeLevel) {
        this.strikeLevel = strikeLevel;
    }

    public String getStrikeOffMethod() {
        return strikeOffMethod;
    }

    public void setStrikeOffMethod(String strikeOffMethod) {
        this.strikeOffMethod = strikeOffMethod;
    }

    public String getVarianceAmountCurrencyCode() {
        return varianceAmountCurrencyCode;
    }

    public void setVarianceAmountCurrencyCode(String varianceAmountCurrencyCode) {
        this.varianceAmountCurrencyCode = varianceAmountCurrencyCode;
    }

    public BigDecimal getVarianceAmountValue() {
        return varianceAmountValue;
    }

    public void setVarianceAmountValue(BigDecimal varianceAmountValue) {
        this.varianceAmountValue = varianceAmountValue;
    }
}
