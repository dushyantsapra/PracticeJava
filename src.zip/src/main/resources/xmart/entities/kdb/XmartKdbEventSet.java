package com.nwm.xmart.entities.kdb;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.streaming.source.kdb.event.KDBSourceEvent;

import static com.nwm.xmart.util.XmartUtil.getStr;

/**
 * Created by aslammh on 08/08/17.
 */
public class XmartKdbEventSet extends XmartGenericSet<KDBSourceEvent> {

    private static final long serialVersionUID = -2957788404037807712L;

    private Long documentKey;

    @Override
    public void addStreamEvent(KDBSourceEvent sourceEvent, int jobId, MappingNode mappingHierarchy)
            throws XmartException {

        XmartKdbSourceEvent xmartKdbSourceEvent = new XmartKdbSourceEvent(jobId, sourceEvent);

        documentKey = xmartKdbSourceEvent.getDocumentKey();

        String rootObjectName = xmartKdbSourceEvent.getSourceFunction();
        // Some kdb functions are used twice but on different tables. We need to append this to function name to get
        //unique value in mapping csv
        String tableName = getStr(xmartKdbSourceEvent.getTableName());
        if (tableName != null && !tableName.equals("")) {
            rootObjectName += "_" + tableName;
        }

        xmartMappedEntities.addAll(mappingHierarchy.mapSourceObject(rootObjectName, xmartKdbSourceEvent, null));
    }

    @Override
    public Long getWindowKey() {
        return documentKey;
    }

    public Long getDocumentKey() {
        return documentKey;
    }

    @Override
    public String toString() {
        return ("XmartTransactionSet [" + documentKey) + "]";
    }
}
