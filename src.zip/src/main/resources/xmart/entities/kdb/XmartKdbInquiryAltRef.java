package com.nwm.xmart.entities.kdb;

import java.io.Serializable;
import java.util.Date;

/**
 * Simple class that holds a single KDB INquiry State
 *
 * @author heskets
 */
public class XmartKdbInquiryAltRef implements Serializable {

    private final String alternateReferenceType;
    private final String alternateReferenceId;

    public XmartKdbInquiryAltRef(String alternateReferenceType, String alternateReferenceId) {
        this.alternateReferenceType = alternateReferenceType;
        this.alternateReferenceId = alternateReferenceId;
    }

    public String getAlternateReferenceType() {
        return alternateReferenceType;
    }

    public String getAlternateReferenceId() {
        return alternateReferenceId;
    }
}
