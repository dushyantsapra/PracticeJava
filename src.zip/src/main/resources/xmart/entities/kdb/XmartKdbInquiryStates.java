package com.nwm.xmart.entities.kdb;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Simple class that holds a list of KDB Inquiry State
 *
 * @author heskets
 */
public class XmartKdbInquiryStates implements Serializable {

    private ArrayList<XmartKdbInquiryState> inquiryStates = new ArrayList<>();

    public XmartKdbInquiryStates() {
    }

    public void addInquiryState(XmartKdbInquiryState newInquiryState) {
        inquiryStates.add(newInquiryState);
    }

    public Collection getInquiryStates() {
        return inquiryStates;
    }
}
