package com.nwm.xmart.entities.kdb;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDateTime;
import java.time.LocalTime;

import static com.nwm.xmart.util.BusinessRulesUtil.isKdbNull;

/**
 * Simple class that holds a single KDB Inquiry Leg
 *
 * @author heskets
 */
public class XmartKdbInquiryLeg implements Serializable {

    private final String legIndex;
    private final String notionalCcy;
    private final String cfiCode;
    private final String deliveryType;
    private final LocalDateTime expiryDate;
    private final String isin;
    private final Double notional;
    private final Double price;
    private final Double strike;
    private final String buySell;
    private final Date optionDate;
    private final String optionType;
    private final Double bestBidPrice;
    private final Double bestAskPrice;
    private final Double coverPrice;
    private final Double yield;
    private final String reportingWaiverType;
    private final String product;

    public XmartKdbInquiryLeg(String legIndex, String cfiCode, String notionalCcy, String deliveryType,
            LocalDateTime expiryDate, String isin, Double notional, Double price, Double strike, String buySell,
            Date optionDate, String optionType, Double bestBidPrice, Double bestAskPrice, Double coverPrice,
            Double yield, String reportingWaiverType, String product) {
        this.legIndex = legIndex;
        this.notionalCcy = notionalCcy;
        this.cfiCode = cfiCode;
        this.deliveryType = deliveryType;
        this.expiryDate = expiryDate;
        this.isin = isin;
        this.notional = notional;
        this.price = price;
        this.strike = strike;
        this.buySell = buySell;
        this.optionDate = optionDate;
        this.optionType = optionType;
        this.bestBidPrice = bestBidPrice;
        this.bestAskPrice = bestAskPrice;
        this.coverPrice = coverPrice;
        this.yield = yield;
        this.reportingWaiverType = reportingWaiverType;
        this.product = product;
    }

    public String getLegIndex() {
        return legIndex;
    }

    public String getNotionalCcy() {
        return notionalCcy;
    }

    public String getDeliveryType() {
        return deliveryType;
    }

    public LocalDateTime getExpiryDate() {
        return expiryDate;
    }

    public String getIsin() {
        return isin;
    }

    public Double getNotional() {
        return notional;
    }

    public String getBuySell() {
        return buySell;
    }

    public Date getOptionDate() {
        return optionDate;
    }

    public String getCfiCode() {
        return cfiCode;
    }

    public Double getPrice() {
        return price;
    }

    public Double getStrike() {
        return strike;
    }

    public String getOptionType() {
        return optionType;
    }

    public Double getBestBidPrice() {
        return bestBidPrice;
    }

    public Double getBestAskPrice() {
        return bestAskPrice;
    }

    public Double getCoverPrice() {
        return coverPrice;
    }

    public Double getYield() {
        return yield;
    }

    public String getReportingWaiverType() {
        return reportingWaiverType;
    }

    public String getProduct() {
        return product;
    }

    public static class XmartKdbInquiryLegBuilder {
        private String legIndex;
        private String notionalCcy;
        private String cfiCode;
        private String deliveryType;
        private LocalDateTime expiryDate;
        private String isin;
        private Double notional;
        private Double price;
        private Double strike;
        private String buySell;
        private Date optionDate;
        private String optionType;
        private Double bestAskPrice;
        private Double bestBidPrice;
        private Double coverPrice;
        private Double yield;
        private String reportingWaiverType;
        private String product;

        public XmartKdbInquiryLegBuilder() {
            this.legIndex = null;
            this.notionalCcy = null;
            this.cfiCode = null;
            this.deliveryType = null;
            this.expiryDate = null;
            this.isin = null;
            this.notional = null;
            this.price = null;
            this.strike = null;
            this.buySell = null;
            this.optionDate = null;
            this.optionType = null;
            this.bestBidPrice = null;
            this.bestAskPrice = null;
            this.coverPrice = null;
            this.yield = null;
            this.reportingWaiverType = null;
            this.product = null;
        }

        public XmartKdbInquiryLegBuilder legIndex(String newLegIndex) {
            this.legIndex = newLegIndex;
            return this;
        }

        public XmartKdbInquiryLegBuilder notionalCcy(String newNotionalCcy) {
            this.notionalCcy = newNotionalCcy;
            return this;
        }

        public XmartKdbInquiryLegBuilder cfiCode(String newCfiCode) {
            this.cfiCode = newCfiCode;
            return this;
        }

        public XmartKdbInquiryLegBuilder deliveryType(String newDeliveryType) {
            this.deliveryType = newDeliveryType;
            return this;
        }

        public XmartKdbInquiryLegBuilder expiryDate(LocalDateTime newExpiryDate) {
            this.expiryDate = newExpiryDate;
            return this;
        }

        public XmartKdbInquiryLegBuilder expiryDate(java.sql.Date newExpiryDate) {
            this.expiryDate = !isKdbNull(newExpiryDate) ? LocalDateTime.of(newExpiryDate.toLocalDate(), LocalTime.MIN) :
                              null;
            return this;
        }

        public XmartKdbInquiryLegBuilder expiryDate(java.sql.Timestamp newExpiryDate) {
            this.expiryDate = !isKdbNull(newExpiryDate) ? newExpiryDate.toLocalDateTime() : null;
            return this;
        }

        public XmartKdbInquiryLegBuilder isin(String newIsin) {
            this.isin = newIsin;
            return this;
        }

        public XmartKdbInquiryLegBuilder notional(Double newNotional) {
            this.notional = newNotional;
            return this;
        }

        public XmartKdbInquiryLegBuilder price(Double newPrice) {
            this.price = newPrice;
            return this;
        }

        public XmartKdbInquiryLegBuilder strike(Double newStrike) {
            this.strike = newStrike;
            return this;
        }

        public XmartKdbInquiryLegBuilder buySell(String newBuySell) {
            this.buySell = newBuySell;
            return this;
        }

        public XmartKdbInquiryLegBuilder optionDate(Date newOptionDate) {
            this.optionDate = newOptionDate;
            return this;
        }

        public XmartKdbInquiryLegBuilder optionType(String newOptionType) {
            this.optionType = newOptionType;
            return this;
        }

        public XmartKdbInquiryLegBuilder bestAskPrice(Double newBestAskPrice) {
            this.bestAskPrice = newBestAskPrice;
            return this;
        }

        public XmartKdbInquiryLegBuilder bestBidPrice(Double newBestBidPrice) {
            this.bestBidPrice = newBestBidPrice;
            return this;
        }

        public XmartKdbInquiryLegBuilder coverPrice(Double newCoverPrice) {
            this.coverPrice = newCoverPrice;
            return this;
        }

        public XmartKdbInquiryLegBuilder yield(Double newYield) {
            this.yield = newYield;
            return this;
        }

        public XmartKdbInquiryLegBuilder reportingWaiverType(String newReportingWaiverType) {
            this.reportingWaiverType = newReportingWaiverType;
            return this;
        }

        public XmartKdbInquiryLegBuilder product(String newProduct) {
            this.product = newProduct;
            return this;
        }

        public XmartKdbInquiryLeg create() {
            return new XmartKdbInquiryLeg(legIndex, cfiCode, notionalCcy, deliveryType, expiryDate, isin, notional,
                    price, strike, buySell, optionDate, optionType, bestBidPrice, bestAskPrice, coverPrice, yield,
                    reportingWaiverType, product);
        }
    }
}
