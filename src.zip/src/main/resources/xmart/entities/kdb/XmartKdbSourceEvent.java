package com.nwm.xmart.entities.kdb;

import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.kdb.event.KDBSourceEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.temporal.ChronoField;
import java.util.HashMap;
import java.util.Map;

import static java.util.Objects.isNull;

/**
 * Created by aslammh on 08/08/17.
 */
public class XmartKdbSourceEvent extends XmartEntity {
    private static final Logger logger = LoggerFactory.getLogger(XmartKdbSourceEvent.class);

    private static final long serialVersionUID = 7845851523286650033L;

    private int jobId;

    private boolean success;
    private String message;
    private String tag;
    private String[] columnNames;
    private Object[] recordData;
    private Map<String, Object> mappedValues;
    private long recordIndex;
    private long currentJobEventID;
    private int sourceId;
    private String sourceFunction;
    private String tableName;
    private long documentReceivedTimestamp;

    public XmartKdbSourceEvent(int jobId, KDBSourceEvent sourceEvent) throws XmartException {

        super(generateDocumentKey(jobId, sourceEvent.getDocumentReceivedTimestamp(),
                Integer.parseInt(sourceEvent.getSourceID()), sourceEvent.getCurrentJobEventID()));

        this.jobId = jobId;
        this.success = sourceEvent.isSuccess();

        if (!isSuccess()) {
            throw new XmartException(
                    "KDB query returned a failure status. Associated message: " + sourceEvent.getMessage());
        }

        this.message = sourceEvent.getMessage();
        this.tag = sourceEvent.getTag();

        this.sourceId = Integer.parseInt(sourceEvent.getSourceID());
        this.sourceFunction = sourceEvent.getFunctionName();
        this.tableName = sourceEvent.getTableName();

        this.columnNames = sourceEvent.getColumnNames();
        this.recordData = sourceEvent.getRecordData();
        this.recordIndex = sourceEvent.getRecordIndex();
        this.currentJobEventID = sourceEvent.getCurrentJobEventID();

        if (isNull(columnNames) || columnNames.length == 0) {
            throw new XmartException("NULL or empty columnNames provided to XmartKdbSourceEvent.");
        }

        if (isNull(recordData) || recordData.length == 0) {
            throw new XmartException("NULL or empty recordData provided to XmartKdbSourceEvent.");
        }

        if (columnNames.length != recordData.length) {
            throw new XmartException(
                    "Mismatch between number of columnNames and number of columns provided to XmartKdbSourceEvent.");
        }

        this.mappedValues = toMap(sourceEvent.getColumnNames(), sourceEvent.getRecordData());

        this.documentReceivedTimestamp = sourceEvent.getDocumentReceivedTimestamp();
    }

    private static long generateDocumentKey(int jobId, long timestamp, int sourceId, long recordId)
            throws XmartException {

        int documentKeyLength = 19;

        StringBuilder docKeyStr = new StringBuilder(documentKeyLength);
        String docKeyComp;

        LocalDateTime consumeUtcTime = Instant.ofEpochMilli(timestamp).atZone(ZoneId.of("UTC")).toLocalDateTime();

        docKeyComp = String.format("%02d", consumeUtcTime.get(ChronoField.YEAR) % 100);
        docKeyStr.insert(0, docKeyComp.substring(docKeyComp.length() - 2));
        docKeyComp = String.format("%03d", consumeUtcTime.getDayOfYear());
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 3));

        docKeyComp = String.format("%02d", jobId);
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 2));

        docKeyComp = String.format("%01d", sourceId);
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 1));

        docKeyComp = String.format("%02d", consumeUtcTime.getHour());
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 2));
        docKeyComp = String.format("%02d", consumeUtcTime.getMinute());
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 2));
        docKeyComp = String.format("%02d", consumeUtcTime.getSecond());
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 2));

        docKeyComp = String.format("%05d", recordId);
        docKeyStr.append(docKeyComp.substring(docKeyComp.length() - 5));

        return Long.parseLong(docKeyStr.toString());
    }

    private static Map<String, Object> toMap(String[] keys, Object[] values) throws XmartException {

        HashMap<String, Object> map = new HashMap<>();

        int keysSize = (keys != null) ? keys.length : 0;
        int valuesSize = (values != null) ? values.length : 0;

        if (keysSize == 0 && valuesSize == 0) {
            // return mutable map
            return map;
        }

        if (keysSize != valuesSize) {
            throw new XmartException("The number of keys in KDB source event doesn't match the number of values.");
        }

        for (int i = 0; i < keysSize; i++) {
            map.put(keys[i], values[i]);
        }

        return map;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("XmartKdbSourceEvent [");
        builder.append(" topicId=\"").append(getJobId()).append("\"");
        builder.append(" documentKey=\"").append(getDocumentKey()).append("\"");
        builder.append("]");
        return builder.toString();
    }

    public int getJobId() {
        return jobId;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public Object getIndexedValue(int index) {
        return recordData[index];
    }

    public Object getMapValue(String key) {
        return mappedValues.get(key);
    }

    public String getTag() {
        return tag;
    }

    public String[] getColumnNames() {
        return columnNames;
    }

    public Object[] getRecordData() {
        return recordData;
    }

    public long getRecordIndex() {
        return recordIndex;
    }

    public int getSourceId() {
        return sourceId;
    }

    public String getSourceFunction() {
        return sourceFunction;
    }

    public long getDocumentReceivedTimestamp() {
        return documentReceivedTimestamp;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
}
