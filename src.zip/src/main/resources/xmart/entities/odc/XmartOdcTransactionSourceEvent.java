package com.nwm.xmart.entities.odc;

import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionId;
import com.rbs.odc.core.domain.ODCValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoField;

import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;

/**
 * Created by aslammh on 08/08/17.
 */
public class XmartOdcTransactionSourceEvent extends XmartEntity {
    private static final Logger logger = LoggerFactory.getLogger(XmartOdcTransactionSourceEvent.class);

    private static final long serialVersionUID = 7845851523286650033L;
    Transaction odcTransaction = null;
    Long odcVersion = null;
    long documentKey = 0;
    private DataFabricStreamEvent<ODCValue<TransactionId, Transaction>> dfStreamEvent;
    private String sourceTopic = null;
    private int sourcePartition = 0;
    private int topicId = 0;
    private long sourcePosition = 0;
    private long sourceTimestamp = 0;
    private String sourceSystemId;
    private String sourceSystemTransactionId;
    private String version = null;

    public XmartOdcTransactionSourceEvent(int topicId,
            DataFabricStreamEvent<ODCValue<TransactionId, Transaction>> dfStreamEvent) throws XmartException {

        super();

        if (isNull(dfStreamEvent)) {
            throw new XmartException("NULL source record provided to XmartOdcTransactionSourceEvent.");
        }

        this.dfStreamEvent = dfStreamEvent;

        this.sourceTopic = dfStreamEvent.getTopic();
        this.sourcePartition = dfStreamEvent.getPartition();
        this.topicId = topicId;
        this.sourcePosition = dfStreamEvent.getStreamPosition();
        this.sourceTimestamp = dfStreamEvent.getTimestamp();

        ODCValue<TransactionId, Transaction> eventPayload = dfStreamEvent.getEventPayload();

        if (isNull(eventPayload)) {
            throw new XmartException(
                    "Invalid source record provided to XmartOdcTransactionSourceEvent - NULL payload.");
        }

        this.odcTransaction = dfStreamEvent.getEventPayload().getDomainObject();
        this.odcVersion = dfStreamEvent.getEventPayload().getOdcVersion();

        if (isNull(odcTransaction)) {
            throw new XmartException(
                    "Invalid source record provided to XmartOdcTransactionSourceEvent - NULL transaction.");
        }

        TransactionId transactionId = odcTransaction.getId();

        if (isNull(dfStreamEvent.getEventPayload())) {
            throw new XmartException(
                    "Invalid source record provided to XmartOdcTransactionSourceEvent - NULL transaction id.");
        }

        this.sourceSystemTransactionId = transactionId.getSourceSystemTransactionId();
        this.sourceSystemId = getStr(transactionId.getSourceSystemId());

        StringBuilder documentKeyString = new StringBuilder(19);
        String documentKeyComponent = null;

        LocalDateTime consumeTime = LocalDateTime
                .ofInstant(Instant.ofEpochMilli(sourceTimestamp), ZoneId.systemDefault());

        documentKeyString.setLength(0);

        documentKeyComponent = String.format("%02d", consumeTime.get(ChronoField.YEAR));
        documentKeyString.insert(0, documentKeyComponent.substring(documentKeyComponent.length() - 2));

        documentKeyComponent = String.format("%03d", consumeTime.getDayOfYear());
        documentKeyString.append(documentKeyComponent.substring(documentKeyComponent.length() - 3));

        documentKeyComponent = String.format("%03d", topicId);
        documentKeyString.append(documentKeyComponent.substring(documentKeyComponent.length() - 3));

        documentKeyComponent = String.format("%02d", sourcePartition);
        documentKeyString.append(documentKeyComponent.substring(documentKeyComponent.length() - 2));

        documentKeyComponent = String.format("%09d", sourcePosition);
        documentKeyString.append(documentKeyComponent.substring(documentKeyComponent.length() - 9));

        documentKey = Long.parseLong(documentKeyString.toString());

        version = odcTransaction.getVersion();
    }

    public DataFabricStreamEvent<ODCValue<TransactionId, Transaction>> getDataFabricStreamEvent() {
        return dfStreamEvent;
    }

    public String getSourceTopic() {
        return sourceTopic;
    }

    public int getTopicId() {
        return topicId;
    }

    public long getSourcePosition() {
        return sourcePosition;
    }

    public int getSourcePartition() {
        return sourcePartition;
    }

    public long getSourceTimestamp() {
        return sourceTimestamp;
    }

    public String getSourceSystemId() {
        return sourceSystemId;
    }

    public String getSourceSystemTransactionId() {
        return sourceSystemTransactionId;
    }

    public String getVersion() {
        return version;
    }

    public Transaction getOdcTransaction() {
        return odcTransaction;
    }

    public Long getOdcVersion() {
        return odcVersion;
    }

    public long getDocumentKey() {
        return documentKey;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("XmartOdcTransactionSourceEvent [");
        builder.append("sourceTopic=\"").append(getSourceTopic()).append("\"");
        builder.append(" topicId=\"").append(getTopicId()).append("\"");
        builder.append(" sourcePosition=\"").append(getSourcePosition()).append("\"");
        builder.append(" sourcePartition=\"").append(getSourcePartition()).append("\"");
        builder.append(" sourceTimestamp=\"").append(getSourceTimestamp()).append("\"");
        builder.append(" sourceSystemId=\"").append(getSourceSystemId()).append("\"");
        builder.append(" sourceSystemTransactionId=\"").append(getSourceSystemTransactionId()).append("\"");
        builder.append(" version=\"").append(getVersion()).append("\"");
        builder.append(" documentKey=\"").append(getDocumentKey()).append("\"");
        builder.append("]");
        return builder.toString();
    }
}
