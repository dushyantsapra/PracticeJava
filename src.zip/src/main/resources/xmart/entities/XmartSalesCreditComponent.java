package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;

public class XmartSalesCreditComponent extends XmartEntity {
    private static final long serialVersionUID = 7408538321857195225L;

    @XmartAttribute
    private String componentAmountCurrencyCode;

    @XmartAttribute
    private BigDecimal componentAmountValue;

    @XmartAttribute
    private BigDecimal componentPercentage;

    @XmartAttribute
    private String componentType;

    @XmartAttribute
    private BigDecimal points;

    @XmartAttribute
    private String riskCommissionAdjustment;

    @XmartAttribute
    private String salesCreditComponentType;

    public XmartSalesCreditComponent(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getComponentAmountCurrencyCode() {
        return componentAmountCurrencyCode;
    }

    public void setComponentAmountCurrencyCode(String componentAmountCurrencyCode) {
        this.componentAmountCurrencyCode = componentAmountCurrencyCode;
    }

    public BigDecimal getComponentAmountValue() {
        return componentAmountValue;
    }

    public void setComponentAmountValue(BigDecimal componentAmountValue) {
        this.componentAmountValue = componentAmountValue;
    }

    public BigDecimal getComponentPercentage() {
        return componentPercentage;
    }

    public void setComponentPercentage(BigDecimal componentPercentage) {
        this.componentPercentage = componentPercentage;
    }

    public String getComponentType() {
        return componentType;
    }

    public void setComponentType(String componentType) {
        this.componentType = componentType;
    }

    public BigDecimal getPoints() {
        return points;
    }

    public void setPoints(BigDecimal points) {
        this.points = points;
    }

    public String getRiskCommissionAdjustment() {
        return riskCommissionAdjustment;
    }

    public void setRiskCommissionAdjustment(String riskCommissionAdjustment) {
        this.riskCommissionAdjustment = riskCommissionAdjustment;
    }

    public String getSalesCreditComponentType() {
        return salesCreditComponentType;
    }

    public void setSalesCreditComponentType(String salesCreditComponentType) {
        this.salesCreditComponentType = salesCreditComponentType;
    }
}
