package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.RegimePartyRole;
import com.rbs.odc.access.domain.RegulatoryRegimeImpact;
import com.rbs.odc.access.domain.TradingCounterpartyId;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

/**
 * Created by aslammh on 17/11/17.
 */
public class XmartRegimePartyRoles
        extends XmartOdcEntityCollection<Transaction, RegulatoryRegimeImpact, XmartRegimePartyRole> {

    private static final long serialVersionUID = 8973096643293751039L;
    private static final Logger logger = LoggerFactory.getLogger(XmartRegimePartyRoles.class);

    public XmartRegimePartyRoles(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<RegulatoryRegimeImpact> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getRegulatoryRegimeImpact(), logger,
                "RegulatoryRegimeImpact not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(RegulatoryRegimeImpact regulatoryRegimeImpact) throws XmartException {
        for (RegimePartyRole regimePartyRole : nullCollToEmpty(regulatoryRegimeImpact.getRegimePartyRoles())) {

            XmartRegimePartyRole xmartRegimePartyRole = new XmartRegimePartyRole(getDocumentKey());
            xmartRegimePartyRole.setRegimeImpact(regulatoryRegimeImpact.getRegimeImpact());
            xmartRegimePartyRole.setRegimeImpactId(regulatoryRegimeImpact.getRegimeImpactId());
            xmartRegimePartyRole.setRegulatoryRegimeImpactId(regulatoryRegimeImpact.getId());
            if (nonNull(regimePartyRole)) {
                xmartRegimePartyRole.setReportingRoleScheme(getStr(regimePartyRole.getReportingRoleScheme()));
                xmartRegimePartyRole.setTradingCapacity(getStr(regimePartyRole.getTradingCapacity()));
                TradingCounterpartyId tradingCounterpartyId = regimePartyRole.getTradingCounterpartyId();
                if (nonNull(tradingCounterpartyId)) {
                    xmartRegimePartyRole.setPartyClassification(getStr(tradingCounterpartyId.getPartyClassification()));
                    xmartRegimePartyRole.setPartyReference(tradingCounterpartyId.getPartyReference());
                }
                xmartRegimePartyRole.setReportableTradingRole(getStr(regimePartyRole.getReportableTradingRole()));
            }
            addEntity(xmartRegimePartyRole);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
