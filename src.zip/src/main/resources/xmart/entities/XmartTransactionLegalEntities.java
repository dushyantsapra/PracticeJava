package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.PartyId;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLegalEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

/**
 * Created by aslammh on 13/11/17.
 */
public class XmartTransactionLegalEntities
        extends XmartOdcEntityCollection<Transaction, TransactionLegalEntity, XmartTransactionLegalEntity> {

    private static final long serialVersionUID = -5786636253116016934L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionLegalEntities.class);

    public XmartTransactionLegalEntities(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLegalEntity> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegalEntities(), logger,
                "No TransactionLegalEntity received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLegalEntity transactionLegalEntity) throws XmartException {

        XmartTransactionLegalEntity xmartTransactionLegalEntity = new XmartTransactionLegalEntity(getDocumentKey());

        xmartTransactionLegalEntity.setTransactionRoleScheme(transactionLegalEntity.getTransactionRoleScheme());

        PartyId partyEntityId = transactionLegalEntity.getPartyEntityId();
        if (nonNull(partyEntityId)) {
            xmartTransactionLegalEntity.setPartyId(partyEntityId.getPartyId());
            xmartTransactionLegalEntity.setPartyIdClassification(getStr(partyEntityId.getScheme()));
        }

        addEntity(xmartTransactionLegalEntity);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
