package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartTransactionProcessDirective extends XmartEntity {
    private static final long serialVersionUID = 2176225070644156657L;

    @XmartAttribute(usedInJoin = true)
    private String processDirectiveType;

    @XmartAttribute
    private String additionalComments;

    @XmartAttribute
    private Boolean confirmationRequired;

    @XmartAttribute
    private Boolean foConfirmationReview;

    @XmartAttribute
    private Boolean manualConfirmationReqd;

    @XmartAttribute
    private Boolean confirmLegsIndividually;

    public XmartTransactionProcessDirective(long docKey) throws XmartException {
        super(docKey);
    }

    public String getProcessDirectiveType() {
        return processDirectiveType;
    }

    public void setProcessDirectiveType(String processDirectiveType) {
        this.processDirectiveType = processDirectiveType;
    }

    public String getAdditionalComments() {
        return additionalComments;
    }

    public void setAdditionalComments(String additionalComments) {
        this.additionalComments = additionalComments;
    }

    public Boolean getConfirmationRequired() {
        return confirmationRequired;
    }

    public void setConfirmationRequired(Boolean confirmationRequired) {
        this.confirmationRequired = confirmationRequired;
    }

    public Boolean getFoConfirmationReview() {
        return foConfirmationReview;
    }

    public void setFoConfirmationReview(Boolean foConfirmationReview) {
        this.foConfirmationReview = foConfirmationReview;
    }

    public Boolean getManualConfirmationReqd() {
        return manualConfirmationReqd;
    }

    public void setManualConfirmationReqd(Boolean manualConfirmationReqd) {
        this.manualConfirmationReqd = manualConfirmationReqd;
    }

    public Boolean getConfirmLegsIndividually() {
        return confirmLegsIndividually;
    }

    public void setConfirmLegsIndividually(Boolean confirmLegsIndividually) {
        this.confirmLegsIndividually = confirmLegsIndividually;
    }
}
