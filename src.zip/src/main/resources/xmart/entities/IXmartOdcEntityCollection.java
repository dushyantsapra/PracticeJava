package com.nwm.xmart.entities;

import com.nwm.xmart.entities.common.IXmartEntityCollection;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.util.Collection;

public interface IXmartOdcEntityCollection<TopMostEntity, FromEntity, ToEntity extends XmartEntity>
        extends IXmartEntityCollection {
    /**
     * The list that contains the created XmartOdcEntityCollection.
     *
     * @return
     */
    Collection<ToEntity> getXmartEntities();

    XmartOdcEntityCollection build() throws XmartException;

    /**
     * gives the iterator to create the required entity.
     *
     * @param topMostEntity the top most entity which holds the data.
     *
     * @return the iterator on the entity which is to be used to create the required entity.
     */
    Collection<FromEntity> getFromEntities(TopMostEntity topMostEntity);

    /**
     * creates the required entity. It is the responsibility of the subclass to call addEntity as soon as the required entity is created.
     *
     * @param fromEntity the entity which is to be used to create the required entity
     *
     * @return the required entity
     *
     * @throws XmartException
     */
    void createAndAddEntity(FromEntity fromEntity) throws XmartException;

    void addEntity(ToEntity entity) throws XmartException;

    boolean shouldAdd(ToEntity entity) throws XmartException;

    boolean isValid(ToEntity entity) throws XmartException;
}
