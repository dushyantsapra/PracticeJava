package com.nwm.xmart.entities.mdx;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.util.CollectionsUtil;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class XmartMdxDocumentEventSet extends XmartGenericSet<MdxDocumentEvent> {
    private static final long serialVersionUID = -2957788404037807712L;

    private Long documentKey;

    public XmartMdxDocumentEventSet() {
        // Nothing in default constructor
    }

    @Override
    public void addStreamEvent(MdxDocumentEvent streamEvent, int jobId, MappingNode mappingHierarchy)
            throws XmartException {
        XmartMdxDocumentEvent xmartMdxDocumentEvent = new XmartMdxDocumentEvent(jobId, streamEvent);

        documentKey = xmartMdxDocumentEvent.getDocumentKey();

        if ("mdxRefRegInstrument".equals(streamEvent.getFunctionName())) {
            xmartMappedEntities.addAll(mappingHierarchy
                    .mapSourceObject(streamEvent.getFunctionName(), xmartMdxDocumentEvent, null));
            xmartMappedEntities.addAll(mappingHierarchy
                    .mapSourceObject("mdxRefRegInstrumentUnderlying", xmartMdxDocumentEvent, null));
        } else {
            xmartMappedEntities.addAll(mappingHierarchy
                    .mapSourceObject(streamEvent.getFunctionName(), xmartMdxDocumentEvent, null));
        }
    }

    @Override
    public Long getWindowKey() {
        return documentKey;
    }

    public Long getDocumentKey() {
        return documentKey;
    }

    public List<XmartMappedEntity> getXmartMappedEntities() {
        return xmartMappedEntities;
    }

    public Collection<XmartMappedEntity> getRequiredEntities(String requiredEntityCollectionName) {
        return xmartMappedEntities.stream().filter(child -> child.isMatchingXmlEntity(requiredEntityCollectionName))
                                  .collect(Collectors.toList());
    }

    public String getXmlEntities(String requiredEntityCollectionName) {
        Collection<XmartMappedEntity> requiredEntities = getRequiredEntities(requiredEntityCollectionName);

        if (CollectionsUtil.isEmptyOrNull(requiredEntities)) {
            return null;
        }

        StringBuilder builder = new StringBuilder();

        for (XmartMappedEntity entity : requiredEntities) {
            builder.append(entity.toString());
        }
        return builder.toString();
    }
}
