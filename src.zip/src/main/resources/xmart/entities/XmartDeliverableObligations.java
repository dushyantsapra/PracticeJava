package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.CollectionsUtil;
import com.rbs.odc.access.domain.CreditDerivativeLeg;
import com.rbs.odc.access.domain.DeliverableObligations;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLeg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartDeliverableObligations
        extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartDeliverableObligation> {
    private static final Logger logger = LoggerFactory.getLogger(XmartDeliverableObligations.class);
    private static final long serialVersionUID = -269442916756402281L;

    public XmartDeliverableObligations(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return CollectionsUtil.nullCollToEmpty(transaction.getTransactionLegs());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        addDeliverableObligations(getDocumentKey(), transactionLeg.getLegIdentifier(),
                transactionLeg.getCreditDerivativeLeg());
    }

    private void addDeliverableObligations(long documentKey, String legIdentifier,
            CreditDerivativeLeg creditDerivativeLeg) throws XmartException {
        if (creditDerivativeLeg == null) {
            return;
        }

        for (DeliverableObligations deliverableObligation : nullCollToEmpty(
                creditDerivativeLeg.getDeliverableObligations())) {
            XmartDeliverableObligation xmartDeliverableObligation = new XmartDeliverableObligation(documentKey,
                    legIdentifier);
            if (nonNull(deliverableObligation)) {
                xmartDeliverableObligation.setCategory(deliverableObligation.getCategory());
                xmartDeliverableObligation.setAccruedInterest(deliverableObligation.getAccruedInterest());
                xmartDeliverableObligation
                        .setObligationLiabilityScheme(getStr(deliverableObligation.getObligationLiabilityScheme()));
                xmartDeliverableObligation.setNotSubordinated(deliverableObligation.getNotSubordinated());
                xmartDeliverableObligation.setNotSovereignLender(deliverableObligation.getNotSovereignLender());
                xmartDeliverableObligation.setNotDomesticCurrency(deliverableObligation.getNotDomesticCurrency());
                xmartDeliverableObligation.setNotDomesticLaw(deliverableObligation.getNotDomesticLaw());
                xmartDeliverableObligation.setNotDomesticIssue(deliverableObligation.getNotDomesticIssue());
                xmartDeliverableObligation.setListed(deliverableObligation.getListed());
                xmartDeliverableObligation.setNotContingent(deliverableObligation.getNotContingent());
                xmartDeliverableObligation.setTransferable(deliverableObligation.getTransferable());
                xmartDeliverableObligation.setAcceleratedOrMatured(deliverableObligation.getAcceleratedOrMatured());
                xmartDeliverableObligation.setNotBearer(deliverableObligation.getNotBearer());
                xmartDeliverableObligation
                        .setIndirectLoanParticipation(deliverableObligation.getIndirectLoanParticipation());
                xmartDeliverableObligation
                        .setQualifyingParticipnSeller(deliverableObligation.getQualifyingParticipnSeller());
                xmartDeliverableObligation
                        .setPartCashAssignableLoans(deliverableObligation.getPartCashAssignableLoans());
                xmartDeliverableObligation
                        .setPartCashConsentRequired(deliverableObligation.getPartCashConsentRequired());
                xmartDeliverableObligation
                        .setPartCashLoanParticipations(deliverableObligation.getPartCashLoanParticipations());
                xmartDeliverableObligation.setExcluded(deliverableObligation.getExcluded());
                xmartDeliverableObligation.setOtherCategory(deliverableObligation.getOtherCategory());
                xmartDeliverableObligation.setOtherCharacteristic(deliverableObligation.getOtherCharacteristic());
            }
            addEntity(xmartDeliverableObligation);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
