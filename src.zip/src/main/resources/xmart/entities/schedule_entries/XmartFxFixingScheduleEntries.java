package com.nwm.xmart.entities.schedule_entries;

import com.nwm.xmart.bean.schedule_entries.domain.XmartODCId;
import com.nwm.xmart.bean.schedule_entries.domain.XmartODCScheduleEntries;
import com.nwm.xmart.bean.schedule_entries.domain.XmartODCScheduleEntryKey;
import com.nwm.xmart.bean.schedule_entries.domain.XmartODCTransactionId;
import com.nwm.xmart.entities.XmartOdcEntityCollection;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.rbs.odc.access.domain.BusinessTime;
import com.rbs.odc.access.domain.FXFixingScheduleEntry;
import com.rbs.odc.access.domain.ScheduleEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Collections;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.DateUtil.convertLocalTime;
import static com.nwm.xmart.util.XmartOdcUtil.getCurrencyCode;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class XmartFxFixingScheduleEntries extends
                                          XmartOdcEntityCollection<DataFabricStreamEvent<XmartODCScheduleEntries>, XmartODCScheduleEntries, XmartFxFixingScheduleEntry> {

    private static final long serialVersionUID = -7513564986930733517L;
    private static final Logger logger = LoggerFactory.getLogger(XmartFxFixingScheduleEntries.class);

    public XmartFxFixingScheduleEntries(long documentKey,
            DataFabricStreamEvent<XmartODCScheduleEntries> xmartODCScheduleEntriesDataFabricStreamEvent)
            throws XmartException {
        super(documentKey, xmartODCScheduleEntriesDataFabricStreamEvent);
    }

    @Override
    public Collection<XmartODCScheduleEntries> getFromEntities(
            DataFabricStreamEvent<XmartODCScheduleEntries> xmartODCScheduleEntriesDataFabricStreamEvent) {
        return Collections.singletonList(xmartODCScheduleEntriesDataFabricStreamEvent.getEventPayload());
    }

    @Override
    public void createAndAddEntity(XmartODCScheduleEntries xmartODCScheduleEntries) throws XmartException {
        XmartODCScheduleEntryKey parentKey = xmartODCScheduleEntries.getParentKey();
        if (isNull(parentKey) || isNull(parentKey.getTransactionId())) {
            return;
        }
        XmartODCId odcId = parentKey.getTransactionId();
        XmartODCTransactionId transactionId = odcId.getId();
        Long odcVersion = odcId.getOdcVersion();

        for (ScheduleEntry scheduleEntry : nullCollToEmpty(xmartODCScheduleEntries.getChildData())) {
            for (FXFixingScheduleEntry fxFixingScheduleEntry : nullCollToEmpty(
                    scheduleEntry.getFxFixingScheduleEntries())) {
                if (isNull(fxFixingScheduleEntry)) {
                    continue;
                }

                XmartFxFixingScheduleEntry xmartFxFixingScheduleEntry = new XmartFxFixingScheduleEntry(getDocumentKey(),
                        parentKey.getLegIdentifier(), getStr(transactionId.getSourceSystemId()),
                        transactionId.getSourceSystemTransactionId(), odcVersion,
                        getStr(scheduleEntry.getScheduleEntryType()));

                xmartFxFixingScheduleEntry.setFxFixingScheduleEntriesFixingDate(
                        convertBusinessDate(fxFixingScheduleEntry.getFixingDate()));

                BusinessTime _businessTime = nonNull(fxFixingScheduleEntry.getFixingTime()) ?
                                             fxFixingScheduleEntry.getFixingTime().getTime() : null;
                if (nonNull(_businessTime)) {
                    xmartFxFixingScheduleEntry
                            .setFxFixingScheduleEntriesFixingTime(convertLocalTime(_businessTime.getLocalTime()));
                }
                xmartFxFixingScheduleEntry
                        .setCurrency1IdCurrencyCode(getCurrencyCode(fxFixingScheduleEntry.getCurrency1Id()));
                xmartFxFixingScheduleEntry
                        .setCurrency2IdCurrencyCode(getCurrencyCode(fxFixingScheduleEntry.getCurrency2Id()));

                xmartFxFixingScheduleEntry
                        .setFxFixingScheduleEntriesQuoteBasis(getStr(fxFixingScheduleEntry.getQuoteBasis()));
                xmartFxFixingScheduleEntry.setInformationSource(fxFixingScheduleEntry.getInformationSource());
                xmartFxFixingScheduleEntry.setInformationSourcePage(fxFixingScheduleEntry.getInformationSourcePage());
                xmartFxFixingScheduleEntry.setStartDate(convertBusinessDate(scheduleEntry.getStartDate()));

                addEntity(xmartFxFixingScheduleEntry);
            }
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}