package com.nwm.xmart.entities.schedule_entries;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;
import java.util.Date;

public class XmartScheduleEntry extends XmartEntity {

    private static final long serialVersionUID = -2222201973744331007L;
    @XmartAttribute(mandatory = true, usedInJoin = true)
    private final String legIdentifier, scheduleEntryType, sourceSystemId, sourceSystemTransactionId;
    @XmartAttribute(mandatory = true, usedInJoin = true)
    private final long odcVersion;
    @XmartAttribute
    private BigDecimal asianAveragingScheduleEntryAverageRateWeighting, barrierScheduleEntryLowerAdjustedTriggerLevel,
            barrierScheduleEntryLowerBarrierTriggerLevel, barrierScheduleEntryUpperAdjustedTriggerLevel,
            barrierScheduleEntryUpperBarrierTriggerLevel, calculationPeriodScheduleDigitalPayoutRate,
            calculationPeriodScheduleEntryRate, calculationPeriodScheduleEntrySpread, capRateScheduleEntryRate,
            floorRateScheduleEntryRate, interestRateScheduleEntryRate, notionalScheduleEntryStepAmountValue,
            quantityScheduleEntryStepQuantity, quantityScheduleEntryValue, rateMultiplier, scheduleEntriesRate,
            scheduleEntriesSpread, triggerPayoutValue, triggerRate, quantityScheduleEntryPercentage,
            quantityScheduleEntryPrice;

    @XmartAttribute
    private Boolean calculationPeriodScheduleNonStandardPeriod;
    @XmartAttribute
    private Date calculationPeriodScheduleFixingDate, calculationPeriodScheduleFixingDateTime, fixingDate, paymentDate,
            startDate, unadjustedStartDate, endDate, unadjustedEndDate;
    @XmartAttribute
    private String asianAveragingScheduleEntryAveragingInOut, barrierScheduleEntryBarrierType,
            barrierScheduleEntryLowerBarrierDirectionType, barrierScheduleEntryLowerKnockConditionType,
            barrierScheduleEntryUpperBarrierDirectionType, barrierScheduleEntryUpperKnockConditionType,
            calculationPeriodScheduleNonStandardPeriodComment, fixingTimeCentre, fixingTimeTime,
            notionalScheduleEntryStepAmountCurrencyCode, notionalScheduleEntrystepDirection, payoutStyle,
            quantityScheduleEntryCurrencyCode, quantityScheduleEntryStepDirection, quantityUnitOfMeasure,
            sourceSystemEventId, triggerPayoutCurrencyCode, quantityScheduleEntryType, quantityScheduleEntryCurrency;

    protected XmartScheduleEntry(long documentKey, String legIdentifier, String scheduleEntryType,
            String sourceSystemId, String sourceSystemTransactionId, long odcVersion) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
        this.scheduleEntryType = scheduleEntryType;
        this.sourceSystemId = sourceSystemId;
        this.sourceSystemTransactionId = sourceSystemTransactionId;
        this.odcVersion = odcVersion;
    }

    public String getSourceSystemId() {
        return sourceSystemId;
    }

    public String getSourceSystemTransactionId() {
        return sourceSystemTransactionId;
    }

    public long getOdcVersion() {
        return odcVersion;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public String getScheduleEntryType() {
        return scheduleEntryType;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getUnadjustedStartDate() {
        return unadjustedStartDate;
    }

    public void setUnadjustedStartDate(Date unadjustedStartDate) {
        this.unadjustedStartDate = unadjustedStartDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getUnadjustedEndDate() {
        return unadjustedEndDate;
    }

    public void setUnadjustedEndDate(Date unadjustedEndDate) {
        this.unadjustedEndDate = unadjustedEndDate;
    }

    public BigDecimal getTriggerRate() {
        return triggerRate;
    }

    public void setTriggerRate(BigDecimal triggerRate) {
        this.triggerRate = triggerRate;
    }

    public String getTriggerPayoutCurrencyCode() {
        return triggerPayoutCurrencyCode;
    }

    public void setTriggerPayoutCurrencyCode(String triggerPayoutCurrencyCode) {
        this.triggerPayoutCurrencyCode = triggerPayoutCurrencyCode;
    }

    public BigDecimal getTriggerPayoutValue() {
        return triggerPayoutValue;
    }

    public void setTriggerPayoutValue(BigDecimal triggerPayoutValue) {
        this.triggerPayoutValue = triggerPayoutValue;
    }

    public String getPayoutStyle() {
        return payoutStyle;
    }

    public void setPayoutStyle(String payoutStyle) {
        this.payoutStyle = payoutStyle;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getBarrierScheduleEntryBarrierType() {
        return barrierScheduleEntryBarrierType;
    }

    public void setBarrierScheduleEntryBarrierType(String barrierScheduleEntryBarrierType) {
        this.barrierScheduleEntryBarrierType = barrierScheduleEntryBarrierType;
    }

    public String getBarrierScheduleEntryLowerBarrierDirectionType() {
        return barrierScheduleEntryLowerBarrierDirectionType;
    }

    public void setBarrierScheduleEntryLowerBarrierDirectionType(String barrierScheduleEntryLowerBarrierDirectionType) {
        this.barrierScheduleEntryLowerBarrierDirectionType = barrierScheduleEntryLowerBarrierDirectionType;
    }

    public BigDecimal getBarrierScheduleEntryLowerAdjustedTriggerLevel() {
        return barrierScheduleEntryLowerAdjustedTriggerLevel;
    }

    public void setBarrierScheduleEntryLowerAdjustedTriggerLevel(
            BigDecimal barrierScheduleEntryLowerAdjustedTriggerLevel) {
        this.barrierScheduleEntryLowerAdjustedTriggerLevel = barrierScheduleEntryLowerAdjustedTriggerLevel;
    }

    public BigDecimal getBarrierScheduleEntryLowerBarrierTriggerLevel() {
        return barrierScheduleEntryLowerBarrierTriggerLevel;
    }

    public void setBarrierScheduleEntryLowerBarrierTriggerLevel(
            BigDecimal barrierScheduleEntryLowerBarrierTriggerLevel) {
        this.barrierScheduleEntryLowerBarrierTriggerLevel = barrierScheduleEntryLowerBarrierTriggerLevel;
    }

    public String getBarrierScheduleEntryLowerKnockConditionType() {
        return barrierScheduleEntryLowerKnockConditionType;
    }

    public void setBarrierScheduleEntryLowerKnockConditionType(String barrierScheduleEntryLowerKnockConditionType) {
        this.barrierScheduleEntryLowerKnockConditionType = barrierScheduleEntryLowerKnockConditionType;
    }

    public String getBarrierScheduleEntryUpperBarrierDirectionType() {
        return barrierScheduleEntryUpperBarrierDirectionType;
    }

    public void setBarrierScheduleEntryUpperBarrierDirectionType(String barrierScheduleEntryUpperBarrierDirectionType) {
        this.barrierScheduleEntryUpperBarrierDirectionType = barrierScheduleEntryUpperBarrierDirectionType;
    }

    public BigDecimal getBarrierScheduleEntryUpperAdjustedTriggerLevel() {
        return barrierScheduleEntryUpperAdjustedTriggerLevel;
    }

    public void setBarrierScheduleEntryUpperAdjustedTriggerLevel(
            BigDecimal barrierScheduleEntryUpperAdjustedTriggerLevel) {
        this.barrierScheduleEntryUpperAdjustedTriggerLevel = barrierScheduleEntryUpperAdjustedTriggerLevel;
    }

    public BigDecimal getBarrierScheduleEntryUpperBarrierTriggerLevel() {
        return barrierScheduleEntryUpperBarrierTriggerLevel;
    }

    public void setBarrierScheduleEntryUpperBarrierTriggerLevel(
            BigDecimal barrierScheduleEntryUpperBarrierTriggerLevel) {
        this.barrierScheduleEntryUpperBarrierTriggerLevel = barrierScheduleEntryUpperBarrierTriggerLevel;
    }

    public String getBarrierScheduleEntryUpperKnockConditionType() {
        return barrierScheduleEntryUpperKnockConditionType;
    }

    public void setBarrierScheduleEntryUpperKnockConditionType(String barrierScheduleEntryUpperKnockConditionType) {
        this.barrierScheduleEntryUpperKnockConditionType = barrierScheduleEntryUpperKnockConditionType;
    }

    public String getAsianAveragingScheduleEntryAveragingInOut() {
        return asianAveragingScheduleEntryAveragingInOut;
    }

    public void setAsianAveragingScheduleEntryAveragingInOut(String asianAveragingScheduleEntryAveragingInOut) {
        this.asianAveragingScheduleEntryAveragingInOut = asianAveragingScheduleEntryAveragingInOut;
    }

    public BigDecimal getAsianAveragingScheduleEntryAverageRateWeighting() {
        return asianAveragingScheduleEntryAverageRateWeighting;
    }

    public void setAsianAveragingScheduleEntryAverageRateWeighting(
            BigDecimal asianAveragingScheduleEntryAverageRateWeighting) {
        this.asianAveragingScheduleEntryAverageRateWeighting = asianAveragingScheduleEntryAverageRateWeighting;
    }

    public BigDecimal getCalculationPeriodScheduleDigitalPayoutRate() {
        return calculationPeriodScheduleDigitalPayoutRate;
    }

    public void setCalculationPeriodScheduleDigitalPayoutRate(BigDecimal calculationPeriodScheduleDigitalPayoutRate) {
        this.calculationPeriodScheduleDigitalPayoutRate = calculationPeriodScheduleDigitalPayoutRate;
    }

    public Date getCalculationPeriodScheduleFixingDate() {
        return calculationPeriodScheduleFixingDate;
    }

    public void setCalculationPeriodScheduleFixingDate(Date calculationPeriodScheduleFixingDate) {
        this.calculationPeriodScheduleFixingDate = calculationPeriodScheduleFixingDate;
    }

    public Date getCalculationPeriodScheduleFixingDateTime() {
        return calculationPeriodScheduleFixingDateTime;
    }

    public void setCalculationPeriodScheduleFixingDateTime(Date calculationPeriodScheduleFixingDateTime) {
        this.calculationPeriodScheduleFixingDateTime = calculationPeriodScheduleFixingDateTime;
    }

    public Boolean getCalculationPeriodScheduleNonStandardPeriod() {
        return calculationPeriodScheduleNonStandardPeriod;
    }

    public void setCalculationPeriodScheduleNonStandardPeriod(Boolean calculationPeriodScheduleNonStandardPeriod) {
        this.calculationPeriodScheduleNonStandardPeriod = calculationPeriodScheduleNonStandardPeriod;
    }

    public String getCalculationPeriodScheduleNonStandardPeriodComment() {
        return calculationPeriodScheduleNonStandardPeriodComment;
    }

    public void setCalculationPeriodScheduleNonStandardPeriodComment(
            String calculationPeriodScheduleNonStandardPeriodComment) {
        this.calculationPeriodScheduleNonStandardPeriodComment = calculationPeriodScheduleNonStandardPeriodComment;
    }

    public BigDecimal getCalculationPeriodScheduleEntryRate() {
        return calculationPeriodScheduleEntryRate;
    }

    public void setCalculationPeriodScheduleEntryRate(BigDecimal calculationPeriodScheduleEntryRate) {
        this.calculationPeriodScheduleEntryRate = calculationPeriodScheduleEntryRate;
    }

    public BigDecimal getCalculationPeriodScheduleEntrySpread() {
        return calculationPeriodScheduleEntrySpread;
    }

    public void setCalculationPeriodScheduleEntrySpread(BigDecimal calculationPeriodScheduleEntrySpread) {
        this.calculationPeriodScheduleEntrySpread = calculationPeriodScheduleEntrySpread;
    }

    public String getNotionalScheduleEntryStepAmountCurrencyCode() {
        return notionalScheduleEntryStepAmountCurrencyCode;
    }

    public void setNotionalScheduleEntryStepAmountCurrencyCode(String notionalScheduleEntryStepAmountCurrencyCode) {
        this.notionalScheduleEntryStepAmountCurrencyCode = notionalScheduleEntryStepAmountCurrencyCode;
    }

    public BigDecimal getNotionalScheduleEntryStepAmountValue() {
        return notionalScheduleEntryStepAmountValue;
    }

    public void setNotionalScheduleEntryStepAmountValue(BigDecimal notionalScheduleEntryStepAmountValue) {
        this.notionalScheduleEntryStepAmountValue = notionalScheduleEntryStepAmountValue;
    }

    public String getNotionalScheduleEntrystepDirection() {
        return notionalScheduleEntrystepDirection;
    }

    public void setNotionalScheduleEntrystepDirection(String notionalScheduleEntrystepDirection) {
        this.notionalScheduleEntrystepDirection = notionalScheduleEntrystepDirection;
    }

    public BigDecimal getCapRateScheduleEntryRate() {
        return capRateScheduleEntryRate;
    }

    public void setCapRateScheduleEntryRate(BigDecimal capRateScheduleEntryRate) {
        this.capRateScheduleEntryRate = capRateScheduleEntryRate;
    }

    public BigDecimal getFloorRateScheduleEntryRate() {
        return floorRateScheduleEntryRate;
    }

    public void setFloorRateScheduleEntryRate(BigDecimal floorRateScheduleEntryRate) {
        this.floorRateScheduleEntryRate = floorRateScheduleEntryRate;
    }

    public BigDecimal getQuantityScheduleEntryStepQuantity() {
        return quantityScheduleEntryStepQuantity;
    }

    public void setQuantityScheduleEntryStepQuantity(BigDecimal quantityScheduleEntryStepQuantity) {
        this.quantityScheduleEntryStepQuantity = quantityScheduleEntryStepQuantity;
    }

    public String getQuantityUnitOfMeasure() {
        return quantityUnitOfMeasure;
    }

    public void setQuantityUnitOfMeasure(String quantityUnitOfMeasure) {
        this.quantityUnitOfMeasure = quantityUnitOfMeasure;
    }

    public String getQuantityScheduleEntryStepDirection() {
        return quantityScheduleEntryStepDirection;
    }

    public void setQuantityScheduleEntryStepDirection(String quantityScheduleEntryStepDirection) {
        this.quantityScheduleEntryStepDirection = quantityScheduleEntryStepDirection;
    }

    public String getQuantityScheduleEntryCurrencyCode() {
        return quantityScheduleEntryCurrencyCode;
    }

    public void setQuantityScheduleEntryCurrencyCode(String quantityScheduleEntryCurrencyCode) {
        this.quantityScheduleEntryCurrencyCode = quantityScheduleEntryCurrencyCode;
    }

    public BigDecimal getQuantityScheduleEntryValue() {
        return quantityScheduleEntryValue;
    }

    public void setQuantityScheduleEntryValue(BigDecimal quantityScheduleEntryValue) {
        this.quantityScheduleEntryValue = quantityScheduleEntryValue;
    }

    public BigDecimal getInterestRateScheduleEntryRate() {
        return interestRateScheduleEntryRate;
    }

    public void setInterestRateScheduleEntryRate(BigDecimal interestRateScheduleEntryRate) {
        this.interestRateScheduleEntryRate = interestRateScheduleEntryRate;
    }

    public String getSourceSystemEventId() {
        return sourceSystemEventId;
    }

    public void setSourceSystemEventId(String sourceSystemEventId) {
        this.sourceSystemEventId = sourceSystemEventId;
    }

    public Date getFixingDate() {
        return fixingDate;
    }

    public void setFixingDate(Date fixingDate) {
        this.fixingDate = fixingDate;
    }

    public String getFixingTimeCentre() {
        return fixingTimeCentre;
    }

    public void setFixingTimeCentre(String fixingTimeCentre) {
        this.fixingTimeCentre = fixingTimeCentre;
    }

    public String getFixingTimeTime() {
        return fixingTimeTime;
    }

    public void setFixingTimeTime(String fixingTimeTime) {
        this.fixingTimeTime = fixingTimeTime;
    }

    public BigDecimal getScheduleEntriesRate() {
        return scheduleEntriesRate;
    }

    public void setScheduleEntriesRate(BigDecimal scheduleEntriesRate) {
        this.scheduleEntriesRate = scheduleEntriesRate;
    }

    public BigDecimal getScheduleEntriesSpread() {
        return scheduleEntriesSpread;
    }

    public void setScheduleEntriesSpread(BigDecimal scheduleEntriesSpread) {
        this.scheduleEntriesSpread = scheduleEntriesSpread;
    }

    public BigDecimal getRateMultiplier() {
        return rateMultiplier;
    }

    public void setRateMultiplier(BigDecimal rateMultiplier) {
        this.rateMultiplier = rateMultiplier;
    }

    public BigDecimal getQuantityScheduleEntryPercentage() {
        return quantityScheduleEntryPercentage;
    }

    public void setQuantityScheduleEntryPercentage(BigDecimal quantityScheduleEntryPercentage) {
        this.quantityScheduleEntryPercentage = quantityScheduleEntryPercentage;
    }

    public BigDecimal getQuantityScheduleEntryPrice() {
        return quantityScheduleEntryPrice;
    }

    public void setQuantityScheduleEntryPrice(BigDecimal quantityScheduleEntryPrice) {
        this.quantityScheduleEntryPrice = quantityScheduleEntryPrice;
    }

    public String getQuantityScheduleEntryType() {
        return quantityScheduleEntryType;
    }

    public void setQuantityScheduleEntryType(String quantityScheduleEntryType) {
        this.quantityScheduleEntryType = quantityScheduleEntryType;
    }

    public String getQuantityScheduleEntryCurrency() {
        return quantityScheduleEntryCurrency;
    }

    public void setQuantityScheduleEntryCurrency(String quantityScheduleEntryCurrency) {
        this.quantityScheduleEntryCurrency = quantityScheduleEntryCurrency;
    }
}
