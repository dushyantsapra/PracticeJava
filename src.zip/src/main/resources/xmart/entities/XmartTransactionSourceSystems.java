package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionSourceSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;

public class XmartTransactionSourceSystems
        extends XmartOdcEntityCollection<Transaction, TransactionSourceSystem, XmartTransactionSourceSystem> {
    private static final long serialVersionUID = 7876411772321004370L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionSourceSystems.class);

    public XmartTransactionSourceSystems(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionSourceSystem> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionSourceSystems(), logger,
                "TransactionSourceSystem not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionSourceSystem transactionSourceSystem) throws XmartException {
        XmartTransactionSourceSystem xmartTransactionSourceSystem = new XmartTransactionSourceSystem(getDocumentKey());

        xmartTransactionSourceSystem.setSystemId(transactionSourceSystem.getSystemId());
        xmartTransactionSourceSystem.setLocation(getStr(transactionSourceSystem.getLocation()));
        xmartTransactionSourceSystem.setSourceSystemRole(getStr(transactionSourceSystem.getSourceSystemRole()));

        addEntity(xmartTransactionSourceSystem);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
