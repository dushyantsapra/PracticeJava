package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartTradingParty extends XmartEntity {
    private static final long serialVersionUID = 8942780922131836182L;
    @XmartAttribute
    private String transactionRoleScheme, tradingPartyId, tradingPartySystemId;

    protected XmartTradingParty(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getTransactionRoleScheme() {
        return transactionRoleScheme;
    }

    public void setTransactionRoleScheme(String transactionRoleScheme) {
        this.transactionRoleScheme = transactionRoleScheme;
    }

    public String getTradingPartyId() {
        return tradingPartyId;
    }

    public void setTradingPartyId(String tradingPartyId) {
        this.tradingPartyId = tradingPartyId;
    }

    public String getTradingPartySystemId() {
        return tradingPartySystemId;
    }

    public void setTradingPartySystemId(String tradingPartySystemId) {
        this.tradingPartySystemId = tradingPartySystemId;
    }
}
