package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.LegBusinessCentre;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionLeg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartLegBusinessCentres
        extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartLegBusinessCentre> {
    private static final long serialVersionUID = -6568160380173454343L;
    private static final Logger logger = LoggerFactory.getLogger(XmartLegBusinessCentres.class);

    public XmartLegBusinessCentres(long documentKey, Transaction transaction) throws XmartException {

        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegs());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        for (LegBusinessCentre legBusinessCentre : nullCollToEmpty(transactionLeg.getLegBusinessCentres())) {
            XmartLegBusinessCentre xmartLegBusinessCentre = new XmartLegBusinessCentre(getDocumentKey());
            xmartLegBusinessCentre.setLegIdentifier(transactionLeg.getLegIdentifier());
            if (nonNull(legBusinessCentre)) {
                xmartLegBusinessCentre.setBusinessCentre(legBusinessCentre.getBusinessCentre());
                xmartLegBusinessCentre.setBusinessCentreRole(getStr(legBusinessCentre.getBusinessCentreRole()));
                xmartLegBusinessCentre.setBusinessDayConvention(getStr(legBusinessCentre.getBusinessDayConvention()));
            }

            addEntity(xmartLegBusinessCentre);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
