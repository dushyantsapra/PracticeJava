package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionProcessDirective;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;

public class XmartTransactionProcessDirectives
        extends XmartOdcEntityCollection<Transaction, TransactionProcessDirective, XmartTransactionProcessDirective> {
    private static final long serialVersionUID = -4336200001601947496L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionProcessDirectives.class);

    public XmartTransactionProcessDirectives(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionProcessDirective> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionProcessDirectives(), logger,
                "TransactionProcessDirectives not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionProcessDirective transactionProcessDirective) throws XmartException {

        XmartTransactionProcessDirective xmartTransactionProcessDirective = new XmartTransactionProcessDirective(
                getDocumentKey());
        xmartTransactionProcessDirective.setProcessDirectiveType(transactionProcessDirective.getProcessDirectiveType());
        xmartTransactionProcessDirective.setAdditionalComments(transactionProcessDirective.getAdditionalComments());
        xmartTransactionProcessDirective.setConfirmationRequired(transactionProcessDirective.isConfirmationRequired());
        xmartTransactionProcessDirective
                .setFoConfirmationReview(transactionProcessDirective.isFoConfirmationReviewRequired());
        xmartTransactionProcessDirective
                .setManualConfirmationReqd(transactionProcessDirective.isManualConfirmationRequired());
        xmartTransactionProcessDirective
                .setConfirmLegsIndividually(transactionProcessDirective.isConfirmLegsIndividually());
        addEntity(xmartTransactionProcessDirective);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
