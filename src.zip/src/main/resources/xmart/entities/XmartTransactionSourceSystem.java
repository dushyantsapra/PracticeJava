package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartTransactionSourceSystem extends XmartEntity {
    private static final long serialVersionUID = -6692937829749094896L;

    @XmartAttribute
    private String systemId;

    @XmartAttribute
    private String location;

    @XmartAttribute
    private String sourceSystemRole;

    public XmartTransactionSourceSystem(long docKey) throws XmartException {
        super(docKey);
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSourceSystemRole() {
        return sourceSystemRole;
    }

    public void setSourceSystemRole(String sourceSystemRole) {
        this.sourceSystemRole = sourceSystemRole;
    }
}
