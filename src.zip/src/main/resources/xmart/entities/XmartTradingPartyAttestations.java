package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.TradingPartyAttestation;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;

public class XmartTradingPartyAttestations
        extends XmartOdcEntityCollection<Transaction, TradingPartyAttestation, XmartTradingPartyAttestation> {

    private static final long serialVersionUID = 5361107420089656709L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTradingPartyAttestations.class);

    public XmartTradingPartyAttestations(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TradingPartyAttestation> getFromEntities(Transaction transaction) {
        Collection<TradingPartyAttestation> collection = null;

        if (transaction.getAttestation() != null && transaction.getAttestation().getMandatedCatAttestation() != null) {
            collection = transaction.getAttestation().getMandatedCatAttestation().getTradingParty();
        }

        return nullCollToEmpty(collection, logger,
                "No TradingPartyAttestation received for documentKey : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TradingPartyAttestation tradingPartyAttestation) throws XmartException {
        XmartTradingPartyAttestation xmartTradingPartyAttestation = new XmartTradingPartyAttestation(getDocumentKey());
        xmartTradingPartyAttestation
                .setTradingPartyAttestationValue(getStr(tradingPartyAttestation.getAttestationValue()));
        xmartTradingPartyAttestation.setTradingPartyId(tradingPartyAttestation.getId());
        xmartTradingPartyAttestation.setTradingPartyIdPath(tradingPartyAttestation.getIdPath());
        addEntity(xmartTradingPartyAttestation);
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
