package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;

public class XmartUnderliers extends XmartOdcEntityCollection<Transaction, TransactionLeg, XmartUnderlier> {
    private static final long serialVersionUID = 5751500974628164554L;
    private static final Logger logger = LoggerFactory.getLogger(XmartUnderliers.class);

    public XmartUnderliers(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<TransactionLeg> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getTransactionLegs(), logger,
                "Transaction legs not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(TransactionLeg transactionLeg) throws XmartException {
        for (Underlier underlier : nullCollToEmpty(transactionLeg.getUnderliers())) {
            XmartUnderlier xmartUnderlier = new XmartUnderlier(getDocumentKey());
            addUnderlierInfo(xmartUnderlier, underlier, transactionLeg.getLegIdentifier());
            addEntity(xmartUnderlier);
        }
    }

    public void addUnderlierInfo(XmartUnderlier xmartUnderlier, Underlier underlier, String legIdentifier) {
        xmartUnderlier.setLegIdentifier(legIdentifier);
        if (isNull(underlier)) {
            return;
        }
        xmartUnderlier.setUnderlierId(underlier.getUnderlierId());
        InstrumentUnderlier instrumentUnderlier = underlier.getInstrumentUnderlier();
        if (instrumentUnderlier != null) {
            BasketWeight bktWgt = instrumentUnderlier.getBasketWeight();
            if (bktWgt != null) {
                xmartUnderlier.setBasketWeightPercentage(bktWgt.getPercentage());
                Amount bktWgtAmt = bktWgt.getAmount();
                if (bktWgtAmt != null) {
                    CurrencyId bktWgtAmtCurId = bktWgtAmt.getCurrencyId();
                    if (bktWgtAmtCurId != null) {
                        xmartUnderlier.setBasketWeightCurrencyCode(bktWgtAmtCurId.getCurrencyCode());
                    }
                    xmartUnderlier.setBasketWeightValue(bktWgtAmt.getValue());
                }
                xmartUnderlier.setOpenUnits(bktWgt.getOpenUnits());
            }

            ReferenceObligation refObl = instrumentUnderlier.getReferenceObligation();
            if (refObl != null) {
                xmartUnderlier.setReferencePricePercentage(refObl.getReferencePricePercentage());
                CurrencyId refOblCurId = refObl.getOriginalFaceAmountCurrency();
                if (refOblCurId != null) {
                    xmartUnderlier.setOriginalFaceAmountCurrencyCode(refOblCurId.getCurrencyCode());
                }
                xmartUnderlier.setStandardReferenceObligation(refObl.getStandardReferenceObligation());
                SecurityInstrument security = refObl.getSecurity();
                if (security != null) {
                    xmartUnderlier.setSecurityName(security.getSecurityName());
                    xmartUnderlier.setSeniority(security.getSeniority());
                }
            }
            xmartUnderlier.setWithholdingTaxApplicable(instrumentUnderlier.isWithholdingTaxApplicable());

            InstrumentId insId = instrumentUnderlier.getInstrumentId();
            if (insId != null) {
                xmartUnderlier.setInstrumentUnderlierInstrumentScheme(getStr(insId.getInstrumentScheme()));
                xmartUnderlier.setInstrumentUnderlierInstrumentId(insId.getInstrumentId());
            }
        }

        TradableIndex tradableIndex = underlier.getTradableIndex();
        if (tradableIndex != null) {
            xmartUnderlier.setAlternateIdentifier(tradableIndex.getAlternateIdentifier());
            xmartUnderlier.setTradeableIndexName(tradableIndex.getName());
            xmartUnderlier.setIndexVersion(tradableIndex.getIndexVersion());
            xmartUnderlier.setAttachmentPoint(tradableIndex.getAttachmentPoint());
            xmartUnderlier.setExhaustionPoint(tradableIndex.getExhaustionPoint());
            xmartUnderlier.setIndexAnnexDate(convertBusinessDate(tradableIndex.getIndexAnnexDate()));
            xmartUnderlier.setIndexEffectiveDate(convertBusinessDate(tradableIndex.getIndexEffectiveDate()));
            xmartUnderlier.setIndexDayCountConvention(getStr(tradableIndex.getIndexDayCountConvention()));

            Interval tenor = tradableIndex.getTenor();
            if (tenor != null) {
                xmartUnderlier.setTenorPeriodMultiplier(tenor.getPeriodMultiplier());
                xmartUnderlier.setTenorPeriodScheme(getStr(tenor.getPeriodScheme()));
            }

            Interval intialLag = tradableIndex.getInitialLag();
            if (intialLag != null) {
                xmartUnderlier.setInitialLagPeriodMultiplier(intialLag.getPeriodMultiplier());
                xmartUnderlier.setInitialLagPeriodScheme(getStr(intialLag.getPeriodScheme()));
            }

            Interval finalLag = tradableIndex.getFinalLag();
            if (finalLag != null) {
                xmartUnderlier.setFinalLagPeriodMultiplier(finalLag.getPeriodMultiplier());
                xmartUnderlier.setFinalLagPeriodScheme(getStr(finalLag.getPeriodScheme()));
            }
            xmartUnderlier.setPaymentPeriodMultiplier(tradableIndex.getPaymentPeriodMultiplier());
            xmartUnderlier.setPaymentPeriodScheme(tradableIndex.getPaymentPeriodScheme());

            InstrumentId instrumentId = tradableIndex.getInstrumentId();
            if (instrumentId != null) {
                xmartUnderlier.setTradeableIndexInstrumentScheme(getStr(instrumentId.getInstrumentScheme()));
                xmartUnderlier.setTradeableIndexInstrumentId(instrumentId.getInstrumentId());
            }

            xmartUnderlier.setIndexSeries(tradableIndex.getIndexSeries());
            xmartUnderlier.setCurrentTrancheStart(tradableIndex.getCurrentTrancheStart());
            xmartUnderlier.setCurrentTrancheEnd(tradableIndex.getCurrentTrancheEnd());
            xmartUnderlier.setOrigPoolAmount(tradableIndex.getOrigPoolAmount());
            xmartUnderlier.setCurrentPoolAmount(tradableIndex.getCurrentPoolAmount());
            xmartUnderlier.setBasketConstituentCount(tradableIndex.getBasketConstituentCount());
            xmartUnderlier.setIndexFactor(tradableIndex.getIndexFactor());
        }

        IncomeStream incomeStream = underlier.getIncomeStream();
        if (incomeStream != null) {
            xmartUnderlier.setMaturityDate(convertBusinessDate(incomeStream.getMaturityDate()));
            xmartUnderlier.setCreditAgreementDate(convertBusinessDate(incomeStream.getCreditAgreementDate()));
            xmartUnderlier.setTranche(incomeStream.getTranche());
            xmartUnderlier.setOutstandingInstrumentId(incomeStream.getOutstandingInstrumentId());
            xmartUnderlier.setFacilityInstrumentId(incomeStream.getFacilityInstrumentId());
            xmartUnderlier.setLxrefInstrumentId(incomeStream.getLxrefInstrumentId());
            xmartUnderlier.setDealInstrumentId(incomeStream.getDealInstrumentId());
            xmartUnderlier.setOutstandingInstrumentName(incomeStream.getOutstandingInstrumentName());
            xmartUnderlier.setFacilityInstrumentName(incomeStream.getFacilityInstrumentName());
            xmartUnderlier.setLxrefInstrumentName(incomeStream.getLxrefInstrumentName());
            xmartUnderlier.setDealInstrumentName(incomeStream.getDealInstrumentName());

            CurrencyId incomeStreamCurId = incomeStream.getInstrumentCurrencyId();
            if (incomeStreamCurId != null) {
                xmartUnderlier.setIncomeStreamCurrencyCode(incomeStreamCurId.getCurrencyCode());
            }
        }

        xmartUnderlier.setUnderlyerAssetClass(underlier.getUnderlyerAssetClass());
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
