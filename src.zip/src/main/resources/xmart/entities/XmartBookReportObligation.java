package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

public class XmartBookReportObligation extends XmartEntity {
    private static final long serialVersionUID = -7644066780877183033L;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private Boolean regimeImpact;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String regimeImpactId;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String reportingRoleScheme;

    @XmartAttribute
    private String regulatoryReportName;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String regulatoryRegimeImpactId;

    public XmartBookReportObligation(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getRegulatoryRegimeImpactId() {
        return regulatoryRegimeImpactId;
    }

    public void setRegulatoryRegimeImpactId(String regulatoryRegimeImpactId) {
        this.regulatoryRegimeImpactId = regulatoryRegimeImpactId;
    }

    public Boolean getRegimeImpact() {
        return regimeImpact;
    }

    public void setRegimeImpact(Boolean regimeImpact) {
        this.regimeImpact = regimeImpact;
    }

    public String getRegimeImpactId() {
        return regimeImpactId;
    }

    public void setRegimeImpactId(String regimeImpactId) {
        this.regimeImpactId = regimeImpactId;
    }

    public String getReportingRoleScheme() {
        return reportingRoleScheme;
    }

    public void setReportingRoleScheme(String reportingRoleScheme) {
        this.reportingRoleScheme = reportingRoleScheme;
    }

    public String getRegulatoryReportName() {
        return regulatoryReportName;
    }

    public void setRegulatoryReportName(String regulatoryReportName) {
        this.regulatoryReportName = regulatoryReportName;
    }
}
