package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.AgreementTransactionContext;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionMarginElection;
import com.rbs.odc.access.domain.TransactionMarginJurisdiction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.isNull;

public class XmartTransactionMarginJurisdictions
        extends XmartOdcEntityCollection<Transaction, AgreementTransactionContext, XmartTransactionMarginJurisdiction> {
    private static final long serialVersionUID = -941741370040037709L;
    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionMarginJurisdictions.class);

    public XmartTransactionMarginJurisdictions(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<AgreementTransactionContext> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getAgreementTransactionContext(), logger,
                "AgreementTransactionContexts not received for document key " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(AgreementTransactionContext agreementTransactionContext) throws XmartException {
        Collection<TransactionMarginElection> txnMarginElections = nullCollToEmpty(
                agreementTransactionContext.getTransactionMarginElection(), logger,
                "Collection TransactionMarginElection not received for document key " + getDocumentKey());

        for (TransactionMarginElection txnMarginElection : txnMarginElections) {
            if (isNull(txnMarginElection)) {
                continue;
            }

            Collection<? extends TransactionMarginJurisdiction> txnMarginJurisdictions = nullCollToEmpty(
                    txnMarginElection.getTransactionMarginJurisdiction(), logger,
                    "TransactionMarginJurisdiction not received for document key " + getDocumentKey());

            for (TransactionMarginJurisdiction txnMarginJurisdiction : txnMarginJurisdictions) {
                if (isNull(txnMarginJurisdiction)) {
                    continue;
                }

                XmartTransactionMarginJurisdiction xmartTransactionMarginJurisdiction
                        = new XmartTransactionMarginJurisdiction(getDocumentKey(), agreementTransactionContext.getId(),
                        getStr(txnMarginElection.getMarginType()));

                xmartTransactionMarginJurisdiction.setJurisdictoryPartyApplicabilityScope(
                        txnMarginJurisdiction.getJurisdictionPartyApplicabilityScope());
                xmartTransactionMarginJurisdiction
                        .setRegulatoryAuthority(txnMarginJurisdiction.getRegulatoryAuthority());

                addEntity(xmartTransactionMarginJurisdiction);
            }
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
