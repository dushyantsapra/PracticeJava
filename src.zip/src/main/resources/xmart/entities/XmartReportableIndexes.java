package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.RegulatoryRegimeImpact;
import com.rbs.odc.access.domain.ReportableIndex;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartReportableIndexes
        extends XmartOdcEntityCollection<Transaction, RegulatoryRegimeImpact, XmartReportableIndex> {

    private static final Logger logger = LoggerFactory.getLogger(XmartReportableIndexes.class);
    private static final long serialVersionUID = 1059502258357772350L;

    public XmartReportableIndexes(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<RegulatoryRegimeImpact> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getRegulatoryRegimeImpact(), logger,
                "Regulatory Regime Impacts not received for document key : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(RegulatoryRegimeImpact regulatoryRegimeImpact) throws XmartException {

        for (ReportableIndex reportableIndex : nullCollToEmpty(regulatoryRegimeImpact.getReportableIndexes())) {

            XmartReportableIndex xmartReportableIndex = new XmartReportableIndex(getDocumentKey());
            xmartReportableIndex.setRegimeImpact(regulatoryRegimeImpact.getRegimeImpact());
            xmartReportableIndex.setRegimeImpactId(regulatoryRegimeImpact.getRegimeImpactId());
            xmartReportableIndex.setRegulatoryRegimeImpactId(regulatoryRegimeImpact.getId());

            if (nonNull(reportableIndex)) {
                xmartReportableIndex.setIndexName(reportableIndex.getIndexName());
                xmartReportableIndex.setPeriodMultiplier(reportableIndex.getPeriodMultiplier());
                xmartReportableIndex.setPeriodScheme(getStr(reportableIndex.getPeriodScheme()));
            }

            addEntity(xmartReportableIndex);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
