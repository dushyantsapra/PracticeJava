package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.RegulatoryRegimeImpact;
import com.rbs.odc.access.domain.ReportableUnderlyingInstrument;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.DateUtil.convertBusinessDate;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartReportableUnderlyingInstruments
        extends XmartOdcEntityCollection<Transaction, RegulatoryRegimeImpact, XmartReportableUnderlyingInstrument> {

    private static final long serialVersionUID = -8945825166654122612L;
    private static final Logger logger = LoggerFactory.getLogger(XmartReportableUnderlyingInstruments.class);

    public XmartReportableUnderlyingInstruments(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<RegulatoryRegimeImpact> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getRegulatoryRegimeImpact(), logger,
                "RegulatoryRegimeImpacts not received for document key " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(RegulatoryRegimeImpact regulatoryRegimeImpact) throws XmartException {
        for (ReportableUnderlyingInstrument reportableUnderlyingInstrument : nullCollToEmpty(
                regulatoryRegimeImpact.getReportableUnderlyingInstruments())) {

            XmartReportableUnderlyingInstrument xmartReportableUnderlyingInstrument
                    = new XmartReportableUnderlyingInstrument(getDocumentKey());
            xmartReportableUnderlyingInstrument.setRegimeImpact(regulatoryRegimeImpact.getRegimeImpact());
            xmartReportableUnderlyingInstrument.setRegimeImpactId(regulatoryRegimeImpact.getRegimeImpactId());
            xmartReportableUnderlyingInstrument.setRegulatoryRegimeImpactId(regulatoryRegimeImpact.getId());

            if (nonNull(reportableUnderlyingInstrument)) {
                xmartReportableUnderlyingInstrument.setInstrumentId(reportableUnderlyingInstrument.getInstrumentId());
                xmartReportableUnderlyingInstrument
                        .setInstrumentScheme(getStr(reportableUnderlyingInstrument.getInstrumentScheme()));
                xmartReportableUnderlyingInstrument
                        .setInstrumentName(reportableUnderlyingInstrument.getInstrumentName());
                xmartReportableUnderlyingInstrument
                        .setInstrumentClassification(reportableUnderlyingInstrument.getInstrumentClassification());
                xmartReportableUnderlyingInstrument
                        .setPriceMultiplier(reportableUnderlyingInstrument.getPriceMultiplier());
                xmartReportableUnderlyingInstrument
                        .setOptionType(getStr(reportableUnderlyingInstrument.getOptionType()));
                xmartReportableUnderlyingInstrument
                        .setOptionExerciseStyle(getStr(reportableUnderlyingInstrument.getOptionExerciseStyle()));
                xmartReportableUnderlyingInstrument
                        .setMaturityDate(convertBusinessDate(reportableUnderlyingInstrument.getMaturityDate()));
                xmartReportableUnderlyingInstrument
                        .setExpiryDate(convertBusinessDate(reportableUnderlyingInstrument.getExpiryDate()));
                xmartReportableUnderlyingInstrument
                        .setSettlementType(getStr(reportableUnderlyingInstrument.getSettlementType()));
            }
            addEntity(xmartReportableUnderlyingInstrument);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
