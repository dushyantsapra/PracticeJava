package com.nwm.xmart.entities;

import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.XmlUtil;

import java.util.ArrayList;
import java.util.Collection;

import static com.nwm.xmart.util.XmlUtil.getXmlDocument;
import static com.nwm.xmart.util.XmlUtil.getXmlFromCollection;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

/**
 * Covers the boiler plate code for creating bean(s) which contains a list of XmartOdcEntityCollection.
 *
 * @param <TopMostEntity> the top most entity from which the data can be fetched to create the required entity.
 * @param <FromEntity>    the entity that is to be mapped to XmartEntity.
 * @param <ToEntity>      the required XmartEnity build using the above two.
 */
public abstract class XmartOdcEntityCollection<TopMostEntity, FromEntity, ToEntity extends XmartEntity>
        implements IXmartOdcEntityCollection<TopMostEntity, FromEntity, ToEntity> {
    private static final long serialVersionUID = -4899161393685683782L;
    private final long documentKey;
    private Collection<ToEntity> xmartEntities;
    private TopMostEntity topMostEntity;

    public XmartOdcEntityCollection(long documentKey, TopMostEntity topMostEntity) throws XmartException {
        this.documentKey = documentKey;
        this.topMostEntity = topMostEntity;
        xmartEntities = new ArrayList<>();
    }

    public final long getDocumentKey() {
        return documentKey;
    }

    /**
     * The list that contains the created XmartOdcEntityCollection.
     *
     * @return
     */
    public final Collection<ToEntity> getXmartEntities() {
        return xmartEntities;
    }

    /**
     * performs the basic validation and iterates over to pass on the source entity to subclass to create the required XmartEntity
     *
     * @throws XmartException
     */
    public XmartOdcEntityCollection build() throws XmartException {
        if (isNull(topMostEntity)) {
            String errorMessage = "Top most entity not provided for : " + getClass().getSimpleName();
            getLogger().error(errorMessage);
            throw new XmartException(errorMessage);
        }

        Collection<FromEntity> fromEntities = getFromEntities(topMostEntity);
        for (FromEntity fromEntity : fromEntities) {
            if (nonNull(fromEntity)) {
                createAndAddEntity(fromEntity);
            }
        }

        topMostEntity = null;

        return this;
    }

    /**
     * By default definition, it adds the entity to the collection if the entity is non-null and valid.
     *
     * @param entity
     *
     * @throws XmartException
     */
    public void addEntity(ToEntity entity) throws XmartException {
        if (shouldAdd(entity)) {
            xmartEntities.add(entity);
        }
    }

    /**
     * Works as a hook method and adds the created entity to the list iff the created entity is not null and valid.
     * Override this if there needs some business validation to be performed on created entity.
     */
    public boolean shouldAdd(ToEntity entity) throws XmartException {
        return isValid(entity);
    }

    /**
     * By default an entity is assumed to valid if it is non-null and valid for XML.
     * Sub-class can give its own definition for validity as per business rule(s)
     *
     * @param entity the entity to be verified, assuming all the available attributes are set.
     *
     * @return true if valid
     */
    public boolean isValid(ToEntity entity) throws XmartException {
        return XmlUtil.isValidEntity(entity);
    }

    /**
     * Creates the xml reprecenation of the extending class.
     * <br> marke final so that cild classes by mistake do not implement it
     *
     * @return String xml of the class.
     */
    public final String toString() {
        return getXmlFromCollection(xmartEntities);
    }

    /**
     * Provides the name to be used in the xml tags for the extending collection
     *
     * @return name to be used in the xml tags for the extending collection
     */
    //TODO #WIP will be made abstract and implementers will provide their own name / class name to go in the xml here
    public String name() {
        //return XmartOdcEntityCollection.class.getName();
        return "XmartOdcEntityCollection";
    }

    /**
     * @param dummyArgument argument is dummy will be dropped.
     *
     * @return Well formed XMl containing prolog and the root xml tags for this
     */
    //TODO #WIP when the name() is implemented then this version of toString will be used (argument is dummy will be dropped.)
    //TODO Also need to decide from where the logXml will be received from
    public String toString(String dummyArgument, Boolean logXml) {
        return getXmlDocument(name(), getXmlFromCollection(xmartEntities), logXml);
    }
}
