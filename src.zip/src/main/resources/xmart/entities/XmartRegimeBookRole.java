package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

/**
 * Created by aslammh on 17/11/17.
 */
public class XmartRegimeBookRole extends XmartEntity {

    private static final long serialVersionUID = 3471255071667107499L;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private Boolean regimeImpact;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String regimeImpactId;

    @XmartAttribute(usedInJoin = true)
    private String reportingRoleScheme;

    @XmartAttribute
    private String tradingCapacity;

    @XmartAttribute
    private String sourceSystemBookId;

    @XmartAttribute
    private String bookSourceSystemId;

    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String reportableTradingRole;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private String regulatoryRegimeImpactId;

    public XmartRegimeBookRole(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getRegulatoryRegimeImpactId() {
        return regulatoryRegimeImpactId;
    }

    public void setRegulatoryRegimeImpactId(String regulatoryRegimeImpactId) {
        this.regulatoryRegimeImpactId = regulatoryRegimeImpactId;
    }

    public Boolean getRegimeImpact() {
        return regimeImpact;
    }

    public void setRegimeImpact(Boolean regimeImpact) {
        this.regimeImpact = regimeImpact;
    }

    public String getRegimeImpactId() {
        return regimeImpactId;
    }

    public void setRegimeImpactId(String regimeImpactId) {
        this.regimeImpactId = regimeImpactId;
    }

    public String getReportingRoleScheme() {
        return reportingRoleScheme;
    }

    public void setReportingRoleScheme(String reportingRoleScheme) {
        this.reportingRoleScheme = reportingRoleScheme;
    }

    public String getTradingCapacity() {
        return tradingCapacity;
    }

    public void setTradingCapacity(String tradingCapacity) {
        this.tradingCapacity = tradingCapacity;
    }

    public String getSourceSystemBookId() {
        return sourceSystemBookId;
    }

    public void setSourceSystemBookId(String sourceSystemBookId) {
        this.sourceSystemBookId = sourceSystemBookId;
    }

    public String getBookSourceSystemId() {
        return bookSourceSystemId;
    }

    public void setBookSourceSystemId(String bookSourceSystemId) {
        this.bookSourceSystemId = bookSourceSystemId;
    }

    public String getReportableTradingRole() {
        return reportableTradingRole;
    }

    public void setReportableTradingRole(String reportableTradingRole) {
        this.reportableTradingRole = reportableTradingRole;
    }
}
