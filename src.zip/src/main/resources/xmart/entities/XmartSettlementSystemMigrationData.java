package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.util.Date;

public class XmartSettlementSystemMigrationData extends XmartEntity {
    private static final long serialVersionUID = 8027492743669207638L;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private String migrationType;
    @XmartAttribute(usedInJoin = false, mandatory = false, xmlTrigger = true)
    private Date effectiveDate;

    protected XmartSettlementSystemMigrationData(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getMigrationType() {
        return migrationType;
    }

    public void setMigrationType(String migrationType) {
        this.migrationType = migrationType;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }
}
