package com.nwm.xmart.entities;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;

/**
 * Created by aslammh on 17/11/17.
 */
public class XmartInterestRateLeg extends XmartEntity {

    private static final long serialVersionUID = -7443103342498244830L;

    @XmartAttribute(usedInJoin = true, xmlTrigger = false)
    private final String legIdentifier;
    @XmartAttribute
    private BigDecimal interestRate;
    @XmartAttribute
    private String fixedOrFloatingRateType;
    @XmartAttribute
    private String varyingNotionalRateSource;
    @XmartAttribute
    private String roundingDirection;
    @XmartAttribute
    private String negativeRateTreatment;
    @XmartAttribute
    private String compoundingMethod;
    @XmartAttribute
    private BigDecimal rateMultiplier;
    @XmartAttribute
    private String discountingType;
    @XmartAttribute
    private String quotationStyle;
    @XmartAttribute
    private Integer roundingPrecision;
    @XmartAttribute
    private BigDecimal calcPeriodNumOfDays;

    public XmartInterestRateLeg(long documentKey, String legIdentifier) throws XmartException {
        super(documentKey);
        this.legIdentifier = legIdentifier;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

    public String getFixedOrFloatingRateType() {
        return fixedOrFloatingRateType;
    }

    public void setFixedOrFloatingRateType(String fixedOrFloatingRateType) {
        this.fixedOrFloatingRateType = fixedOrFloatingRateType;
    }

    public String getVaryingNotionalRateSource() {
        return varyingNotionalRateSource;
    }

    public void setVaryingNotionalRateSource(String varyingNotionalRateSource) {
        this.varyingNotionalRateSource = varyingNotionalRateSource;
    }

    public String getRoundingDirection() {
        return roundingDirection;
    }

    public void setRoundingDirection(String roundingDirection) {
        this.roundingDirection = roundingDirection;
    }

    public String getNegativeRateTreatment() {
        return negativeRateTreatment;
    }

    public void setNegativeRateTreatment(String negativeRateTreatment) {
        this.negativeRateTreatment = negativeRateTreatment;
    }

    public String getCompoundingMethod() {
        return compoundingMethod;
    }

    public void setCompoundingMethod(String compoundingMethod) {
        this.compoundingMethod = compoundingMethod;
    }

    public BigDecimal getRateMultiplier() {
        return rateMultiplier;
    }

    public void setRateMultiplier(BigDecimal rateMultiplier) {
        this.rateMultiplier = rateMultiplier;
    }

    public String getDiscountingType() {
        return discountingType;
    }

    public void setDiscountingType(String discountingType) {
        this.discountingType = discountingType;
    }

    public String getQuotationStyle() {
        return quotationStyle;
    }

    public void setQuotationStyle(String quotationStyle) {
        this.quotationStyle = quotationStyle;
    }

    public Integer getRoundingPrecision() {
        return roundingPrecision;
    }

    public void setRoundingPrecision(Integer roundingPrecision) {
        this.roundingPrecision = roundingPrecision;
    }

    public BigDecimal getCalcPeriodNumOfDays() {
        return calcPeriodNumOfDays;
    }

    public void setCalcPeriodNumOfDays(BigDecimal calcPeriodNumOfDays) {
        this.calcPeriodNumOfDays = calcPeriodNumOfDays;
    }
}
