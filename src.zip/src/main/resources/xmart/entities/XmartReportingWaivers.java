package com.nwm.xmart.entities;

import com.nwm.xmart.exception.XmartException;
import com.rbs.odc.access.domain.RegulatoryRegimeImpact;
import com.rbs.odc.access.domain.ReportingWaiver;
import com.rbs.odc.access.domain.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.CollectionsUtil.nullCollToEmpty;
import static com.nwm.xmart.util.XmartUtil.getStr;
import static java.util.Objects.nonNull;

public class XmartReportingWaivers
        extends XmartOdcEntityCollection<Transaction, RegulatoryRegimeImpact, XmartReportingWaiver> {
    private static final long serialVersionUID = 855086229683912841L;

    private static final Logger logger = LoggerFactory.getLogger(XmartReportingWaivers.class);

    public XmartReportingWaivers(long documentKey, Transaction transaction) throws XmartException {
        super(documentKey, transaction);
    }

    @Override
    public Collection<RegulatoryRegimeImpact> getFromEntities(Transaction transaction) {
        return nullCollToEmpty(transaction.getRegulatoryRegimeImpact(), logger,
                "RegulatoryRegimeImpact not received for documentkey : " + getDocumentKey());
    }

    @Override
    public void createAndAddEntity(RegulatoryRegimeImpact regulatoryRegimeImpact) throws XmartException {
        for (ReportingWaiver reportingWaiver : nullCollToEmpty(regulatoryRegimeImpact.getReportingWaiver())) {

            XmartReportingWaiver xmartReportingWaiver = new XmartReportingWaiver(getDocumentKey());
            xmartReportingWaiver.setRegimeImpact(regulatoryRegimeImpact.getRegimeImpact());
            xmartReportingWaiver.setRegimeImpactId(regulatoryRegimeImpact.getRegimeImpactId());
            xmartReportingWaiver.setRegulatoryRegimeImpactId(regulatoryRegimeImpact.getId());
            if (nonNull(reportingWaiver)) {
                xmartReportingWaiver.setReportingWaiverType(getStr(reportingWaiver.getReportingWaiverType()));
            }

            addEntity(xmartReportingWaiver);
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
