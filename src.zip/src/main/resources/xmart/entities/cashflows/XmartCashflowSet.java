package com.nwm.xmart.entities.cashflows;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;

public class XmartCashflowSet extends XmartGenericSet<XmartCashflowsEvent> {

    private XmartCashflowsEvent xmartCashflowsEvent;

    @Override
    public void addStreamEvent(XmartCashflowsEvent xmartCashflowsEvent, int sourceTopicId, MappingNode mappingHierarchy)
            throws XmartException {
        this.xmartCashflowsEvent = xmartCashflowsEvent;
        xmartMappedEntities.addAll(mappingHierarchy.mapSourceObject("cashflows", xmartCashflowsEvent, null));
    }

    @Override
    public Long getWindowKey() {
        return this.xmartCashflowsEvent.getDocumentKey();
    }
}
