package com.nwm.xmart.entities.cashflows;

import com.nwm.xmart.entities.XmartOdcEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.rbs.odc.access.domain.Cashflows;
import com.rbs.odc.core.domain.ODCValue;

/**
 * Wrapper class to contain the {@link com.rbs.odc.access.domain.Cashflows}
 * recieved in the {@link com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent}
 */
public class XmartCashflowsEvent extends XmartOdcEntity {

    private final Cashflows cashflows;
    private final Long odcVersion;

    /**
     * Create object for {@link XmartCashflowsEvent}
     *
     * @param streamEvent {@link DataFabricStreamEvent} containing the Cashflows and the odcVersion we are interested in.
     * @param topicId     The Kafka topic of the cashflows topic, used in the document key.
     *
     * @throws XmartException When things seem to go south.
     */
    public XmartCashflowsEvent(DataFabricStreamEvent<ODCValue> streamEvent, int topicId) throws XmartException {
        super(generateDocumentKey(streamEvent.getPartition(), topicId, streamEvent.getStreamPosition(),
                streamEvent.getTimestamp()));
        this.cashflows = (Cashflows) streamEvent.getEventPayload().getDomainObject();
        this.odcVersion = streamEvent.getEventPayload().getOdcVersion();
    }

    /**
     * Get the {@link Cashflows} retrieved from the stream event.
     *
     * @return cashflows
     */
    public Cashflows getCashflows() {
        return cashflows;
    }

    /**
     * Odc Version of the cashflows.
     *
     * @return
     */
    public Long getOdcVersion() {
        return odcVersion;
    }
}
