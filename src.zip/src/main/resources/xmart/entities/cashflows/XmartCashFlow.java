package com.nwm.xmart.entities.cashflows;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @deprecated Cashflows are loaded with configurable mappings
 */
@Deprecated
public class XmartCashFlow extends XmartEntity {

    @XmartAttribute
    private String sourceSystemId;
    @XmartAttribute
    private String sourceSystemTransactionId;
    @XmartAttribute
    private String legIdentifier;
    @XmartAttribute
    private Long odcVersion;
    @XmartAttribute
    private BigDecimal cashflowAmountValue;
    @XmartAttribute
    private String cashflowAmountCurrencyCode;
    @XmartAttribute
    private Date effectiveDate;
    @XmartAttribute
    private Date effectiveDtAdjustedDate;
    @XmartAttribute
    private Date effectiveDtUnadjustedDate;
    @XmartAttribute
    private Date eventDateTime;
    @XmartAttribute
    private Boolean isEstimated;
    @XmartAttribute
    private String payerSourceSystemBookId;
    @XmartAttribute
    private String payerBookSourceSystemId;
    @XmartAttribute
    private String payerPartyClassification;
    @XmartAttribute
    private String payerPartyReference;
    @XmartAttribute
    private String paymentType;
    @XmartAttribute
    private String receiverSourceSystemBookId;
    @XmartAttribute
    private String receiverBookSourceSystemId;
    @XmartAttribute
    private String receiverPartyClassification;
    @XmartAttribute
    private String receiverPartyReference;
    @XmartAttribute
    private String sourceSystemEventId;
    @XmartAttribute
    private BigDecimal rcAmountValue;
    @XmartAttribute
    private String rcAmountCurrencyCode;
    @XmartAttribute
    private Boolean settlementMessageRequired;

    //TODO this wont be needing document key
    protected XmartCashFlow(long documentKey) throws XmartException {
        super(documentKey);
    }

    public String getSourceSystemId() {
        return sourceSystemId;
    }

    public void setSourceSystemId(String sourceSystemId) {
        this.sourceSystemId = sourceSystemId;
    }

    public String getSourceSystemTransactionId() {
        return sourceSystemTransactionId;
    }

    public void setSourceSystemTransactionId(String sourceSystemTransactionId) {
        this.sourceSystemTransactionId = sourceSystemTransactionId;
    }

    public BigDecimal getCashflowAmountValue() {
        return cashflowAmountValue;
    }

    public void setCashflowAmountValue(BigDecimal cashflowAmountValue) {
        this.cashflowAmountValue = cashflowAmountValue;
    }

    public String getCashflowAmountCurrencyCode() {
        return cashflowAmountCurrencyCode;
    }

    public void setCashflowAmountCurrencyCode(String cashflowAmountCurrencyCode) {
        this.cashflowAmountCurrencyCode = cashflowAmountCurrencyCode;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public Date getEffectiveDtAdjustedDate() {
        return effectiveDtAdjustedDate;
    }

    public void setEffectiveDtAdjustedDate(Date effectiveDtAdjustedDate) {
        this.effectiveDtAdjustedDate = effectiveDtAdjustedDate;
    }

    public Date getEffectiveDtUnadjustedDate() {
        return effectiveDtUnadjustedDate;
    }

    public void setEffectiveDtUnadjustedDate(Date effectiveDtUnadjustedDate) {
        this.effectiveDtUnadjustedDate = effectiveDtUnadjustedDate;
    }

    public Date getEventDateTime() {
        return eventDateTime;
    }

    public void setEventDateTime(Date eventDateTime) {
        this.eventDateTime = eventDateTime;
    }

    public Boolean isEstimated() {
        return isEstimated;
    }

    public void setEstimated(Boolean estimated) {
        isEstimated = estimated;
    }

    public String getLegIdentifier() {
        return legIdentifier;
    }

    public void setLegIdentifier(String legIdentifier) {
        this.legIdentifier = legIdentifier;
    }

    public String getPayerSourceSystemBookId() {
        return payerSourceSystemBookId;
    }

    public void setPayerSourceSystemBookId(String payerSourceSystemBookId) {
        this.payerSourceSystemBookId = payerSourceSystemBookId;
    }

    public String getPayerBookSourceSystemId() {
        return payerBookSourceSystemId;
    }

    public void setPayerBookSourceSystemId(String payerBookSourceSystemId) {
        this.payerBookSourceSystemId = payerBookSourceSystemId;
    }

    public String getPayerPartyClassification() {
        return payerPartyClassification;
    }

    public void setPayerPartyClassification(String payerPartyClassification) {
        this.payerPartyClassification = payerPartyClassification;
    }

    public String getPayerPartyReference() {
        return payerPartyReference;
    }

    public void setPayerPartyReference(String payerPartyReference) {
        this.payerPartyReference = payerPartyReference;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getReceiverSourceSystemBookId() {
        return receiverSourceSystemBookId;
    }

    public void setReceiverSourceSystemBookId(String receiverSourceSystemBookId) {
        this.receiverSourceSystemBookId = receiverSourceSystemBookId;
    }

    public String getReceiverBookSourceSystemId() {
        return receiverBookSourceSystemId;
    }

    public void setReceiverBookSourceSystemId(String receiverBookSourceSystemId) {
        this.receiverBookSourceSystemId = receiverBookSourceSystemId;
    }

    public String getReceiverPartyClassification() {
        return receiverPartyClassification;
    }

    public void setReceiverPartyClassification(String receiverPartyClassification) {
        this.receiverPartyClassification = receiverPartyClassification;
    }

    public String getReceiverPartyReference() {
        return receiverPartyReference;
    }

    public void setReceiverPartyReference(String receiverPartyReference) {
        this.receiverPartyReference = receiverPartyReference;
    }

    public String getSourceSystemEventId() {
        return sourceSystemEventId;
    }

    public void setSourceSystemEventId(String sourceSystemEventId) {
        this.sourceSystemEventId = sourceSystemEventId;
    }

    public BigDecimal getRcAmountValue() {
        return rcAmountValue;
    }

    public void setRcAmountValue(BigDecimal rcAmountValue) {
        this.rcAmountValue = rcAmountValue;
    }

    public String getRcAmountCurrencyCode() {
        return rcAmountCurrencyCode;
    }

    public void setRcAmountCurrencyCode(String rcAmountCurrencyCode) {
        this.rcAmountCurrencyCode = rcAmountCurrencyCode;
    }

    public Boolean getSettlementMessageRequired() {
        return settlementMessageRequired;
    }

    public void setSettlementMessageRequired(Boolean settlementMessageRequired) {
        this.settlementMessageRequired = settlementMessageRequired;
    }

    public Long getOdcVersion() {
        return odcVersion;
    }

    public void setOdcVersion(Long odcVersion) {
        this.odcVersion = odcVersion;
    }
}
