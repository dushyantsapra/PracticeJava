package com.nwm.xmart.entities.crm;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XmartCRMSourceEventSet extends XmartGenericSet<CRMSourceEvent> {
    private static final long serialVersionUID = -6650986451151217492L;

    private static final Logger logger = LoggerFactory.getLogger(XmartCRMSourceEventSet.class);

    private long documentKey;

    @Override
    public void addStreamEvent(CRMSourceEvent event, int sourceTopicId, MappingNode mappingHierarchy)
            throws XmartException {
        XmartCRMSourceEvent xmartCRMSourceEvent = new XmartCRMSourceEvent(event, sourceTopicId);

        this.documentKey = xmartCRMSourceEvent.getDocumentKey();

        logger.info("map: docKey {} topicId {} source[ TimeStamp={}, Partition={}, Position={}] dfVersion {} key {} "
                        + "collectionName :{}", documentKey, sourceTopicId, event.getTimeStamp(), event.getPartitionId(),
                event.getOffset(), event.getDfVersion(), event.getKey(), event.getCrmSourceEventType().name());
        xmartMappedEntities.addAll(mappingHierarchy
                .mapSourceObject(xmartCRMSourceEvent.getStreamEvent().getCrmSourceEventType().name(),
                        xmartCRMSourceEvent, null));
    }

    @Override
    public Long getWindowKey() {
        return documentKey;
    }
}
