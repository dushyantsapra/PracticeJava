package com.nwm.xmart.exception;

public class XmartMandatoryAttributeMissingException extends XmartException {

    public XmartMandatoryAttributeMissingException() {
    }

    public XmartMandatoryAttributeMissingException(String message) {
        super(message);
    }

    public XmartMandatoryAttributeMissingException(String message, Throwable cause) {
        super(message, cause);
    }

    public XmartMandatoryAttributeMissingException(Throwable cause) {
        super(cause);
    }
}
