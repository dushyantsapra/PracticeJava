package com.nwm.xmart.exception;

/**
 * Created by aslammh on 10/08/17.
 */
public class XmartException extends Exception {

    public XmartException() {
        super();
    }

    public XmartException(String message) {
        super(message);
    }

    public XmartException(String message, Throwable cause) {
        super(message, cause);
    }

    public XmartException(Throwable cause) {
        super(cause);
    }
}
