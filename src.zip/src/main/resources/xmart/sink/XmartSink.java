package com.nwm.xmart.sink;

import com.google.inject.Inject;
import com.nwm.xmart.database.dao.XmartDao;
import com.nwm.xmart.exception.XmartException;
import org.apache.flink.api.common.accumulators.AverageAccumulator;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>Defines the standard methods that all Xmart Sinks must must provide to be used in the Flink sinks.</p>
 * <p>To use the DAO the calling class must initialise by calling the open function,
 * objects can then be written using the write method. The close method must be called
 * to ensure the connection to any underlying persistance layer is closed correctly.</p>
 *
 * @author heskets
 */
public class XmartSink<T> extends RichSinkFunction<T> {

    private static final long serialVersionUID = 8433525385316679218L;

    private static final Logger logger = LoggerFactory.getLogger(XmartSink.class);
    ParameterTool parameters = null;
    private Boolean accumulatorsOn = false;
    private Long startTime = null;
    private IntCounter recordsProcessed = new IntCounter();
    private AverageAccumulator avgRecordPreparationTime = new AverageAccumulator();
    private AverageAccumulator avgRecordProcessTime = new AverageAccumulator();
    private XmartDao writer;

    @Inject
    public XmartSink() {

    }

    @Override
    public void invoke(Object in) throws Exception {

        if (in != null) {

            if (accumulatorsOn) {
                startTime = System.nanoTime();
            }

            Long executeTime = writer.write(in, parameters);

            if (accumulatorsOn) {
                recordsProcessed.add(1);
                avgRecordPreparationTime.add(executeTime - startTime);
                avgRecordProcessTime.add(System.nanoTime() - executeTime);
            }
        } else {
            logger.error("Error - ignored NULL record in sink - failure in previous operator.");
        }
    }

    @Override
    public void open(Configuration configuration) throws XmartException {

        parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        accumulatorsOn = parameters.getBoolean("operator.monitoring.accumulators.enable", false);
        if (accumulatorsOn) {
            getRuntimeContext().addAccumulator("sinkRecordsProcessed", recordsProcessed);
            getRuntimeContext().addAccumulator("sinkAvgRecordPreparationTime", avgRecordPreparationTime);
            getRuntimeContext().addAccumulator("sinkAvgRecordProcessTime", avgRecordProcessTime);
        }

        writer.open(parameters);
    }

    @Override
    public void close() throws Exception {

        if (writer != null) {
            writer.close();
        }
    }

    public void setWriter(XmartDao writer) {
        this.writer = writer;
    }
}
