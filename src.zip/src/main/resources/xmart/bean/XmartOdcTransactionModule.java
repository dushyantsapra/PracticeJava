package com.nwm.xmart.bean;

import com.google.inject.AbstractModule;
import com.google.inject.name.Names;
import com.nwm.xmart.database.statement.TdxTradeXmlInsertStatement;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.mapper.XmartOdcTransactionMapper;
import com.nwm.xmart.mapper.XmartTransactionAggregateProcessFunction;
import com.nwm.xmart.mapper.XmartTransactionSetToXMLMapper;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.streaming.api.functions.ProcessFunction;

/**
 * Created by aslammh on 22/09/17.
 */
public class XmartOdcTransactionModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(RichMapFunction.class).annotatedWith(Names.named("XmartTransactionMapper"))
                                   .to(XmartOdcTransactionMapper.class);

        bind(ProcessFunction.class).annotatedWith(Names.named("XmartWindowMapper"))
                                   .to(XmartTransactionAggregateProcessFunction.class);

        bind(RichMapFunction.class).annotatedWith(Names.named("XmartOdcXmlMapper"))
                                   .to(XmartTransactionSetToXMLMapper.class);

        bind(XmartStatement.class).annotatedWith(Names.named("XmartStatement")).to(TdxTradeXmlInsertStatement.class);
    }
}
