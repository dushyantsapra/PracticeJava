package com.nwm.xmart.bean.schedule_entries.domain;

import java.io.Serializable;

public class XmartODCTransactionId implements Serializable {

    private static final long serialVersionUID = 440343225051555233L;
    private String sourceSystemTransactionId;
    private String sourceSystemId;

    public String getSourceSystemTransactionId() {
        return sourceSystemTransactionId;
    }

    public String getSourceSystemId() {
        return sourceSystemId;
    }
}