package com.nwm.xmart.bean.schedule_entries;

import com.google.inject.AbstractModule;
import com.google.inject.name.Names;
import com.nwm.xmart.database.dao.ScheduleEntriesXmlInsertStatement;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.mapper.XmartAggregateProcessFunction;
import com.nwm.xmart.mapper.XmartTransactionAggregateProcessFunction;
import com.nwm.xmart.mapper.XmartTransactionSetToXMLMapper;
import com.nwm.xmart.mapper.XmartXmlMapper;
import com.nwm.xmart.mapper.schedule_entries.XmartScheduleEntriesOdcMapper;

public class XmartScheduleEntriesModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(XmartScheduleEntriesOdcMapper.class).annotatedWith(Names.named("XmartScheduleEntriesOdcMapper"))
                                                 .to(XmartScheduleEntriesOdcMapper.class);

        bind(XmartAggregateProcessFunction.class).annotatedWith(Names.named("XmartWindowMapper"))
                                                 .to(XmartTransactionAggregateProcessFunction.class);

        bind(XmartXmlMapper.class).annotatedWith(Names.named("XmartOdcXmlMapper"))
                                  .to(XmartTransactionSetToXMLMapper.class);

        bind(XmartStatement.class).annotatedWith(Names.named("XmartStatement"))
                                  .to(ScheduleEntriesXmlInsertStatement.class);
    }
}
