package com.nwm.xmart.bean;

import com.google.inject.TypeLiteral;
import com.google.inject.name.Names;
import com.nwm.xmart.core.inject.XmartAbstractModule;
import com.nwm.xmart.database.dao.LoggerDao;
import com.nwm.xmart.database.dao.XmartDao;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.mapper.XmartArgonMapper;
import com.nwm.xmart.sink.LoggerSink;
import com.nwm.xmart.sink.XmartSink;
import com.nwm.xmart.source.argon.XmartArgonEvent;
import org.apache.flink.api.common.functions.RichMapFunction;

public class XmartArgonModule extends XmartAbstractModule {
    @Override
    protected void additionalConfigure() {
        bind(XmartDao.class).annotatedWith(Names.named("LoggerDao")).to(LoggerDao.class);

        bind(XmartSink.class).annotatedWith(Names.named("LoggerSink")).to(LoggerSink.class);

        bind(new TypeLiteral<RichMapFunction<XmartArgonEvent, XmartGenericSet>>() {
        }).annotatedWith(Names.named("XmartSourceEventMapper")).to(XmartArgonMapper.class);
    }
}
