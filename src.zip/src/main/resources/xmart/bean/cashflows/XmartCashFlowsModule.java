package com.nwm.xmart.bean.cashflows;

import com.google.inject.TypeLiteral;
import com.google.inject.name.Names;
import com.nwm.xmart.core.inject.XmartAbstractModule;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.database.statement.tdx.TdxCashFlowXmlInsertStatement;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.mapper.cashflows.XmartCashflowsMapper;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.rbs.odc.core.domain.ODCValue;
import org.apache.flink.api.common.functions.RichMapFunction;

/**
 * Specific class to configure the module for ODC /TDX cashflows.
 * Extends {@link XmartAbstractModule} which provides common injections. any custom can be declared here
 *
 * @author vashpan
 */
public class XmartCashFlowsModule extends XmartAbstractModule {

    @Override
    protected void additionalConfigure() {
        bind(new TypeLiteral<RichMapFunction<DataFabricStreamEvent<ODCValue>, XmartGenericSet>>() {
        }).annotatedWith(Names.named("XmartOdcMapper")).to(XmartCashflowsMapper.class);

        bind(XmartStatement.class).annotatedWith(Names.named("XmartStatement")).to(TdxCashFlowXmlInsertStatement.class);
    }
}
