package com.nwm.xmart.bean.mdx;

import com.google.inject.TypeLiteral;
import com.google.inject.name.Names;
import com.nwm.xmart.core.inject.XmartAbstractModule;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.database.statement.mdx.MdxInstrumentXmlInsertStatement;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.mapper.mdx.XmartMdxMapper;
import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import org.apache.flink.api.common.functions.RichMapFunction;

public class XmartMdxInstrumentModule extends XmartAbstractModule {
    @Override
    protected void additionalConfigure() {
        bind(new TypeLiteral<RichMapFunction<MdxDocumentEvent, XmartGenericSet>>() {
        }).annotatedWith(Names.named("XmartSourceEventMapper")).to(XmartMdxMapper.class);

        bind(XmartStatement.class).annotatedWith(Names.named("XmartStatement"))
                                  .to(MdxInstrumentXmlInsertStatement.class);
    }
}
