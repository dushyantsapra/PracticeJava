package com.nwm.xmart.bean.sds;

import com.google.inject.TypeLiteral;
import com.google.inject.name.Names;
import com.nwm.xmart.core.inject.XmartAbstractModule;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.database.statement.sds.SdsXmlInsertStatement;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.mapper.common.XmartGenericAggregateProcessFunction;
import com.nwm.xmart.mapper.common.XmartGenericXmlMapper;
import com.nwm.xmart.mapper.sds.XmartSdsMapper;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.nwm.xmart.streaming.source.df.event.DataFabricWatchEvent;
import com.nwm.xmart.streaming.source.json.JSONDocumentTraverser;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.streaming.api.functions.ProcessFunction;

import java.util.List;

public class XmartSdsModule extends XmartAbstractModule {

    @Override
    protected void additionalConfigure() {
        bind(new TypeLiteral<RichMapFunction<DataFabricWatchEvent, XmartGenericSet>>() {
        }).annotatedWith(Names.named("XmartSdsMapper")).to(XmartSdsMapper.class);

        bind(new TypeLiteral<ProcessFunction<XmartGenericSet, List<XmartGenericSet>>>() {
        }).annotatedWith(Names.named("XmartWindowMapper")).to(XmartGenericAggregateProcessFunction.class);

        bind(new TypeLiteral<RichMapFunction<List<XmartGenericSet>, XmartGenericXmlSet>>() {
        }).annotatedWith(Names.named("XmartXmlMapper")).to(XmartGenericXmlMapper.class);

        bind(XmartStatement.class).annotatedWith(Names.named("XmartStatement")).to(SdsXmlInsertStatement.class);
    }
}
