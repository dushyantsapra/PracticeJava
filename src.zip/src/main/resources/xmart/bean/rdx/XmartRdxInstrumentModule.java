package com.nwm.xmart.bean.rdx;

import com.google.inject.AbstractModule;
import com.google.inject.TypeLiteral;
import com.google.inject.name.Names;
import com.nwm.xmart.database.statement.RdxInstrumentXmlInsertStatement;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.mapper.common.XmartGenericAggregateProcessFunction;
import com.nwm.xmart.mapper.common.XmartGenericXmlMapper;
import com.nwm.xmart.mapper.rdx.XmartRdxMapper;
import com.nwm.xmart.streaming.source.rdx.event.RDXSourceEvent;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.streaming.api.functions.ProcessFunction;

import java.util.List;

/**
 * Created by aslammh on 22/09/17.
 */
public class XmartRdxInstrumentModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(new TypeLiteral<RichMapFunction<RDXSourceEvent, XmartGenericSet>>() {
        }).annotatedWith(Names.named("XmartSourceEventMapper")).to(XmartRdxMapper.class);

        bind(new TypeLiteral<ProcessFunction<XmartGenericSet, List<XmartGenericSet>>>() {
        }).annotatedWith(Names.named("XmartWindowMapper")).to(XmartGenericAggregateProcessFunction.class);

        bind(new TypeLiteral<RichMapFunction<List<XmartGenericSet>, XmartGenericXmlSet>>() {
        }).annotatedWith(Names.named("XmartXmlMapper")).to(XmartGenericXmlMapper.class);

        bind(XmartStatement.class).annotatedWith(Names.named("XmartStatement"))
                                  .to(RdxInstrumentXmlInsertStatement.class);
    }
}
