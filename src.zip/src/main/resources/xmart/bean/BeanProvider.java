package com.nwm.xmart.bean;

import com.nwm.xmart.processor.JobType;
import com.nwm.xmart.processor.XmartProcessor;

/**
 * Created by aslammh on 22/09/17.
 */
public interface BeanProvider {
    public <T extends XmartProcessor> T getBean(Class clazz, JobType jobType);
}
