package com.nwm.xmart.bean;

import com.google.inject.Module;
import com.nwm.xmart.processor.JobType;

/**
 * Created by aslammh on 22/09/17.
 * <p>
 * Provides binding of beans which all are required at the project level.
 * Hence this must be placed in a separate module and can have dependency on the required modules.
 */
public class UnifiedBeanProvider extends AbstractBeanProvider {
    @Override
    public Module[] getModules(JobType jobType) {
        return new Module[] { new XmartModule() };
    }
}
