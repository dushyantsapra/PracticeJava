package com.nwm.xmart.source.file.exeption;

public class XmartFileEmailSendException extends RuntimeException {
    public XmartFileEmailSendException(String s) {
        super(s);
    }

    public XmartFileEmailSendException(String s, Throwable e) {
        super(s, e);
    }
}
