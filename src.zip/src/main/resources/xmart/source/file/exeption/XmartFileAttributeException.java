package com.nwm.xmart.source.file.exeption;

public class XmartFileAttributeException extends RuntimeException {
    public XmartFileAttributeException(String s) {
        super(s);
    }

    public XmartFileAttributeException(String s, Throwable e) {
        super(s, e);
    }
}
