package com.nwm.xmart.source.file.util;

/**
 * The basis of file to sort
 */
public enum FileSortType {

    /**
     * Sort on business date i.e. date in the filename
     */
    BUSINESS_DATE("BUSINESS_DATE"), /**
     * Sort on file modified date
     */
    MODIFIED_DATE("MODIFIED_DATE");

    private String myStr;

    FileSortType(String myStr) {
        this.myStr = myStr;
    }

    @Override
    public String toString() {
        return myStr;
    }
}
