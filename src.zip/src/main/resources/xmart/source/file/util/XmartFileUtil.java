package com.nwm.xmart.source.file.util;

import com.nwm.xmart.source.file.XmartFileAttributes;
import com.nwm.xmart.source.file.db.entity.FileExtractEntity;
import com.nwm.xmart.source.file.event.XmartMarkerFileWrapper;
import com.nwm.xmart.source.file.exeption.XmartFileProcessingException;
import com.nwm.xmart.streaming.source.file.event.FileEventType;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.filefilter.WildcardFileFilter;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import static com.google.common.base.Strings.isNullOrEmpty;
import static com.nwm.xmart.source.file.XmartFilePropertyNames.DAYS_OLD;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

public class XmartFileUtil implements Serializable {

    /**
     * checks if the path exists and points to a directory
     *
     * @param filePath to check if this is a directory
     *
     * @return true if exists and is a directory false otherwise
     */
    public static boolean directoryExists(String filePath) {
        return exists(filePath) && Paths.get(filePath).toFile().isDirectory();
    }

    /**
     * checks if the path exists and points to a file
     *
     * @param filePath
     *
     * @return
     */
    public static boolean fileExists(String filePath) {
        return exists(filePath) && Paths.get(filePath).toFile().isFile();
    }

    /**
     * Cheks if a path exists, whether directory or file check later.
     *
     * @param filePath path to check
     *
     * @return true if the path exists. false otherwise
     */
    public static boolean exists(String filePath) {
        return !isNullOrEmpty(filePath) && Paths.get(filePath).toFile().exists();
    }

    /**
     * Gets the number of records in the file for further processing, skips empty, header and tail lines
     *
     * @param file file to count
     *
     * @return Number of lines in the file
     *
     * @throws XmartFileProcessingException File does not exist or any other issue in accesing fiel.
     */
    public static long getRecordCount(File file, String lineIgnorePrefix, String separator)
            throws XmartFileProcessingException {
        long lineCount = 0;
        try (LineNumberReader br = new LineNumberReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (br.getLineNumber() == 1 || line.startsWith(lineIgnorePrefix) || line.split(separator).length == 1) {
                    //first line is header, line that begins with ignore prefix or line that is empty i.e. split results in no records
                    continue;
                }
                lineCount++;
            }
        } catch (IOException e) {
            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                    "System Error: Could not count records", "Could not count records of file " + file.getPath(), e);
        }
        return lineCount;
    }

    /**
     * Searches for a file starting with prefix and ending with suffix, returns the list of file sorted in order of modified time
     * reads
     */
    public static List<XmartMarkerFileWrapper> findFiles(XmartFileAttributes fileAttributes, boolean caseSensitive)
            throws XmartFileProcessingException {
        List<XmartMarkerFileWrapper> markerFileWrappers = new LinkedList<>();
        IOCase ioCase = caseSensitive ? IOCase.SENSITIVE : IOCase.INSENSITIVE;

        if (FileEventType.XMART_RGL_ORGUNIT_HIERARCHY.toString().equals(fileAttributes.getFileEventType().name())) {
            String fileName = extractFromZip(fileAttributes, "_OrgUnit_");
            if (fileName != null) {
                String markerFileName = fileName
                        .replace(fileAttributes.getFileExtension(), fileAttributes.getMarkerFileExtension());
                createMarkerFile(fileAttributes.getFileLocation(), markerFileName);
            }
        }

        Collection<File> files = FileUtils.listFiles(new File(fileAttributes.getFileLocation()),
                new WildcardFileFilter(fileAttributes.getFilePrefix() + "*" + fileAttributes.getMarkerFileExtension(),
                        ioCase), null);

        for (File markerFile : files) {
            switch (fileAttributes.getFileSortType()) {
            case BUSINESS_DATE:
                try {
                    markerFileWrappers.add(new XmartMarkerFileWrapper(fileAttributes, markerFile));
                } catch (ParseException e) {
                    throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                            "Filename contains invalid date",
                            "Date in marker file " + markerFile.getPath() + " not understood. Expecting to be "
                                    + fileAttributes.getProcessDateFormat());
                }
                break;
            case MODIFIED_DATE:
                markerFileWrappers.add(new XmartMarkerFileWrapper(markerFile));
                break;
            default:
                break;
            }
        }
        markerFileWrappers.sort(Comparator.comparing(p -> p.getFileDate()));
        return markerFileWrappers;
    }

    private static String extractFromZip(XmartFileAttributes fileAttributes, String match)
            throws XmartFileProcessingException {
        /*Collection<File> files = FileUtils.listFiles(new File(fileAttributes.getFileLocation()),
                new WildcardFileFilter(fileAttributes.getDirPrefix() + "*" + "zip", IOCase.INSENSITIVE), null);*/

        Collection<File> markerFiles = FileUtils.listFiles(new File(fileAttributes.getFileLocation()),
                new WildcardFileFilter(fileAttributes.getDirPrefix() + "*" + fileAttributes.getMarkerFileExtension(), IOCase.INSENSITIVE), null);

        for (File markerFile : markerFiles) {
            ZipFile zipFile = null;
            try {
                File zipFileName = new File(markerFile.getPath().substring(0, markerFile.getPath().lastIndexOf(".") + 1) + "zip");
                zipFile = new ZipFile(zipFileName);
            } catch (Exception ex) {
                throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                        "Failed in ZipFile creation by File.", "Failed in ZipFile creation by File " + ex.getMessage(),
                        ex);
            }

            if (zipFile != null) {
                Enumeration<? extends ZipEntry> zipEnum = zipFile.entries();
                while (zipEnum.hasMoreElements()) {
                    ZipEntry zipEntry = zipEnum.nextElement();
                    if (zipEntry.getName().contains(match)) {
                        String suffix = markerFile.getName().replace(fileAttributes.getDirPrefix(), "").replace("." + fileAttributes.getMarkerFileExtension(), "");
                        String name = fileAttributes.getFilePrefix() + suffix + "." + fileAttributes.getFileExtension();

                        try {
                            BufferedWriter writer = new BufferedWriter(
                                    new FileWriter(fileAttributes.getFileLocation() + "//" + name));
                            InputStream is = zipFile.getInputStream(zipEntry);
                            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                            String line = null;
                            while ((line = reader.readLine()) != null) {
                                writer.write(line + "\n");
                            }
                            writer.close();
                        } catch (Exception ex) {
                            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                                    "Failed to Write New File from Zip files.",
                                    "Failed to Write New File from Zip files " + ex.getMessage(), ex);
                        }

                        return name;
                    }
                }
            }
        }

        return null;
    }

    private static void createMarkerFile(String filePath, String fileName) throws XmartFileProcessingException {
        try {
            BufferedWriter markerWriter = new BufferedWriter(new FileWriter(filePath + "//" + fileName));
            markerWriter.write("");
            markerWriter.close();
        } catch (Exception ex) {
            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                    "Failed to create marker files.", "Failed to create marker files " + ex.getMessage(), ex);
        }
    }

    /**
     * Finds the file for the marker file
     * e.g. for marker myFile.marker will return myFile.csv
     *
     * @param markerFile the file to search for
     * @param fileExt    Extension of the file to look for.
     *
     * @return found file against the marker file
     *
     * @throws XmartFileProcessingException if the path cannot be determined
     */
    public static File findFileForMarker(File markerFile, String fileExt) throws XmartFileProcessingException {
        File returnFile = new File(
                markerFile.getPath().substring(0, markerFile.getPath().lastIndexOf(".") + 1) + fileExt);
        if (!returnFile.exists()) {
            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                    "File not found for marker file",
                    "File to process " + returnFile.getPath() + " not found for marker file " + markerFile.getPath());
        }

        return returnFile;
    }

    public static File findZipFile(File file, String fileEventType) throws XmartFileProcessingException {
        String fileName = null;
        if (FileEventType.XMART_RGL_ORGUNIT_HIERARCHY.toString().equals(fileEventType)) {
            fileName = file.getPath().replace("_OrgUnit", "").replace("DAT", "zip");
        }

        File returnFile = new File(fileName);
        if (!returnFile.exists()) {
            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                    "File not found for Zip file",
                    "File to process " + returnFile.getPath() + " not found for marker file " + file.getPath());
        }

        return returnFile;
    }

    /**
     * Creates a marker file for the supplied file with the supploed extension
     *
     * @param file            File for whihc marker is to be created
     * @param markerExtension Extension of the marker file.
     *
     * @return file pat + file name of marker file created, can be
     *
     * @throws XmartFileProcessingException could create file, file exists and all that bad stuff
     */
    public static String createMarkerForFile(String file, String markerExtension) throws XmartFileProcessingException {
        String markerFilePath = file.substring(0, file.lastIndexOf(".") + 1) + markerExtension;
        try {
            if (!new File(markerFilePath).createNewFile()) {
                throw new XmartFileProcessingException(XmartFileProcessingException.Priority.WARN,
                        "Marker file  already exists", "Marker file exists " + markerFilePath + " for file " + file);
            }
        } catch (IOException e) {
            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                    "Failed to create marker file ",
                    "Could not create marker file " + markerFilePath + " for file " + file + ". Cause " + e
                            .getMessage(), e);
        }

        return markerFilePath;
    }

    public static long getSize(File file) {
        return file.length();
    }

    /**
     * @param file        {@link File} file to validate
     * @param fileAttr    properties
     * @param recordCount count of records in this file
     *
     * @throws XmartFileProcessingException in case of validation failure, always with XmartFileProcessingException.Priority.ERROR pririoty
     */
    public static void basicValidations(File file, XmartFileAttributes fileAttr, long recordCount)
            throws XmartFileProcessingException {
        if (file.isDirectory()) {
            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                    file.getPath() + " is a directory",
                    file.getPath() + " is a directory, expected it to be a file. Remove this directory.");
        }

        if (file.length() <= 0) {
            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                    " Zero length file " + file.getPath(),
                    file.getPath() + "  is a zero length file check and validationWithExtractPro file.");
        }

        if (recordCount < fileAttr.getMinRecords()) {
            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                    " File [" + file.getPath() + "] does not have minimum records ",
                    file.getPath() + " contains " + recordCount + " records. These are less than expected " + fileAttr
                            .getMinRecords() + ". \n File moved to " + fileAttr.getErrorFolder());
        }
        Date now = new Date();
        long diffInDays = TimeUnit.MILLISECONDS.toDays(now.getTime() - file.lastModified());
        if (diffInDays > fileAttr.getDaysOld()) {
            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                    " File of older business date [" + file.getPath() + "]",
                    file.getPath() + "  has modification date " + new Date(file.lastModified()).toString()
                            + ", which is " + diffInDays + " days older than the configured value " + fileAttr
                            .getDaysOld() + ". \nIf you want to load this file, either increase the parameter ["
                            + DAYS_OLD + "] or change the file modification date to recent one.");
        }
    }

    /**
     * Performs file validation on the file before starting the processing
     * Validations performed include
     * <ol>
     * <li>File size of file is not zero</li>
     * <li>File is at most of last business date </li>
     * <li>if check to be based on record count then file has atleast provided number of records</li>
     * <li>if check to be based on size then file size</li>
     * </ol>
     * <p>
     * Sets the recrod coutn and the file size in incomimg {@link FileExtractEntity}
     *
     * @param file     to validationWithExtractPro
     * @param fileAttr configuration attributes to get paramarts frmom
     */
    public static void validationWithExtractProcResult(File file, XmartFileAttributes fileAttr,
            FileExtractEntity fileExtractEntity) throws XmartFileProcessingException {

        switch (fileAttr.getQuantaCheckType()) {
        case RECORD_COUNT:

           /* // IN case last file details received as 0 assume this file failed last time
            if (nonNull(fileExtractEntity.getPreviousFileName()) && fileExtractEntity.getPreviousFileRowCount() == 0) {
                throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                        " File process failure [" + file.getPath() + "]",
                        file.getPath() + " not processed because No-Go received for extract procedure. "
                                + "\nPlease investigate as per previoous error communication for this file"
                                + ". File moved to " + fileAttr.getErrorFolder());
            }*/

            long errorRecordCount = fileExtractEntity.getPreviousFileRowCount() - (
                    fileExtractEntity.getPreviousFileRowCount() * fileAttr.getDeviationPercentError() / 100);
            if (fileExtractEntity.getRecordCount() < errorRecordCount) {
                throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                        " File record error threshold [" + file.getPath() + "]",
                        file.getPath() + " contains " + fileExtractEntity.getRecordCount() + " records. These are "
                                + fileAttr.getDeviationPercentError() + "% less than last file " + fileExtractEntity
                                .getPreviousFileName() + " which contained " + fileExtractEntity
                                .getPreviousFileRowCount() + ". File moved to " + fileAttr.getErrorFolder());
            }

            long warnRecordCount = fileExtractEntity.getPreviousFileRowCount() - (
                    fileExtractEntity.getPreviousFileRowCount() * fileAttr.getDeviationPercentWarn() / 100);

            if (fileExtractEntity.getRecordCount() < warnRecordCount) {
                throw new XmartFileProcessingException(XmartFileProcessingException.Priority.WARN,
                        " File record warn threshold [" + file.getPath() + "]",
                        "WARNING:" + file.getPath() + " contains " + fileExtractEntity.getRecordCount()
                                + " records. These are " + fileAttr.getDeviationPercentWarn() + "% less than last file "
                                + fileExtractEntity.getPreviousFileName() + " which contained " + fileExtractEntity
                                .getPreviousFileRowCount() + " records.");
            }

            break;
        case FILE_SIZE:
            // TODO future files may need check based on the file size to save time of iterating the file.
            break;
        case NONE:
        default:
        }
    }

    /**
     * Deletes the provided file
     *
     * @param file file to delete
     *
     * @throws XmartFileProcessingException As per exception that occurs
     */
    public static void delete(File file) throws XmartFileProcessingException {
        try {
            Files.delete(Paths.get(file.toURI()));
        } catch (IOException e) {
            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                    "Delete failed " + file.getName(),
                    "Failed to delete file " + file.getPath() + " because of error " + e.getMessage());
        }
    }

    /**
     * MOves the supplied {@link File} to the supplied directory
     *
     * @param fileToMove File to move
     * @param directory  DIrectory to move to
     *
     * @throws XmartFileProcessingException Well, when coudl this occur?
     */
    public static void moveFile(File fileToMove, String directory) throws XmartFileProcessingException {
        moveFile(fileToMove, directory, fileToMove.getName());
    }

    /**
     * MOves the supplied {@link File} to the supplied directory
     *
     * @param fileToMove File to move
     * @param directory  DIrectory to move to
     * @param newName    New base name of file to move to
     *
     * @throws XmartFileProcessingException Well, when coudl this occur?
     */
    public static void moveFile(File fileToMove, String directory, String newName) throws XmartFileProcessingException {
        File destFile = new File(directory + File.separator + newName);
        try {
            FileUtils.moveFile(fileToMove, destFile);
        } catch (IOException e) {
            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR, "File move failed",
                    "Could not move file " + fileToMove.getPath() + " to " + directory + ". Due to " + e.getMessage()
                            + ". \nPlease remove this file manually", e);
        }
    }

    /**
     * MOve fmultiple files to the spcified directory e.g. moving all marker fiels to the error folder.
     */
    public static void moveFiles(Collection<XmartMarkerFileWrapper> filesToMove, String directory)
            throws XmartFileProcessingException {
        XmartFileProcessingException accException = null;
        for (XmartMarkerFileWrapper file : filesToMove) {
            try {
                moveFile(file.getMarkerFile(), directory);
            } catch (XmartFileProcessingException e) {
                accException = isNull(accException) ? e : accException;
                accException.include(e);
            }
        }
        if (nonNull(accException))
            throw accException;
    }

    /**
     * Moves the marker files specified and the files to be procesed along with the marker files to the supplied directory i.e. error directory
     */
    public static void moveMarkerAndRelatedFiles(Collection<XmartMarkerFileWrapper> markerFilesToMove, String directory,
            String fileExtension) throws XmartFileProcessingException {
        XmartFileProcessingException accException = null;
        for (XmartMarkerFileWrapper markerFile : markerFilesToMove) {
            try {
                moveFile(markerFile.getMarkerFile(), directory);
                moveFile(findFileForMarker(markerFile.getMarkerFile(), fileExtension), directory);
            } catch (XmartFileProcessingException e) {
                accException = isNull(accException) ? e : accException;
                accException.include(e);
            }
        }

        if (nonNull(accException))
            throw accException;
    }

    public static void validateFileDateWithCurrentDate(XmartFileAttributes fileAttributes,
            XmartMarkerFileWrapper xmartMarkerFileWrapper) throws XmartFileProcessingException, ParseException {
        String dateNowString = fileAttributes.getDateSuffixFormatter().format(new Date());
        Date dateNow = fileAttributes.getDateSuffixFormatter().parse(dateNowString);
        if (xmartMarkerFileWrapper.getFileDate().after(dateNow)) {
            throw new XmartFileProcessingException(XmartFileProcessingException.Priority.ERROR,
                    "Filename" + " contains invalid date",
                    "Date in marker file " + xmartMarkerFileWrapper.getMarkerFile().getPath()
                            + " is after current Date " + dateNow);
        }
    }

    public static void main(String[] args) throws XmartFileProcessingException {
        createMarkerForFile("C:\\Users\\vashpan\\work\\BDX\\code\\app-streaming\\target\\app-streaming-null.jar",
                "mkr");
    }
}


