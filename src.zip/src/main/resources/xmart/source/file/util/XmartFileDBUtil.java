package com.nwm.xmart.source.file.util;

import com.microsoft.sqlserver.jdbc.SQLServerConnection;
import com.nwm.xmart.database.dao.SqlServerDao;
import com.nwm.xmart.source.file.XmartFileAttributes;
import com.nwm.xmart.source.file.db.entity.FileExtractEntity;
import com.nwm.xmart.source.file.exeption.XmartFileEmailSendException;
import com.nwm.xmart.source.file.exeption.XmartFileProcessingException;
import com.nwm.xmart.streaming.database.SqlServerConnectionDetails;
import com.nwm.xmart.streaming.database.SqlServerConnector;
import com.nwm.xmart.streaming.database.exceptions.SqlServerConnectorException;
import org.apache.flink.api.java.utils.ParameterTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.sql.*;
import java.util.Date;
import java.util.concurrent.atomic.AtomicReference;

import static java.util.Objects.nonNull;

/**
 * Utility class for calling database procs from the source.
 * <p>
 * Uses
 */
public class XmartFileDBUtil implements Serializable {

    private static final Logger logger = LoggerFactory.getLogger(XmartFileDBUtil.class);

    /**
     * ALTER PROCEDURE [fwk].[usp_FileExtractStart]
     * 1      @pFileHandlerName VARCHAR(50)
     * 2    , @pFileName NVARCHAR(255)
     * 3    , @pFileLastModified DATETIME2 = NULL
     * 4    , @pFileSize BIGINT = NULL
     * 5    , @pExtractStart DATETIME2 = NULL
     * 6    , @pFileExtractID INT OUTPUT
     */
    private static final String auditRecordProc = "exec [fwk].[usp_FileExtractStart] ?, ?, ?, ?, ?, ?";
    private static final String mailOption = "SEND_MAIL_BASIC";
    private static final String emailProcSBL = "EXEC [fwk].[usp_SblProcessInvoke] ?, ?, ?, ?";
    private final SqlServerConnector sqlServerConnector;
    private final ParameterTool paramaterTool;
    private AtomicReference<SQLServerConnection> sqlConnRef = new AtomicReference<>();

    public XmartFileDBUtil(ParameterTool paramaterTool) {
        this.paramaterTool = paramaterTool;
        this.sqlServerConnector = new SqlServerConnector(new SqlServerConnectionDetails(paramaterTool));
        //        sqlConnRef.set(sqlServerConnector.getConnection(paramaterTool));
    }

    public static String createMailXML(String mailPriority, String env, String subject, String from, String to,
            String message) {
        return "<steps><step number=\"1\"><parameters> "
                + "<parameter name=\"\\Package\\Mail.Properties[Subject]\" type=\"number\"> " + mailPriority + " : "
                + env + " : " + subject + " </parameter>"
                + "<parameter name=\"\\Package\\Mail.Properties[FromLine]\" type=\"number\">" + from
                + "</parameter><parameter name=\"\\Package\\Mail.Properties[ToLine]\" type=\"number\">" + to
                + "</parameter>" + "<parameter name=\"\\Package\\Mail.Properties[MessageSource]\" type=\"string\">"
                + message + "</parameter>" + "</parameters></step></steps>";
    }

    public static void main(String[] args) {
        System.out.println(createMailXML("ERROR", "UAT", "TEST", "ServiceBrokerFramework@NoReply.com",
                "sapan.vashishth@natwestmarkets.com", "Test message"));
    }

    /**
     * Calls the audit proc in database to get the details of last processed file, or updating audit record for the current file in process
     *
     * @param handlerName      SBL handler for this file DB needs thsi from us :O
     * @param fileName         Complete file name with the path
     * @param loadStartDate    start of the load now
     * @param fileModifiedDate File Modified date i.e. actual File system file modified date.
     * @param fileSize         File size (bytes) of file being prcessed
     *
     * @return Tuple3 containing the following <ol><li>process complete time of the last file in this same category, if null then current file should not be processed</li>
     * <li>record count in the last file processed in the same cateory</li><li>audit id to be used for the records in current file.</li></ol>
     *
     * @throws SqlServerConnectorException in case of any sql errorrs
     */
    public FileExtractEntity getFileExtractFromDB(String handlerName, String fileName, Date loadStartDate,
            Date fileModifiedDate, long fileSize) throws SqlServerConnectorException {

        FileExtractEntity fileExtractEntity = new FileExtractEntity();
        if (!sqlServerConnector.checkConnection(sqlConnRef.get())) {
            sqlConnRef.set(sqlServerConnector.getConnection());
        }

        CallableStatement auditProc;
        try {
            auditProc = sqlConnRef.get().prepareCall(auditRecordProc);
            auditProc.setString(1, handlerName);
            auditProc.setString(2, fileName);
            auditProc.setTimestamp(3, new java.sql.Timestamp(fileModifiedDate.getTime()));
            auditProc.setLong(4, fileSize);
            auditProc.setTimestamp(5, new java.sql.Timestamp(loadStartDate.getTime()));

            auditProc.registerOutParameter(6, Types.INTEGER);

            auditProc.execute();
        } catch (Exception e) {
            throw new SqlServerConnectorException("Could not execute stored proc " + auditRecordProc, e);
        }

        try (ResultSet rs = auditProc.getResultSet()) {
            if (rs.next()) {
                fileExtractEntity.setPreviousFileExtractId(rs.getInt("FileExtractID"));
                fileExtractEntity.setPreviousFileName(rs.getString("FileName"));
                if (nonNull(rs.getTimestamp("ExtractStart"))) {
                    fileExtractEntity
                            .setPreviousFileExtractStartDate(new Date(rs.getTimestamp("ExtractStart").getTime()));
                }
                if (nonNull(rs.getTimestamp("ExtractEnd"))) {
                    fileExtractEntity.setPreviousFileExtractEndDate(new Date(rs.getTimestamp("ExtractEnd").getTime()));
                }

                fileExtractEntity.setPreviousFileRowCount(rs.getInt("RowCount"));
                if (nonNull(rs.getTimestamp("FileLastModified"))) {
                    fileExtractEntity
                            .setPreviousFileLastModifiedDate(new Date(rs.getTimestamp("FileLastModified").getTime()));
                }
                fileExtractEntity.setPreviousfileSize(rs.getInt("FileSizeInBytes"));
            }

            fileExtractEntity.setNewFileExtractId(auditProc.getInt(6));
            fileExtractEntity.setNewFileBusinessDate(fileModifiedDate);
        } catch (SQLException e1) {
            throw new SqlServerConnectorException("Could not get resultset from proc" + auditRecordProc, e1);
        }

        return fileExtractEntity;
    }

    /**
     * send email using SBL for the failures.
     *
     * @throws SqlServerConnectorException in case of sql errors
     */
    private void sendMailUsingSBL(String xmlPayload) {
        if (!sqlServerConnector.checkConnection(sqlConnRef.get())) {
            try {
                sqlConnRef.set(sqlServerConnector.getConnection());
            } catch (SqlServerConnectorException e) {
                logger.error("Could connect to SQL Server while preparing to send mail", e);
                throw new XmartFileEmailSendException("Could connect to SQL Server while preparing to send mail", e);
            }
        }

        try {
            PreparedStatement emailProc = sqlConnRef.get().prepareStatement(emailProcSBL);
            emailProc.setString(1, mailOption);
            emailProc.setInt(2, 0);
            emailProc.setString(3, xmlPayload);
            emailProc.setInt(4, 1);
            emailProc.execute();
        } catch (Exception e) {
            logger.error("Could not execute mail sending proc " + emailProcSBL, e);
            throw new XmartFileEmailSendException("Could not execute mail sending proc " + emailProcSBL, e);
        }
    }

    /**
     * send email using SBL for the failures.
     *
     * @throws SqlServerConnectorException in case of sql errors
     */
    public void sendMailUsingSBL(String mailPriority, XmartFileAttributes fileAttributes, String subject,
            String message) {
        sendMailUsingSBL(
                createMailXML(mailPriority, fileAttributes.getEnvironment(), subject, fileAttributes.getMailFrom(),
                        fileAttributes.getMailTo(), message));
    }

    /**
     * send email using SBL for the failures.
     *
     * @throws SqlServerConnectorException in case of sql errors
     */
    public void sendMailUsingSBL(XmartFileAttributes fileAttributes, XmartFileProcessingException e) {
        sendMailUsingSBL(e.getPriority().toString(), fileAttributes, e.getEmailSubject(), e.getMessage());
    }
}
