package com.nwm.xmart.source.file;

import com.nwm.xmart.source.file.exeption.XmartFileAttributeException;
import com.nwm.xmart.source.file.util.FileSortType;
import com.nwm.xmart.streaming.source.file.event.FileEventType;
import com.nwm.xmart.streaming.source.file.event.QuantaCheckType;
import org.apache.flink.configuration.Configuration;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.nwm.xmart.source.file.util.XmartFileUtil.directoryExists;
import static com.nwm.xmart.util.ParameterUtil.*;

/**
 * utilty class to hold the parameters related to a file for the specific source
 * source should be created with this object
 */
public class XmartFileAttributes implements Serializable {

    private final Boolean enabled;
    private final FileEventType fileEventType;
    private final String fileExtension;
    private final Configuration parameters;
    private final String dirPrefix;
    private final String filePrefix;
    // Suffix to put at the end of processed file
    private final String processedFileSuffix;
    // Date stamp format to put at end of processed file name
    // and also the format of the business date received in incoming file.
    private final String processDateFormat;
    private final String fileLocation;
    private final String doneFolder;
    private final String errorFolder;
    private final String markerFileExtension;
    // Percent deviation to raise error
    private final int deviationPercentError;
    // percent devation to raise warn
    private final int deviationPercentWarn;
    private final String separator;
    private final long pollInterval;
    //Min records requried to be present in the file e.g. one being header and may be a TAIL
    // this in not the threshold record based on percent deviation
    private final int minRecords;
    // records with this will be ignored e.g. TAIL.
    private final String lineIgnorePrefix;
    // DB handler name for this kind of file, that we shoudl tell the database :D
    private final String sblHandlerName;
    // Perform check for record count or for file size. can be one of RECORD_COUNT FILE_SIZE or NONE, both are picked from Database
    private final QuantaCheckType quantaCheckType;
    // how old file in days is to be rejected
    private final int daysOld;
    // Email related parameters
    private final String mailTo;
    private final String mailFrom;
    private final String environment;
    private final String columnNames;
    private SimpleDateFormat dateSuffixFormatter;
    private FileSortType fileSortType;

    /**
     * Creates object for getting the file source attributes from the configuration
     *
     * @param sourcePrefix the prefix that is appended to source specific configs in the properties, e.g. 'filesource1.', should include the '.'
     * @param parameters   Configuration to get from .
     */
    public XmartFileAttributes(String sourcePrefix, Configuration parameters) {
        this.parameters = parameters;
        enabled = getValidBooleanParameter(sourcePrefix + XmartFilePropertyNames.ENABLED, parameters);
        fileEventType = FileEventType
                .valueOf(getValidStringParameter(sourcePrefix + XmartFilePropertyNames.FILE_EVENT, parameters));
        dirPrefix = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.DIR_PREFIX, parameters);
        filePrefix = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.FILE_PREFIX, parameters);
        fileExtension = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.FILE_EXTENSION, parameters);
        processedFileSuffix = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.PROCESSED_FILE_SUFFIX,
                parameters);
        fileLocation = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.SHARED_FILE_LOCATION, parameters);
        doneFolder = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.DONE_FILE_LOCATION, parameters);
        errorFolder = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.ERROR_FILE_LOCATION, parameters);
        markerFileExtension = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.MARKER_FILE_EXT,
                parameters);
        deviationPercentError = getValidIntParameter(sourcePrefix + XmartFilePropertyNames.DEVIATION_PERCENT_ERROR,
                parameters);
        separator = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.SEPARATOR, parameters);
        pollInterval = getValidIntParameter(sourcePrefix + XmartFilePropertyNames.FOLDER_POLL_INTERVAL, parameters);
        minRecords = getValidIntParameter(sourcePrefix + XmartFilePropertyNames.MIN_RECORDS, parameters);
        lineIgnorePrefix = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.LINE_IGNORE_PREFIX,
                parameters);
        sblHandlerName = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.FILE_HANDLER_NAME, parameters);
        quantaCheckType = QuantaCheckType
                .valueOf(getValidStringParameter(sourcePrefix + XmartFilePropertyNames.QUANTA_CHECK_TYPE, parameters));
        deviationPercentWarn = getValidIntParameter(sourcePrefix + XmartFilePropertyNames.DEVIATION_PERCENT_WARN,
                parameters);

        processDateFormat = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.PROCESS_DATE_FORMAT,
                parameters);
        mailFrom = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.MAIL_FROM, parameters);
        mailTo = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.MAIL_TO, parameters);
        environment = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.ENVIRONMENT, parameters);
        daysOld = getValidIntParameter(sourcePrefix + XmartFilePropertyNames.DAYS_OLD, parameters);
        fileSortType = FileSortType
                .valueOf(getValidStringParameter(sourcePrefix + XmartFilePropertyNames.FILE_SORT_TYPE, parameters));
        columnNames = getValidStringParameter(sourcePrefix + XmartFilePropertyNames.COLUMN_NAMES, parameters);
        try {
            // will never block as there is one object per source object
            synchronized (this) {
                dateSuffixFormatter = new SimpleDateFormat(processDateFormat);
            }
        } catch (Exception e) {
            throw new XmartFileAttributeException(
                    "Invalid date format supplied in processDateFormat " + processDateFormat);
        }

        if (enabled && (!directoryExists(fileLocation) || !directoryExists(doneFolder) || !directoryExists(
                errorFolder))) {
            throw new XmartFileAttributeException(
                    "Folders do not exist or are not directories [" + fileLocation + "],[" + doneFolder + "],["
                            + errorFolder + "]");
        }
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public FileSortType getFileSortType() {
        return fileSortType;
    }

    public String getMailTo() {
        return mailTo;
    }

    public String getMailFrom() {
        return mailFrom;
    }

    public String getEnvironment() {
        return environment;
    }

    public int getDeviationPercentWarn() {
        return deviationPercentWarn;
    }

    public FileEventType getFileEventType() {
        return fileEventType;
    }

    public String getFileExtension() {
        return fileExtension;
    }

    public Configuration getParameters() {
        return parameters;
    }

    public String getDirPrefix() {
        return dirPrefix;
    }

    public String getFilePrefix() {
        return filePrefix;
    }

    public String getProcessedFileSuffix() {
        return processedFileSuffix;
    }

    public String getProcessDateFormat() {
        return processDateFormat;
    }

    public String getFormattedDateStr(Date date) {
        return dateSuffixFormatter.format(date);
    }

    public Date getdateFromString(String dateStr) throws ParseException {
        return dateSuffixFormatter.parse(dateStr);
    }

    public String getFileLocation() {
        return fileLocation;
    }

    public String getDoneFolder() {
        return doneFolder;
    }

    public String getErrorFolder() {
        return errorFolder;
    }

    public String getMarkerFileExtension() {
        return markerFileExtension;
    }

    public int getDeviationPercentError() {
        return deviationPercentError;
    }

    public String getSeparator() {
        return separator;
    }

    public long getPollInterval() {
        return pollInterval;
    }

    public int getMinRecords() {
        return minRecords;
    }

    public String getLineIgnorePrefix() {
        return lineIgnorePrefix;
    }

    public String getSblHandlerName() {
        return sblHandlerName;
    }

    public String getColumnNames() {
        return columnNames;
    }

    public QuantaCheckType getQuantaCheckType() {
        return quantaCheckType;
    }

    public int getDaysOld() {
        return daysOld;
    }

    public SimpleDateFormat getDateSuffixFormatter() {
        return dateSuffixFormatter;
    }

    @Override
    public String toString() {
        return "XmartFileAttributes{" + "enabled=" + enabled + ", fileEventType=" + fileEventType + ", fileExtension='"
                + fileExtension + '\'' + ", parameters=" + parameters + ", dirPrefix='" + dirPrefix + ", filePrefix='"
                + filePrefix + '\'' + ", processedFileSuffix='" + processedFileSuffix + '\'' + ", processDateFormat='"
                + processDateFormat + '\'' + ", fileLocation='" + fileLocation + '\'' + ", doneFolder='" + doneFolder
                + '\'' + ", errorFolder='" + errorFolder + '\'' + ", markerFileExtension='" + markerFileExtension + '\''
                + ", deviationPercentError=" + deviationPercentError + ", deviationPercentWarn=" + deviationPercentWarn
                + ", separator='" + separator + '\'' + ", pollInterval=" + pollInterval + ", minRecords=" + minRecords
                + ", lineIgnorePrefix='" + lineIgnorePrefix + '\'' + ", sblHandlerName='" + sblHandlerName + '\''
                + ", quantaCheckType=" + quantaCheckType + ", daysOld=" + daysOld + ", mailTo='" + mailTo + '\''
                + ", mailFrom='" + mailFrom + '\'' + ", environment='" + environment + '\'' + ", dateSuffixFormatter="
                + dateSuffixFormatter + ", fileSortType=" + fileSortType + ", columnNames=" + columnNames + '}';
    }
}



