package com.nwm.xmart.source.rdx;

import com.nwm.xmart.streaming.source.rdx.event.RDXSourceEvent;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Created by aslammh on 04/08/17.
 */
public class RdxTestSource extends RichParallelSourceFunction<RDXSourceEvent> {

    private volatile boolean isRunning = true;

    //@Override
    public void run(SourceContext<RDXSourceEvent> sourceContext) throws Exception {
        // Create the listener to get the event.
        int recordCount = 0;

        RDXSourceEvent event;

        while (isRunning && recordCount < 10000) {

            // keep processing until we get direction to stop. i.e until cancel is not called.
            Thread.sleep(1000);

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HHmmssSSS");

            LocalDateTime now = LocalDateTime.now();

            event = RdxTextEventBuilder.getRdxInstrumentStreamEvent(Integer.parseInt(now.format(formatter)),
                    Integer.toString(recordCount));

            sourceContext.collect((RDXSourceEvent) event);

            recordCount++;
        }
    }

    //@Override
    public void cancel() {
        isRunning = false;
    }
}
