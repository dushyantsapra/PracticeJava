package com.nwm.xmart.source.rdx;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.rdx.event.RDXSourceEvent;
import com.nwm.xmart.streaming.source.rdx.json.RdxFixedIncome;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.dx.webService.impl.DxValuationDate;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.time.Instant;

/**
 * Created by heskets on 13/11/2017.
 */
public class RdxTextEventBuilder {

    private static final Logger logger = LoggerFactory.getLogger(RdxTextEventBuilder.class);

    private static final ObjectMapper jsonMapper = new ObjectMapper();
    private static final File jsonFile = new File(
            RdxTextEventBuilder.class.getClassLoader().getResource("rdx/RdxEvent.json").getFile());

    private static RdxFixedIncome rdxFixedIncome = null;

    public RdxTextEventBuilder() throws XmartException {

        ObjectMapper jsonMapper = new ObjectMapper();

        ClassLoader classloader = Thread.currentThread().getContextClassLoader();

        InputStream jsonStream = classloader.getResourceAsStream("rdx/RdxEvent.json");

        try {
            rdxFixedIncome = jsonMapper.readerFor(RdxFixedIncome.class).readValue(jsonStream);
        } catch (IOException e) {
            throw new XmartException("Failed to deserialise rdxBond");
        }
    }

    public static RDXSourceEvent getRdxInstrumentStreamEvent(int changeId, String rdxId) {

        RdxFixedIncome testRdxFixedIncome = new RdxFixedIncome();

        testRdxFixedIncome.setStatus("Y");
        testRdxFixedIncome.setRdxChangeId(changeId);

        return new RDXSourceEvent(testRdxFixedIncome, changeId, rdxId, "2,", new DxValuationDate("2018-01-01"), 0, null,
                Instant.now().toEpochMilli());
    }
}
