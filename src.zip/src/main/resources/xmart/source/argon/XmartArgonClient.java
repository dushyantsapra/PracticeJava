package com.nwm.xmart.source.argon;

import com.nwm.xmart.core.BindObject;
import com.rbsfm.argon.client.cga.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.Iterator;

import static java.util.Objects.isNull;

public class XmartArgonClient implements BindObject {

    private static final Logger logger = LoggerFactory.getLogger(XmartArgonClient.class);
    private final Client client;
    private final XmartArgonAttributes xmartArgonAttributes;
    private final Receiver receiver;

    public XmartArgonClient(XmartArgonAttributes xmartArgonAttributes) throws XmartArgonException {
        logger.info("Creating xmart argon client with attributes {}", xmartArgonAttributes);
        setSystemProperties(xmartArgonAttributes);

        this.xmartArgonAttributes = xmartArgonAttributes;
        StreamList streamList = new StreamList();
        try {
            this.client = new Client();
            client.getLogSettings().setLevel(getLogLevel(xmartArgonAttributes.getArgonLogLevel()));
            streamList.addStream(xmartArgonAttributes.getMessageType(),
                    new ClientNodeAddress(xmartArgonAttributes.getArgonSource()));
            this.receiver = client.createReceiver(streamList);
        } catch (ClientException e) {
            logger.warn("Exception in initialising the client ", e);
            throw new XmartArgonException("Could not create client due to " + e.getMessage(), e);
        }

        logger.info("Created Argon client for route {}", xmartArgonAttributes.getArgonSink());
    }

    /**
     * Properties for argon
     *
     * @param xmartArgonAttributes
     */
    private void setSystemProperties(XmartArgonAttributes xmartArgonAttributes) {
        System.setProperty("argon.bootstrap.file", xmartArgonAttributes.getArgonConnectionSettings());
        System.setProperty("argon.settings", xmartArgonAttributes.getArgonSettings());
        System.setProperty("EnableFileSSL", String.valueOf(xmartArgonAttributes.getEnableFileSSL()));
    }

    public void connect() throws XmartArgonException {
        try {
            if (!client.getConnected()) {
                client.connect(new ClientNodeAddress(xmartArgonAttributes.getArgonSink()),
                        xmartArgonAttributes.getArgonPassword());
            }
            logger.info("Argon client connected.{}", xmartArgonAttributes.getArgonSink());
        } catch (ClientException e) {
            logger.warn("Exception connecting the client ", e);
            if (e.getLogNumber() == ClientException.IO_CLIENT_ALREADY_CONNECTED) {
                logger.warn("Connect called on already connected client, ignoring ");
            } else {
                //IO_CLIENT_CONNECT_ERROR and others
                logger.error(String.format("Unable to connect to argon route %s due to %s",
                        xmartArgonAttributes.getArgonSink(), e.getMessage()), e);
                throw new XmartArgonException("Could not connect argon client", e);
            }
        }
    }

    public void disconnect() {
        try {
            client.disconnect();
            logger.info("Argon client disconnected.Argon route details {}", xmartArgonAttributes.getArgonSink());
        } catch (ClientException e) {
            logger.warn("Exception in disconnecting the client ", e);
            if (e.getLogNumber() == ClientException.IO_CLIENT_NOT_CONNECTED) {
                logger.warn("Disconnect called on client that is not connected");
            } else {
                logger.warn("Could not disconnect argon client {}", xmartArgonAttributes.getArgonSink(), e);
            }
        }
    }

    public ReceivedMessage receiveMessage() throws XmartArgonException {
        // checking if the client is not connected and connect just in case
        connect();
        try {
            return receiver.receive(xmartArgonAttributes.getMessageReceiveTimeout());
        } catch (ClientException e) {
            logger.warn("Exception in receive message", e);
            throw new XmartArgonException(
                    "Message receive failed for route " + xmartArgonAttributes.getArgonSink() + " source "
                            + xmartArgonAttributes.getArgonSource(), e);
        }
    }

    public String processAndAckFileMessage(ReceivedMessage receivedMessage) throws XmartArgonException {
        //  if (isNull(receivedMessage) || !ArgonMessageType.file_xfer.toString()
        //                                                          .equals(receivedMessage.getMessageType())) {
        if (isNull(receivedMessage) || !ArgonMessageType.checkAvailability(receivedMessage.getMessageType())) {
            throw new XmartArgonException(
                    "Can only process messages of " + ArgonMessageType.file_xfer.toString() + " type");
        }
        Iterator iterator1 = receivedMessage.getAssociatedFileList().iterator();
        File file = null;
        if (iterator1.hasNext()) {
            ReceivedAssociatedFile s = (ReceivedAssociatedFile) iterator1.next();
            try {
                //check if the file exists
                file = new File(xmartArgonAttributes.getDirectory() + File.separator + s.getFileName());
                if (file.exists()) {
                    logger.warn("Duplicate file received, message id {} file name {}",
                            receivedMessage.getApplicationID(), s.getFileName());
                } else {
                    s.writeToFile(xmartArgonAttributes.getDirectory() + File.separator + s.getFileName());
                }
            } catch (ClientException e) {
                logger.warn("Exception in process message", e);
                throw new XmartArgonException("Failed to process message", e);
            }
        }
        ackMessage(receivedMessage);
        return file.getPath();
    }

    public void ackMessage(ReceivedMessage receivedMessage) throws XmartArgonException {
        // conditionally ack the message, used only for testing
        if (xmartArgonAttributes.getAckMessages()) {
            try {
                receivedMessage.acknowledge();
            } catch (ClientException e) {
                logger.warn("Exception in ack message", e);
                throw new XmartArgonException("Failed to acknowledge message " + receivedMessage, e);
            }
        }
    }

    private int getLogLevel(String logLevelStr) throws XmartArgonException {
        switch (logLevelStr) {
        case "ALL":
            return LogSettings.LEVEL_ALL;
        case "DEBUG":
            return LogSettings.LEVEL_DEBUG;
        case "INFO":
            return LogSettings.LEVEL_INFO;
        case "WARN":
            return LogSettings.LEVEL_WARN;
        case "ERROR":
            return LogSettings.LEVEL_ERROR;
        case "NONE":
            return LogSettings.LEVEL_NONE;
        default:
            throw new XmartArgonException("Argon log level " + logLevelStr + " not recognised");
        }
    }
}



