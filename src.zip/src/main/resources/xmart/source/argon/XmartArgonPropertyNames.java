package com.nwm.xmart.source.argon;

import java.io.Serializable;

/**
 * Property names for file processing jobs
 * <p>
 * mostly because of avoiding typos while using the property names in thousand places.
 *
 * @author vashpan
 */
public interface XmartArgonPropertyNames extends Serializable {

    /**
     * source id
     */
    String ID = "id";
    /**
     * source name
     */
    String NAME = "name";
    /**
     * Enabled/ Disable
     */
    String ENABLED = "enabled";
    /**
     * source parallelism
     */
    String PARALLELISM = "parallelism";
    /**
     * File location to copy the file to
     */
    String DIRECTORY = "directory";
    /**
     * Marker file extension
     */
    String MARKER_EXT = "marker.extension";
    /**
     * Whether or not to ack the messages, useful for testing
     */
    String ACK_MSG = "ack.message";

    /**
     * argon sink
     */
    String RT_SINK = "sink";

    /**
     * argon source for creating receiver
     */
    String RT_SOURCE = "source";

    /**
     * password to connect argon client
     */
    String RT_PASSWORD = "password";
    /**
     * Argon setting file
     */
    String ARGON_SETTINGS = "argon.settings";
    /**
     * Argon connetion settings file.
     */
    String ARGON_CONN_SETTINGS = "argon.connection.settings";
    /**
     * Message type for this source. one of file_xfer etc
     */
    String MSG_TYPE = "message.type";
    /**
     * Message timeout
     */
    String MSG_TIMEOUT = "message.timeout";
    /**
     * log level for argon client
     */
    String LOG_LEVEL = "argon.log.level";
    /**
     * sleep time for waiting when new messages are not received
     */
    String SLEEP_TIME = "sleep.time";
    /**
     * Argon has issue with security in Java 8 so this is to be set to false, can be set to true when issue fixed
     * see http://sharepoint.fm.rbsgrp.net/teams/APSite/Lists/Argon%20FAQ/DispForm.aspx?ID=260
     */
    String FILE_SSL = "enable.file.ssl";

    String FILE_EXT = "ignorefile.extension";

    String SOURCE_ID = "sourceId";
}
