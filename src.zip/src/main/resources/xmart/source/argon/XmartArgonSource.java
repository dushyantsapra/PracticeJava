package com.nwm.xmart.source.argon;

import com.nwm.xmart.source.file.XmartFileAttributes;
import com.nwm.xmart.source.file.exeption.XmartFileProcessingException;
import com.rbsfm.argon.client.cga.ReceivedMessage;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.nwm.xmart.source.file.util.XmartFileUtil.createMarkerForFile;
import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;
import static java.util.Objects.isNull;

/**
 * Flink source for processing files. Use {@link XmartFileAttributes} for creating instance of this class
 *
 * @author vashpan
 */
public class XmartArgonSource extends RichParallelSourceFunction<XmartArgonEvent> implements Serializable {

    private static final Logger logger = LoggerFactory.getLogger(XmartArgonSource.class);
    XmartArgonClient xmartArgonClient;
    private XmartArgonAttributes argonAttributes;
    private AtomicBoolean isCancelled = new AtomicBoolean(false);

    /**
     * Craete a file source instance with the supplied {@link XmartFileAttributes} object
     */
    public XmartArgonSource(XmartArgonAttributes argonAttributes) {
        this.argonAttributes = argonAttributes;
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        xmartArgonClient = new XmartArgonClient(argonAttributes);
        logger.info("Opening argon client connection with parameters {} ", argonAttributes);
        xmartArgonClient.connect();
        logger.info("Argon Client opened successful");
    }

    @Override
    public void run(SourceContext<XmartArgonEvent> ctx) throws Exception {
        putJobNameInMDC(argonAttributes.getParameters());
        logger.info("Starting source preparing to receive messages");

        try {
            while (!isCancelled.get()) {
                ReceivedMessage receivedMessage = xmartArgonClient.receiveMessage();
                if (isNull(receivedMessage)) {
                    logger.info("No new message received on route source {} sink {}", argonAttributes.getArgonSource(),
                            argonAttributes.getArgonSink());
                    logger.info("Sleeping for checkig later");
                    sleep();
                    continue;
                }
                logger.info("Message received {} ", receivedMessage);
                XmartArgonEvent xmartArgonEvent = new XmartArgonEvent(receivedMessage);

                // if ("file_xfer".equals(argonAttributes.getMessageType())) {
                if (ArgonMessageType.checkAvailability(argonAttributes.getMessageType())) {
                    if (receivedMessage.getXMLText().contains(argonAttributes.getIgnorefileExtension())
                            && ArgonMessageType.checkSDMAvailability(argonAttributes.getSourceId())) {
                        xmartArgonClient.ackMessage(receivedMessage);
                        continue;
                    }

                    String fileCreated = xmartArgonClient.processAndAckFileMessage(receivedMessage);
                    logger.info("File received {}, creating marker file", fileCreated);
                    try {
                        createMarkerForFile(fileCreated, argonAttributes.getMarkerFileExtension());
                    } catch (XmartFileProcessingException e) {
                        logger.error("Error occured while creating marker file", e);
                        if (e.getPriority() == XmartFileProcessingException.Priority.ERROR) {
                            throw e;
                        }
                    }
                } else {
                    // lets collect message just for the sake of it
                    ctx.collect(xmartArgonEvent);
                    throw new IllegalArgumentException("Not implemented");
                }
            }
        } finally {
            logger.info("Disconnecting argon client");
            xmartArgonClient.disconnect();
        }
        logger.info("Cancel job received, stopping source, cleaning up file handles");
    }

    private void sleep() {
        try {
            logger.info("Waiting for {} before polling again", argonAttributes.getSleepTime());
            TimeUnit.SECONDS.sleep(argonAttributes.getSleepTime());
        } catch (InterruptedException e) {
            logger.warn("Interrupted sleep ");
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public void cancel() {
        putJobNameInMDC(argonAttributes.getParameters());
        logger.info("Cancelled received for job");
        isCancelled.set(true);
    }
}
