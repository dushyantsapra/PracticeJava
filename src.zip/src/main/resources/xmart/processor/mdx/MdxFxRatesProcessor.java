package com.nwm.xmart.processor.mdx;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.keyselectors.XmartSetKeySelector;
import com.nwm.xmart.processor.XmartProcessor;
import com.nwm.xmart.sink.XmartSink;
import com.nwm.xmart.streaming.source.mdx.MdxDailySource;
import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

public class MdxFxRatesProcessor implements XmartProcessor {
    private static final Logger logger = LoggerFactory.getLogger(MdxFxRatesProcessor.class);
    private static final long serialVersionUID = 2788820519193417235L;

    private RichParallelSourceFunction sourceFunction;

    @Inject
    @Named("BdxSink")
    private XmartSink sink;

    @Inject
    @Named("XmartSourceEventMapper")
    private RichMapFunction<MdxDocumentEvent, XmartGenericSet> mdxMapper;

    @Inject
    @Named("XmartWindowMapper")
    private ProcessFunction<XmartGenericSet, List<XmartGenericSet>> windowMapper;

    @Inject
    @Named("XmartXmlMapper")
    private RichMapFunction<List<XmartGenericSet>, XmartGenericXmlSet> xmlMapper;

    public MdxFxRatesProcessor() {
        // No initiation required
    }

    /**
     * Defines the procesing steps to complete and executes
     *
     * @param env    the Flink procesing stream that is to be initiated
     * @param config the flink Configuration used to control the processing
     *
     * @throws RuntimeException for hard Flink process failures not handled
     */
    @Override
    public void configureAndExecuteStream(StreamExecutionEnvironment env, Configuration config) throws XmartException {

        putJobNameInMDC(config);
        logger.debug("Entering configureAndExecuteStream MDX");

        /* ******************************************************************************
         * STEP 1 - Set up Mdx Consumer source
         ****************************************************************************** */

        final TypeInformation<MdxDocumentEvent> mdxSourceEventType = TypeInformation
                .of(new TypeHint<MdxDocumentEvent>() {
                });
        Class<MdxDocumentEvent> mdxSourceClassRef = mdxSourceEventType.getTypeClass();

        DataStream<MdxDocumentEvent> stream = configureSrc(env, config, mdxSourceClassRef, mdxSourceEventType);

        /* ******************************************************************************
         * STEP 2 - This will map the MDX Event to the flattened structures
         *          required by BDX
         ****************************************************************************** */
        DataStream<XmartGenericSet> xmartMdxStream = stream.map(mdxMapper).returns(XmartGenericSet.class)
                                                           .uid(config.getString("operator.mapper.name", null))
                                                           .name(config.getString("operator.mapper.name", null))
                                                           .setParallelism(
                                                                   config.getInteger("operator.mapper.parallelism", 1));

        /* ******************************************************************************
         * STEP 3 - Aggregate using a count and time based window
         ****************************************************************************** */
        // Configuration of the keyed aggregation function in the stream
        DataStream<List<XmartGenericSet>> xmartBatchedMdxStream = xmartMdxStream.keyBy(new XmartSetKeySelector())
                                                                                .process(windowMapper).uid(config
                        .getString("operator.aggregate.window.name", null)).name(config
                        .getString("operator.aggregate.window.name", null)).setParallelism(
                        config.getInteger("operator.aggregate.window.parallelism", 1));

        /* ******************************************************************************
         * STEP 4 - convert the mapped POJO into a set of XML parameters to pass to the
         *          database in the sink
         ****************************************************************************** */
        // Configuration of the XML mapper function in the stream
        String xmlConvOperator = config.getString("operator.convertor.xml.name", null);
        Integer xmlConvParallelism = config.getInteger("operator.convertor.xml.parallelism", 1);
        DataStream<XmartGenericXmlSet> xmartXmlStream = xmartBatchedMdxStream.map(xmlMapper).uid(xmlConvOperator)
                                                                             .name(xmlConvOperator)
                                                                             .setParallelism(xmlConvParallelism);

        /* ******************************************************************************
         * STEP 5 - Add the output sink
         ****************************************************************************** */
        String sinkName = config.getString("operator.sink.name", null);
        Integer sinkParallelism = config.getInteger("operator.sink.parallelism", 1);
        xmartXmlStream.addSink(sink).uid(sinkName).name(sinkName).setParallelism(sinkParallelism);

        /* ******************************************************************************
         * STEP 6 - Execute the processing pipeline defined above
         ****************************************************************************** */
        try {
            logger.info("EXECUTION PLAN = " + env.getExecutionPlan());
            env.execute(config.getString("flink.job.name", null));
        } catch (Exception e) {
            logger.error("Exception running the " + config.getString("flink.job.name", null) + " job", e);
            throw new RuntimeException("Exception running the " + config.getString("flink.job.name", null) + " job", e);
        }
    }

    private DataStream<MdxDocumentEvent> configureSrc(StreamExecutionEnvironment env, Configuration configuration,
            Class<MdxDocumentEvent> mdxSourceClassRef, TypeInformation<MdxDocumentEvent> mdxSourceEventType) {

        String sourceName = configuration.getString("mdx.src.sourceName", null);
        int sourceId = 1;

        SourceFunction<MdxDocumentEvent> src = new MdxDailySource(sourceId,
                configuration.getString("mdx.src.dirLoad.request", null),
                configuration.getString("mdx.src.bdx.payload.handler", null));

        DataStream<MdxDocumentEvent> dateStream = env.addSource(src, mdxSourceEventType).uid(Integer.toString(sourceId))
                                                     .name(sourceName).setParallelism(
                        configuration.getInteger("operator.source.parallelism", 1));
        return dateStream;
    }
}
