package com.nwm.xmart.processor;

public enum JobType {
    BDX_KDB_LOAD("BDX_KDB_LOAD"), BDX_TRANSACTION_LOAD("BDX_TRANSACTION_LOAD"),
    BDX_CASHFLOWS_LOAD("BDX_CASHFLOWS_LOAD"), BDX_MDX_INSTRUMENT_LOAD("BDX_MDX_INSTRUMENT_LOAD"),
    BDX_MDX_FX_RATES_LOAD("BDX_MDX_FX_RATES_LOAD"), BDX_RDX_INSTRUMENT_LOAD("BDX_RDX_INSTRUMENT_LOAD"),
    BDX_SCHEDULE_ENTRIES_LOAD("BDX_SCHEDULE_ENTRIES_LOAD"), BDX_CRM_LOAD("BDX_CRM_LOAD"),
    BDX_FILE_LOAD("BDX_FILE_LOAD"), BDX_ARGON("BDX_ARGON"),
    BDX_CASH_FLOWS_STATUS_LOAD("BDX_CASH_FLOWS_STATUS_LOAD"),BDX_SDS_LOAD("BDX_SDS_LOAD");

    private String name;

    private JobType(String name) {
        this.name = name;
    }

    public static JobType getFrom(String name) {
        try {
            return valueOf(name);
        } catch (IllegalArgumentException e) {
            //throw new XmartException("Unsupported ProcessorType : " + name);
            return null;
        }
    }

}
