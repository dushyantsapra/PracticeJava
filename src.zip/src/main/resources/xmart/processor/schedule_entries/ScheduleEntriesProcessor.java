package com.nwm.xmart.processor.schedule_entries;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.nwm.xmart.bean.schedule_entries.domain.XmartODCScheduleEntries;
import com.nwm.xmart.entities.XmartTransactionSet;
import com.nwm.xmart.keyselectors.ODCKeySelector;
import com.nwm.xmart.mapper.XmartAggregateProcessFunction;
import com.nwm.xmart.mapper.XmartXmlMapper;
import com.nwm.xmart.mapper.schedule_entries.XmartScheduleEntriesOdcMapper;
import com.nwm.xmart.processor.XmartProcessor;
import com.nwm.xmart.sink.XmartSink;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.nwm.xmart.streaming.source.df.DataFabricFlinkKafkaSource;
import com.nwm.xmart.streaming.source.df.KafkaProperties;
import com.nwm.xmart.streaming.source.df.serialisation.FlinkDeserializer;
import com.nwm.xmart.streaming.monitor.GeneosPersistenceFile;
import com.nwm.xmart.streaming.monitor.InactiveKafkaMonitor;
import com.nwm.xmart.streaming.monitor.InactivityMonitor;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.apache.flink.streaming.util.serialization.KeyedDeserializationSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

//TODO This processor can be re-used for similar topologies.
public class ScheduleEntriesProcessor implements XmartProcessor {

    private static final Logger logger = LoggerFactory.getLogger(ScheduleEntriesProcessor.class);
    private static final long serialVersionUID = -469318148152677531L;

    private RichParallelSourceFunction sourceFunction;

    @Inject
    @Named("BdxSink")
    private XmartSink sink;

    @Inject
    @Named("XmartScheduleEntriesOdcMapper")
    private XmartScheduleEntriesOdcMapper xmartScheduleEntriesOdcMapper;

    @Inject
    @Named("XmartWindowMapper")
    private XmartAggregateProcessFunction windowMapper;

    @Inject
    @Named("XmartOdcXmlMapper")
    private XmartXmlMapper xmlMapper;

    public ScheduleEntriesProcessor() {
        // No initiation required
    }

    /**
     * Defines the procesing steps to complete and executes
     *
     * @param env    the Flink procesing stream that is to be initiated
     * @param config the flink Configuration used to control the processing
     *
     * @throws RuntimeException for hard Flink process failures not handled
     */
    public void configureAndExecuteStream(StreamExecutionEnvironment env, Configuration config)
            throws RuntimeException {

        putJobNameInMDC(config);
        logger.debug("Entering configureAndExecuteStream.");

        /* ******************************************************************************
         * STEP 1 - Set up Kafka Consumer source
         ****************************************************************************** */

        DataFabricUtil dataFabricUtil = new DataFabricUtil(config);

        // Type info reqd for the FlinkDeserializer
        final TypeInformation<DataFabricStreamEvent<XmartODCScheduleEntries>> info = TypeInformation
                .of(new TypeHint<DataFabricStreamEvent<XmartODCScheduleEntries>>() {
                });

        // Get the deserializer  source function
        KeyedDeserializationSchema<DataFabricStreamEvent<XmartODCScheduleEntries>> deserialiser = getDeserializer(
                config, dataFabricUtil, info);

        sourceFunction = new DataFabricFlinkKafkaSource<DataFabricStreamEvent<XmartODCScheduleEntries>>(dataFabricUtil,
                config, new KafkaProperties(config), deserialiser);

        // Configuration of the source function in the stream
        String sourceName = config.getString("operator.source.name", null);
        Integer srcParallelism = config.getInteger("operator.source.parallelism", 1);

        DataStream<DataFabricStreamEvent<XmartODCScheduleEntries>> odcValueStream = env.addSource(sourceFunction, info)
                                                                                       .uid(sourceName).name(sourceName)
                                                                                       .setParallelism(srcParallelism);

        /* ******************************************************************************
         * STEP 2 - This will map the ODC Transaction to the flattened structures
         *          required by BDX
         ****************************************************************************** */

        // Configuration of the mapper function in the stream
        DataStream<XmartTransactionSet> xmartStream = odcValueStream.map(xmartScheduleEntriesOdcMapper)
                                                                    .returns(XmartTransactionSet.class)
                                                                    .uid(config.getString("operator.mapper.name", null))
                                                                    .name(config
                                                                            .getString("operator.mapper.name", null))
                                                                    .setParallelism(config.getInteger(
                                                                            "operator.mapper.parallelism", 1));

        /* ******************************************************************************
         * STEP 3 - Aggregate using a count and time based window
         ****************************************************************************** */

        // Configuration of the keyed aggregation function in the stream
        DataStream<List<XmartTransactionSet>> xmartBatchedStream = xmartStream.keyBy(new ODCKeySelector())
                                                                              .process(windowMapper).uid(config
                        .getString("operator.aggregate.window.name", null)).name(config
                        .getString("operator.aggregate.window.name", null)).setParallelism(
                        config.getInteger("operator.aggregate.window.parallelism", 1));

        /* ******************************************************************************
         * STEP 4 - convert the mapped POJO into a set of XML parameters to pass to the
         *          database in the sink
         ****************************************************************************** */

        // Configuration of the XML mapper function in the stream
        DataStream<XmartTransactionSet> xmartXmlStream = xmartBatchedStream.map(xmlMapper).uid(config
                .getString("operator.convertor.xml.name", null)).name(config
                .getString("operator.convertor.xml.name", null)).setParallelism(
                config.getInteger("operator.convertor.xml.parallelism", 1));

        /* ******************************************************************************
         * STEP 5 - Add the output sink
         ****************************************************************************** */

        xmartXmlStream.addSink(sink).uid(config.getString("operator.sink.name", null))
                      .name(config.getString("operator.sink.name", null))
                      .setParallelism(config.getInteger("operator.sink.parallelism", 1));

        /* ******************************************************************************
         * STEP 6 - Execute the processing pipeline defined above
         ****************************************************************************** */
        try {

            logger.info("EXECUTION PLAN = " + env.getExecutionPlan());
            env.execute(config.getString("flink.job.name", null));
        } catch (Exception e) {

            logger.error("Exception running the " + config.getString("flink.job.name", null) + " job", e);
            throw new RuntimeException("Exception running the " + config.getString("flink.job.name", null) + " job", e);
        }
    }

    /**
     * initialises a Deserialisation object to use against the Fafka consumer
     *
     * @param configuration  the flink Configuration used to control the processing
     * @param dataFabricUtil utilities for DF Source Connection and Error Handling
     * @param info           identifies the type of object to be deserialised
     *
     * @return KeyedDeserializationSchema    the deserialiser class that is used by the Kafka consumer to convert the stored DF recrds to ODCValue objects
     */
    private KeyedDeserializationSchema<DataFabricStreamEvent<XmartODCScheduleEntries>> getDeserializer(
            Configuration configuration, DataFabricUtil dataFabricUtil,
            TypeInformation<DataFabricStreamEvent<XmartODCScheduleEntries>> info) {

        InactivityMonitor inactivityMonitor = new InactiveKafkaMonitor(configuration,
                new GeneosPersistenceFile(configuration));

        Class<DataFabricStreamEvent<XmartODCScheduleEntries>> sourceRef = info.getTypeClass();

        // get the deserializer itself
        return new FlinkDeserializer<DataFabricStreamEvent<XmartODCScheduleEntries>, XmartODCScheduleEntries, XmartODCScheduleEntries>(
                dataFabricUtil, sourceRef, XmartODCScheduleEntries.class, inactivityMonitor, configuration);
    }
}
