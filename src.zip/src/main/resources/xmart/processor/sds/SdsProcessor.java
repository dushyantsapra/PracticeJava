package com.nwm.xmart.processor.sds;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.keyselectors.XmartSetKeySelector;
import com.nwm.xmart.processor.XmartProcessor;
import com.nwm.xmart.sink.XmartSink;
import com.nwm.xmart.streaming.source.df.DFWatchSource;
import com.nwm.xmart.streaming.source.df.DFWatchSourceConnectionDetails;
import com.nwm.xmart.streaming.source.df.event.DataFabricWatchEvent;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

public class SdsProcessor implements XmartProcessor {

        private static final Logger logger = LoggerFactory.getLogger(com.nwm.xmart.processor.sds.SdsProcessor.class);
        private static final long serialVersionUID = -469318148152677531L;

        @Inject
        @Named("BdxSink")
        private XmartSink sink;

        @Inject
        @Named("XmartSdsMapper")
        private RichMapFunction<DataFabricWatchEvent, XmartGenericSet> sdsMapper;

        @Inject
        @Named("XmartWindowMapper")
        private ProcessFunction<XmartGenericSet, List<XmartGenericSet>> windowMapper;

        @Inject
        @Named("XmartXmlMapper")
        private RichMapFunction<List<XmartGenericSet>, XmartGenericXmlSet> xmlMapper;

        public SdsProcessor() {
            // No initiation required
        }

        /**
         * Defines the procesing steps to complete and executes
         *
         * @param env    the Flink procesing stream that is to be initiated
         * @param config the flink Configuration used to control the processing
         *
         * @throws RuntimeException for hard Flink process failures not handled
         */
        public void configureAndExecuteStream(StreamExecutionEnvironment env, Configuration config)
                throws RuntimeException {

            putJobNameInMDC(config);
            logger.debug("Entering configureAndExecuteStream.");

            /* ******************************************************************************
             * STEP 1 - Set up DF Consumer source
             ****************************************************************************** */

            DataFabricUtil dataFabricUtil = new DataFabricUtil(config);

            final TypeInformation<DataFabricWatchEvent> info = TypeInformation.of(new TypeHint<DataFabricWatchEvent>() {});

            DFWatchSourceConnectionDetails legalAgreementConnectionDetails = new DFWatchSourceConnectionDetails("df.sds.legal.agreements", config);
            RichParallelSourceFunction sourceFunction = new DFWatchSource(legalAgreementConnectionDetails, dataFabricUtil);

            SingleOutputStreamOperator sdsValueStream = env.addSource(sourceFunction, info)
                    .uid(config.getString("df.sds.legal.agreements.source.id", null))
                    .name(config.getString("df.sds.legal.agreements.source.name", null))
                    .setParallelism(1);

            /* ******************************************************************************
             * STEP 2 - This will map the sds data to the flattened structures
             *          required by BDX
             ****************************************************************************** */

            // Configuration of the mapper function in the stream
            SingleOutputStreamOperator xmartSdsStream = sdsValueStream.map(sdsMapper)
                                                                      .uid(config.getString("operator.mapper.name", null))
                                                                      .name(config.getString("operator.mapper.name", null))
                                                                      .setParallelism(config.getInteger("operator.mapper.parallelism", 1))
                                                                      .returns(XmartGenericSet.class);

            /* ******************************************************************************
             * STEP 3 - Aggregate using a count and time based window
             ****************************************************************************** */

            // Configuration of the keyed aggregation function in the stream
            SingleOutputStreamOperator xmartBatchedSdsStream = xmartSdsStream
                    .keyBy(new XmartSetKeySelector()).process(windowMapper)
                    .uid(config.getString("operator.aggregate.window.name", null))
                    .name(config.getString("operator.aggregate.window.name", null))
                    .setParallelism(config.getInteger("operator.aggregate.window.parallelism", 1));

            /* ******************************************************************************
             * STEP 4 - convert the mapped POJO into a set of XML parameters to pass to the
             *          database in the sink
             ****************************************************************************** */

            // Configuration of the XML mapper function in the stream
            String xmlConvOperator = config.getString("operator.convertor.xml.name", null);
            Integer xmlConvParallelism = config.getInteger("operator.convertor.xml.parallelism", 1);
            SingleOutputStreamOperator xmartXmlStream = xmartBatchedSdsStream.map(xmlMapper).uid(xmlConvOperator)
                    .name(xmlConvOperator)
                    .setParallelism(xmlConvParallelism);

            /* ******************************************************************************
             * STEP 5 - Add the output sink
             ****************************************************************************** */
            String sinkName = config.getString("operator.sink.name", null);
            Integer sinkParallelism = config.getInteger("operator.sink.parallelism", 1);
            xmartXmlStream.addSink(sink).uid(sinkName).name(sinkName).setParallelism(sinkParallelism);

            /* ******************************************************************************
             * STEP 6 - Execute the processing pipeline defined above
             ****************************************************************************** */
            try {

                logger.info("EXECUTION PLAN = " + env.getExecutionPlan());
                env.execute(config.getString("flink.job.name", null));
            } catch (Exception e) {

                logger.error("Exception running the " + config.getString("flink.job.name", null) + " job", e);
                throw new RuntimeException("Exception running the " + config.getString("flink.job.name", null) + " job", e);
            }
        }

    }
