package com.nwm.xmart.processor;

import com.nwm.xmart.processor.crm.CRMProcessor;
import com.nwm.xmart.processor.kdb.KdbProcessor;
import com.nwm.xmart.bean.BeanProvider;
import com.nwm.xmart.core.BindObject;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.processor.argon.XmartArgonProcessor;
import com.nwm.xmart.processor.cashflows.CashFlowsProcessor;
import com.nwm.xmart.processor.file.XmartFileProcessor;
import com.nwm.xmart.processor.mdx.MdxFxRatesProcessor;
import com.nwm.xmart.processor.mdx.MdxInstrumentProcessor;
import com.nwm.xmart.processor.rdx.RdxInstrumentProcessor;
import com.nwm.xmart.processor.schedule_entries.ScheduleEntriesProcessor;
import com.nwm.xmart.processor.sds.SdsProcessor;
import com.nwm.xmart.processor.tdx.TdxProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProcessorProvider implements BindObject {

    private static final Logger logger = LoggerFactory.getLogger(ProcessorProvider.class);
    private static final long serialVersionUID = -5331291094907345468L;

    private ProcessorProvider() {
        // do not allow to create an instance
    }

    /**
     * Returns the {@link XmartProcessor} implementation instance based on the class provided
     *
     * @param beanProvider     Custom {@link BeanProvider} implementation for providing scenario specific Guice injection mappings
     * @param processClass     {@link XmartProcessor} implementation whose instance is required with the dependencies injected as per beanProvider
     * @param processorTypeStr Type of processor required, Value is deduced from {@link ProcessorType} enum.
     *
     * @return {@link XmartProcessor} implementation instance based on the class provided
     *
     * @throws XmartException if anything or everything goes wrong
     * @deprecated Callers should not need to provide the processClass param for getting the instance.
     * <br> Recommended method is to use {@link ProcessorProvider#getProcessor(BeanProvider, String)}
     */
    @Deprecated
    public static XmartProcessor getProcessor(BeanProvider beanProvider, Class processClass, String processorTypeStr)
            throws XmartException {

        ProcessorType type = ProcessorType.getFrom(processorTypeStr);

        switch (type) {
        case BDX_ODC_TRANSACTION_LOAD:
        case BDX_TDX_TRANSACTION_LOAD:
            return beanProvider.getBean(processClass, JobType.BDX_TRANSACTION_LOAD);
        case BDX_CASHFLOWS_LOAD:
            return beanProvider.getBean(processClass, JobType.BDX_CASHFLOWS_LOAD);
        case BDX_MDX_INSTRUMENT_LOAD:
            return beanProvider.getBean(MdxInstrumentProcessor.class, JobType.BDX_MDX_INSTRUMENT_LOAD);
        case BDX_MDX_FX_RATES_LOAD:
            return beanProvider.getBean(MdxFxRatesProcessor.class, JobType.BDX_MDX_FX_RATES_LOAD);
        case BDX_RDX_INSTRUMENT_LOAD:
            return beanProvider.getBean(processClass, JobType.BDX_RDX_INSTRUMENT_LOAD);
        case BDX_KDB_LOAD:
            return beanProvider.getBean(processClass, JobType.BDX_KDB_LOAD);
        case BDX_CRM_LOAD:
            return beanProvider.getBean(processClass, JobType.BDX_CRM_LOAD);
        default:
            logger.error("Processor not configured of type : " + processorTypeStr);
            throw new XmartException("Processor not configured of type : " + processorTypeStr);
        }
    }

    /**
     * Returns the {@link XmartProcessor} implementation instance based on the class provided
     *
     * @param beanProvider     Custom {@link BeanProvider} implementation for providing scenario specific Guice injection mappings
     * @param processorTypeStr Type of processor required, Value is deduced from {@link ProcessorType} enum.
     *
     * @return {@link XmartProcessor} implementation instance based on the processorTypeStr provided.
     *
     * @throws XmartException if anything or everything goes wrong
     */
    public static XmartProcessor getProcessor(BeanProvider beanProvider, String processorTypeStr)
            throws XmartException {

        ProcessorType type = ProcessorType.getFrom(processorTypeStr);

        switch (type) {
        case BDX_KDB_LOAD:
            return beanProvider.getBean(KdbProcessor.class, JobType.BDX_KDB_LOAD);
        case BDX_RDX_INSTRUMENT_LOAD:
            return beanProvider.getBean(RdxInstrumentProcessor.class, JobType.BDX_RDX_INSTRUMENT_LOAD);
        case BDX_ODC_TRANSACTION_LOAD:
            return beanProvider.getBean(OdcTransactionProcessor.class, JobType.BDX_TRANSACTION_LOAD);
        case BDX_TDX_TRANSACTION_LOAD:
            return beanProvider.getBean(OdcTransactionProcessor.class, JobType.BDX_TRANSACTION_LOAD);
        case BDX_CASHFLOWS_LOAD:
            return beanProvider.getBean(CashFlowsProcessor.class, JobType.BDX_CASHFLOWS_LOAD);
        case BDX_MDX_INSTRUMENT_LOAD:
            return beanProvider.getBean(MdxInstrumentProcessor.class, JobType.BDX_MDX_INSTRUMENT_LOAD);
        case BDX_MDX_FX_RATES_LOAD:
            return beanProvider.getBean(MdxFxRatesProcessor.class, JobType.BDX_MDX_FX_RATES_LOAD);
        case BDX_SCHEDULE_ENTRIES_LOAD:
            return beanProvider.getBean(ScheduleEntriesProcessor.class, JobType.BDX_SCHEDULE_ENTRIES_LOAD);
        case BDX_CRM_LOAD:
            return beanProvider.getBean(CRMProcessor.class, JobType.BDX_CRM_LOAD);
        case BDX_FILE_LOAD:
            return beanProvider.getBean(XmartFileProcessor.class, JobType.BDX_FILE_LOAD);
        case BDX_ARGON:
            return beanProvider.getBean(XmartArgonProcessor.class, JobType.BDX_ARGON);
        case BDX_CASH_FLOWS_STATUS_LOAD:
            return beanProvider.getBean(TdxProcessor.class, JobType.BDX_CASH_FLOWS_STATUS_LOAD);
        case BDX_SDS_LOAD:
            return beanProvider.getBean(SdsProcessor.class, JobType.BDX_SDS_LOAD);
        default:
            logger.error("Processor not configured of type : " + processorTypeStr);
            throw new XmartException("Processor not configured of type : " + processorTypeStr);
        }
    }
}
