package com.nwm.xmart.keyselectors;

import com.nwm.xmart.entities.cashflows.XmartCashFlowsSet;
import org.apache.flink.api.java.functions.KeySelector;

public class ScheduleEntryKeySelector implements KeySelector<XmartCashFlowsSet, Long> {

    private static final long serialVersionUID = 8382054815107621959L;

    public ScheduleEntryKeySelector() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    public Long getKey(XmartCashFlowsSet value) throws Exception {
        if (value == null) {
            return 0L;
        }
        return value.getWindowKey();
    }
}
