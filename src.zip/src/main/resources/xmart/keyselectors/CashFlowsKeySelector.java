package com.nwm.xmart.keyselectors;

import com.nwm.xmart.entities.cashflows.XmartCashflowSet;
import com.nwm.xmart.entities.common.XmartGenericSet;
import org.apache.flink.api.java.functions.KeySelector;

public class CashFlowsKeySelector implements KeySelector<XmartGenericSet, Long> {

    private static final long serialVersionUID = 8382054815107621959L;

    public CashFlowsKeySelector() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    public Long getKey(XmartGenericSet value) {
        if (value == null) {
            return 0L;
        }
        return value.getWindowKey();
    }
}
