package com.nwm.xmart.streaming.source.file.event;

import java.io.Serializable;

/**
 * File event type decides the source from where the file is received
 * this value comes from the configuration..
 */
public enum FileEventType implements Serializable {
    NULL(0, "NULL"), SMART_SALESDAY(1, "SMART_SALESDAY"), XMART_REVENUE_SHARE(2, "XMART_REVENUE_SHARE"),
    XMART_CRM_PEER_2_PEER(3, "XMART_CRM_PEER_2_PEER"), XMART_SDM_PRODUCT(4, "XMART_SDM_PRODUCT"),
    XMART_SDM_GLPRODUCT(5, "XMART_SDM_GLPRODUCT"), XMART_SDM_LEDGERBOOK(6, "XMART_SDM_LEDGERBOOK"),
    XMART_SDM_GLBOOKSET(7, "XMART_SDM_GLBOOKSET"), XMART_COALITION(8, "XMART_COALITION"),
    XMART_COALITION_MAPPING(9, "XMART_COALITION_MAPPING"), XMART_RGL_ORGUNIT_MAPPING(10, "XMART_RGL_ORGUNIT_MAPPING"),
    XMART_RGL_ORGUNIT_HIERARCHY(11, "XMART_RGL_ORGUNIT_HIERARCHY"),
    XMART_FENERGO_LASTAPPROVED_KYC_REVIEW(12, "XMART_FENERGO_LASTAPPROVED_KYC_REVIEW"),
    XMART_FENERGO_INFLIGHT_KYC_REVIEW(13, "XMART_FENERGO_INFLIGHT_KYC_REVIEW"),
    XMART_FENERGO_PRODUCT_SETTLEMENT(14, "XMART_FENERGO_PRODUCT_SETTLEMENT"),
    XMART_FENERGO_REVIEW_ACTIVITY_AUDIT(15, "XMART_FENERGO_REVIEW_ACTIVITY_AUDIT"),
    XMART_CNC_ANNUAL_REPORT(16, "XMART_CNC_ANNUAL_REPORT");

    private int sourceId;
    private String typeStr;

    FileEventType(int id, String typeStr) {
        sourceId = id;
        this.typeStr = typeStr;
    }

    public static boolean checkMessageType(FileEventType fileEventType) {
        switch (fileEventType) {
            case XMART_SDM_PRODUCT:
                return true;
            case XMART_SDM_GLPRODUCT:
                return true;
            case XMART_SDM_LEDGERBOOK:
                return true;
            case XMART_SDM_GLBOOKSET:
                return true;
            case XMART_RGL_ORGUNIT_MAPPING:
                return true;
            case XMART_RGL_ORGUNIT_HIERARCHY:
                return true;
            default:
                return false;
        }
    }

    public int getId() {
        return this.sourceId;
    }

    @Override
    public String toString() {
        return this.typeStr;
    }
}
