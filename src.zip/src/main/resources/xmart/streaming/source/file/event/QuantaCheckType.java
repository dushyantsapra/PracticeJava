package com.nwm.xmart.streaming.source.file.event;

/**
 * constants to be used against the file check for count of records or for size of file.
 * more can be added as needed
 */
public enum QuantaCheckType {
    /**
     * check number of records in file
     */
    RECORD_COUNT, /**
     * check file size
     */
    FILE_SIZE, /**
     * do not check
     */
    NONE;
}
