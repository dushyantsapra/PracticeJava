package com.nwm.xmart.util;

import com.nwm.xmart.exception.XmartException;

import javax.annotation.Nullable;

public final class Preconditions {
    private Preconditions() {
    }

    /**
     * Ensures the truth of an expression involving one or more parameters to the calling method.
     *
     * @param expression   a boolean expression
     * @param errorMessage the exception message to use if the check fails; will be converted to a
     *                     string using {@link String#valueOf(Object)}
     *
     * @throws XmartException if {@code expression} is false
     */
    public static void checkArgument(boolean expression, @Nullable Object errorMessage) throws XmartException {
        if (!expression) {
            throw new XmartException(String.valueOf(errorMessage));
        }
    }

    /**
     * Ensures that an object reference passed as a parameter to the calling method is not null.
     *
     * @param reference    an object reference
     * @param errorMessage the exception message to use if the check fails; will be converted to a
     *                     string using {@link String#valueOf(Object)}
     *
     * @return the non-null reference that was validated
     *
     * @throws XmartException if {@code reference} is null
     */
    public static <T> void checkNotNull(T reference, @Nullable Object errorMessage) throws XmartException {
        if (reference == null) {
            throw new XmartException(String.valueOf(errorMessage));
        }
    }
}
