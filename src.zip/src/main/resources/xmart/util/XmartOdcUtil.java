package com.nwm.xmart.util;

import com.rbs.odc.access.domain.CurrencyId;

import static java.util.Objects.nonNull;

/**
 * Utility class to provide methods to extract information from the ODC objects.
 */
public class XmartOdcUtil {

    /**
     * Get the currency code from the supplied
     * {@link CurrencyId#getCurrencyCode()}
     * <br> Handles nulls.
     *
     * @param currencyId to extract Currency Code from
     *
     * @return Currecy Code from the given currency id
     */
    public static String getCurrencyCode(CurrencyId currencyId) {
        return nonNull(currencyId) ? currencyId.getCurrencyCode() : null;
    }
}


