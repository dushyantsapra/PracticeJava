package com.nwm.xmart.util;

import com.rbs.odc.access.domain.CurrencyId;

import java.util.Objects;

import static java.util.Objects.nonNull;

/**
 * Created by aslammh on 02/11/17.
 */
public class XmartUtil {

    private XmartUtil() {
        // do not allow to create an instance
    }

    public static Character getCharacter(Boolean trueOrFalse) {
        if (trueOrFalse == null) {
            return null;
        }
        if (trueOrFalse == true) {
            return Character.valueOf('Y');
        }
        return Character.valueOf('N');
    }

    public static boolean isNotValidDocumentKey(long documentKey) {
        return documentKey <= 0;
    }

    public static boolean isNotValidSourceTopicId(long sourceTopicId) {
        return sourceTopicId < 0;
    }

    public static boolean isNotValidSourcePartition(long sourcePartition) {
        return sourcePartition < 0;
    }

    public static boolean isNotValidSourcePosition(long sourcePosition) {
        return sourcePosition < 0;
    }

    public static boolean isEmptyOrNull(String str) {
        return (str == null || str.isEmpty());
    }

    /**
     * Returns {@link String} representation of the supplied object. Calls {@link Objects#toString(Object, String)} internally.
     * <br>Basically saves some typing effort :)
     *
     * @param object the object to return the String representation of
     *
     * @return toString of the Object, null if the object is null
     */
    public static String getStr(Object object) {
        return Objects.toString(object, null);
    }
}
