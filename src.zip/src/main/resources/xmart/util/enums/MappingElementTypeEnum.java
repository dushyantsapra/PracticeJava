package com.nwm.xmart.util.enums;

/**
 * Created by heskets on 16/01/2018.
 */
public enum MappingElementTypeEnum {

    top, root, attribute, attribute_rule, object, collection, business_rule;

    public static boolean contains(String s) {
        for (MappingElementTypeEnum type : values())
            if (type.name().equals(s))
                return true;
        return false;
    }

}
