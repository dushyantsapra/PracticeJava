package com.nwm.xmart.util.enums;

import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.rbs.odc.access.domain.BusinessDate;
import com.rbs.odc.access.domain.ODCEnumeration;

import java.lang.reflect.Type;

/**
 * Created by heskets on 16/01/2018.
 */
public enum BusinessRuleEnum {

    extractKdbDateTime("extractKdbDateTime", XmartMappedEntity.class),
    extractFiRfqInquiryStates("extractFiRfqInquiryStates", XmartMappedEntity.class),
    extractFiRfqInquiryLegs("extractFiRfqInquiryLegs", XmartMappedEntity.class),
    extractKdbQecQuoteTime("extractKdbQecQuoteTime", XmartMappedEntity.class),
    extractKdbQecQuoteDate("extractKdbQecQuoteDate", XmartMappedEntity.class),
    extractFiQecInquiryStates("extractFiQecInquiryStates", XmartMappedEntity.class),
    extractFiQecInquiryLegs("extractFiQecInquiryLegs", XmartMappedEntity.class),
    extractFiQecInquiryHeader("extractFiQecInquiryHeader", XmartMappedEntity.class),
    extractFxHftInquiryLegs("extractFxHftInquiryLegs", XmartMappedEntity.class),
    extractFxHftInquiryStates("extractFxHftInquiryStates", XmartMappedEntity.class),
    extractFxOmsInquiryStates("extractFxOmsInquiryStates", XmartMappedEntity.class),
    extractFxOmsInquiryAltRefs("extractFxOmsInquiryAltRefs", XmartMappedEntity.class),
    extractFxRfqInquiryLegs("extractFxRfqInquiryLegs", XmartMappedEntity.class),
    extractFxRfqInquiryStates("extractFxRfqInquiryStates", XmartMappedEntity.class),
    extractFxRfqInquiryAltRefs("extractFxRfqInquiryAltRefs", XmartMappedEntity.class),
    extractCRMOrganizationMemberUserId("extractCRMOrganizationMemberUserId", XmartMappedEntity.class),
    extractTDXAgreementDateTime("extractTDXAgreementDateTime", XmartMappedEntity.class),
    getTxStateEffectiveDateTime("getTxStateEffectiveDateTime", XmartMappedEntity.class),
    getTxStateEffectiveDate("getTxStateEffectiveDate", XmartMappedEntity.class),
    extractKdbDateTimeFromTimeStamp("extractKdbDateTimeFromTimeStamp", XmartMappedEntity.class),
    extractKdbSourceReference("extractKdbSourceReference", XmartMappedEntity.class),
    parseKdbStringAsLocalDate("parseKdbStringAsLocalDate", XmartMappedEntity.class);

    private final String method;
    private final Type returnType;

    BusinessRuleEnum(String method, Type returnType) {
        this.method = method;
        this.returnType = returnType;
    }

    public static boolean contains(String s) {
        for (BusinessRuleEnum type : values())
            if (type.method.equals(s))
                return true;
        return false;
    }

    public static Type returnType(String s) {
        for (BusinessRuleEnum type : values())
            if (type.method.equals(s))
                return type.returnType;
        return null;
    }

}
