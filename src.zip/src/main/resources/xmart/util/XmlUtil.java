package com.nwm.xmart.util;

import com.nwm.xmart.core.XmartAttribute;
import com.nwm.xmart.entities.common.XmartEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.exception.XmartMandatoryAttributeMissingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

import static com.nwm.xmart.util.BusinessRulesUtil.isKdbNull;
import static com.nwm.xmart.util.DateUtil.*;
import static com.nwm.xmart.util.ReflectionUtil.getFields;
import static com.nwm.xmart.util.ReflectionUtil.isPopulated;
import static java.util.Objects.nonNull;

/**
 * Various utility classes used in gerneration of XML for submissioni to XMart database
 */
public class XmlUtil {

    private static final Logger logger = LoggerFactory.getLogger(XmlUtil.class);

    private static final DecimalFormat decimalFormat = new DecimalFormat("0",
            DecimalFormatSymbols.getInstance(Locale.ENGLISH));

    private XmlUtil() {
        // No Setup
    }

    /**
     * Returns XML for supply entity and contents, optionally prints the XML content to the logs based on the flag supplied.
     *
     * @param entity        Entity to genrate XML for.
     * @param contents      Contents that are to be parsed to xml form
     * @param printXmlToLog {@link Boolean} {@code true}: Log XML to file, {@code false}: Do not log it
     *
     * @return XML representation of the entity
     */
    public static String getXmlDocument(String entity, String contents, Boolean printXmlToLog) {
        String xmlStr = getXmlDocument(entity, contents);
        if (printXmlToLog) {
            logger.info("getXmlDocument entity {} XML {}", entity, xmlStr);
        }
        return xmlStr;
    }

    private static String getXmlDocument(String entity, String contents) {
        return "<?xml version=\"1.0\" encoding=\"utf-16\" standalone=\"yes\"?>" + "<" + entity + ">" + contents + "</"
                + entity + ">";
    }

    public static String getXmlElement(String entity, String contents) {
        return "<" + entity + " " + contents + "/>";
    }

    public static String getXmlAttribute(String elementName, Class elementClass, Object obj) {
        if (!isKdbNull(obj)) {
            StringBuilder builder = new StringBuilder();

            builder.append(elementName).append("=\"");

            if (elementClass == java.util.Date.class) {
                builder.append(formatDate((java.util.Date) obj));
            } else if (elementClass == java.sql.Timestamp.class) {
                builder.append(formatTimestamp((java.sql.Timestamp) obj));
            } else if (elementClass == java.time.LocalDate.class) {
                builder.append(formatLocalDate((java.time.LocalDate) obj));
            } else if (elementClass == java.time.LocalDateTime.class) {
                builder.append(formatLocalDateTime((java.time.LocalDateTime) obj));
            } else if (elementClass == String.class) {
                builder.append(obj.toString().replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                                  .replace("\"", "&quot;").replace("\'", "&apos;"));
            } else if (elementClass == BigDecimal.class) {
                builder.append(((BigDecimal) obj).toPlainString());
            } else if (elementClass == Double.class) {
                decimalFormat.setMaximumFractionDigits(340);
                builder.append(decimalFormat.format((Double) obj));
            } else {
                builder.append(obj.toString());
            }

            builder.append("\" ");

            return builder.toString();
        } else {
            return "";
        }
    }

    public static String getXml(Object object) {
        if (CollectionsUtil.isNotNull(object)) {
            Field[] allFields = getFields(object.getClass());
            if (allFields.length > 0) {
                StringBuilder builder = new StringBuilder();
                for (Field field : allFields) {
                    Annotation annotation = field.getAnnotation(XmartAttribute.class);
                    // If the field is annotated with XmlAttribute then only get its value.
                    if (CollectionsUtil.isNotNull(annotation)) {
                        String fieldName = field.getName();
                        Class fieldType = field.getType();
                        field.setAccessible(true);
                        try {
                            Object fieldValue = field.get(object);
                            builder.append(getXmlAttribute(fieldName, fieldType, fieldValue));
                        } catch (IllegalAccessException e) {
                            //e.printStackTrace();
                            // Can be ignored as the access to the current field has already given.
                        }
                    }
                }
                String xmlAttribute = builder.toString();
                return getXmlElement(object.getClass().getSimpleName(), xmlAttribute);
            }
        }

        return "";
    }

    public static <T extends XmartEntity> String getXmlFromCollection(Collection<T> entities) {
        StringBuilder builder = new StringBuilder();
        if (CollectionsUtil.isNotEmpty(entities)) {
            for (T entity : entities) {
                if (CollectionsUtil.isNotNull(entity)) {
                    builder.append(entity.toString());
                }
            }
        }
        return builder.toString();
    }

    /**
     * Checks for the validity of the passed entity. An entity is supposed to be valid as per the use-cases mentioned.
     * If valid then its corresponding xml entry will be added to the parent/holding xml tags.
     *
     * @param entity - the XMartEntity to be validated
     *
     * @return boolean showing whether the entity is valid
     */
    public static <T extends XmartEntity> boolean isValidEntity(T entity) throws XmartException {

        boolean isValid = false;

        if (nonNull(entity)) {
            Field[] allFields = getFields(entity.getClass());
            if (allFields.length > 0) {
                List<String> missingMandatoryAttributes = new ArrayList<>();
                List<String> missingJoinAttributes = new ArrayList<>();

                for (Field field : allFields) {

                    Annotation annotation = field.getAnnotation(XmartAttribute.class);
                    // If the field is annotated with XmartAttribute then only get its value.
                    if (nonNull(annotation)) {
                        XmartAttribute attribute = (XmartAttribute) annotation;

                        // set the variables, as per the field/attribute state.
                        boolean attributePopulated = isPopulated(field, entity);

                        if (attributePopulated) {
                            if (attribute.xmlTrigger()) {
                                isValid = true;
                            }
                        } else {
                            if (attribute.mandatory()) {
                                missingMandatoryAttributes.add(field.getName());
                            }
                            // In case any attributre marked to take part in join and is not populated,
                            if (attribute.usedInJoin()) {
                                missingJoinAttributes.add(field.getName());
                            }
                        }
                    }
                }

                // If the join-attributes are missing, just log those.
                if (missingJoinAttributes.size() > 0) {
                    // If mandatory attribute are not populated then log it
                    logger.warn(
                            "Join attribute(s) missing in " + entity.getClass().getSimpleName() + " for documentKey "
                                    + entity.getDocumentKey() + "; Missing attribute(s) : " + missingJoinAttributes);
                }

                // log all the mandatory fields which are missing, and throw the exception :
                if (missingMandatoryAttributes.size() > 0) {
                    // If mandatory attribute are not populated then log it
                    throw new XmartMandatoryAttributeMissingException(
                            "Mandatory attribute(s) missing in " + entity.getClass().getSimpleName()
                                    + " for documentKey " + entity.getDocumentKey() + "; Missing attribute(s) : "
                                    + missingMandatoryAttributes);
                }
            }

            // In case the entity is not valid, log it here.
            if (!isValid) {
                logger.warn("Invalid entity " + entity.getClass().getSimpleName()
                        + " found and will be ignored. Reason : No xmlTrigger attribute is populated for documentKey = "
                        + entity.getDocumentKey());
            }
        }

        return isValid;
    }
}

