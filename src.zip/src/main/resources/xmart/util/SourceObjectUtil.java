package com.nwm.xmart.util;

import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.enums.AttributeMappingRuleEnum;
import com.nwm.xmart.util.enums.BusinessRuleEnum;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;

/**
 * Created by heskets on 15/01/2018.
 */
public class SourceObjectUtil<T> {

    private static final AttributeMappingRulesUtil attributeMappingRulesUtil = new AttributeMappingRulesUtil();
    private static final BusinessRulesUtil businessRuleUtil = new BusinessRulesUtil();

    public static Object getObject(Method method, Object sourceObject) throws XmartException {

        try {

            return method.invoke(sourceObject);
        } catch (IllegalAccessException e) {

            throw new XmartException("Invalid method requested from Source Object - IllegalAccessException", e);
        } catch (InvocationTargetException e) {

            throw new XmartException("Invalid method requested from Source Object -InvocationTargetException", e);
        }
    }

    public static Object getIndexedObject(Method method, Object sourceObject, int index, String attributeClassName)
            throws XmartException {

        try {

            return method.invoke(sourceObject, index);
        } catch (IllegalAccessException e) {

            throw new XmartException("Invalid method requested from Source Object - IllegalAccessException", e);
        } catch (InvocationTargetException e) {

            throw new XmartException("Invalid method requested from Source Object -InvocationTargetException", e);
        }
    }

    public static Object getMappedObject(Method method, Object sourceObject, String attributeName,
            String attributeClassName) throws XmartException {

        try {

            Object returnObject = method.invoke(sourceObject, attributeName);
            if (returnObject != null && !attributeClassName.equals(returnObject.getClass().getSimpleName())) {
                throw new XmartException("Invalid method requested from Source Object - method " + attributeName
                        + " returns invalid type - expected " + attributeClassName);
            }

            return returnObject;
        } catch (IllegalAccessException e) {

            throw new XmartException(
                    "Invalid method requested from Source Object - IllegalAccessException - method " + attributeName,
                    e);
        } catch (InvocationTargetException e) {

            throw new XmartException(
                    "Invalid method requested from Source Object -InvocationTargetException - method " + attributeName,
                    e);
        }
    }

    public static Object getMappedObject(Method method, Object sourceObject, String attributeName,
            String attributeName2, String attributeClassName) throws XmartException {

        try {

            Object returnObject = method.invoke(sourceObject, attributeName, attributeName2);

            if (returnObject != null && !attributeClassName.equals(returnObject.getClass().getSimpleName())) {
                throw new XmartException("Invalid method requested from Source Object - method [ " + method.getName()
                        + " ], attribute 1 [ " + attributeName + " ], attribute 2 [ " + attributeName2
                        + " ], returns invalid type - expected " + attributeClassName);
            }

            return returnObject;
        } catch (IllegalAccessException e) {

            throw new XmartException("Invalid method requested from Source Object - IllegalAccessException", e);
        } catch (InvocationTargetException e) {

            throw new XmartException("Invalid method requested from Source Object -InvocationTargetException", e);
        }
    }

    public static Method getMethod(Object sourceObject, String attributeMethod, String attributeClassName,
            Boolean isIndexedMethod, Boolean isMappedMethod, Boolean isSingleParameterisedMethod,
            Boolean isDoubleParameterisedMethod) throws XmartException {

        Method method = null;

        try {

            if (isIndexedMethod) {
                method = sourceObject.getClass().getMethod(attributeMethod, int.class);
            } else if (isMappedMethod || isSingleParameterisedMethod) {
                method = sourceObject.getClass().getMethod(attributeMethod, String.class);
            } else if (isDoubleParameterisedMethod) {
                method = sourceObject.getClass().getMethod(attributeMethod, String.class, String.class);
            } else {
                method = sourceObject.getClass().getMethod(attributeMethod);
            }
        } catch (NoSuchMethodException e) {

            throw new XmartException(
                    "Invalid method requested from Source Object - method not found: " + attributeMethod);
        }

        if ((isIndexedMethod || isMappedMethod) && !method.getReturnType().getSimpleName().equals("Object")) {

            throw new XmartException("Invalid method requested from Source Object - method " + attributeMethod
                    + " returns invalid type - expected Object");
        } else if (!isIndexedMethod && !isMappedMethod && !attributeClassName
                .equals(method.getReturnType().getSimpleName())) {

            throw new XmartException("Invalid method requested from Source Object - method " + attributeMethod
                    + " returns invalid type - expected " + attributeClassName);
        }

        return method;
    }

    public static Object applyBusinessRule(Object sourceObject, String ruleMethod, String returnClassName)
            throws XmartException {

        Method method = null;

        Class[] methodParameterClasses = new Class[1];

        if (!BusinessRuleEnum.contains(ruleMethod)) {
            throw new XmartException("Invalid business logic method requested: " + ruleMethod);
        }

        methodParameterClasses[0] = (Class) BusinessRuleEnum.returnType(ruleMethod);

        try {

            method = businessRuleUtil.getClass().getDeclaredMethod(ruleMethod, methodParameterClasses);
        } catch (NoSuchMethodException e) {

            throw new XmartException(
                    "Invalid business logic method requested from Source Object - method not found: " + ruleMethod);
        }

        if (!returnClassName.equals(method.getReturnType().getSimpleName())) {

            throw new XmartException(
                    "Invalid method requested from Source Object - method returns invalid type: " + ruleMethod
                            + " expected " + returnClassName);
        }

        try {

            method.setAccessible(true);
            return method.invoke(businessRuleUtil, sourceObject);
        } catch (IllegalAccessException e) {

            throw new XmartException("Invalid method requested from Source Object - IllegalAccessException", e);
        } catch (InvocationTargetException e) {

            throw new XmartException("Failure invoking method requested from Source Object - InvocationTargetException",
                    e);
        }
    }

    public static Object applyAttributeMappingRule(Object sourceObject, String ruleMethod, String ruleClassName)
            throws XmartException {

        Method method = null;

        Class[] methodParameterClasses = new Class[1];
        methodParameterClasses[0] = Object.class;

        if (!AttributeMappingRuleEnum.contains(ruleMethod)) {

            throw new XmartException("Invalid business logic method requested: " + ruleMethod);
        }

        try {

            method = attributeMappingRulesUtil.getClass().getDeclaredMethod(ruleMethod, methodParameterClasses);
        } catch (NoSuchMethodException e) {

            throw new XmartException(
                    "Invalid business logic method requested from Source Object - method not found: " + ruleMethod);
        }

        if (!ruleClassName.equals(method.getReturnType().getSimpleName())) {

            throw new XmartException(
                    "Invalid method requested from Source Object - method returns invalid type: " + ruleMethod
                            + " expected " + ruleClassName);
        }

        try {

            method.setAccessible(true);
            return method.invoke(attributeMappingRulesUtil, sourceObject);
        } catch (IllegalAccessException e) {

            throw new XmartException("Invalid method requested from Source Object - IllegalAccessException", e);
        } catch (InvocationTargetException e) {

            throw new XmartException("Invalid method requested from Source Object -InvocationTargetException", e);
        }
    }

    public static Collection getCollection(Object sourceObject, String attributeMethod, String attributeClassName)
            throws XmartException {

        Method method = null;

        try {

            method = sourceObject.getClass().getMethod(attributeMethod);
        } catch (NoSuchMethodException e) {

            throw new XmartException(
                    "Invalid method requested from Source Object - method not found - " + attributeMethod);
        }

        if (!attributeClassName.equals(method.getReturnType().getSimpleName())) {

            throw new XmartException(
                    "Invalid method requested from Source Object - method returns invalid type - " + attributeMethod);
        }

        try {

            Collection returnObject = (Collection) method.invoke(sourceObject);

            return returnObject;
        } catch (IllegalAccessException e) {

            throw new XmartException(
                    "Invalid method requested from Source Object - IllegalAccessException - " + attributeMethod, e);
        } catch (InvocationTargetException e) {

            throw new XmartException(
                    "Invalid method requested from Source Object -InvocationTargetException - " + attributeMethod, e);
        }
    }

    public static Collection getCollection(Method method, Object sourceObject) throws XmartException {

        try {

            Collection returnObject = (Collection) method.invoke(sourceObject);

            return returnObject;
        } catch (IllegalAccessException e) {

            throw new XmartException(
                    "Invalid method requested from Source Object - IllegalAccessException - " + method.getName(), e);
        } catch (InvocationTargetException e) {

            throw new XmartException(
                    "Invalid method requested from Source Object -InvocationTargetException - " + method.getName(), e);
        }
    }

    public static Collection getJSONCollection(Method method, Object sourceObject, String methodAttributeValue)
            throws XmartException {

        try {

            Collection returnObject = (Collection) method.invoke(sourceObject, methodAttributeValue);

            return returnObject;
        } catch (IllegalAccessException e) {

            throw new XmartException(
                    "Invalid method requested from Source Object - IllegalAccessException - " + method.getName(), e);
        } catch (InvocationTargetException e) {

            throw new XmartException(
                    "Invalid method requested from Source Object -InvocationTargetException - " + method.getName(), e);
        }
    }
}
