package com.nwm.xmart.util;

import com.rbs.odc.access.domain.BusinessDate;
import org.joda.time.LocalTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static java.util.Objects.nonNull;

/**
 * Created by aslammh on 04/08/17.
 */
public final class DateUtil {
    private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);
    private static final String DEF_LOCAL_DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
    private static final String DEF_DATE_TIME_FORMAT_UTC = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    private static final String DEF_TIMESTAMP_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.nnnnnnnnn";
    private static final String DEF_DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
    private static final String DEF_TIME_FORMAT = "HH:mm:ss.SSSXXX";
    private static final String DEF_TIME_FORMAT_WITHOUT_TIMEZONE = "HH:mm:ss.SSS";
    private static final String DEF_DATE_FORMAT = "yyyy-MM-dd";

    private static DateTimeFormatter localDateTimeFormatter = DateTimeFormatter.ofPattern(DEF_LOCAL_DATE_TIME_FORMAT);
    private static DateTimeFormatter localDateTimeFormatterUTC = DateTimeFormatter.ofPattern(DEF_DATE_TIME_FORMAT_UTC);
    private static DateTimeFormatter localDateFormatter = DateTimeFormatter.ofPattern(DEF_DATE_FORMAT);
    private static DateTimeFormatter timeStampFormatter = DateTimeFormatter.ofPattern(DEF_TIMESTAMP_FORMAT);

    private static ThreadLocal<SimpleDateFormat> dateTimeFormat = ThreadLocal
            .withInitial(() -> new SimpleDateFormat(DEF_DATE_TIME_FORMAT));

    private static ThreadLocal<SimpleDateFormat> timeFormatter = ThreadLocal
            .withInitial(() -> new SimpleDateFormat(DEF_TIME_FORMAT));

    private static ThreadLocal<SimpleDateFormat> timeFormatterWithoutTimeFormat = ThreadLocal
            .withInitial(() -> new SimpleDateFormat(DEF_TIME_FORMAT_WITHOUT_TIMEZONE));

    private static ThreadLocal<SimpleDateFormat> dateFormatter = ThreadLocal
            .withInitial(() -> new SimpleDateFormat(DEF_DATE_FORMAT));

    private DateUtil() {
        // Do not allow to create an instance.
    }

    /**
     * Retrieves {@link BusinessDate#asMidnightUKDate()} for the supplied param, with null handling
     *
     * @param busDate to be coverted to {@link Date}
     *
     * @return date as retuned by the {@link BusinessDate#asMidnightUKDate()}.
     */
    public static Date convertBusinessDate(BusinessDate busDate) {
        return busDate == null ? null : busDate.asMidnightUKDate();
    }

    /**
     * Formats a Date to the default format. "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
     * <br>Additionally replaces the UTC offset 'Z' with '+00:00" to maintain unformity.
     *
     * @param date to be formatted
     *
     * @return String representing the formatted date.
     */
    public static String formatDate(Date date) {
        return dateTimeFormat.get().format(date).replace("Z", "+00:00");
    }

    /**
     * Formats a java.sql.Time to the default format. "HH:mm:ss.SSSXXX"
     *
     * @param time to be formatted
     *
     * @return String representing the formatted date.
     */
    public static String formatTime(java.sql.Time time) {
        return timeFormatterWithoutTimeFormat.get().format(time);
    }

    /**
     * Formats a java.sql.Timestamp to the default format. "yyyy-MM-dd'T'HH:mm:ss.fff"
     *
     * @param timestamp to be formatted
     *
     * @return String representing the formatted date.
     */
    public static String formatTimestamp(java.sql.Timestamp timestamp) {
        return nonNull(timestamp) ? timestamp.toLocalDateTime().format(timeStampFormatter) : null;
    }

    /**
     * Formats a LocalDateTime to the default format. "yyyy-MM-dd'T'HH:mm:ss.SSS"
     *
     * @param localDateTime to be formatted
     *
     * @return String representing the formatted date.
     */
    public static String formatLocalDateTime(java.time.LocalDateTime localDateTime) {
        return localDateTime.format(localDateTimeFormatter);
    }

    public static String formatLocalDateTimeUTC(java.time.LocalDateTime localDateTime) {
        return localDateTime.format(localDateTimeFormatterUTC);
    }

    public static String formatLocalDate(LocalDate localDate) {
        return localDate.format(localDateFormatter);
    }

    /**
     * Formats the {@link LocalTime} to {@link String}
     * * <br> Format is specified by {@link DateUtil#DEF_TIME_FORMAT}
     *
     * @param localTime {@link LocalTime} object to be formatted.
     *
     * @return {@link String} representation of the supplied {@link LocalTime}.
     */
    //TODO commented for FROBI-7296
    public static String convertLocalTime(LocalTime localTime) {
        if (localTime == null) {
            return null;
        }
        //get internal field iLocalMillis
        Field localMillis = null;
        long millis = 0l;
        try {
            localMillis = localTime.getClass().getDeclaredField("iLocalMillis");
            localMillis.setAccessible(true);
            millis = (Long) localMillis.get(localTime);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            logger.warn("iLocalMillis field not found in the LocalTime Object ", e);
            return null;
        }

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.add(Calendar.MILLISECOND, (int) millis);
        return timeFormatter.get().format(cal.getTime());
    }

    /**
     * Formats a Date Without Time Component. "yyyy-MM-dd"
     *
     * @param date to be formatted
     *
     * @return String representing the formatted date.
     */
    public static String formatDateWithOutTime(Date date) {
        return dateFormatter.get().format(date);
    }

    public static LocalDate parseStringAsLocalDate(String inputDateString) {
        if (inputDateString == null || inputDateString.equals("")) {
            return null;
        }
        String dateString = inputDateString;
        dateString = dateString.replace('/', '-');
        dateString = dateString.replace('.', '-');
        dateString = dateString.replace('\\', '-');

        List<DateTimeFormatter> dateTimeFormatterList = new ArrayList<>();
        //date formats
        dateTimeFormatterList.add(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        dateTimeFormatterList.add(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        dateTimeFormatterList.add(DateTimeFormatter.ofPattern("yyyy-M-d"));
        dateTimeFormatterList.add(DateTimeFormatter.ofPattern("d-M-yyyy"));

        //datetime formats
        dateTimeFormatterList.add(DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss"));
        dateTimeFormatterList.add(DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm:ss"));
        dateTimeFormatterList.add(DateTimeFormatter.ofPattern("yyyy-M-d hh:mm:ss"));
        dateTimeFormatterList.add(DateTimeFormatter.ofPattern("d-M-yyyy hh:mm:ss"));

        for (DateTimeFormatter formatter : dateTimeFormatterList) {
            try {
                return LocalDate.parse(dateString, formatter);
            } catch (Exception ignored) {
            }
        }

        logger.warn("unable to parse string as date: " + inputDateString);
        return null;
    }
}
