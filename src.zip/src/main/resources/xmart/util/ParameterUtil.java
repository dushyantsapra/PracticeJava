package com.nwm.xmart.util;

import com.nwm.xmart.core.BindObject;
import com.nwm.xmart.source.file.exeption.XmartFileAttributeException;
import org.apache.flink.configuration.Configuration;

import static com.google.common.base.Strings.isNullOrEmpty;
import static java.util.Objects.isNull;

public class ParameterUtil implements BindObject {
    /**
     * Gets and validates param from {@link Configuration}
     *
     * @param paramName  anem of param
     * @param parameters Configuration object
     *
     * @return Value of param if it is non null and not empty
     */
    public static String getValidStringParameter(String paramName, Configuration parameters) {
        if (isNull(parameters)) {
            throw new XmartFileAttributeException("Parameters are null");
        }

        String paramValue = parameters.getString(paramName, null);
        if (isNullOrEmpty(paramValue)) {
            throw new XmartFileAttributeException(paramName + " not provided");
        }

        return paramValue;
    }

    /**
     * Gets and validates boolean param from {@link Configuration}
     *
     * @param paramName  anem of param
     * @param parameters Configuration object
     *
     * @return Value of param if it is non null and not empty
     */
    public static Boolean getValidBooleanParameter(String paramName, Configuration parameters) {
        if (isNull(parameters)) {
            throw new XmartFileAttributeException("Parameters are null");
        }

        Boolean paramValue = parameters.getBoolean(paramName, false);

        return paramValue;
    }

    /**
     * Gets and validates param from {@link Configuration}
     *
     * @param paramName  anem of param
     * @param parameters Configuration object
     *
     * @return Value of param if it is non null and not empty
     */
    public static int getValidIntParameter(String paramName, Configuration parameters) {
        if (isNull(parameters)) {
            throw new XmartFileAttributeException("Parameters are null");
        }

        int paramValue = parameters.getInteger(paramName, -1);
        if (paramValue == -1) {
            throw new XmartFileAttributeException(paramName + " not provided");
        }
        return paramValue;
    }

    /**
     * Gets and validates param from {@link Configuration}
     *
     * @param paramName  anem of param
     * @param parameters Configuration object
     *
     * @return Value of param if it is non null and not empty
     */
    public static long getValidLongParameter(String paramName, Configuration parameters) {
        if (isNull(parameters)) {
            throw new XmartFileAttributeException("Parameters are null");
        }

        long paramValue = parameters.getLong(paramName, -1);
        if (paramValue == -1) {
            throw new XmartFileAttributeException(paramName + " not provided");
        }
        return paramValue;
    }
}
