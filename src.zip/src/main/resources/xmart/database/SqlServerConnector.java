package com.nwm.xmart.database;

import com.microsoft.sqlserver.jdbc.SQLServerConnection;
import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import com.nwm.xmart.core.BindObject;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.sso.EncryptDecryptAES;
import org.apache.flink.api.java.utils.ParameterTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;

/**
 * <p>Connects to a SQL Server database using JDBC drivers and returns a connection.</p>
 *
 * @author aslammh
 */
public class SqlServerConnector implements BindObject {

    private static final long serialVersionUID = -9138275687038624138L;
    private static final Logger logger = LoggerFactory.getLogger(SqlServerConnector.class);
    private SQLServerDataSource ds;
    private ParameterTool parameters = null;

    /**
     * Creates and validates a SQL Server connection.Private constructor to prevent instatiation of this class.
     *
     * @param parameters the flink ParamaterTool object holding the job nodes
     *
     * @return SQLServerConnection returns a SQL Server JDBC connection object
     *
     * @throws XmartException If the connection fails after the required number of retry attempts.
     */
    public SQLServerConnection getConnection(ParameterTool parameters) throws XmartException {

        this.parameters = parameters;

        logger.debug("Entering getConnection");

        SQLServerConnection connection = null;

        getDataSource();

        int retryCounter = 0;
        boolean isComplete = false;

        while (!isComplete && retryCounter < parameters.getInt("operator.sink.sqlserver.retry.limit")) {

            if (logger.isDebugEnabled()) {
                logger.debug("Attempt {} to connect to SQL Server: {}", retryCounter + 1, ds.getURL());
            }

            try {

                connection = (SQLServerConnection) ds.getConnection();

                if (checkConnection(connection)) {
                    isComplete = true;
                } else {
                    logger.error("Invalid connection returned by SQL Data Source");
                }
            } catch (SQLServerException e) {

                logger.error("Error getting SQL Server connection:", e);
            }

            if (!isComplete) {

                retryCounter++;

                try {

                    Thread.sleep(parameters.getInt("operator.sink.sqlserver.retry.period"));
                } catch (InterruptedException ie) {

                    logger.error("Interrupt before retrying SQL Server connection:", ie);
                    Thread.currentThread().interrupt();

                    isComplete = true;
                }
            }
        }

        if (!isComplete) {
            throw new XmartException("SQL Server connection attempts exceeded retry limit.");
        }

        return connection;
    }

    /**
     * Sets class variable ds to a new SQLServerDataSource is it is not already instantiated.
     */
    private void getDataSource() {
        logger.debug("Entering getDataSource()");

        if (ds == null) {
            ds = createNewDataSource();
        }
    }

    /**
     * Creates a new SQLServerDataSource object based on the parameters provided.
     *
     * @return SQLServerDataSource the connection details for a SQLServer database
     */
    private SQLServerDataSource createNewDataSource() {

        /*putJobNameInMDC(parameters);*/
        logger.debug("Entering createNewDataSource()");

        String server = parameters.get("operator.sink.sqlserver.server");
        String database = parameters.get("operator.sink.sqlserver.database");
        String username = parameters.get("operator.sink.sqlserver.username");
        String password = EncryptDecryptAES.decrypt(parameters.get("operator.sink.sqlserver.password"));

        String url = "jdbc:sqlserver://" + server + ";databaseName=" + database;

        // create the SQLServer connector using the parameters above

        ds = new SQLServerDataSource();

        ds.setURL(url);
        ds.setUser(username);
        ds.setPassword(password);

        return ds;
    }

    /**
     * Checks the status of a SQLServerConnection object to ensure the connection is valid
     *
     * @param connection a SQLServerConnection object
     *
     * @return boolean a flag indicating whether the connection provided is valid
     */
    public boolean checkConnection(SQLServerConnection connection) {

        logger.debug("Entering checkConnection() " + connection);

        Boolean isValid = false;

        try {
            if (connection == null) {

                logger.error("SQL Server connection is invalid (null).");
            } else if (connection.isValid(parameters.getInt("operator.sink.sqlserver.timeout.sec"))) {

                if (logger.isDebugEnabled()) {
                    logger.debug("SQL Server connection is valid: {}", connection.toString());
                }

                isValid = true;
            } else {

                logger.error("SQL Server connection is invalid.");
            }
        } catch (SQLException e) {

            logger.error("SQL Exception checking connection:", e);
        } finally {

            if (!isValid && connection != null) {
                try {

                    connection.close();
                } catch (SQLException e) {

                    logger.error("SQL Exception checking connection:", e);
                }
            }
        }

        return isValid;
    }
}
