package com.nwm.xmart.database.statement;

import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;
import com.nwm.xmart.entities.XmartXmlTransactionSet;
import com.nwm.xmart.exception.XmartException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;

/**
 * <p>
 * Sets up the prepare statement for the Stored Procedure usp_TdxTradeXmlInsert.
 * </p>
 * <p>
 * This class extends the XmartStatement class and sets up the command and
 * parameters for the prepare statement associated with this XML based stored
 * procedure.
 * </p>
 *
 * @author heskets
 */
public class TdxTradeXmlInsertStatement extends XmartStatement {
    /**
     *
     */
    private static final long serialVersionUID = -395538314942462388L;
    private static final Logger logger = LoggerFactory.getLogger(TdxTradeXmlInsertStatement.class);

    /**
     * Constructor class that initialises the prepared statement and the SQL
     * Server execute command..
     */
    public TdxTradeXmlInsertStatement() {
        super();

        //Contains completed groups of 10 (ten) ?'s and last of (n % 10)
        PROC_COMMAND = "EXEC [api].[usp_TdxTradeXmlInsert] " + "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
                + "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, " + "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, " + "?, ?, ?, ?, ?, ?, ?, ?, ?, ?,"
                + "?, ?, ?, ?, ?, ?, ?, ?, ?, ?," + "?, ?, ?, ?, ?, ?";
    }

    /**
     * Returns a completed prepared statement with parameters set up ready for
     * execution
     *
     * @param obj a Xmart Xml Map object containing the XML to be used in the
     *            prepared statement
     *
     * @return SQLServerPreparedStatement a JDBC driver class representing the
     * SQL Server prepared statement ready for execution
     */
    @Override
    public SQLServerPreparedStatement getPreparedStatement(Object obj) throws SQLException, XmartException {

        super.getPreparedStatement(obj);

        XmartXmlTransactionSet transactionSetXml = (XmartXmlTransactionSet) obj;
        preparedStatement.setObject(1, transactionSetXml.getXmartTransactionsXml());
        preparedStatement.setObject(2, transactionSetXml.getXmartTransactionLegsXml());
        preparedStatement.setObject(3, transactionSetXml.getXmartLegInformationSourcesXml());
        preparedStatement.setObject(4, transactionSetXml.getXmartAlternateTransactionIdentifiersXml());
        preparedStatement.setObject(5, transactionSetXml.getXmartAgreementTransactionContextsXml());
        preparedStatement.setObject(6, transactionSetXml.getXmartTransactionStatusesXml());
        preparedStatement.setObject(7, transactionSetXml.getXmartBookCounterPartiesXml());
        preparedStatement.setObject(8, transactionSetXml.getXmartTradingPartiesXml());
        preparedStatement.setObject(9, transactionSetXml.getXmartTransactionLegalEntitiesXml());
        preparedStatement.setObject(10, transactionSetXml.getXmartFxLegsXml());
        preparedStatement.setObject(11, transactionSetXml.getXmartRegulatoryRegimeImpactsXml());
        preparedStatement.setObject(12, transactionSetXml.getXmartReportableInstrumentsXml());
        preparedStatement.setObject(13, transactionSetXml.getXmartRegimePartyRolesXml());
        preparedStatement.setObject(14, transactionSetXml.getXmartRegimeBookRolesXml());
        preparedStatement.setObject(15, transactionSetXml.getXmartInterestRateLegsXml());
        preparedStatement.setObject(16, transactionSetXml.getXmartTransactionRegulatoryMarginImpactsXml());
        preparedStatement.setObject(17, transactionSetXml.getXmartTransactionSourceSystemsXml());
        preparedStatement.setObject(18, transactionSetXml.getXmartUnderliersXml());
        preparedStatement.setObject(19, transactionSetXml.getXmartVarianceLegsXml());
        preparedStatement.setObject(20, transactionSetXml.getXmartBookReportObligationsXml());
        preparedStatement.setObject(21, transactionSetXml.getXmartCompoundUnderlierMembersXml());
        preparedStatement.setObject(22, transactionSetXml.getXmartCreditDerivativeAdditionalTermsXml());
        preparedStatement.setObject(23, transactionSetXml.getXmartCreditEventPublicSourcesXml());
        preparedStatement.setObject(24, transactionSetXml.getXmartCreditDerivativeLegsXml());
        preparedStatement.setObject(25, transactionSetXml.getXmartDeliverableObligationsXml());
        preparedStatement.setObject(26, transactionSetXml.getXmartEmployeeIdEntriesXml());
        preparedStatement.setObject(27, transactionSetXml.getXmartExceptionalTermsDetailsXml());
        preparedStatement.setObject(28, transactionSetXml.getXmartExternalTransactionIdentifiersXml());
        preparedStatement.setObject(29, transactionSetXml.getXmartForwardFeaturesXml());
        preparedStatement.setObject(30, transactionSetXml.getXmartFuturesLegsXml());
        preparedStatement.setObject(31, transactionSetXml.getXmartInflationRateLegsXml());
        preparedStatement.setObject(32, transactionSetXml.getXmartLegBusinessCentresXml());
        preparedStatement.setObject(33, transactionSetXml.getXmartLegParametersXml());
        preparedStatement.setObject(34, transactionSetXml.getXmartLinkedTransactionsXml());
        preparedStatement.setObject(35, transactionSetXml.getXmartNotionalResetsXml());
        preparedStatement.setObject(36, transactionSetXml.getXmartOptionFeaturesXml());
        preparedStatement.setObject(37, transactionSetXml.getXmartPartyReportObligationsXml());
        preparedStatement.setObject(38, transactionSetXml.getXmartPostTradeClassificationsXml());
        preparedStatement.setObject(39, transactionSetXml.getXmartPrincipalMovementEventsXml());
        preparedStatement.setObject(40, transactionSetXml.getXmartRegulatoryAuthoritiesXml());
        preparedStatement.setObject(41, transactionSetXml.getXmartRelatedCurrenciesXml());
        preparedStatement.setObject(42, transactionSetXml.getXmartReportableIndexesXml());
        preparedStatement.setObject(43, transactionSetXml.getXmartReportableUnderlyingInstrumentsXml());
        preparedStatement.setObject(44, transactionSetXml.getXmartReportingWaiversXml());
        preparedStatement.setObject(45, transactionSetXml.getXmartRoutingAttributesXml());
        preparedStatement.setObject(46, transactionSetXml.getXmartSalesCreditComponentsXml());
        preparedStatement.setObject(47, transactionSetXml.getXmartSettlementSystemMigrationDatasXml());
        preparedStatement.setObject(48, transactionSetXml.getXmartTransactionInstanceLinksXml());
        preparedStatement.setObject(49, transactionSetXml.getXmartTransactionLegCurvesXml());
        preparedStatement.setObject(50, transactionSetXml.getXmartTransactionLifecycleEventsXml());
        preparedStatement.setObject(51, transactionSetXml.getXmartTransactionMarginElectionsXml());
        preparedStatement.setObject(52, transactionSetXml.getXmartTransactionMarginJurisdictionsXml());
        preparedStatement.setObject(53, transactionSetXml.getXmartTransactionProcessDirectivesXml());
        preparedStatement.setObject(54, transactionSetXml.getXmartTransactionProcessRolePlayersXml());
        preparedStatement.setObject(55, transactionSetXml.getXmartReportableTransactionStatesXml());
        preparedStatement.setObject(56, transactionSetXml.getXmartTradingPartyAttestationsXml());

        preparedStatement.addBatch();
        return preparedStatement;
    }
}
