package com.nwm.xmart.database.statement;

import com.microsoft.sqlserver.jdbc.SQLServerConnection;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;
import com.nwm.xmart.core.BindObject;
import com.nwm.xmart.exception.XmartException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;

/**
 * <p>Sets up the prepare statement for generic Stored Procedure.</p>
 * <p>This class must be extended to provide details of the specific stored procedure to be called.</p>
 *
 * @author heskets
 */
public abstract class XmartStatement implements BindObject {

    private static final long serialVersionUID = 8548391047048079120L;
    private static final Logger logger = LoggerFactory.getLogger(XmartStatement.class);

    protected String PROC_COMMAND;

    protected SQLServerPreparedStatement preparedStatement;

    /**
     * Instantiates a SQLServerPreparedStatement class to execute the stored procedure. This method is
     * called when Flink opens the Sink.
     *
     * @param connection a SQL Server JDBC Connection already initiated
     *
     * @throws SQLServerException if there are problems setting up the prepared statement for instance, if the command is in valid of there are connection issues
     */
    public void open(SQLServerConnection connection) throws SQLServerException {

        logger.debug("Opening Xmart prepared statement");

        preparedStatement = (SQLServerPreparedStatement) connection.prepareStatement(PROC_COMMAND);
    }

    /**
     * Closes the prepared statement for the stored procedure. This method is called when Flink closes the Sink.
     *
     * @throws SQLServerException if there are problems closing the prepared statement
     */
    public void close() throws SQLServerException {

        logger.debug("Closing XMart prepared statement.");

        // TODO - this could be checked and logged as it is not fatal
        preparedStatement.close();
    }

    /**
     * Returns a clean version of the prepared statement.
     *
     * @param object a generic object to be used in the set up of the prepared statement - used in overridden versions of this method
     *
     * @return SQLServerPreparedStatement a JDBC driver class representing the SQL Server prepared statement
     *
     * @throws SQLServerException if there are problems clearing the parameters from the prepared statement
     */
    public SQLServerPreparedStatement getPreparedStatement(Object object) throws SQLException, XmartException {

        preparedStatement.clearParameters();

        return preparedStatement;
    }
}
