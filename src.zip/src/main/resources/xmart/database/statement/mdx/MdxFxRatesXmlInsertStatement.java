package com.nwm.xmart.database.statement.mdx;

import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.entities.common.XmartSessionMetadata;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.database.session.XmartSession;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Map;

import static java.util.Objects.isNull;

public class MdxFxRatesXmlInsertStatement extends XmartStatement {
    public MdxFxRatesXmlInsertStatement() {
        super();
        /*
         * [api].[usp_FilePayloadXmlInsert]
         * @pPayload XML = NULL,
         * @pPayloadHandlerName VARCHAR(200) ,
         * @pTotalRowCount INT ,
         * @pFileExtractAuditId INT
         */
        PROC_COMMAND = "EXEC [api].[usp_DataPayloadXmlInsert] ?, ?, ?, ?";
    }

    @Override
    public SQLServerPreparedStatement getPreparedStatement(Object obj) throws SQLException, XmartException {
        super.getPreparedStatement(obj);

        XmartGenericXmlSet genericXmlSetXml = (XmartGenericXmlSet) obj;
        for (Map.Entry<String, String> entry : genericXmlSetXml.getXmlEntityMap().entrySet()) {
            XmartSessionMetadata eventMetadata = (XmartSessionMetadata) genericXmlSetXml.getMetadata(entry.getKey());
            if (isNull(eventMetadata)) {
                continue;
            }

            XmartSession xmartSession = eventMetadata.getXmartSession();

            preparedStatement.setString(1, genericXmlSetXml.getEntityXml(entry.getKey()));
            preparedStatement.setString(2, xmartSession.getPayloadHandlerName());
            preparedStatement.setInt(3, xmartSession.getRowCount());
            preparedStatement.setInt(4, xmartSession.getSessionId());

            preparedStatement.addBatch();
        }
        return preparedStatement;
    }
}
