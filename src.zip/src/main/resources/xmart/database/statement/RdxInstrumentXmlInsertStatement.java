package com.nwm.xmart.database.statement;

import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.exception.XmartException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;

/**
 * <p>
 * Sets up the prepare statement for the Stored Procedure usp_TdxTradeXmlInsert.
 * </p>
 * <p>
 * This class extends the XmartStatement class and sets up the command and
 * parameters for the prepare statement associated with this XML based stored
 * procedure.
 * </p>
 *
 * @author heskets
 */
public class RdxInstrumentXmlInsertStatement extends XmartStatement {
    /**
     *
     */
    private static final long serialVersionUID = -395538314942462388L;
    private static final Logger logger = LoggerFactory.getLogger(RdxInstrumentXmlInsertStatement.class);

    /**
     * Constructor class that initialises the prepared statement and the SQL
     * Server execute command..
     */
    public RdxInstrumentXmlInsertStatement() {
        super();

        //Contains completed groups of 10 (ten) ?'s and last of (n % 10)
        PROC_COMMAND = "EXEC [api].[usp_RdxInstrumentXmlInsert] " + "?, ?, ?, ?, ?, ?";
    }

    /**
     * Returns a completed prepared statement with parameters set up ready for
     * execution
     *
     * @param obj a Xmart Xml Map object containing the XML to be used in the
     *            prepared statement
     *
     * @return SQLServerPreparedStatement a JDBC driver class representing the
     * SQL Server prepared statement ready for execution
     */
    @Override
    public SQLServerPreparedStatement getPreparedStatement(Object obj) throws SQLException, XmartException {

        super.getPreparedStatement(obj);

        XmartGenericXmlSet transactionSetXml = (XmartGenericXmlSet) obj;

        preparedStatement.setObject(1, transactionSetXml.getEntityXml("XmartRdxInstruments"));
        preparedStatement.setObject(2, transactionSetXml.getEntityXml("XmartRdxInstrumentAliases"));
        preparedStatement.setObject(3, transactionSetXml.getEntityXml("XmartRdxInstrumentParties"));
        preparedStatement.setObject(4, transactionSetXml.getEntityXml("XmartRdxInstrumentMortgageFactorHistories"));
        preparedStatement.setObject(5, transactionSetXml.getEntityXml("XmartRdxInstrumentRatings"));
        preparedStatement.setObject(6, transactionSetXml.getEntityXml("XmartRdxInstrumentUnderwriters"));

        preparedStatement.addBatch();
        return preparedStatement;
    }
}
