package com.nwm.xmart.database.statement.kdb;

import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.exception.XmartException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;

/**
 * <p>
 * Sets up the prepare statement for the Stored Procedure usp_TdxTradeXmlInsert.
 * </p>
 * <p>
 * This class extends the XmartStatement class and sets up the command and
 * parameters for the prepare statement associated with this XML based stored
 * procedure.
 * </p>
 *
 * @author heskets
 */
public class KdbXmlInsertStatement extends XmartStatement {
    /**
     *
     */
    private static final long serialVersionUID = -395538314942462388L;
    private static final Logger logger = LoggerFactory.getLogger(KdbXmlInsertStatement.class);

    /**
     * Constructor class that initialises the prepared statement and the SQL
     * Server execute command..
     */
    public KdbXmlInsertStatement() {
        super();

        PROC_COMMAND = "EXEC [api].[usp_KdbXmlInsert] ?, ?, ?, ?, ?, ?";
    }

    /**
     * Returns a completed prepared statement with parameters set up ready for
     * execution
     *
     * @param obj a Xmart Xml Map object containing the XML to be used in the
     *            prepared statement
     *
     * @return SQLServerPreparedStatement a JDBC driver class representing the
     * SQL Server prepared statement ready for execution
     */
    @Override
    public SQLServerPreparedStatement getPreparedStatement(Object obj) throws SQLException, XmartException {

        super.getPreparedStatement(obj);

        XmartGenericXmlSet xmlXmlSet = (XmartGenericXmlSet) obj;

        int index = 1;

        preparedStatement.setObject(index++, xmlXmlSet.getEntityXml("XmartKdbInquiryHeaders"));
        preparedStatement.setObject(index++, xmlXmlSet.getEntityXml("XmartKdbInquiryLegs"));
        preparedStatement.setObject(index++, xmlXmlSet.getEntityXml("XmartKdbInquiryStates"));
        preparedStatement.setObject(index++, xmlXmlSet.getEntityXml("XmartKdbInquiryReferences"));
        preparedStatement.setObject(index++, xmlXmlSet.getEntityXml("XmartFactInquiryBestExecEligibilities"));
        preparedStatement.setObject(index++, xmlXmlSet.getEntityXml("XmartFactInquiryPreTradeTransparencyStatuses"));

        preparedStatement.addBatch();
        return preparedStatement;
    }
}
