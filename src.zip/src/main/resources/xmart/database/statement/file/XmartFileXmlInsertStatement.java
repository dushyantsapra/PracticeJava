package com.nwm.xmart.database.statement.file;

import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;
import com.nwm.xmart.database.statement.XmartStatement;
import com.nwm.xmart.entities.common.XmartGenericXmlSet;
import com.nwm.xmart.entities.file.XmartFileEventMetadata;
import com.nwm.xmart.exception.XmartException;

import java.sql.SQLException;
import java.util.Map;

import static java.util.Objects.isNull;

public class XmartFileXmlInsertStatement extends XmartStatement {

    public XmartFileXmlInsertStatement() {
        super();
        /**
         * [api].[usp_FilePayloadXmlInsert]
         * @pPayload XML = NULL,
         * @pPayloadHandlerName VARCHAR(200) ,
         * @pTotalRowCount INT ,
         * @FileLastModifiedAt DATETIME ,
         * @pFileExtractAuditId INT
         */
        PROC_COMMAND = "EXEC [api].[usp_FilePayloadXmlInsert] ?, ?, ?, ?, ?";
    }

    @Override
    public SQLServerPreparedStatement getPreparedStatement(Object obj) throws SQLException, XmartException {
        super.getPreparedStatement(obj);

        XmartGenericXmlSet genericXmlSetXml = (XmartGenericXmlSet) obj;
        for (Map.Entry<String, String> entry : genericXmlSetXml.getXmlEntityMap().entrySet()) {
            int index = 1;
            XmartFileEventMetadata eventMetadata = (XmartFileEventMetadata) genericXmlSetXml
                    .getMetadata(entry.getKey());
            if (isNull(eventMetadata)) {
                continue;
            }
            preparedStatement.setObject(index++, genericXmlSetXml.getEntityXml(entry.getKey()));
            preparedStatement.setObject(index++, eventMetadata.getFileHandler());
            preparedStatement.setObject(index++, eventMetadata.getRecordCount());
            preparedStatement.setObject(index++, eventMetadata.getBusinessDate());
            preparedStatement.setObject(index++, eventMetadata.getAuditId());

            preparedStatement.addBatch();
        }
        return preparedStatement;
    }
}

