package com.nwm.xmart.database.dao;

import com.nwm.xmart.exception.XmartException;
import org.apache.flink.api.java.utils.ParameterTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <p>Provides a data access layer to allow persisting data to the standard logger tool for use in testing and debug of the application.</p>
 * <p>The open and close methods perform no actions for this DAO. The write simply outputs a text version of the object to the logger.<p/>
 *
 * @author heskets
 */
public class LoggerDao implements XmartDao {

    private static final Logger logger = LoggerFactory.getLogger(LoggerDao.class);

    /**
     * Performs no actions for this DAO - to match interface only.
     *
     * @param parameters the flink ParamaterTool object holding the job nodes
     *
     * @throws XmartException When the open fails. For instance, if the method cannot connect to
     *                        the persistence layer.
     */
    @Override
    public void open(ParameterTool parameters) throws XmartException {
    }

    /**
     * Performs no actions for this DAO - to match interface only.
     */
    @Override
    public void close() {
        // no close required
    }

    /**
     * Writes the text returned by the toString method of the object to the logger at info level.
     *
     * @param o          the object to be written
     * @param parameters the flink ParamaterTool object holding the job nodes
     *
     * @throws XmartException To match interface - no errors checked.
     */
    @Override
    public Long write(Object o, ParameterTool parameters) throws XmartException {

        Long executeTime;

        logger.debug("Writing object of type {} to console using toString",
                parameters.get("operator.odc.transaction.datatype"));

        executeTime = System.nanoTime();

        if (logger.isInfoEnabled()) {

            logger.info(o.toString());
        }

        return executeTime;
    }
}
