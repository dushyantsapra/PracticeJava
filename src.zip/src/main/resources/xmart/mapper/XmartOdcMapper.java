package com.nwm.xmart.mapper;

import com.nwm.xmart.core.XmartODCSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.rbs.odc.access.domain.HasId;
import com.rbs.odc.access.domain.Id;
import com.rbs.odc.core.domain.ODCValue;
import org.apache.flink.api.common.accumulators.AverageAccumulator;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

public abstract class XmartOdcMapper<IdType extends Id, DomainObject extends HasId<? extends IdType>>
        extends RichMapFunction<DataFabricStreamEvent<ODCValue<IdType, DomainObject>>, XmartODCSet> {

    private static final long serialVersionUID = -8808066445516912845L;

    protected Boolean accumulatorsOn = false;
    protected int topicId;
    protected String jobName;
    protected String operatorName;
    protected Long startTime = null;
    protected IntCounter recordsProcessed = new IntCounter();
    protected AverageAccumulator avgRecordProcessTime = new AverageAccumulator();
    private ParameterTool parameters;

    public Boolean getAccumulatorsOn() {
        return accumulatorsOn;
    }

    public ParameterTool getParameters() {
        return parameters;
    }

    public int getTopicId() {
        return topicId;
    }

    public String getJobName() {
        return jobName;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public Long getStartTime() {
        return startTime;
    }

    public IntCounter getRecordsProcessed() {
        return recordsProcessed;
    }

    public AverageAccumulator getAvgRecordProcessTime() {
        return avgRecordProcessTime;
    }

    @Override
    public void open(Configuration config) throws XmartException {
        parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        putJobNameInMDC(parameters);
        logger().debug("Entering open()");

        topicId = parameters.getInt("flink.kafka.consumer.topic.ID");
        jobName = parameters.get("flink.job.name");
        operatorName = parameters.get("operator.mapper.name");

        accumulatorsOn = parameters.getBoolean("operator.monitoring.accumulators.enable", false);
        if (accumulatorsOn) {
            getRuntimeContext().addAccumulator("mapRecordsProcessed", recordsProcessed);
            getRuntimeContext().addAccumulator("mapAvgRecordProcessTime", avgRecordProcessTime);
        }
    }

    /**
     * Implementing clases should provide the {@link Logger} such that the log messages go in their name
     *
     * @return Looger instance created in the implementing classes.
     */
    public abstract Logger logger();
}
