package com.nwm.xmart.mapper.schedule_entries;

import com.nwm.xmart.bean.schedule_entries.domain.XmartODCScheduleEntries;
import com.nwm.xmart.entities.XmartTransactionSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.rbs.odc.access.domain.ScheduleEntry;
import org.apache.flink.api.common.accumulators.AverageAccumulator;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;
import static java.util.Objects.isNull;

public final class XmartScheduleEntriesOdcMapper
        extends RichMapFunction<DataFabricStreamEvent<XmartODCScheduleEntries>, XmartTransactionSet> {

    private static final long serialVersionUID = -7005332867338816285L;
    private static final Logger logger = LoggerFactory.getLogger(XmartScheduleEntriesOdcMapper.class);

    protected Boolean accumulatorsOn = false;
    protected int topicId;
    protected String jobName;
    protected Long startTime = null;
    protected IntCounter recordsProcessed = new IntCounter();
    protected AverageAccumulator avgRecordProcessTime = new AverageAccumulator();
    private String operatorName;
    private ParameterTool parameters;

    public Boolean getAccumulatorsOn() {
        return accumulatorsOn;
    }

    public ParameterTool getParameters() {
        return parameters;
    }

    public String getJobName() {
        return jobName;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public Long getStartTime() {
        return startTime;
    }

    public IntCounter getRecordsProcessed() {
        return recordsProcessed;
    }

    public AverageAccumulator getAvgRecordProcessTime() {
        return avgRecordProcessTime;
    }

    @Override
    public void open(Configuration config) throws XmartException {
        parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        putJobNameInMDC(parameters);
        logger.debug("Entering open()");

        topicId = parameters.getInt("flink.kafka.consumer.topic.ID");
        jobName = parameters.get("flink.job.name");
        operatorName = parameters.get("operator.mapper.name");

        accumulatorsOn = parameters.getBoolean("operator.monitoring.accumulators.enable", false);
        if (accumulatorsOn) {
            getRuntimeContext().addAccumulator("mapRecordsProcessed", recordsProcessed);
            getRuntimeContext().addAccumulator("mapAvgRecordProcessTime", avgRecordProcessTime);
        }
    }

    @Override
    public XmartTransactionSet map(DataFabricStreamEvent<XmartODCScheduleEntries> streamEvent) throws Exception {

        logger.debug("Entering map()");

        Long startTime = 0L;
        XmartTransactionSet xmartTransactionSet = new XmartTransactionSet();

        try {
            if (getAccumulatorsOn()) {
                startTime = System.nanoTime();
            }

            XmartODCScheduleEntries odcScheduleEntries = streamEvent.getEventPayload();
            Collection<ScheduleEntry> scheduleEntries = odcScheduleEntries.getChildData();

            if (isNull(scheduleEntries)) {
                logger.error("NULL ScheduleEntries received");
                throw new XmartException("NULL ScheduleEntries received");
            }

            logger.info("map: topicId {} source[ TimeStamp={}, Partition={}, Position={}] ", topicId,
                    streamEvent.getTimestamp(), streamEvent.getPartition(), streamEvent.getStreamPosition());

            xmartTransactionSet.addOdcAttribute(streamEvent, topicId);

            if (getAccumulatorsOn()) {
                getRecordsProcessed().add(1);
                getAvgRecordProcessTime().add(System.nanoTime() - startTime);
            }
        } catch (Exception e) {
            logger.error("Error mapping record", e);
            throw new XmartException("Error mapping record", e);
        }

        return xmartTransactionSet;
    }
}
