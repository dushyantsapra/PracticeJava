package com.nwm.xmart.mapper.common;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.exception.XmartException;
import org.apache.flink.api.common.accumulators.AverageAccumulator;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

public abstract class XmartMapper<T> extends RichMapFunction<T, XmartGenericSet> {

    private static final long serialVersionUID = -8808066445516912845L;

    protected Boolean accumulatorsOn = false;
    protected int jobId;
    protected String jobName;
    protected String operatorName;
    protected Long startTime = null;
    protected IntCounter recordsProcessed = new IntCounter();
    protected AverageAccumulator avgRecordProcessTime = new AverageAccumulator();
    protected ParameterTool parameters;

    public Boolean getAccumulatorsOn() {
        return accumulatorsOn;
    }

    public ParameterTool getParameters() {
        return parameters;
    }

    public int getTopicId() {
        return jobId;
    }

    public String getJobName() {
        return jobName;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public Long getStartTime() {
        return startTime;
    }

    public IntCounter getRecordsProcessed() {
        return recordsProcessed;
    }

    public AverageAccumulator getAvgRecordProcessTime() {
        return avgRecordProcessTime;
    }

    @Override
    public void open(Configuration config) throws XmartException {
        parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        putJobNameInMDC(parameters);
        logger().debug("Entering open()");

        jobId = parameters.getInt("flink.job.id");
        jobName = parameters.get("flink.job.name");
        operatorName = parameters.get("operator.mapper.name");

        accumulatorsOn = parameters.getBoolean("operator.monitoring.accumulators.enable", false);
        if (accumulatorsOn) {
            getRuntimeContext().addAccumulator("mapRecordsProcessed", recordsProcessed);
            getRuntimeContext().addAccumulator("mapAvgRecordProcessTime", avgRecordProcessTime);
        }
    }

    /**
     * Implementing clases should provide the {@link Logger} such that the log messages go in their name
     *
     * @return Looger instance created in the implementing classes.
     */
    public abstract Logger logger();
}
