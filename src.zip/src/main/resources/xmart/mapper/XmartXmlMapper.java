package com.nwm.xmart.mapper;

import com.nwm.xmart.core.XmartSet;
import com.nwm.xmart.core.XmartXmlSet;
import com.nwm.xmart.exception.XmartException;
import org.apache.flink.api.common.accumulators.AverageAccumulator;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;

import java.util.List;

import static com.nwm.xmart.util.ConfigParams.LOG_XML_PARAM;
import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

public abstract class XmartXmlMapper<IN extends XmartSet, OUT extends XmartXmlSet>
        extends RichMapFunction<List<IN>, OUT> {

    private static final long serialVersionUID = 6343504338985101285L;
    protected ParameterTool parameters;
    protected String jobName;
    protected IntCounter recordsProcessed;
    protected AverageAccumulator avgRecordProcessTime;
    protected Boolean accumulatorsOn;
    protected Boolean logEntityXml;
    private String operatorName;
    private int topicId;

    protected String getOperatorName() {
        return operatorName;
    }

    protected int getTopicId() {
        return topicId;
    }

    protected String getJobName() {
        return jobName;
    }

    @Override
    public void open(Configuration config) throws XmartException {
        putJobNameInMDC(config);
        logger().debug("Entering open()");
        recordsProcessed = new IntCounter();
        avgRecordProcessTime = new AverageAccumulator();
        accumulatorsOn = false;

        parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        topicId = parameters.getInt("flink.job.id");
        jobName = parameters.get("flink.job.name");
        operatorName = parameters.get("operator.mapper.name");
        logEntityXml = parameters.getBoolean(LOG_XML_PARAM, false);

        accumulatorsOn = parameters.getBoolean("operator.monitoring.accumulators.enable", false);
        if (accumulatorsOn) {
            getRuntimeContext().addAccumulator("xmlRecordsProcessed", recordsProcessed);
            getRuntimeContext().addAccumulator("xmlAvgRecordProcessTime", avgRecordProcessTime);
        }
    }

    /**
     * Gets the {@link Logger} from the implementing class. Very useful for collating logs
     *
     * @return Logger
     */
    protected abstract Logger logger();
}
