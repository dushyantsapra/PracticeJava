package com.nwm.xmart.mapper.mdx;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.mdx.XmartMdxDocumentEventSet;
import com.nwm.xmart.entities.common.XmartSessionMetadata;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.common.XmartMapper;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.streaming.source.mdx.event.MdxEventType;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XmartMdxMapper extends XmartMapper<MdxDocumentEvent> {
    private static final long serialVersionUID = -3815025350133699262L;
    private static final Logger logger = LoggerFactory.getLogger(XmartMdxMapper.class);

    protected MappingNode mappingHierarchy;

    @Override
    public Logger logger() {
        return logger;
    }

    @Override
    public void open(Configuration config) throws XmartException {
        super.open(config);
        mappingHierarchy = MappingNodeFactory.ReadResourceFile(parameters.get("operator.mapper.config.file"));
    }

    public XmartGenericSet map(MdxDocumentEvent mdxDocumentEvent) throws Exception {
        if (accumulatorsOn) {
            logger.debug("Entering map()");
            startTime = System.nanoTime();
        }

        if (mdxDocumentEvent.getMdxEventType() == MdxEventType.SERIES_VIEW) {
            if ("reference.regulatory.instrument".equals(mdxDocumentEvent.getSeriesTypeName())) {
                logger.info("map: MdxEventType {}, Identifier {}, version {}, MdxWriteTime {}",
                        mdxDocumentEvent.getMdxEventType().name(), mdxDocumentEvent.getIdentifier(),
                        mdxDocumentEvent.getRefRegInstrument().getMdxDocumentVersion(),
                        mdxDocumentEvent.getRefRegInstrument().getXmlWriteTime());
            } else if ("reference.regulatory".equals(mdxDocumentEvent.getSeriesTypeName())) {
                logger.info("map: MdxEventType {}, Identifier {}", mdxDocumentEvent.getMdxEventType().name(),
                        mdxDocumentEvent.getSeriesTypeName());
            } else {
                logger.info("map: MdxEventType {}, Series {}, Identifier {}, version {}, MdxWriteTime {}",
                        mdxDocumentEvent.getMdxEventType().name(), mdxDocumentEvent.getSeriesTypeName(),
                        mdxDocumentEvent.getIdentifier(), mdxDocumentEvent.getVersion(),
                        mdxDocumentEvent.getMdxDataStoreWriteTime());
            }
        } else if (mdxDocumentEvent.getMdxEventType() == MdxEventType.TIME_SERIES) {
            logger.info("map: MdxEventType {}, Identifier {}, version {}, MdxWriteTime {}",
                    mdxDocumentEvent.getMdxEventType().name(), mdxDocumentEvent.getIdentifier(),
                    mdxDocumentEvent.getTimeSeriesEsma().getMdxDocumentVersion(),
                    mdxDocumentEvent.getTimeSeriesEsma().getXmlWriteTime());
        }

        XmartGenericSet<MdxDocumentEvent> xmartSet = new XmartMdxDocumentEventSet();
        xmartSet.addStreamEvent(mdxDocumentEvent, jobId, mappingHierarchy);
        xmartSet.setMetadata(new XmartSessionMetadata(mdxDocumentEvent.getXmartSession()));

        if (accumulatorsOn) {
            this.recordsProcessed.add(1);
            this.avgRecordProcessTime.add(System.nanoTime() - startTime);
        }
        return xmartSet;
    }
}
