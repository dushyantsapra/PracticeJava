package com.nwm.xmart.mapper;

import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.common.XmartMapper;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import org.apache.flink.configuration.Configuration;

import static java.util.Objects.isNull;

/**
 * Class for providing the common functionality to the mappers using the configurable mappings.
 * Performs setup tasks such as getting the parameters and parsing the mapping hierarchy from the mapping csv file.
 * <br> file is read from the location as specified by the configuration parameter operator.mapper.config.file
 *
 * @param <T> The type of the object to be parsed from.
 */
public abstract class XmartGenericMapper<T> extends XmartMapper<T> {

    protected MappingNode mappingHierarchy;

    @Override
    public void open(Configuration config) throws XmartException {
        super.open(config);
        String mappingConfigCsv = parameters.get("operator.mapper.config.file", null);
        if (isNull(mappingConfigCsv)) {
            throw new XmartException(
                    "Mapping config file not specified in properties; define it as \'operator.mapper.config.file\' param");
        }

        mappingHierarchy = MappingNodeFactory.ReadResourceFile(mappingConfigCsv);
    }
}
