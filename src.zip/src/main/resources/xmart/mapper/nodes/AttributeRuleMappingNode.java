package com.nwm.xmart.mapper.nodes;

import com.nwm.xmart.entities.common.XmartMappedAttribute;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.SourceObjectUtil;

import java.util.List;

import static com.nwm.xmart.util.BusinessRulesUtil.isKdbNull;

/**
 * <p>
 * Provides a mechanism to apply business logic against a single attribute node and add the results to
 * an XmartEntity object.
 * </p>
 * <p>
 * This node will contain no child nodes.
 * </p>
 *
 * @author heskets
 */
public class AttributeRuleMappingNode extends MappingNode {

    private Boolean triggerAttribute;
    private Boolean outputAttribute;
    private Boolean keyAttribute;
    private String methodName;
    private String methodReturnType;

    AttributeRuleMappingNode(String[] stringNode) throws XmartException {

        super(stringNode);

        validateNode(stringNode);

        this.triggerAttribute = stringNode[9].equals("Y");
        this.outputAttribute = stringNode[10].equals("Y");
        this.keyAttribute = stringNode[11].equals("Y");
        this.methodName = stringNode[12];
        this.methodReturnType = stringNode[13];
    }

    private void validateNode(String[] stringNode) throws XmartException {

        if (stringNode.length < 13) {
            throw new XmartException("Invalid attribute mapping - insufficient number of elements in row");
        }

        if (stringNode[9].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - triggerAttribute is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }

        if (!(stringNode[9].equals("Y") || stringNode[9].equals("N"))) {
            throw new XmartException(
                    "Invalid mapping - triggerAttribute flag in mapping nodes not a valid value - element: "
                            + stringNode[4] + " " + stringNode[5] + " - " + stringNode[9]);
        }

        if (stringNode[10].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - outputAttribute is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }

        if (!(stringNode[10].equals("Y") || stringNode[10].equals("N"))) {
            throw new XmartException(
                    "Invalid mapping - outputAttribute flag in mapping nodes not a valid value - element: "
                            + stringNode[4] + " " + stringNode[5] + " - " + stringNode[10]);
        }

        if (stringNode[11].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - keyAttribute is not populated in mapping nodes - element: " + stringNode[4] + " "
                            + stringNode[5]);
        }

        if (!(stringNode[11].equals("Y") || stringNode[11].equals("N"))) {
            throw new XmartException(
                    "Invalid mapping - keyAttribute flag in mapping nodes not a valid value - element: " + stringNode[4]
                            + " " + stringNode[5] + " - " + stringNode[11]);
        }

        if (stringNode[12].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - methodName is not populated in mapping nodes - element: " + stringNode[4] + " "
                            + stringNode[5]);
        }

        if (stringNode[13].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - methodReturnType is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }
    }

    private Boolean isTriggerAttribute() {
        return triggerAttribute;
    }

    private Boolean isOutputAttribute() {
        return outputAttribute;
    }

    private Boolean isKeyAttribute() {
        return keyAttribute;
    }

    private String getMethodName() {
        return methodName;
    }

    private String getMethodReturnType() {
        return methodReturnType;
    }

    @Override
    public List<XmartMappedEntity> mapSourceObject(String rootObjectName, Object objectToMap,
            List<XmartMappedEntity> mappedEntities) throws XmartException {

        if (objectToMap == null) {
            throw new XmartException("Failure mapping attribute - objectToMap is null - element: " + getElementId() + ""
                    + getElementName());
        }

        Object attributeObj = SourceObjectUtil
                .applyAttributeMappingRule(objectToMap, getMethodName(), getMethodReturnType());

        if (!isKdbNull(attributeObj)) {
            XmartMappedAttribute attribute = new XmartMappedAttribute(getElementName(), attributeObj,
                    isMandatoryElement(), isTriggerAttribute(), isOutputAttribute(), isKeyAttribute());
            mappedEntities.forEach((entity) -> entity.addAttribute(attribute));
        } else {
            if (isMandatoryElement()) {
                throw new XmartException(
                        "Failure mapping attribute - missing mandatory attribute: " + getElementId() + " "
                                + getElementName());
            }
        }

        return mappedEntities;
    }

    @Override
    public String toString() {
        return "AttributeRuleMappingNode{" + "triggerAttribute=" + triggerAttribute + ", outputAttribute="
                + outputAttribute + ", keyAttribute=" + keyAttribute + ", methodName='" + methodName + '\''
                + ", methodReturnType='" + methodReturnType + '\'' + ", elementType='" + elementType + '\''
                + ", rootObjectName='" + rootObjectName + '\'' + ", elementCollection='" + elementCollection + '\''
                + ", elementGroup='" + elementGroup + '\'' + ", elementId=" + elementId + ", elementName='"
                + elementName + '\'' + ", parentElementId=" + parentElementId + ", parentElementName='"
                + parentElementName + '\'' + ", mandatoryElement=" + mandatoryElement + ", children=" + children + '}';
    }
}
