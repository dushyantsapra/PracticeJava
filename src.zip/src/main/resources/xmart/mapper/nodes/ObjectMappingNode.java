package com.nwm.xmart.mapper.nodes;

import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.SourceObjectUtil;

import java.lang.reflect.Method;
import java.util.List;

import static com.nwm.xmart.util.BusinessRulesUtil.isKdbNull;

/**
 * <p>
 * Provides an object mapping node to pull a single object from a source object and apply the relevant child mappings.
 * </p>
 * <p>
 * This node will contain a set of child mapping node (AttributeMappingNode, ObjectMappingNode and/or
 * CollectionMappingNode) objects that will  provide the next level of mapping for the single object
 * returned.
 * </p>
 *
 * @author heskets
 */
public class ObjectMappingNode extends MappingNode {

    private String methodName;
    private String methodReturnType;
    private Method methodReflectionMethod;
    private String methodAttributeName;

    /**
     * Standard constructor for core attributes of a mapping node - and the ObjectMappingNode specific
     * configuration.
     *
     * @param stringNode an array of strings containing the configuration of the required mapping node
     */
    ObjectMappingNode(String[] stringNode) throws XmartException {

        super(stringNode);

        validateNode(stringNode);

        this.methodName = stringNode[12];
        this.methodReturnType = stringNode[13];

        if (isSingleParameterisedMethod()) {
            this.methodAttributeName = stringNode[14];
        }
    }

    private void validateNode(String[] stringNode) throws XmartException {

        if (stringNode.length < 14) {
            throw new XmartException("Invalid object mapping - insufficient number of elements in row");
        }

        if (stringNode[12] == null || stringNode[12].isEmpty()) {
            throw new XmartException(
                    "Invalid object mapping - methodName is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }

        if (stringNode[13] == null || stringNode[13].isEmpty()) {
            throw new XmartException(
                    "Invalid object mapping - methodReturnType is not populated in mapping nodes - element: "
                            + stringNode[4] + " " + stringNode[5]);
        }
    }

    private String getMethodName() {
        return methodName;
    }

    private String getMethodReturnType() {
        return methodReturnType;
    }

    /**
     * For the supplied source object pull the sub-object using the method specified in the mapping.
     * Then loop through child mapping nodes as follows:
     * <p>
     * First go through any child attribute mapping nodes, adding the attributes pulled from the source object to
     * each of the input XmartMappedEntities.
     * Second go through any child object mapping nodes, pulling the lower level object and then iterating through
     * the next level of mapping nodes that apply.
     * Third go through any child collection mapping nodes, pulling the lower level object array, expanding the number
     * of XmartMappedEntities by the number of items in the collection and then, for each object in the array,
     * iterating through the next level of mapping nodes that apply.
     *
     * @param rootObjectName the name of the root object to ensure the correct mapping hierarchy is being applied
     * @param objectToMap    the source object from the source to which the child root mappings are to be applied
     * @param mappedEntities NULL for a top level mapping
     *
     * @return List<XmartMappedEntity> an updated list of XmartMappedEntities produced by applying this mapping
     * hierarchy level to the source object
     */
    @Override
    public List<XmartMappedEntity> mapSourceObject(String rootObjectName, Object objectToMap,
            List<XmartMappedEntity> mappedEntities) throws XmartException {

        if (objectToMap == null) {
            throw new XmartException("Failure mapping object - objectToMap is null - element: " + getElementId() + ""
                    + getElementName());
        }

        if (methodReflectionMethod == null) {

            //            SourceObjectUtil.getMappedObject(methodReflectionMethod, objectToMap, methodAttributeName, getMethodReturnType());
            methodReflectionMethod = SourceObjectUtil
                    .getMethod(objectToMap, getMethodName(), getMethodReturnType(), false, false,
                            isSingleParameterisedMethod(), false);
        }

        Object thisObject = null;
        if (!isSingleParameterisedMethod()) {
            thisObject = SourceObjectUtil.getObject(methodReflectionMethod, objectToMap);
        } else {
            thisObject = SourceObjectUtil
                    .getMappedObject(methodReflectionMethod, objectToMap, methodAttributeName, getMethodReturnType());
        }

        if (!isKdbNull(thisObject)) {

            for (MappingNode node : getChildAttributeNodes()) {
                if (rootObjectName.equals(node.getRootObjectName())) {
                    mappedEntities = node.mapSourceObject(rootObjectName, thisObject, mappedEntities);
                }
            }

            for (MappingNode node : getChildObjectNodes()) {
                if (rootObjectName.equals(node.getRootObjectName())) {
                    mappedEntities = node.mapSourceObject(rootObjectName, thisObject, mappedEntities);
                }
            }

            for (MappingNode node : getChildCollectionNodes()) {
                if (rootObjectName.equals(node.getRootObjectName())) {
                    mappedEntities = node.mapSourceObject(rootObjectName, thisObject, mappedEntities);
                }
            }

            for (MappingNode node : getChildBusinessRuleNodes()) {
                if (rootObjectName.equals(node.getRootObjectName())) {
                    mappedEntities = node.mapSourceObject(rootObjectName, objectToMap, mappedEntities);
                }
            }
        } else {
            if (isMandatoryElement()) {
                throw new XmartException("Failure mapping object - missing mandatory object: " + getElementId() + " "
                        + getElementName());
            }
        }

        return mappedEntities;
    }

    private Boolean isSingleParameterisedMethod() {
        return getMethodName() != null && (getMethodName().equals("getNodeAt") || getMethodName().equals("getNodesAt")
                || getMethodName().equals("getNodeUsingQuery") || getMethodName().equals("getObjectNode"));
    }

    @Override
    public String toString() {
        return "ObjectMappingNode{" + "methodName='" + methodName + '\'' + ", methodReturnType='" + methodReturnType
                + '\'' + ", methodReflectionMethod=" + methodReflectionMethod + ", elementType='" + elementType + '\''
                + ", rootObjectName='" + rootObjectName + '\'' + ", elementCollection='" + elementCollection + '\''
                + ", elementGroup='" + elementGroup + '\'' + ", elementId=" + elementId + ", elementName='"
                + elementName + '\'' + ", parentElementId=" + parentElementId + ", parentElementName='"
                + parentElementName + '\'' + ", mandatoryElement=" + mandatoryElement + ", children=" + children + '}';
    }
}
