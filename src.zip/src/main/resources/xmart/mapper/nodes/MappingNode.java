package com.nwm.xmart.mapper.nodes;

import com.nwm.xmart.core.BindObject;
import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.enums.MappingElementTypeEnum;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * An abstract class providing the core functionality for a mapping node to be extended by more specific
 * mapping node types.
 * </p>
 * <p>
 * This class provides the code functionality for managing a node in the mapping hierarchy including
 * management of child / parent relationship, core info on the mapping hierarchy and
 * whether this node is mandatory.
 * </p>
 *
 * @author heskets
 */
public abstract class MappingNode implements BindObject {

    final List<MappingNode> children = new ArrayList<>();
    String elementType;
    String rootObjectName;
    String elementCollection;
    String elementGroup;
    Integer elementId;
    String elementName;
    Integer parentElementId;
    String parentElementName;
    Boolean mandatoryElement;

    /**
     * Default constructor - used for the fixed TopMappingNode only
     */
    protected MappingNode() {
        // no default constructor
    }

    /**
     * Standard constructor for core attributes of a mapping node
     *
     * @param stringNode an array of strings containing the configuration of the required mapping node
     */
    protected MappingNode(String[] stringNode) throws XmartException {

        validateNode(stringNode);

        this.elementType = stringNode[0];
        this.rootObjectName = stringNode[1];
        this.elementCollection = stringNode[2];
        this.elementGroup = stringNode[3];
        this.elementId = Integer.parseInt(stringNode[4]);
        this.elementName = stringNode[5];
        if (this.elementType.equals(MappingElementTypeEnum.root.name())) {
            this.parentElementId = 0;
            this.parentElementName = "top";
        } else {
            this.parentElementId = Integer.parseInt(stringNode[6]);
            this.parentElementName = stringNode[7];
        }
        this.mandatoryElement = stringNode[8].equals("Y");
    }

    /**
     * Method that adds a child node if it is a direct child or tries to add it to the existing child nodes
     * if not.
     *
     * @param childNode the childNode that is to be added to the hierarchy
     */
    public Boolean addChildNode(MappingNode childNode) throws XmartException {

        if (!elementGroup.equals(childNode.getElementGroup()) || !rootObjectName
                .equals(childNode.getRootObjectName())) {

            return false;
        }

        if (elementId.equals(childNode.getParentElementId())) {

            if (!elementName.equals(childNode.getParentElementName())) {
                throw new XmartException(
                        "Child parent ID matched, but names do not match - " + elementName + ":" + childNode
                                .getParentElementName());
            }

            children.add(childNode);

            return true;
        }

        for (MappingNode node : children) {

            if (node.addChildNode(childNode)) {
                return true;
            }
        }

        return false;
    }

    private void validateNode(String[] stringNode) throws XmartException {

        if (stringNode.length < 9) {
            throw new XmartException("Invalid mapping - insufficient number of elements in row");
        }

        if (stringNode[1] == null || stringNode[1].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - topLevelObjectName is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }

        if (stringNode[2] == null || stringNode[2].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - elementCollection is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }

        if (stringNode[3] == null || stringNode[3].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - elementGroup is not populated in mapping nodes - element: " + stringNode[4] + " "
                            + stringNode[5]);
        }

        if (stringNode[4] == null || stringNode[4].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - elementId is not populated in mapping nodes - element: " + stringNode[3] + " "
                            + stringNode[3]);
        }

        if (stringNode[5] == null || stringNode[5].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - elementName is not populated in mapping nodes - element: " + stringNode[4] + " "
                            + stringNode[5]);
        }

        if (!stringNode[0].equals(MappingElementTypeEnum.root.name()) && (stringNode[6] == null || stringNode[6]
                .isEmpty())) {
            throw new XmartException(
                    "Invalid mapping - parentElementId is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }

        if (!stringNode[0].equals(MappingElementTypeEnum.root.name()) && (stringNode[7] == null || stringNode[7]
                .isEmpty())) {
            throw new XmartException(
                    "Invalid mapping - parentElementName is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }

        if (stringNode[8] == null || stringNode[8].isEmpty()) {
            throw new XmartException(
                    "Invalid mapping - mandatoryElement is not populated in mapping nodes - element: " + stringNode[4]
                            + " " + stringNode[5]);
        }

        if (!(stringNode[8].equals("Y") || stringNode[8].equals("N"))) {
            throw new XmartException(
                    "Invalid mapping - mandatoryElement flag in mapping nodes not a valid value - element: "
                            + stringNode[4] + " " + stringNode[5] + " - " + stringNode[8]);
        }
    }

    String getElementType() {
        return elementType;
    }

    String getRootObjectName() {
        return rootObjectName;
    }

    String getElementGroup() {
        return elementGroup;
    }

    String getElementCollection() {
        return elementCollection;
    }

    Integer getElementId() {
        return elementId;
    }

    String getElementName() {
        return elementName;
    }

    Integer getParentElementId() {
        return parentElementId;
    }

    String getParentElementName() {
        return parentElementName;
    }

    Boolean isMandatoryElement() {
        return mandatoryElement;
    }

    Collection<MappingNode> getChildNodes() {
        return children;
    }

    Collection<MappingNode> getChildRootNodes() {
        return children.stream().filter(child -> child.getElementType().equals(MappingElementTypeEnum.root.name()))
                       .collect(Collectors.toList());
    }

    Collection<MappingNode> getChildAttributeNodes() {
        return children.stream().filter(child -> child.getElementType().equals(MappingElementTypeEnum.attribute.name()))
                       .collect(Collectors.toList());
    }

    Collection<MappingNode> getChildModifiedAttributeNodes() {
        return children.stream()
                       .filter(child -> child.getElementType().equals(MappingElementTypeEnum.attribute_rule.name()))
                       .collect(Collectors.toList());
    }

    Collection<MappingNode> getChildObjectNodes() {
        return children.stream().filter(child -> child.getElementType().equals(MappingElementTypeEnum.object.name()))
                       .collect(Collectors.toList());
    }

    Collection<MappingNode> getChildCollectionNodes() {
        return children.stream()
                       .filter(child -> child.getElementType().equals(MappingElementTypeEnum.collection.name()))
                       .collect(Collectors.toList());
    }

    Collection<MappingNode> getChildBusinessRuleNodes() {
        return children.stream()
                       .filter(child -> child.getElementType().equals(MappingElementTypeEnum.business_rule.name()))
                       .collect(Collectors.toList());
    }

    /**
     * For the specified object apply the matching mapping hierarchy, adding any required attributes to the
     * input mappedEntities and returning the updated set of entities.
     *
     * @param rootObjectName the name of the root object to ensure the correct mapping hierarchy is being applied
     * @param objectToMap    the source object (or element / sub object) from the source to which the mapping is to be applied
     * @param mappedEntities the current state of the mapped Xmart Entities reached at this level of the mapping
     *
     * @return List<XmartMappedEntity> an updated list of XmartMappedEntities produced by applying this mapping
     * hierarchy level to the source object
     */
    public abstract List<XmartMappedEntity> mapSourceObject(String rootObjectName, Object objectToMap,
            List<XmartMappedEntity> mappedEntities) throws XmartException;
}
