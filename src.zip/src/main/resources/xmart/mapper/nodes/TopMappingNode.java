package com.nwm.xmart.mapper.nodes;

import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.util.enums.MappingElementTypeEnum;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * Provides a top node from which to start a mapping hierarchy.
 * </p>
 * <p>
 * This node will contain a set of root nodes each of which will define the mappings for a specific flattened structure
 * to be passed to the XMart database
 * </p>
 *
 * @author heskets
 */
public class TopMappingNode extends MappingNode {

    /**
     * Default constructor - used to set up a standard fixed TopMappingNode
     */
    TopMappingNode() {
        super();

        this.elementType = "top";
        this.rootObjectName = "top";
        this.elementCollection = "top";
        this.elementGroup = "top";
        this.elementId = 0;
        this.elementName = "top";
        this.parentElementId = null;
        this.parentElementName = null;
        this.mandatoryElement = true;
    }

    /**
     * Method that adds a child node if it is a root node or tries to add it to the existing root nodes
     * if not.
     *
     * @param childNode the childNode that is to be added to the hierarchy
     */
    @Override
    public Boolean addChildNode(MappingNode childNode) throws XmartException {

        if (childNode.getElementType().equals(MappingElementTypeEnum.root.name())) {

            children.add(childNode);

            return true;
        } else {

            for (MappingNode node : children) {
                if (node.addChildNode(childNode)) {
                    return true;
                }
            }

            throw new XmartException(
                    "Failed to add hierarchy node - element: " + childNode.getElementId() + " " + childNode
                            .getElementName());
        }
    }

    /**
     * For the specified object apply the child root mappings where the rootObjectNames match. Each root mapping will
     * apply the mapping hierarchy, adding any required attributes to the input mappedEntities and returning the
     * updated set of entities. This top mapping node merges all those entities into a single list.
     *
     * @param rootObjectName        the name of the root object to ensure the correct mapping hierarchy is being applied
     * @param objectToMap           the source object from the source to which the child root mappings are to be applied
     * @param initialMappedEntities NULL for a top level mapping
     *
     * @return List<XmartMappedEntity> an updated list of XmartMappedEntities produced by applying this mapping
     * hierarchy level to the source object
     */
    @Override
    public List<XmartMappedEntity> mapSourceObject(String rootObjectName, Object objectToMap,
            List<XmartMappedEntity> initialMappedEntities) throws XmartException {

        List<XmartMappedEntity> returnMappedEntities = new ArrayList<>();
        List<XmartMappedEntity> nodeInitialMappedEntities;

        for (MappingNode node : getChildRootNodes()) {
            if (rootObjectName.equals(node.getRootObjectName())) {

                XmartMappedEntity initialXmartMappedEntity = new XmartMappedEntity(node.getElementCollection(),
                        node.getElementGroup());

                nodeInitialMappedEntities = new ArrayList<>();

                nodeInitialMappedEntities.add(initialXmartMappedEntity);

                returnMappedEntities
                        .addAll(node.mapSourceObject(rootObjectName, objectToMap, nodeInitialMappedEntities));
            }
        }

        return returnMappedEntities;
    }

    @Override
    public String toString() {
        return "TopMappingNode{" + "elementType='" + elementType + '\'' + ", rootObjectName='" + rootObjectName + '\''
                + ", elementCollection='" + elementCollection + '\'' + ", elementGroup='" + elementGroup + '\''
                + ", elementId=" + elementId + ", elementName='" + elementName + '\'' + ", parentElementId="
                + parentElementId + ", parentElementName='" + parentElementName + '\'' + ", mandatoryElement="
                + mandatoryElement + ", children=" + children + '}';
    }
}
