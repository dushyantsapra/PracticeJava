package com.nwm.xmart.mapper.nodes;

import com.nwm.xmart.entities.common.XmartMappedEntity;
import com.nwm.xmart.exception.XmartException;

import java.util.List;

/**
 * <p>
 * Provides a root node from which to start a mapping hierarchy.
 * </p>
 * <p>
 * This node will contain a set of object / attribute / collection child nodes each of which will define the mappings for the specific flattened structure
 * to be passed to the XMart database
 * </p>
 *
 * @author heskets
 */
public class RootMappingNode extends MappingNode {

    /**
     * Standard constructor for core attributes of a mapping node - no additional set up beyond that in the
     * MappingNode super class
     *
     * @param stringNode an array of strings containing the configuration of the required mapping node
     */
    RootMappingNode(String[] stringNode) throws XmartException {

        super(stringNode);
    }

    /**
     * For the specified object apply the child root mappings where the rootObjectNames match.
     * <p>
     * First go through any child attribute mapping nodes, adding the attributes pulled from the source object to
     * each of the input XmartMappedEntities.
     * Second go through any child object mapping nodes, pulling the lower level object and then iterating through
     * the next level of mapping nodes that apply.
     * Third go through any child collection mapping nodes, pulling the lower level object array, expanding the number
     * of XmartMappedEntities by the number of items in the collection and then, for each object in the array,
     * iterating through the next level of mapping nodes that apply.
     *
     * @param rootObjectName the name of the root object to ensure the correct mapping hierarchy is being applied
     * @param objectToMap    the source object from the source to which the child root mappings are to be applied
     * @param mappedEntities NULL for a top level mapping
     *
     * @return List<XmartMappedEntity> an updated list of XmartMappedEntities produced by applying this mapping
     * hierarchy level to the source object
     */
    @Override
    public List<XmartMappedEntity> mapSourceObject(String rootObjectName, Object objectToMap,
            List<XmartMappedEntity> mappedEntities) throws XmartException {

        for (MappingNode node : getChildAttributeNodes()) {
            if (rootObjectName.equals(node.getRootObjectName())) {
                mappedEntities = node.mapSourceObject(rootObjectName, objectToMap, mappedEntities);
            }
        }

        for (MappingNode node : getChildObjectNodes()) {
            if (rootObjectName.equals(node.getRootObjectName())) {
                mappedEntities = node.mapSourceObject(rootObjectName, objectToMap, mappedEntities);
            }
        }

        for (MappingNode node : getChildCollectionNodes()) {
            if (rootObjectName.equals(node.getRootObjectName())) {
                mappedEntities = node.mapSourceObject(rootObjectName, objectToMap, mappedEntities);
            }
        }

        for (MappingNode node : getChildBusinessRuleNodes()) {
            if (rootObjectName.equals(node.getRootObjectName())) {
                mappedEntities = node.mapSourceObject(rootObjectName, objectToMap, mappedEntities);
            }
        }

        return mappedEntities;
    }

    @Override
    public String toString() {
        return "RootMappingNode{" + "elementType='" + elementType + '\'' + ", rootObjectName='" + rootObjectName + '\''
                + ", elementCollection='" + elementCollection + '\'' + ", elementGroup='" + elementGroup + '\''
                + ", elementId=" + elementId + ", elementName='" + elementName + '\'' + ", parentElementId="
                + parentElementId + ", parentElementName='" + parentElementName + '\'' + ", mandatoryElement="
                + mandatoryElement + ", children=" + children + '}';
    }
}
