package com.nwm.xmart.mapper;

import com.nwm.xmart.entities.argon.XmartArgonEventSet;
import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.common.XmartMapper;
import com.nwm.xmart.mapper.file.XmartFileMapper;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.source.argon.XmartArgonEvent;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

public class XmartArgonMapper extends XmartMapper<XmartArgonEvent> {
    private static final long serialVersionUID = 1840368311799171161L;
    private static final Logger logger = LoggerFactory.getLogger(XmartFileMapper.class);
    protected MappingNode mappingHierarchy;

    @Override
    public Logger logger() {
        return logger;
    }

    @Override
    public void open(Configuration config) throws XmartException {
        super.open(config);
        parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
    }

    public XmartGenericSet map(XmartArgonEvent xmartArgonEvent) throws Exception {
        putJobNameInMDC(parameters);

        if (accumulatorsOn) {
            logger.debug("Entering map()");
            startTime = System.nanoTime();
        }

        logger.info("Processing Argon event {}", xmartArgonEvent);

        XmartGenericSet xmartSet = new XmartArgonEventSet();
        xmartSet.addStreamEvent(xmartArgonEvent, jobId, null);

        if (accumulatorsOn) {
            this.recordsProcessed.add(1);
            this.avgRecordProcessTime.add(System.nanoTime() - startTime);
        }
        return xmartSet;
    }
}

