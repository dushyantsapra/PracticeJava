package com.nwm.xmart.mapper;

import com.nwm.xmart.entities.XmartTransactionSet;
import org.apache.flink.streaming.api.windowing.triggers.Trigger;
import org.apache.flink.streaming.api.windowing.triggers.TriggerResult;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;

/**
 * Created by heskets on 20/10/2017.
 */
public class TimeCountTrigger extends Trigger<XmartTransactionSet, TimeWindow> {
    /**
     *
     */
    private static final long serialVersionUID = 5432023132829802658L;

    private int count;
    private int maxCount;

    public TimeCountTrigger(int maxCount) {
        this.maxCount = maxCount;
    }

    @Override
    public TriggerResult onElement(XmartTransactionSet element, long timestamp, TimeWindow window, TriggerContext ctx)
            throws Exception {

        TriggerResult result = TriggerResult.CONTINUE;

        count++;

        if (count >= maxCount) {
            count = 0;
            result = TriggerResult.FIRE_AND_PURGE;
        }

        return result;
    }

    @Override
    public TriggerResult onProcessingTime(long time, TimeWindow window, TriggerContext ctx) throws Exception {

        TriggerResult result = TriggerResult.CONTINUE;

        if (count > 0) {
            result = TriggerResult.FIRE_AND_PURGE;
        }

        return result;
    }

    @Override
    public TriggerResult onEventTime(long time, TimeWindow window, TriggerContext ctx) throws Exception {
        return TriggerResult.CONTINUE;
    }

    @Override
    public void clear(TimeWindow window, TriggerContext ctx) throws Exception {

    }
}
