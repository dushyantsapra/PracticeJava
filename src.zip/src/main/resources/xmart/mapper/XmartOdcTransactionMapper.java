package com.nwm.xmart.mapper;

import com.nwm.xmart.entities.XmartTransactionSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.rbs.odc.access.domain.Transaction;
import com.rbs.odc.access.domain.TransactionId;
import com.rbs.odc.core.domain.ODCValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static java.util.Objects.isNull;

/**
 * Created by aslammh on 07/08/17.
 */
public class XmartOdcTransactionMapper extends XmartOdcMapper<TransactionId, Transaction> {

    private static final long serialVersionUID = -3815025350133699262L;
    private static final Logger logger = LoggerFactory.getLogger(XmartOdcTransactionMapper.class);

    @Override
    public Logger logger() {
        return logger;
    }

    @Override
    public XmartTransactionSet map(DataFabricStreamEvent<ODCValue<TransactionId, Transaction>> odcValueSourceEvent)
            throws Exception {
        logger.debug("Entering map()");

        XmartTransactionSet xmartTransaction = new XmartTransactionSet();

        // This is how you throw any error...MUST ONLY USE THE RAW BYTES don't provide a class to store for ODC
        try {

            if (accumulatorsOn) {
                startTime = System.nanoTime();
            }

            Transaction odcTransaction = odcValueSourceEvent.getEventPayload().getDomainObject();
            Long odcVersion = odcValueSourceEvent.getEventPayload().getOdcVersion();

            if (isNull(odcTransaction)) {
                logger.error("NULL transaction received");
                throw new XmartException("NULL transaction received");
            }

            logger.info("map: agreementDate {} topicId {} source[ TimeStamp={}, Partition={}, Position={}]",
                    odcTransaction.getAgreementDate(), topicId, odcValueSourceEvent.getTimestamp(),
                    odcValueSourceEvent.getPartition(), odcValueSourceEvent.getStreamPosition());

            xmartTransaction
                    .addOdcAttribute(odcValueSourceEvent.getTopic(), odcValueSourceEvent.getPartition(), topicId,
                            odcValueSourceEvent.getStreamPosition(), odcValueSourceEvent.getTimestamp(), odcTransaction,
                            odcValueSourceEvent, odcVersion);

            logger.trace("Mapping transaction - {}", xmartTransaction.toString());

            if (accumulatorsOn) {
                recordsProcessed.add(1);
                avgRecordProcessTime.add(System.nanoTime() - startTime);
            }
        } catch (Exception e) {
            logger.error("Error mapping record", e);
            throw new XmartException("Error mapping record", e);
        }

        return xmartTransaction;
    }
}
