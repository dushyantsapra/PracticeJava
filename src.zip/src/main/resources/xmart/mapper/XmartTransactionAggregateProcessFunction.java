package com.nwm.xmart.mapper;

import com.nwm.xmart.entities.XmartTransactionSet;
import com.nwm.xmart.exception.XmartException;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Extending class to {@link XmartAggregateProcessFunction}<br> overrides nothing currently, but can do so in future.
 *
 * <br> Marker Class :)
 */
public class XmartTransactionAggregateProcessFunction extends XmartAggregateProcessFunction<XmartTransactionSet> {
    private static final Logger logger = LoggerFactory.getLogger(XmartTransactionAggregateProcessFunction.class);
    private static final long serialVersionUID = 6597431779129958386L;

    @Override
    public void processElement(XmartTransactionSet xmartTransactionSet, Context ctx,
            Collector<List<XmartTransactionSet>> out) throws Exception {

        if (getAccumulatorsOn()) {
            setStartTime(System.nanoTime());
        }

        if (getWindowCount() == 0) {
            // schedule the next timer the specified number of milliseconds from the current process time
            ctx.timerService()
               .registerProcessingTimeTimer(ctx.timerService().currentProcessingTime() + getMaxWindowTime());
        }

        try {
            if (xmartTransactionSet != null) {
                getAccumulatorSet().add(xmartTransactionSet);
            } else {
                logger.error("Error - ignored NULL record in window function - failure in previous operator.");
            }
        } catch (Exception e) {
            logger.error("Error aggregating record", e);
            throw new XmartException("Error aggregating record", e);
        }

        setWindowCount(getWindowCount() + 1);

        if (getWindowCount() >= getMaxWindowCount()) {
            if (getAccumulatorsOn()) {
                this.getRecordsProcessed().add(getAccumulatorSet().size());
                this.getWindowsProcessed().add(1);
            }
            accumulateElements(out);
            setWindowCount(0);
        }

        if (getAccumulatorsOn()) {
            this.getAvgRecordProcessTime().add(System.nanoTime() - getStartTime());
        }
    }

    @Override
    public Logger getLogger() {
        return logger;
    }
}
