package com.nwm.xmart.mapper.file;

import com.nwm.xmart.entities.common.XmartGenericSet;
import com.nwm.xmart.entities.file.XmartFileEventSet;
import com.nwm.xmart.exception.XmartException;
import com.nwm.xmart.mapper.common.XmartMapper;
import com.nwm.xmart.mapper.nodes.MappingNode;
import com.nwm.xmart.mapper.nodes.MappingNodeFactory;
import com.nwm.xmart.source.file.event.FileEvent;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

public class XmartFileMapper extends XmartMapper<FileEvent> {
    private static final long serialVersionUID = 1840368311799171161L;
    private static final Logger logger = LoggerFactory.getLogger(XmartFileMapper.class);
    protected MappingNode mappingHierarchy;

    @Override
    public Logger logger() {
        return logger;
    }

    @Override
    public void open(Configuration config) throws XmartException {
        super.open(config);
        parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        putJobNameInMDC(parameters);

        mappingHierarchy = MappingNodeFactory.ReadResourceFile(parameters.get("operator.mapper.config.file", null));
    }

    public XmartGenericSet map(FileEvent fileEvent) throws Exception {
        putJobNameInMDC(parameters);

        if (accumulatorsOn) {
            logger.debug("Entering map()");
            startTime = System.nanoTime();
        }

        logger.info("Processing file event {}", fileEvent);

        XmartGenericSet xmartSet = new XmartFileEventSet();
        xmartSet.addStreamEvent(fileEvent, jobId, mappingHierarchy);
        //Adding file metadata here, could not be done from the mappings as the
        xmartSet.setMetadata(fileEvent.getFileMetadata());

        if (accumulatorsOn) {
            this.recordsProcessed.add(1);
            this.avgRecordProcessTime.add(System.nanoTime() - startTime);
        }
        return xmartSet;
    }
}
