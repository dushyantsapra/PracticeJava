package com.nwm.xmart.streaming.source.rdx.subscription;

import com.nwm.xmart.streaming.source.rdx.exception.RdxSubscriptionException;
import com.nwm.xmart.streaming.source.rdx.query.RdxSubscriptionCriteriaBuilder;
import com.nwm.xmart.streaming.source.rdx.session.RDXSessionContext;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import rbs.gbm.mdx.messaging.IReferenceDataChangeHandler;

import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created by gardlex on 21/05/2018.
 */
public interface RdxSubscription<RdxSourceEvent> extends IReferenceDataChangeHandler {
    RdxSubscription withApplicationSubscriptionName(String applicationSubscriptionName);
    void startCachingSubscriptionEvents();
    void close();
    RdxSubscription withSourceFunction(SourceFunction<RdxSourceEvent> sourceFunction);
    ReentrantLock getSubscriptionLock();
    RdxSubscription withInitialCapacity(int capacity);
    RdxSourceEvent getNextRdxEvent() throws RdxSubscriptionException;
    RdxSubscription setISINList(Set<String> isinList);
    RdxSubscription withRDXSession(RDXSessionContext rdxSession);
    RdxSubscription withRdxSubscriptionCriteriaBuilder(RdxSubscriptionCriteriaBuilder rdxSubscriptionCriteriaBuilder);
    void setStartChangeID(long changeID);
}
