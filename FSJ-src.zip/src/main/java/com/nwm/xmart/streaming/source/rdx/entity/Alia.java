
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AliasType",
    "AliasValue",
    "StartDate",
    "EndDate"
})
public class Alia {

    @JsonProperty("AliasType")
    private String aliasType;
    @JsonProperty("AliasValue")
    private String aliasValue;
    @JsonProperty("StartDate")
    private String startDate;
    @JsonProperty("EndDate")
    private String endDate;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("AliasType")
    public String getAliasType() {
        return aliasType;
    }

    @JsonProperty("AliasType")
    public void setAliasType(String aliasType) {
        this.aliasType = aliasType;
    }

    @JsonProperty("AliasValue")
    public String getAliasValue() {
        return aliasValue;
    }

    @JsonProperty("AliasValue")
    public void setAliasValue(String aliasValue) {
        this.aliasValue = aliasValue;
    }

    @JsonProperty("StartDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("StartDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    @JsonProperty("EndDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("EndDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("aliasType", aliasType).append("aliasValue", aliasValue).append("startDate", startDate).append("endDate", endDate).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(aliasValue).append(additionalProperties).append(endDate).append(startDate).append(aliasType).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Alia) == false) {
            return false;
        }
        Alia rhs = ((Alia) other);
        return new EqualsBuilder().append(aliasValue, rhs.aliasValue).append(additionalProperties, rhs.additionalProperties).append(endDate, rhs.endDate).append(startDate, rhs.startDate).append(aliasType, rhs.aliasType).isEquals();
    }

}
