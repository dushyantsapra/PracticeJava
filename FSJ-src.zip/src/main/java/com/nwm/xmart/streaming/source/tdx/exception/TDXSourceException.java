package com.nwm.xmart.streaming.source.tdx.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class TDXSourceException extends RuntimeException {

    public TDXSourceException() {
        super();
    }

    public TDXSourceException(String msg) {
        super(msg);
    }

    public TDXSourceException(String msg, Throwable t) {
        super(msg, t);
    }
}
