package com.nwm.xmart.streaming.source.kdb.parameters;

import com.nwm.xmart.streaming.database.SqlServerConnectionDetails;
import com.nwm.xmart.streaming.database.dao.SqlServerDao;
import com.nwm.xmart.streaming.database.exceptions.XmartSqlServerException;
import com.nwm.xmart.streaming.database.statements.StatementParameters;
import com.nwm.xmart.streaming.database.statements.XmartStatement;
import com.nwm.xmart.streaming.database.statements.kdb.KdbLastRunReadStatement;
import com.nwm.xmart.streaming.source.kdb.data.KDBProcessingMode;
import com.nwm.xmart.streaming.source.kdb.exception.KDBParameterException;
import com.nwm.xmart.streaming.source.kdb.exception.RepairDateParsingException;
import com.nwm.xmart.streaming.source.kdb.data.ProcessingDays;
import com.nwm.xmart.streaming.source.kdb.data.RepairDatesPropertyParser;
import com.nwm.xmart.streaming.source.kdb.exception.FunctionParameterParsingException;
import com.nwm.xmart.streaming.source.kdb.exception.InvalidDefaultRunDateException;
import com.nwm.xmart.streaming.database.exceptions.SqlServerConnectorException;
import org.apache.flink.api.java.utils.ParameterTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by gardlex on 12/06/2018.
 */
public class DateParameterUtil {
    private static Logger logger = LoggerFactory.getLogger(DateParameterUtil.class);
    private static final String DEFAULT_START_DATE = "DEFAULT_OPERATIONAL_DATE";


    public static boolean validateDateRange(String startDate, String endDate) {
        LocalDate localStartDate = LocalDate.parse(startDate.replaceAll("\\.", "-"));
        LocalDate localEndDate = LocalDate.parse(endDate.replaceAll("\\.", "-"));

        return (localEndDate.isAfter(localStartDate) || (localEndDate.isEqual(localStartDate)));
    }

    public static boolean isSameDate(String startDate, String endDate) {
        String startDateFormatted = startDate.replaceAll("\\.", "-");
        String endDateFormatted = endDate.replaceAll("\\.", "-");

        LocalDate localStartDate = LocalDate.parse(startDateFormatted);
        LocalDate localEndDate = LocalDate.parse(endDateFormatted);

        return (localEndDate.isEqual(localStartDate));
    }

//    public static

    public static List<String> getDaysToLoad(String startDate, String endDate) {
        LocalDate localStartDate = LocalDate.parse(startDate.replaceAll("\\.", "-"));
        LocalDate localEndDate = LocalDate.parse(endDate.replaceAll("\\.", "-"));
        if (!validateDateRange(getKDBDateFromLOcalDate(localStartDate), getKDBDateFromLOcalDate(localEndDate))) {
            throw new KDBParameterException("Invalid date Range specified, startDate [ " + startDate + " ], endDate [ " + endDate + " ]");
        }

        long daysBetween = java.time.temporal.ChronoUnit.DAYS.between(localStartDate, localEndDate);
        List<String> daysToLoadList = new ArrayList<>();

        if (daysBetween == 0) {
            daysToLoadList.add(startDate);
            return daysToLoadList;
        }

        if (daysBetween > 0) {
            LocalDate currentDate = localStartDate;
            daysToLoadList.add(localStartDate.toString().replaceAll("-", "."));

            for (int x=0; x < (daysBetween); x++) {
                currentDate = currentDate.plusDays(1);
                daysToLoadList.add(currentDate.toString().replaceAll("-", "."));
            }
        }

        return daysToLoadList;
    }

    public static LocalDate getLocalDateFor(String date) {
        return LocalDate.parse(date.replaceAll("\\.", "-"));
    }

    public static ProcessingDays getProcessingDays(ParameterTool params, Map<String, String> functionParameters)
            throws XmartSqlServerException {
        return getProcessingDays(params, functionParameters, null);
    }

    public static ProcessingDays getProcessingDays(ParameterTool params, Map<String, String> functionParameters, String functionName)
            throws XmartSqlServerException {

        String mode = params.get("kdb.mode", "");
        logger.debug("Kdb mode = " + mode);

        switch(mode) {
            case ("repair"):
                return getRepairModeDays(params);
            case ("daily"):
                return getDailyRunDays(params, functionName);
            case ("single"):
                return getSingleRunDays();
            case ("range"):
                return getRangeDays(functionParameters);
            default:
                throw new InvalidDefaultRunDateException("Repair Mode, nor daily, nor single, nor range, defined in properties file");
        }
    }

    private static ProcessingDays getRepairModeDays(ParameterTool params){
        List<String> repairDates = null;
        try {
            String unparsedRepairDates = params.get("kdb.repair.dates");
            repairDates = RepairDatesPropertyParser.getRepairDatesFrom(unparsedRepairDates);
        } catch (Exception e) {
            logger.error("Problem with parsing repair dates property", e);
            throw new RepairDateParsingException("Problem with parsing repair dates property", e);
        }

        return new ProcessingDays(repairDates, KDBProcessingMode.REPAIR_DATE_RANGE);
    }

    private static ProcessingDays getDailyRunDays(ParameterTool params, String functionName)
            throws XmartSqlServerException {
        LocalDate lastSuccessDate = getLastSuccessfulDateForKdbFunction(params, functionName);
        LocalDate today = LocalDate.now();

        List<String> days;

        // Check if the last success day was yesterday
        if (lastSuccessDate.equals(today.minus(1, ChronoUnit.DAYS))) {
            logger.debug("Function is up to date. Setting processing days to empty list for function: " + functionName);
            days = new ArrayList<>();
        } else {
            // Add one day to last success as we have already inserted data for that date.
            LocalDate localStartDate = lastSuccessDate.plus(1, ChronoUnit.DAYS);

            // Remove one day from today as we can only insert data up until yesterday.
            LocalDate localEndDate = today.minus(1, ChronoUnit.DAYS);

            try {
                days = getDaysToLoad(getKDBDateFromLOcalDate(localStartDate), getKDBDateFromLOcalDate(localEndDate));
            } catch (KDBParameterException ex) {
                logger.error(ex.toString());
                logger.error("Error trying to get processing days. " +
                        "Setting processing days to empty list for function: " + functionName);
                days = new ArrayList<>();
            }
        }

        return new ProcessingDays(days, KDBProcessingMode.OPERATIONAL_DEFAULT_DAILY);
    }

    // this is a temp function and will be updated in the future once the two projects are merged
    private static LocalDate getLastSuccessfulDateForKdbFunction(ParameterTool parameterTool, String functionName)
            throws XmartSqlServerException {

        String lastSuccessDateString = parameterTool.get("kdb.daily.initialLastSuccessfulDay", null);

        XmartStatement xmartStatement = new KdbLastRunReadStatement();

        StatementParameters statementParams = new StatementParameters();
        statementParams.add("functionName", functionName);

        SqlServerDao dao = new SqlServerDao(xmartStatement, new SqlServerConnectionDetails(parameterTool));

        try {

        dao.open();
        ResultSet queryResults = dao.read("fn_GetProcessState", statementParams);

        while ( queryResults.next() ) {
            String date = queryResults.getString("results");
            if(date != null && !date.isEmpty()){
                lastSuccessDateString = date;
            }
        }
        } catch (SQLException e) {
            logger.error("failed to get last process state from query results");
            throw new XmartSqlServerException("failed to get last process state from query results", e);
        } finally{
            dao.close();
        }

        // Return lastSuccessDate using formatter
        java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("yyyy.MM.dd");
        return LocalDate.parse(lastSuccessDateString, formatter);
    }

    private static ProcessingDays getSingleRunDays() {
        // Now resort to normal operational mode
        LocalDate today = LocalDate.now();
        LocalDate localStartDate = null;
        LocalDate localEndDate = null;

        DayOfWeek dayOfWeek = today.getDayOfWeek();
        switch (dayOfWeek) {
            case MONDAY:
                localStartDate = today.minus(3, java.time.temporal.ChronoUnit.DAYS);
                localEndDate = today.minus(1, java.time.temporal.ChronoUnit.DAYS);
                break;
            case TUESDAY:
            case WEDNESDAY:
            case THURSDAY:
            case FRIDAY:
                localStartDate = today.minus(1, java.time.temporal.ChronoUnit.DAYS);
                localEndDate = today.minus(1, java.time.temporal.ChronoUnit.DAYS);
                break;
            default:
                throw new InvalidDefaultRunDateException("When running the program with the DEFAULT OPERATION DATE, must run the program between Mon to Fri inclusive");
        }

        List<String> defaultDateRange = getDaysToLoad(getKDBDateFromLOcalDate(localStartDate), getKDBDateFromLOcalDate(localEndDate));

        return new ProcessingDays(defaultDateRange, KDBProcessingMode.OPERATIONAL_DEFAULT_DATE_RANGE);
    }

    private static ProcessingDays getRangeDays(Map<String, String> functionParameters) {
        ProcessingDays results;

        if (functionParameters == null) {
            throw new FunctionParameterParsingException("function parameters is null");
        }

        String startDate = functionParameters.get("startDate");
        String endDate = functionParameters.get("endDate");
        if (startDate == null || endDate == null) {
            throw new FunctionParameterParsingException("StartDate or EndDate are missing from the FunctionalParameters - unable to run in range mode");
        }

        try {
            results = new ProcessingDays(getDaysToLoad(startDate, endDate), KDBProcessingMode.SPECIFIED_DATE_RANGE);
        } catch (Exception e) {
            logger.error("Problem with parsing SPECIFIED DATE RANGE startDate [ " + startDate + " ], endDate [ " + endDate + " ]", e);
            throw new FunctionParameterParsingException("Problem with parsing SPECIFIED DATE RANGE startDate [ " + startDate + " ], endDate [ " + endDate + " ]", e);
        }

        return results;
    }

    public static String getKDBDateFromLOcalDate(LocalDate date) {
        return date.toString().replaceAll("-", ".");
    }
}