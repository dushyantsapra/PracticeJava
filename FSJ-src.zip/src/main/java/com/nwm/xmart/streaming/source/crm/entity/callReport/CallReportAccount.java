package com.nwm.xmart.streaming.source.crm.entity.callReport;

import com.nwm.xmart.streaming.source.crm.entity.common.Account;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Id", "CreatedById", "CreatedDate", "IsDeleted", "LastModifiedById", "LastModifiedDate", "Name",
                     "SystemModstamp", "Account", "Call_Report", "Is_Primary" })
public class CallReportAccount implements Serializable {
    private static final long serialVersionUID = -5936190041854468902L;

    @JsonProperty("Id")
    private String id;
    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("IsDeleted")
    private Boolean isDeleted;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("Account")
    private Account account;
    @JsonProperty("Call_Report")
    private String callReport;
    @JsonProperty("Is_Primary")
    private Boolean isPrimary;

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("IsDeleted")
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    @JsonProperty("IsDeleted")
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("Account")
    public Account getAccount() {
        return account;
    }

    @JsonProperty("Account")
    public void setAccount(Account account) {
        this.account = account;
    }

    @JsonProperty("Call_Report")
    public String getCallReport() {
        return callReport;
    }

    @JsonProperty("Call_Report")
    public void setCallReport(String callReport) {
        this.callReport = callReport;
    }

    @JsonProperty("Is_Primary")
    public Boolean getIsPrimary() {
        return isPrimary;
    }

    @JsonProperty("Is_Primary")
    public void setIsPrimary(Boolean isPrimary) {
        this.isPrimary = isPrimary;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CallReportAccount{");
        sb.append("id='").append(id).append('\'');
        sb.append(", createdById='").append(createdById).append('\'');
        sb.append(", createdDate='").append(createdDate).append('\'');
        sb.append(", isDeleted=").append(isDeleted);
        sb.append(", lastModifiedById='").append(lastModifiedById).append('\'');
        sb.append(", lastModifiedDate='").append(lastModifiedDate).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", systemModstamp='").append(systemModstamp).append('\'');
        sb.append(", account=").append(account);
        sb.append(", callReport='").append(callReport).append('\'');
        sb.append(", isPrimary=").append(isPrimary);
        sb.append('}');
        return sb.toString();
    }
}
