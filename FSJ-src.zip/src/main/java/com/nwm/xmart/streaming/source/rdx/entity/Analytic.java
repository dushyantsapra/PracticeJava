
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AnalyticDate",
    "MtgeAmountOutstandingPerFace",
    "MortgageFaceAmount",
    "OutstandingAmount",
    "CurrentFactor",
    "CreditScoreWeightedAvg",
    "WeightedAverageCoupon",
    "WAT2M",
    "MTGFactSettle",
    "MtgeFactorNumericDate",
    "AnalyticProvider",
    "WeightedAverageLife"
})
public class Analytic {

    @JsonProperty("AnalyticDate")
    private Object analyticDate;
    @JsonProperty("MtgeAmountOutstandingPerFace")
    private Object mtgeAmountOutstandingPerFace;
    @JsonProperty("MortgageFaceAmount")
    private Object mortgageFaceAmount;
    @JsonProperty("OutstandingAmount")
    private Double outstandingAmount;
    @JsonProperty("CurrentFactor")
    private Double currentFactor;
    @JsonProperty("CreditScoreWeightedAvg")
    private Object creditScoreWeightedAvg;
    @JsonProperty("WeightedAverageCoupon")
    private Object weightedAverageCoupon;
    @JsonProperty("WAT2M")
    private Object wAT2M;
    @JsonProperty("MTGFactSettle")
    private Object mTGFactSettle;
    @JsonProperty("MtgeFactorNumericDate")
    private Object mtgeFactorNumericDate;
    @JsonProperty("AnalyticProvider")
    private Object analyticProvider;
    @JsonProperty("WeightedAverageLife")
    private Object weightedAverageLife;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("AnalyticDate")
    public Object getAnalyticDate() {
        return analyticDate;
    }

    @JsonProperty("AnalyticDate")
    public void setAnalyticDate(Object analyticDate) {
        this.analyticDate = analyticDate;
    }

    @JsonProperty("MtgeAmountOutstandingPerFace")
    public Object getMtgeAmountOutstandingPerFace() {
        return mtgeAmountOutstandingPerFace;
    }

    @JsonProperty("MtgeAmountOutstandingPerFace")
    public void setMtgeAmountOutstandingPerFace(Object mtgeAmountOutstandingPerFace) {
        this.mtgeAmountOutstandingPerFace = mtgeAmountOutstandingPerFace;
    }

    @JsonProperty("MortgageFaceAmount")
    public Object getMortgageFaceAmount() {
        return mortgageFaceAmount;
    }

    @JsonProperty("MortgageFaceAmount")
    public void setMortgageFaceAmount(Object mortgageFaceAmount) {
        this.mortgageFaceAmount = mortgageFaceAmount;
    }

    @JsonProperty("OutstandingAmount")
    public Double getOutstandingAmount() {
        return outstandingAmount;
    }

    @JsonProperty("OutstandingAmount")
    public void setOutstandingAmount(Double outstandingAmount) {
        this.outstandingAmount = outstandingAmount;
    }

    @JsonProperty("CurrentFactor")
    public Double getCurrentFactor() {
        return currentFactor;
    }

    @JsonProperty("CurrentFactor")
    public void setCurrentFactor(Double currentFactor) {
        this.currentFactor = currentFactor;
    }

    @JsonProperty("CreditScoreWeightedAvg")
    public Object getCreditScoreWeightedAvg() {
        return creditScoreWeightedAvg;
    }

    @JsonProperty("CreditScoreWeightedAvg")
    public void setCreditScoreWeightedAvg(Object creditScoreWeightedAvg) {
        this.creditScoreWeightedAvg = creditScoreWeightedAvg;
    }

    @JsonProperty("WeightedAverageCoupon")
    public Object getWeightedAverageCoupon() {
        return weightedAverageCoupon;
    }

    @JsonProperty("WeightedAverageCoupon")
    public void setWeightedAverageCoupon(Object weightedAverageCoupon) {
        this.weightedAverageCoupon = weightedAverageCoupon;
    }

    @JsonProperty("WAT2M")
    public Object getWAT2M() {
        return wAT2M;
    }

    @JsonProperty("WAT2M")
    public void setWAT2M(Object wAT2M) {
        this.wAT2M = wAT2M;
    }

    @JsonProperty("MTGFactSettle")
    public Object getMTGFactSettle() {
        return mTGFactSettle;
    }

    @JsonProperty("MTGFactSettle")
    public void setMTGFactSettle(Object mTGFactSettle) {
        this.mTGFactSettle = mTGFactSettle;
    }

    @JsonProperty("MtgeFactorNumericDate")
    public Object getMtgeFactorNumericDate() {
        return mtgeFactorNumericDate;
    }

    @JsonProperty("MtgeFactorNumericDate")
    public void setMtgeFactorNumericDate(Object mtgeFactorNumericDate) {
        this.mtgeFactorNumericDate = mtgeFactorNumericDate;
    }

    @JsonProperty("AnalyticProvider")
    public Object getAnalyticProvider() {
        return analyticProvider;
    }

    @JsonProperty("AnalyticProvider")
    public void setAnalyticProvider(Object analyticProvider) {
        this.analyticProvider = analyticProvider;
    }

    @JsonProperty("WeightedAverageLife")
    public Object getWeightedAverageLife() {
        return weightedAverageLife;
    }

    @JsonProperty("WeightedAverageLife")
    public void setWeightedAverageLife(Object weightedAverageLife) {
        this.weightedAverageLife = weightedAverageLife;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("analyticDate", analyticDate).append("mtgeAmountOutstandingPerFace", mtgeAmountOutstandingPerFace).append("mortgageFaceAmount", mortgageFaceAmount).append("outstandingAmount", outstandingAmount).append("currentFactor", currentFactor).append("creditScoreWeightedAvg", creditScoreWeightedAvg).append("weightedAverageCoupon", weightedAverageCoupon).append("wAT2M", wAT2M).append("mTGFactSettle", mTGFactSettle).append("mtgeFactorNumericDate", mtgeFactorNumericDate).append("analyticProvider", analyticProvider).append("weightedAverageLife", weightedAverageLife).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(outstandingAmount).append(mTGFactSettle).append(mtgeAmountOutstandingPerFace).append(mtgeFactorNumericDate).append(wAT2M).append(analyticDate).append(mortgageFaceAmount).append(analyticProvider).append(weightedAverageLife).append(additionalProperties).append(currentFactor).append(creditScoreWeightedAvg).append(weightedAverageCoupon).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Analytic) == false) {
            return false;
        }
        Analytic rhs = ((Analytic) other);
        return new EqualsBuilder().append(outstandingAmount, rhs.outstandingAmount).append(mTGFactSettle, rhs.mTGFactSettle).append(mtgeAmountOutstandingPerFace, rhs.mtgeAmountOutstandingPerFace).append(mtgeFactorNumericDate, rhs.mtgeFactorNumericDate).append(wAT2M, rhs.wAT2M).append(analyticDate, rhs.analyticDate).append(mortgageFaceAmount, rhs.mortgageFaceAmount).append(analyticProvider, rhs.analyticProvider).append(weightedAverageLife, rhs.weightedAverageLife).append(additionalProperties, rhs.additionalProperties).append(currentFactor, rhs.currentFactor).append(creditScoreWeightedAvg, rhs.creditScoreWeightedAvg).append(weightedAverageCoupon, rhs.weightedAverageCoupon).isEquals();
    }

}
