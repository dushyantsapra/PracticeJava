package com.nwm.xmart.streaming.source.kdb;

import com.nwm.xmart.streaming.source.kdb.parameters.BdxKdbFunctionDetails;
import com.nwm.xmart.streaming.source.kdb.session.BdxKdbFunctionContext;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;

/**
 * Created by gardlex on 08/08/2018.
 */
public class KDBFunctionSelector {
    private final LinkedList<String> circularfunctionList = new LinkedList();
    private final Map<String, LinkedList<String>> functionProcessingDays = new HashMap<>();

    public KDBFunctionSelector(List<BdxKdbFunctionDetails> functionsList, ConcurrentMap<String, BdxKdbFunctionContext> functionMap) {
        for (BdxKdbFunctionDetails bdxKdbFunctionDetails : functionsList) {
            String sourceName = bdxKdbFunctionDetails.getKdbSourceName();
            LinkedList<String> days = new LinkedList<>(functionMap.get(sourceName).getProcessingDays().getDaysToLoad());

            if(days != null && days.size() > 0) {
                circularfunctionList.add(sourceName);
                functionProcessingDays.put(sourceName, days);
            }
        }
    }

    public boolean isFunctionProcessingDayAvailable() {
        if (circularfunctionList.size() > 0) {
            return true;
        }

        return false;
    }

    public String getNextFunctionToProcess() {
        String nextFunction = circularfunctionList.getFirst();
        circularfunctionList.addLast(nextFunction);
        circularfunctionList.removeFirst();

        return nextFunction;
    }

    public String getNextProcessingDayForFunction(String functionName) {
        LinkedList<String> processingDays = functionProcessingDays.get(functionName);
        String nextProcessingDay = processingDays.removeFirst();
        if (processingDays.size() == 0) {
            functionProcessingDays.remove(functionName);
            circularfunctionList.removeLast();
        }

        return nextProcessingDay;
    }

    public void removeFunction(String functionName){
        circularfunctionList.remove(functionName);
        functionProcessingDays.remove(functionName);
    }
}

