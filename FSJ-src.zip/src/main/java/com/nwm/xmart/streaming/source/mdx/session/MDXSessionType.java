package com.nwm.xmart.streaming.source.mdx.session;

/**
 * Created by gardlex on 03/05/2018.
 */
public enum MDXSessionType {
    SSO, MDX_ACCESS;
}
