package com.nwm.xmart.streaming.manager.utils;

import com.nwm.xmart.streaming.database.exceptions.XmartSqlServerException;
import org.apache.flink.api.java.utils.ParameterTool;

import java.time.LocalDate;

public interface SourceManagerSqlUtilInterface {
    LocalDate getLastSuccessfulDateForFunction(ParameterTool params, String functionName)
            throws XmartSqlServerException;

    void insertLastSuccessfulDateForFunction(ParameterTool params, String functionName, String date)
            throws XmartSqlServerException;

}
