package com.nwm.xmart.streaming.source.mdx.pull;

import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.streaming.source.mdx.exception.MdxLoadFailureException;
import com.nwm.xmart.streaming.source.mdx.session.MdxSessionContext;
import org.apache.flink.api.common.accumulators.IntCounter;
import rbs.gbm.mdx.webService.interfaces.MdxException;

import java.util.List;

/**
 * Created by gardlex on 19/04/2018.
 */
public interface MdxReader {

    List<MdxDocumentEvent> getMdxDocuments(List<String> fullIdentifiersList)
            throws MdxException;

    void close() throws MdxException;

}
