
package com.nwm.xmart.streaming.source.rdx.json;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "GuarantorPariPassu",
    "PartyCode",
    "PartyName",
    "PartyNameVendor",
    "PartyLongNameVendor",
    "PartyRoleType",
    "PartyAlias",
    "LegalEntityIdentifier",
    "CISCode",
    "DFIdentifier",
    "CountryOfResidenceId",
    "CountryOfResidenceName",
    "CountryOfResidenceIsoScheme",
    "CountryOfIncorporationId",
    "CountryOfIncorporationName",
    "CountryOfIncorporationIsoScheme",
    "CountryOfRiskId",
    "CountryOfRiskName",
    "CountryOfRiskIsoScheme"
})
public class InstrumentParty {

    @JsonProperty("GuarantorPariPassu")
    private Object guarantorPariPassu;
    @JsonProperty("PartyCode")
    private String partyCode;
    @JsonProperty("PartyName")
    private String partyName;
    @JsonProperty("PartyNameVendor")
    private String partyNameVendor;
    @JsonProperty("PartyLongNameVendor")
    private String partyLongNameVendor;
    @JsonProperty("PartyRoleType")
    private String partyRoleType;
    @JsonProperty("PartyAlias")
    private String partyAlias;
    @JsonProperty("LegalEntityIdentifier")
    private String legalEntityIdentifier;
    @JsonProperty("CISCode")
    private String cISCode;
    @JsonProperty("DFIdentifier")
    private Object dFIdentifier;
    @JsonProperty("CountryOfResidenceId")
    private String countryOfResidenceId;
    @JsonProperty("CountryOfResidenceName")
    private String countryOfResidenceName;
    @JsonProperty("CountryOfResidenceIsoScheme")
    private String countryOfResidenceIsoScheme;
    @JsonProperty("CountryOfIncorporationId")
    private String countryOfIncorporationId;
    @JsonProperty("CountryOfIncorporationName")
    private String countryOfIncorporationName;
    @JsonProperty("CountryOfIncorporationIsoScheme")
    private String countryOfIncorporationIsoScheme;
    @JsonProperty("CountryOfRiskId")
    private String countryOfRiskId;
    @JsonProperty("CountryOfRiskName")
    private String countryOfRiskName;
    @JsonProperty("CountryOfRiskIsoScheme")
    private String countryOfRiskIsoScheme;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("GuarantorPariPassu")
    public Object getGuarantorPariPassu() {
        return guarantorPariPassu;
    }

    @JsonProperty("GuarantorPariPassu")
    public void setGuarantorPariPassu(Object guarantorPariPassu) {
        this.guarantorPariPassu = guarantorPariPassu;
    }

    @JsonProperty("PartyCode")
    public String getPartyCode() {
        return partyCode;
    }

    @JsonProperty("PartyCode")
    public void setPartyCode(String partyCode) {
        this.partyCode = partyCode;
    }

    @JsonProperty("PartyName")
    public String getPartyName() {
        return partyName;
    }

    @JsonProperty("PartyName")
    public void setPartyName(String partyName) {
        this.partyName = partyName;
    }

    @JsonProperty("PartyNameVendor")
    public String getPartyNameVendor() {
        return partyNameVendor;
    }

    @JsonProperty("PartyNameVendor")
    public void setPartyNameVendor(String partyNameVendor) {
        this.partyNameVendor = partyNameVendor;
    }

    @JsonProperty("PartyLongNameVendor")
    public String getPartyLongNameVendor() {
        return partyLongNameVendor;
    }

    @JsonProperty("PartyLongNameVendor")
    public void setPartyLongNameVendor(String partyLongNameVendor) {
        this.partyLongNameVendor = partyLongNameVendor;
    }

    @JsonProperty("PartyRoleType")
    public String getPartyRoleType() {
        return partyRoleType;
    }

    @JsonProperty("PartyRoleType")
    public void setPartyRoleType(String partyRoleType) {
        this.partyRoleType = partyRoleType;
    }

    @JsonProperty("PartyAlias")
    public String getPartyAlias() {
        return partyAlias;
    }

    @JsonProperty("PartyAlias")
    public void setPartyAlias(String partyAlias) {
        this.partyAlias = partyAlias;
    }

    @JsonProperty("LegalEntityIdentifier")
    public String getLegalEntityIdentifier() {
        return legalEntityIdentifier;
    }

    @JsonProperty("LegalEntityIdentifier")
    public void setLegalEntityIdentifier(String legalEntityIdentifier) {
        this.legalEntityIdentifier = legalEntityIdentifier;
    }

    @JsonProperty("CISCode")
    public String getCISCode() {
        return cISCode;
    }

    @JsonProperty("CISCode")
    public void setCISCode(String cISCode) {
        this.cISCode = cISCode;
    }

    @JsonProperty("DFIdentifier")
    public Object getDFIdentifier() {
        return dFIdentifier;
    }

    @JsonProperty("DFIdentifier")
    public void setDFIdentifier(Object dFIdentifier) {
        this.dFIdentifier = dFIdentifier;
    }

    @JsonProperty("CountryOfResidenceId")
    public String getCountryOfResidenceId() {
        return countryOfResidenceId;
    }

    @JsonProperty("CountryOfResidenceId")
    public void setCountryOfResidenceId(String countryOfResidenceId) {
        this.countryOfResidenceId = countryOfResidenceId;
    }

    @JsonProperty("CountryOfResidenceName")
    public String getCountryOfResidenceName() {
        return countryOfResidenceName;
    }

    @JsonProperty("CountryOfResidenceName")
    public void setCountryOfResidenceName(String countryOfResidenceName) {
        this.countryOfResidenceName = countryOfResidenceName;
    }

    @JsonProperty("CountryOfResidenceIsoScheme")
    public String getCountryOfResidenceIsoScheme() {
        return countryOfResidenceIsoScheme;
    }

    @JsonProperty("CountryOfResidenceIsoScheme")
    public void setCountryOfResidenceIsoScheme(String countryOfResidenceIsoScheme) {
        this.countryOfResidenceIsoScheme = countryOfResidenceIsoScheme;
    }

    @JsonProperty("CountryOfIncorporationId")
    public String getCountryOfIncorporationId() {
        return countryOfIncorporationId;
    }

    @JsonProperty("CountryOfIncorporationId")
    public void setCountryOfIncorporationId(String countryOfIncorporationId) {
        this.countryOfIncorporationId = countryOfIncorporationId;
    }

    @JsonProperty("CountryOfIncorporationName")
    public String getCountryOfIncorporationName() {
        return countryOfIncorporationName;
    }

    @JsonProperty("CountryOfIncorporationName")
    public void setCountryOfIncorporationName(String countryOfIncorporationName) {
        this.countryOfIncorporationName = countryOfIncorporationName;
    }

    @JsonProperty("CountryOfIncorporationIsoScheme")
    public String getCountryOfIncorporationIsoScheme() {
        return countryOfIncorporationIsoScheme;
    }

    @JsonProperty("CountryOfIncorporationIsoScheme")
    public void setCountryOfIncorporationIsoScheme(String countryOfIncorporationIsoScheme) {
        this.countryOfIncorporationIsoScheme = countryOfIncorporationIsoScheme;
    }

    @JsonProperty("CountryOfRiskId")
    public String getCountryOfRiskId() {
        return countryOfRiskId;
    }

    @JsonProperty("CountryOfRiskId")
    public void setCountryOfRiskId(String countryOfRiskId) {
        this.countryOfRiskId = countryOfRiskId;
    }

    @JsonProperty("CountryOfRiskName")
    public String getCountryOfRiskName() {
        return countryOfRiskName;
    }

    @JsonProperty("CountryOfRiskName")
    public void setCountryOfRiskName(String countryOfRiskName) {
        this.countryOfRiskName = countryOfRiskName;
    }

    @JsonProperty("CountryOfRiskIsoScheme")
    public String getCountryOfRiskIsoScheme() {
        return countryOfRiskIsoScheme;
    }

    @JsonProperty("CountryOfRiskIsoScheme")
    public void setCountryOfRiskIsoScheme(String countryOfRiskIsoScheme) {
        this.countryOfRiskIsoScheme = countryOfRiskIsoScheme;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("guarantorPariPassu", guarantorPariPassu).append("partyCode", partyCode).append("partyName", partyName).append("partyNameVendor", partyNameVendor).append("partyLongNameVendor", partyLongNameVendor).append("partyRoleType", partyRoleType).append("partyAlias", partyAlias).append("legalEntityIdentifier", legalEntityIdentifier).append("cISCode", cISCode).append("dFIdentifier", dFIdentifier).append("countryOfResidenceId", countryOfResidenceId).append("countryOfResidenceName", countryOfResidenceName).append("countryOfResidenceIsoScheme", countryOfResidenceIsoScheme).append("countryOfIncorporationId", countryOfIncorporationId).append("countryOfIncorporationName", countryOfIncorporationName).append("countryOfIncorporationIsoScheme", countryOfIncorporationIsoScheme).append("countryOfRiskId", countryOfRiskId).append("countryOfRiskName", countryOfRiskName).append("countryOfRiskIsoScheme", countryOfRiskIsoScheme).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(partyAlias).append(legalEntityIdentifier).append(dFIdentifier).append(partyNameVendor).append(partyRoleType).append(countryOfResidenceId).append(countryOfResidenceIsoScheme).append(countryOfIncorporationIsoScheme).append(countryOfRiskIsoScheme).append(countryOfResidenceName).append(guarantorPariPassu).append(cISCode).append(partyCode).append(partyName).append(partyLongNameVendor).append(countryOfIncorporationId).append(countryOfRiskId).append(additionalProperties).append(countryOfRiskName).append(countryOfIncorporationName).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InstrumentParty) == false) {
            return false;
        }
        InstrumentParty rhs = ((InstrumentParty) other);
        return new EqualsBuilder().append(partyAlias, rhs.partyAlias).append(legalEntityIdentifier, rhs.legalEntityIdentifier).append(dFIdentifier, rhs.dFIdentifier).append(partyNameVendor, rhs.partyNameVendor).append(partyRoleType, rhs.partyRoleType).append(countryOfResidenceId, rhs.countryOfResidenceId).append(countryOfResidenceIsoScheme, rhs.countryOfResidenceIsoScheme).append(countryOfIncorporationIsoScheme, rhs.countryOfIncorporationIsoScheme).append(countryOfRiskIsoScheme, rhs.countryOfRiskIsoScheme).append(countryOfResidenceName, rhs.countryOfResidenceName).append(guarantorPariPassu, rhs.guarantorPariPassu).append(cISCode, rhs.cISCode).append(partyCode, rhs.partyCode).append(partyName, rhs.partyName).append(partyLongNameVendor, rhs.partyLongNameVendor).append(countryOfIncorporationId, rhs.countryOfIncorporationId).append(countryOfRiskId, rhs.countryOfRiskId).append(additionalProperties, rhs.additionalProperties).append(countryOfRiskName, rhs.countryOfRiskName).append(countryOfIncorporationName, rhs.countryOfIncorporationName).isEquals();
    }

}
