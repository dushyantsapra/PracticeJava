package com.nwm.xmart.streaming.example;

import com.nwm.xmart.streaming.common.job.StreamJob;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.nwm.xmart.streaming.source.df.DataFabricFlinkKafkaSource;
import com.nwm.xmart.streaming.source.df.KafkaProperties;
import com.nwm.xmart.streaming.source.df.serialisation.FlinkDeserializer;
import com.nwm.xmart.streaming.monitor.InactiveKafkaMonitor;
import com.nwm.xmart.streaming.monitor.InactivityMonitor;
import com.nwm.xmart.streaming.monitor.InactivityStatus;
import com.nwm.xmart.streaming.monitor.PersistenceFile;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.flink.streaming.util.serialization.KeyedDeserializationSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * Created by gardlex on 18/10/2017.
 */
public class ExampleDataFabricFlinkJob {

    private static Logger logger = LoggerFactory.getLogger(ExampleDataFabricFlinkJob.class);

    public static void main(String[] args) throws Exception {

        // StreamJob implementation can override any abstract methid as long as it calls super() first
        StreamJob streamJob = new StreamJob() {
            @Override
            protected void configureAndExecuteStream(StreamExecutionEnvironment env) {

                DataFabricUtil dataFabricUtil = new DataFabricUtil(configuration);

                // Type info reqd for the FlinkDeserializer
                final TypeInformation<DataFabricStreamEvent<ExampleTradePOJO>> info = TypeInformation.of(new TypeHint<DataFabricStreamEvent<ExampleTradePOJO>>(){});
                Class<DataFabricStreamEvent<ExampleTradePOJO>> sourceRef = info.getTypeClass();

                InactivityMonitor inactivityMonitor = new InactiveKafkaMonitor(configuration, new PersistenceFile() {
                    @Override
                    public void persistOffsetInfo(InactivityStatus inactivityStatus, long currentKafkaOffset, long lastOffset, long currentTimestamp, long lastTimestamp, long lastOffsetChangeTimestamp) throws IOException {
                        // do nothing
                    }
                });

                // The deserializer itself
                KeyedDeserializationSchema<DataFabricStreamEvent<ExampleTradePOJO>> deserialiser =
                        new FlinkDeserializer<DataFabricStreamEvent<ExampleTradePOJO>,ExampleTradePOJO, ExampleTradePOJO>(
                                dataFabricUtil,
                                sourceRef,
                                ExampleTradePOJO.class,
                                inactivityMonitor,
                                configuration);

                // Configuration of the stream
                DataStream<DataFabricStreamEvent<ExampleTradePOJO>> input = env
                        .addSource(new DataFabricFlinkKafkaSource<DataFabricStreamEvent<ExampleTradePOJO>>(dataFabricUtil, configuration, new KafkaProperties(configuration), deserialiser), info)
                        .uid(configuration.getString("operator.trade.source.name",""))
                        .name(configuration.getString("operator.trade.source.name",""))
                        .setParallelism(configuration.getInteger("operator.trade.source.parallelism",1));
                input.addSink(new RichSinkFunction<DataFabricStreamEvent<ExampleTradePOJO>>() {
                    @Override
                    public void invoke(DataFabricStreamEvent<ExampleTradePOJO> value) throws Exception {
                        logger.info("value = " + value);
                    }
                })
                        .uid(configuration.getString("operator.datafabric.sink.name",""))
                        .name(configuration.getString("operator.datafabric.sink.name",""))
                        .setParallelism(configuration.getInteger("operator.datafabric.sink.parallelism",1));

                try {
                    logger.info("EXECUTION PLAN = " + env.getExecutionPlan());
                    env.execute("ExampleODCFlinkJob");
                } catch (Exception e) {
                    logger.error("Exception running the ExampleODCFlinkJob",e);
                    throw new RuntimeException(e);
                }
            }
        };
        streamJob.run(args);
    }
}
