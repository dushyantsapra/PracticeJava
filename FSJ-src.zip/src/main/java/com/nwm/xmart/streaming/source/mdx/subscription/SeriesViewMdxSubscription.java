package com.nwm.xmart.streaming.source.mdx.subscription;


import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.streaming.source.mdx.event.ProcessingType;
import com.nwm.xmart.streaming.source.mdx.identifier.SeriesViewIdentifierGenerator;
import com.nwm.xmart.streaming.source.mdx.session.MdxSessionContext;
import org.apache.commons.lang3.reflect.ConstructorUtils;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.util.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.mdx.messaging.IMdxDocumentChangeHandler;
import rbs.gbm.mdx.webService.interfaces.*;

import java.time.Instant;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantLock;


/**
 * Encapsulates the logic required for capturing real time publication of new MDX Document events.
 *
 * Created by gardlex on 23/03/2018.
 */
public class SeriesViewMdxSubscription<T> implements IMdxDocumentChangeHandler, MdxSubscription<T> {

    private static Logger logger = LoggerFactory.getLogger(SeriesViewMdxSubscription.class);
    private volatile boolean isMdxSessionClosed;
    private final Class<T> sourceEventClass;
    private volatile String mdxIdentifier;
    private volatile String mdxIdentifierWildcard;
    private final AtomicReference<MdxRealTimeEventExchange<T>> mdxEventExchangeRef = new AtomicReference<>();
    private final AtomicReference<MdxSessionContext> mdxSessionContextRef = new AtomicReference<>();
    private final ReentrantLock subscriptionLock = new ReentrantLock();
    private final ConcurrentMap<String, String> isinMap = new ConcurrentHashMap<>();
    private final AtomicReference<SourceFunction<T>> sourceFunctionRef = new AtomicReference<>();
    private final AtomicReference<SeriesViewIdentifierGenerator> identifierGenerator = new AtomicReference<>();
    private final String sourceID;
    private final AtomicLong currentJobEventIDCounter;

    public SeriesViewMdxSubscription(Class<T> sourceEventClass, String sourceID, AtomicLong currentJobEventIDCounter) {
        this.sourceEventClass = sourceEventClass;
        this.sourceID = sourceID;
        this.currentJobEventIDCounter = currentJobEventIDCounter;
    }


    @Override
    public MdxSubscription withMdxEventExchange(MdxRealTimeEventExchange<T> mdxEventExchange) {
        this.mdxEventExchangeRef.set(mdxEventExchange);
        return this;
    }

    @Override
    public MdxSubscription withMdxIdentifier(String identifier) {
        this.mdxIdentifier = identifier;
        this.identifierGenerator.set(new SeriesViewIdentifierGenerator(identifier));
        return this;
    }

    @Override
    public MdxSubscription withMdxIdentifierWildcard(String wildcard) {
        this.mdxIdentifierWildcard = wildcard;
        return this;
    }

    @Override
    public MdxSubscription withMdxSessionContext(MdxSessionContext mdxSessionContext) {
        this.mdxSessionContextRef.set(mdxSessionContext);
        return this;
    }

    @Override
    public MdxSubscription withSourceFunction(SourceFunction<T> sourceFunction) {
        this.sourceFunctionRef.set(sourceFunction);

        return this;
    }

    @Override
    public MdxSubscription setISINList(Set<String> isinList) {
        subscriptionLock.lock();
        try {
            isinMap.clear();
            for (String isin : isinList) {
                isinMap.put(isin, "");
            }
        } finally {
            subscriptionLock.unlock();
        }

        return this;
    }

    @Override
    public void startConsumingEvents() {
        try {
            subscribeToRealTimeEvents();
            logger.info("Now subscribing to SeriesView: " +mdxIdentifier+mdxIdentifierWildcard);
        }
        catch (Exception e)
        {
            logger.error("Could not start the SeriesViewMdxSubscription",e);
            close();
        }
    }

    private void subscribeToRealTimeEvents() throws MdxException {
//        String identifier = "saved/reference.regulatory.instrument/public/Credit/%";  ///>"; Rates
        Object ooo = mdxSessionContextRef.get().getMdxSeriesViewSession().subscribe(mdxIdentifier+mdxIdentifierWildcard, this, "MySubscription");
    }

    @Override
    public void close() {
        try
        {
            mdxSessionContextRef.get().getMdxSeriesViewSession().close();
        } catch (MdxException e)
        {
            logger.warn("Close(): Could not close the SeriesViewMdxSubscription session", e);
        }
    }

    /**
     * When called, blocks current thread until the RendezvousSingleEventExchange has an event for consumption
     *
     * @return
     * @throws MdxSubscriptionFailureException
     */
    @Override
    public T getMdxNextEvent() {
        return mdxEventExchangeRef.get().getNextMdxDocumentEvent();
    }

    @Override
    public ReentrantLock getSubscriptionLock() {
        return subscriptionLock;
    }


    @Override
    public void onMdxDocChange(IMdxSession iMdxSession, Object o, Object o1, IMdxDocument mdxDocument, DocumentOperationType documentOperationType) throws MdxException {
        switch(documentOperationType) {
            case WRITE:
                String identifier = mdxDocument.getHeader().getIdentifier().getPath();
                // filter out any events that aren't in the ISIN list
                if (isinMap.get(identifierGenerator.get().extractISINFromIdentifier(identifier)) == null) {
                    return;
                }
                long epochXmlWriteTime = Instant.parse(mdxDocument.getHeader().getXmlWriteTime()).toEpochMilli();
                int version = mdxDocument.getHeader().getVersion();
                try {
                    mdxEventExchangeRef.get().putMdxDocumentEvent((T)
                            MdxDocumentEvent.ofIMdxDocumentWithRegInstrument(sourceID, currentJobEventIDCounter.incrementAndGet(), mdxDocument, System.currentTimeMillis(), epochXmlWriteTime, version, identifier, ProcessingType.SUBSCRIPTION));
                } catch (Exception e) {
                    logger.error("Could not create MdxDocumentEvent constructor", e);
                    throw new MdxSubscriptionFailureException("Could not create MdxDocumentEvent constructor", e);
                }
                break;
            default:
        }
    }

    @Override
    public void onSubscriptionRevoked(IMdxSession iMdxSession, Object o, Object o1) {
        logger.error("onSubscriptionRevoked");
        sourceFunctionRef.get().cancel();
    }
}
