package com.nwm.xmart.streaming.database.statements;

import java.util.*;

/**
 * THIS IS A SLIM COPY OF THE SAME CLASS IN APP-STREAMING
 * THIS IS ONLY INTENDED TO BE USED UNTIL WE MERGE THE TWO PROJECTS
 */
public class StatementParameters {

    private volatile Map<String, String> map = new LinkedHashMap<>();

    public void add(String key, String value) {
        map.put(key,value);
    }

    public String get(String key){
        return map.get(key);
    }

}
