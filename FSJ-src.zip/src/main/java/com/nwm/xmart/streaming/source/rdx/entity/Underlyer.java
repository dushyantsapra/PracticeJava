
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "UnderlyingCusip",
    "UnderlyerTicker",
    "UnderlyerBloombergUniqueCode"
})
public class Underlyer {

    @JsonProperty("UnderlyingCusip")
    private Object underlyingCusip;
    @JsonProperty("UnderlyerTicker")
    private Object underlyerTicker;
    @JsonProperty("UnderlyerBloombergUniqueCode")
    private Object underlyerBloombergUniqueCode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("UnderlyingCusip")
    public Object getUnderlyingCusip() {
        return underlyingCusip;
    }

    @JsonProperty("UnderlyingCusip")
    public void setUnderlyingCusip(Object underlyingCusip) {
        this.underlyingCusip = underlyingCusip;
    }

    @JsonProperty("UnderlyerTicker")
    public Object getUnderlyerTicker() {
        return underlyerTicker;
    }

    @JsonProperty("UnderlyerTicker")
    public void setUnderlyerTicker(Object underlyerTicker) {
        this.underlyerTicker = underlyerTicker;
    }

    @JsonProperty("UnderlyerBloombergUniqueCode")
    public Object getUnderlyerBloombergUniqueCode() {
        return underlyerBloombergUniqueCode;
    }

    @JsonProperty("UnderlyerBloombergUniqueCode")
    public void setUnderlyerBloombergUniqueCode(Object underlyerBloombergUniqueCode) {
        this.underlyerBloombergUniqueCode = underlyerBloombergUniqueCode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("underlyingCusip", underlyingCusip).append("underlyerTicker", underlyerTicker).append("underlyerBloombergUniqueCode", underlyerBloombergUniqueCode).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(underlyerBloombergUniqueCode).append(underlyerTicker).append(additionalProperties).append(underlyingCusip).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Underlyer) == false) {
            return false;
        }
        Underlyer rhs = ((Underlyer) other);
        return new EqualsBuilder().append(underlyerBloombergUniqueCode, rhs.underlyerBloombergUniqueCode).append(underlyerTicker, rhs.underlyerTicker).append(additionalProperties, rhs.additionalProperties).append(underlyingCusip, rhs.underlyingCusip).isEquals();
    }

}
