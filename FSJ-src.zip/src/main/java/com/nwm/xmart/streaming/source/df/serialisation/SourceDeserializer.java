package com.nwm.xmart.streaming.source.df.serialisation;

import com.rbs.datafabric.domain.Record;
import com.rbs.datafabric.domain.event.RecordModifiedEvent;

/**
 * Created by gardlex on 29/10/2017.
 */
public interface SourceDeserializer {
    public <Target> Target deserialize(RecordModifiedEvent recordModifiedEvent, Class<Target> targetClass);
    public <Target> Target deserialize(Record record, Class<Target> targetClass);
}
