package com.nwm.xmart.streaming.monitor;

import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;


/**
 * Created by gardlex on 06/11/2017.
 */
public class InactiveKafkaMonitor implements InactivityMonitor, Serializable {

    private static Logger logger = LoggerFactory.getLogger(InactivityMonitor.class);
    private final long minOffsetDelta;
    private long lastOffset;
    private long lastTimestamp;
    private long lastOffsetChangeTimestamp;
    private InactivityStatus lastInactivityStatus;
    private final PersistenceFile persistenceFile;
    private long offsetDelta;

    public InactiveKafkaMonitor(Configuration configuration, PersistenceFile persistenceFile) {
        this.persistenceFile = persistenceFile;
        minOffsetDelta = Long.valueOf(configuration.getString("kafka.inactivity.monitor.interval.minOffsetDelta", ""));
        // Set the lastOffsetChangeTimestamp to when this object was constructed so we have a reference point
        lastOffsetChangeTimestamp = System.currentTimeMillis();
    }

    @Override
    public void updateStreamPosition(long currentKafkaOffset) throws IOException {

        long currentTimestamp = System.currentTimeMillis();

        try {
            if ( currentKafkaOffset <= lastOffset) {
                persistOffsetInfo(
                        InactivityStatus.INACTIVE,
                        currentKafkaOffset,
                        lastOffset,
                        currentTimestamp,
                        lastTimestamp,
                        lastOffsetChangeTimestamp);
            } else {
                offsetDelta = currentKafkaOffset - lastOffset;
                lastOffsetChangeTimestamp = currentTimestamp;

                if (offsetDelta < minOffsetDelta) {
                    persistOffsetInfo(
                            InactivityStatus.ACTIVE_LESS_THAN_MIN_OFFSET_DELTA,
                            currentKafkaOffset,
                            lastOffset,
                            currentTimestamp,
                            lastTimestamp,
                            lastOffsetChangeTimestamp);
                } else {
                    persistOffsetInfo(
                            InactivityStatus.ACTIVE_AT_LEAST_MIN_OFFSET_DELTA,
                            currentKafkaOffset,
                            lastOffset,
                            currentTimestamp,
                            lastTimestamp,
                            lastOffsetChangeTimestamp);
                }
            }
        } finally {
            lastOffset = currentKafkaOffset;
            lastTimestamp = currentTimestamp;
        }
    }

    public void persistOffsetInfo(InactivityStatus inactivityStatus,
                                  long currentKafkaOffset,
                                  long lastOffset,
                                  long currentTimestamp,
                                  long lastTimestamp,
                                  long lastOffsetChangeTimestamp) throws IOException {
        lastInactivityStatus = inactivityStatus;
        try {
            persistenceFile.persistOffsetInfo(inactivityStatus,currentKafkaOffset,lastOffset,currentTimestamp,lastTimestamp, lastOffsetChangeTimestamp);
        } catch (IOException e) {
            logger.error("InactiveKafkaMonitor: cannot write to Geneos inactivity monitor log file", e);
            throw e;
        }
    }

    public InactivityStatus getLastInactivityStatus() {
        return lastInactivityStatus;
    }
}
