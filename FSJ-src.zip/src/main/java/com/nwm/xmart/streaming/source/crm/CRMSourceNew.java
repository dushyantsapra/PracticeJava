package com.nwm.xmart.streaming.source.crm;

import com.nwm.xmart.streaming.source.crm.entity.accountCoverage.AccountCoverage;
import com.nwm.xmart.streaming.source.crm.entity.accountDesk.AccountDesk;
import com.nwm.xmart.streaming.source.crm.entity.callLog.CallLog;
import com.nwm.xmart.streaming.source.crm.entity.callReport.CallReport;
import com.nwm.xmart.streaming.source.crm.entity.contact.Contact;
import com.nwm.xmart.streaming.source.crm.entity.contactCoverage.ContactCoverage;
import com.nwm.xmart.streaming.source.crm.entity.interest.Interest;
import com.nwm.xmart.streaming.source.crm.entity.organization.Organization;
import com.nwm.xmart.streaming.source.crm.entity.user.User;
import com.nwm.xmart.streaming.source.crm.entity.userRole.UserRole;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEventType;
import com.nwm.xmart.streaming.source.crm.exception.CRMException;
import com.nwm.xmart.streaming.source.df.serialisation.DFSourceDeserializer;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import com.nwm.xmart.util.MDCUtil;
import com.rbs.datafabric.client.DataFabricClient;
import com.rbs.datafabric.domain.OffsetCommitter;
import com.rbs.datafabric.domain.Record;
import com.rbs.datafabric.domain.WatchContext;
import com.rbs.datafabric.domain.client.StartFrom;
import com.rbs.datafabric.domain.client.builder.ConsumerConfigurationBuilder;
import com.rbs.datafabric.domain.client.builder.ResumeDurableWatchScanRequestBuilder;
import com.rbs.datafabric.domain.event.*;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Subscriber;
import rx.Subscription;

import java.util.Date;
import java.util.concurrent.CountDownLatch;

import static java.lang.String.format;

public class CRMSourceNew extends RichParallelSourceFunction<CRMSourceEvent>
        implements CheckpointedFunction, CheckpointListener {
    private static final long serialVersionUID = -6188869053630002089L;
    private final IntCounter numSubscriptionSourceEvents = new IntCounter();
    private Logger logger = LoggerFactory.getLogger(CRMSourceNew.class);
    private String watchId;
    private String watchName;
    private String watchGroupId;
    private DataFabricUtil dataFabricUtil;
    private transient DataFabricClient dataFabricClient;
    private transient WatchContext<ContinuousQueryEvent> watchContext;
    private transient OffsetCommitter offsetCommitter;
    private transient ListState<Long> state;
    private volatile Long offset;
    private volatile boolean isSubscriptionRunning = true;
    private boolean isStartFromOffset = false;
    private Long specificOffset = 0L;
    private DFSourceDeserializer dfSourceDeserializer;
    private transient volatile CountDownLatch runningLatch;

    private Subscription subscription;

    public CRMSourceNew(String topic, String topciName, String groupId, DataFabricUtil dataFabricUtil,
            boolean isStartFromOffset, Long specificOffset) {
        this.watchId = topic;
        this.watchName = topciName;
        this.watchGroupId = groupId;
        this.dataFabricUtil = dataFabricUtil;
        this.isStartFromOffset = isStartFromOffset;
        this.specificOffset = specificOffset;
    }

    @Override
    public void open(Configuration configuration) throws Exception {
        ParameterTool params = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        MDCUtil.putJobNameInMDC(params);

        runningLatch = new CountDownLatch(1);

        dfSourceDeserializer = new DFSourceDeserializer(dataFabricUtil);

        dataFabricClient = dataFabricUtil.getDataFabricClient();
        logger.info("DataFabric client initialized, version = {}, for watch id = {}",
                dataFabricClient.getClientVersion().getBuildVersion(), watchId);

        ConsumerConfigurationBuilder consumerConfiguration = ConsumerConfigurationBuilder.create()
                                                                                         .withGroupId(watchGroupId)
                                                                                         .withAutoCommit(false)
                                                                                                 /*withSessionTimeoutInMs(
                                                                                                         Integer.MAX_VALUE)
                                                                                         .withRequestTimeoutInMs(
                                                                                                 Integer.MAX_VALUE)*/;

        if (isStartFromOffset) {
            logger.info("Starting with Manually provided offset {}, watchName {}", specificOffset, watchName);
            offset = specificOffset;
        }

        if (offset != null) {
            consumerConfiguration.withStartOffset(offset);
        } else {
            consumerConfiguration.withStartFrom(StartFrom.BEGINNING);
        }

        logger.info("Resuming durable watch scan, watchId = {}, offset={}", watchId, offset);

        try {
            watchContext = dataFabricClient.resumeDurableWatchScan(ResumeDurableWatchScanRequestBuilder.create(watchId)
                                                                                                       .withConsumerConfiguration(
                                                                                                               consumerConfiguration
                                                                                                                       .build()));
        } catch (Exception e) {
            throw new CRMException(
                    format("Failed to resume durable watch scan, offset = %s, topic=%s", offset, watchName), e);
        }

        logger.info("Durable watch scan resumed, topic = {}, offset={}", watchName, offset);
        offsetCommitter = watchContext.getOffsetCommitter();

        getRuntimeContext()
                .addAccumulator("numSubscription" + watchName + "SourceEvents ", this.numSubscriptionSourceEvents);
    }

    @Override
    public void run(SourceContext<CRMSourceEvent> ctx) throws InterruptedException {
        //MDC for logging
        ParameterTool parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        MDCUtil.putJobNameInMDC(parameters);

        subscription = watchContext.getSubject().subscribe(new Subscriber<ContinuousQueryEvent>() {
            @Override
            public void onCompleted() {
                cancel();
            }

            @Override
            public void onError(Throwable throwable) {
                logger.error("On Error method called ", (Exception) throwable);
                cancel();
                throw new CRMException("On Error method called {}", (Exception) throwable);
            }

            @Override
            public void onNext(ContinuousQueryEvent event) {
                MDCUtil.putJobNameInMDC(parameters);

                CRMSourceEvent crmSourceEvent = null;
                if (event instanceof ContinuousQuerySnapshotStreamFailedEvent) {
                    ContinuousQuerySnapshotStreamFailedEvent evt = (ContinuousQuerySnapshotStreamFailedEvent) event;
                    logger.info("Durable watch scan initial snapshot load failed, watchName={} cause={}", watchName,
                            evt.getCause());
                    return;
                } else if (event instanceof ContinuousQuerySnapshotStreamEvent) {
                    ContinuousQuerySnapshotStreamEvent evt = (ContinuousQuerySnapshotStreamEvent) event;
                    crmSourceEvent = createCRMEvent(evt.getCollectionName(), evt.getOffset(), evt.getRecord());
                } else if (event instanceof ContinuousQueryInsertEvent) {
                    ContinuousQueryInsertEvent evt = (ContinuousQueryInsertEvent) event;
                    crmSourceEvent = createCRMEvent(evt.getCollectionName(), evt.getOffset(), evt.getRecord());
                } else if (event instanceof ContinuousQueryUpdateEvent) {
                    ContinuousQueryUpdateEvent evt = (ContinuousQueryUpdateEvent) event;
                    crmSourceEvent = createCRMEvent(evt.getCollectionName(), evt.getOffset(), evt.getRecord());
                } else if (event instanceof ContinuousQuerySnapshotStreamEndedEvent) {
                    ContinuousQuerySnapshotStreamEndedEvent evt = (ContinuousQuerySnapshotStreamEndedEvent) event;
                    return;
                }
                if (crmSourceEvent != null) {
                    synchronized (ctx.getCheckpointLock()) {
                        ctx.collect(crmSourceEvent);
                        offset = crmSourceEvent.getOffset();
                        numSubscriptionSourceEvents.add(1);
                    }
                }
            }
        });
        runningLatch.await();
        subscription.unsubscribe();
    }

    private CRMSourceEvent createCRMEvent(String collectionName, long offset, Record record) {
        CRMSourceEvent crmSourceEvent = null;

        CRMSourceEventType crmSourceEventType = CRMSourceEventType.get(collectionName);

        switch (crmSourceEventType) {
        case AccountCoverage:
            AccountCoverage accountCoverage = dfSourceDeserializer.deserialize(record, AccountCoverage.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.AccountCoverage, record.getId().getKey()).setAccountCoverage(accountCoverage);
            break;
        case CallLog:
            CallLog callLog = dfSourceDeserializer.deserialize(record, CallLog.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.CallLog, record.getId().getKey()).setCallLog(callLog);
            break;
        case CallReport:
            CallReport callReport = dfSourceDeserializer.deserialize(record, CallReport.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.CallReport, record.getId().getKey()).setCallReport(callReport);
            break;
        case Contact:
            Contact contact = dfSourceDeserializer.deserialize(record, Contact.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.Contact, record.getId().getKey()).setContact(contact);
            break;
        case ContactCoverage:
            ContactCoverage contactCoverage = dfSourceDeserializer.deserialize(record, ContactCoverage.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.ContactCoverage, record.getId().getKey()).setContactCoverage(contactCoverage);
            break;
        case Organization:
            Organization organization = dfSourceDeserializer.deserialize(record, Organization.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.Organization, record.getId().getKey()).setOrganization(organization);
            break;
        case User:
            User user = dfSourceDeserializer.deserialize(record, User.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.User, record.getId().getKey()).setUser(user);
            break;
        case UserRole:
            UserRole userRole = dfSourceDeserializer.deserialize(record, UserRole.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.UserRole, record.getId().getKey()).setUserRole(userRole);
            break;
        case Interest:
            Interest interest = dfSourceDeserializer.deserialize(record, Interest.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.Interest, record.getId().getKey()).setInterest(interest);
            break;
        case AccountDesk:
            AccountDesk accountDesk = dfSourceDeserializer.deserialize(record, AccountDesk.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.AccountDesk, record.getId().getKey()).setAccountDesk(accountDesk);
            break;
        }
        return crmSourceEvent;
    }

    @Override
    public void notifyCheckpointComplete(long l) throws Exception {
        if (offset != null) {
            logger.info("Checkpoint complete, now committing to kafka, offset={}, topic = {}", offset, watchName);
            try {
                offsetCommitter.commit();
            } catch (Exception e) {
                logger.error("Offset commit to Kafka failed, offset={}, topic = {}", offset, watchName);
                throw new CRMException(
                        format("Offset commit to Kafka failed, offset = %s, topic = %s", offset, watchName), e);
            }
            logger.info("Offset committed to Kafka, offset={}, topic = {}", offset, watchName);
        }
    }

    @Override
    public void snapshotState(FunctionSnapshotContext functionSnapshotContext) {
        try {
            if (offset != null) {
                state.clear();
                logger.info("Checkpoint requested, offset={}, Topic = {}", offset, watchName);
                state.add(offset);
                logger.info("Checkpoint Saved, offset={}, Topic = {}", offset, watchName);
            } else {
                logger.info("Checkpoint requested, but no update to state, offset={}, Topic = {}", offset, watchName);
            }
        } catch (Exception e) {
            logger.error("snapshotState error offset = {}, Topic = {}", offset, watchName);
            throw new CRMException(format("snapshotState error offset = %s, topic = %s", offset, watchName), e);
        }
    }

    @Override
    public void initializeState(FunctionInitializationContext context) {
        try {
            state = context.getOperatorStateStore().getListState(new ListStateDescriptor<Long>(watchName, Long.class));

            if (context.isRestored()) {
                for (Long offset : state.get()) {
                    this.offset = offset;
                }

                if (offset != null) {
                    logger.info("State restored, topic={} offset={}", watchName, offset);
                }
            } else {
                logger.info("State initialized, topic={}", watchName);
            }
        } catch (Exception e) {
            logger.error("initializeState error, topic={}", watchName);
            throw new CRMException("initializeState error, topic=" + watchName, e);
        }
    }

    @Override
    public void cancel() {
        runningLatch.countDown();
        if (subscription != null) {
            try {
                subscription.unsubscribe();
            } catch (Exception e) {
                logger.error("Exception occurred while unsubscribe, watchName = {}", watchName, e);
            }
        }
        dataFabricUtil.close();
    }
}
