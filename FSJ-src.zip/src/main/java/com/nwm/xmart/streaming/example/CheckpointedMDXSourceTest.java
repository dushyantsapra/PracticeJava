package com.nwm.xmart.streaming.example;

import com.nwm.xmart.sso.EncryptDecryptAES;
import com.nwm.xmart.streaming.common.job.StreamJob;
import com.nwm.xmart.streaming.source.mdx.MdxIsinSource;
import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.streaming.source.mdx.event.MdxEventType;
import com.nwm.xmart.streaming.source.mdx.session.MDXSessionType;
import com.rbs.datafabric.client.DataFabricClient;
import com.rbs.datafabric.client.DataFabricClientFactory;
import com.rbs.datafabric.domain.ClientConfiguration;
import com.rbs.datafabric.domain.Credentials;
import com.rbs.datafabric.domain.Document;
import com.rbs.datafabric.domain.client.builder.InsertRequestBuilder;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;

import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by gardlex on 18/10/2017.
 */
public class CheckpointedMDXSourceTest {

    private static Logger logger = LoggerFactory.getLogger(CheckpointedMDXSourceTest.class);

    public static void main(String[] args) throws Exception {

        // Populate cache with 10 stream events
        CheckpointedMDXSourceTest t = new CheckpointedMDXSourceTest();
        t.buildStream(args);

    }

    public void buildStream(String[] args) throws Exception {
        // StreamJob implementation can override any abstract methid as long as it calls super() first
        MdxStreamJob streamJob = new MdxStreamJob();
        streamJob.run(args);
    }

    class MdxStreamJob extends StreamJob {

        @Override
        protected void configureAndExecuteStream(StreamExecutionEnvironment env) {

            String data = parameters.get("rdx.facet.data");

            try {
                // Type info reqd for the FlinkDeserializer
                final TypeInformation<MdxDocumentEvent> mdxSourceEventType = TypeInformation.of(new TypeHint<MdxDocumentEvent>(){});
                Class<MdxDocumentEvent> mdxSourceClassRef = mdxSourceEventType.getTypeClass();



                // Configuration of the stream
//            DataStream<MdxDocumentEvent> input = env
//                    .addSource(src1, mdxSourceEventType)
//                    .addS
//                    .uid("MDX_SOURCE_UID")
//                    .name("MDX_SOURCE_NAME")
//                    .setParallelism(1);

                DataStream<MdxDocumentEvent> stream1 = configureSrc1(env, parameters, mdxSourceClassRef, mdxSourceEventType);
                DataStream<MdxDocumentEvent> stream2 = configureSrc2(env, parameters, mdxSourceClassRef, mdxSourceEventType);
                DataStream<MdxDocumentEvent> stream3 = configureSrc3(env, parameters, mdxSourceClassRef, mdxSourceEventType);
                DataStream<MdxDocumentEvent> stream4 = configureSrc4(env, parameters, mdxSourceClassRef, mdxSourceEventType);
                DataStream<MdxDocumentEvent> joinedMdxStream = stream1.union(stream2, stream3, stream4);

                joinedMdxStream.addSink(new TestSink())

//                stream4.addSink(new TestSink())
//                stream1.addSink(new TestSink())
//                stream2.addSink(new TestSink())
//                stream4.addSink(new TestSink())
                        .uid("MDX-DF-Sink")
                        .name("MDX-DF-Sink")
                        .setParallelism(3);
                env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);


                String execPlan = env.getExecutionPlan();
                logger.info("EXECUTION PLAN = " + execPlan);
                env.execute(configuration.getString("flink.job.name",""));
            } catch (Exception e) {
                logger.error("Exception running the CheckpointedMDXSourceTest",e);
                throw new RuntimeException(e);
            }
        }
    }

    private DataStream<MdxDocumentEvent> configureSrc1(StreamExecutionEnvironment env, ParameterTool parameters, Class<MdxDocumentEvent> mdxSourceClassRef, TypeInformation<MdxDocumentEvent> mdxSourceEventType) {
        SourceFunction<MdxDocumentEvent> src1 =  new MdxIsinSource<MdxDocumentEvent>("1",
                mdxSourceClassRef,
                parameters.get("mdx.src1.initialLoad.identifier"),
                parameters.get("mdx.src1.initialLoad.identifier.wildcard"),
                parameters.get("mdx.src1.subscription.identifier"),
                parameters.get("mdx.src1.subscription.identifier.wildcard"),
                parameters.get("mdx.src1.sourceName"),
                MdxEventType.SERIES_VIEW,
                MDXSessionType.SSO,
                parameters.get("mdx.src1.sql.isin.query"));
        DataStream<MdxDocumentEvent> dateStream = env.addSource(src1, mdxSourceEventType)
                .uid("MDX_FOREIGN_EXCHANGE")
                .name("MDX_FOREIGN_EXCHANGE")
                .setParallelism(1);

        return dateStream;
    }

    private DataStream<MdxDocumentEvent> configureSrc2(StreamExecutionEnvironment env, ParameterTool parameters, Class<MdxDocumentEvent> mdxSourceClassRef, TypeInformation<MdxDocumentEvent> mdxSourceEventType) {
        SourceFunction<MdxDocumentEvent> src2 =  new MdxIsinSource<MdxDocumentEvent>("2",
                mdxSourceClassRef,
                parameters.get("mdx.src2.initialLoad.identifier"),
                parameters.get("mdx.src2.initialLoad.identifier.wildcard"),
                parameters.get("mdx.src2.subscription.identifier"),
                parameters.get("mdx.src2.subscription.identifier.wildcard"),
                parameters.get("mdx.src2.sourceName"),
                MdxEventType.SERIES_VIEW,
                MDXSessionType.SSO,
                parameters.get("mdx.src2.sql.isin.query"));
        DataStream<MdxDocumentEvent> dateStream = env.addSource(src2, mdxSourceEventType)
                .uid("MDX_CREDIT")
                .name("MDX_CREDIT")
                .setParallelism(1);

        return dateStream;
    }

    private DataStream<MdxDocumentEvent> configureSrc3(StreamExecutionEnvironment env, ParameterTool parameters, Class<MdxDocumentEvent> mdxSourceClassRef, TypeInformation<MdxDocumentEvent> mdxSourceEventType) {
        SourceFunction<MdxDocumentEvent> src3 =  new MdxIsinSource<MdxDocumentEvent>("3",
                mdxSourceClassRef,
                parameters.get("mdx.src3.initialLoad.identifier"),
                parameters.get("mdx.src3.initialLoad.identifier.wildcard"),
                parameters.get("mdx.src3.subscription.identifier"),
                parameters.get("mdx.src3.subscription.identifier.wildcard"),
                parameters.get("mdx.src3.sourceName"),
                MdxEventType.SERIES_VIEW,
                MDXSessionType.SSO,
                parameters.get("mdx.src3.sql.isin.query"));
        DataStream<MdxDocumentEvent> dateStream = env.addSource(src3, mdxSourceEventType)
                .uid("MDX_RATES")
                .name("MDX_RATES")
                .setParallelism(1);

        return dateStream;
    }

    private DataStream<MdxDocumentEvent> configureSrc4(StreamExecutionEnvironment env, ParameterTool parameters, Class<MdxDocumentEvent> mdxSourceClassRef, TypeInformation<MdxDocumentEvent> mdxSourceEventType) {
        SourceFunction<MdxDocumentEvent> src4 =  new MdxIsinSource<MdxDocumentEvent>("4",
                mdxSourceClassRef,
                parameters.get("mdx.src4.initialLoad.identifier"),
                parameters.get("mdx.src4.initialLoad.identifier.wildcard"),
                parameters.get("mdx.src4.subscription.identifier"),
                parameters.get("mdx.src4.subscription.identifier.wildcard"),
                parameters.get("mdx.src4.sourceName"),
                MdxEventType.TIME_SERIES,
                MDXSessionType.SSO,
                parameters.get("mdx.src4.sql.isin.query"));
        DataStream<MdxDocumentEvent> dateStream = env.addSource(src4, mdxSourceEventType)
                .uid("MDX_TIME_SERIES")
                .name("MDX_TIME_SERIES")
                .setParallelism(1);

        return dateStream;
    }

    class TestSink extends RichSinkFunction<MdxDocumentEvent> implements CheckpointListener {

        private Logger logger = LoggerFactory.getLogger(TestSink.class);
        private DataFabricClient dataFabricClient;

        private int ctr;

        public TestSink() throws IOException {
        }

        @Override
        public void notifyCheckpointComplete(long checkpointId) throws Exception {
            logger.info("TestSINK Checkpoint RECD = " + checkpointId);
        }

        @Override
        public void invoke(MdxDocumentEvent event) throws Exception {
            Document document = dataFabricClient.getDataFabricSerializer().serialize(event);
            dataFabricClient.insert(InsertRequestBuilder.create("session-db", "session-mdx-test-2").withDocument(document));
        }

        @Override
        public void open(Configuration parameters) throws Exception {
            dataFabricClient = getDFC();
        }

        private DataFabricClient getDFC() throws Exception {
            // TST
            ClientConfiguration clientConfiguration = new ClientConfiguration().withCredentials(new Credentials().withUsername("svc-XMartAppUat")
                    .withPassword(EncryptDecryptAES.decrypt("Gl6c8x+8lGbkwF0HWPDRSg==")))
                    .withHost("DATAFABRIC-TST")
                    .withAccessToken(EncryptDecryptAES.decrypt("9k1IyB07YGjc1r5rQf1MgrdZH6XNdr1WT0UEWLz1XmVX7tupKZdtPA2t/iljneNe"));

            DataFabricClient dataFabricClient = DataFabricClientFactory.createDataFabricClient(clientConfiguration);
            return dataFabricClient;
        }
    }

}
