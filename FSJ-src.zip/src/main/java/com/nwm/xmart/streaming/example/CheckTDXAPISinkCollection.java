package com.nwm.xmart.streaming.example;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nwm.xmart.streaming.source.json.JSONDocumentTraverser;
import com.nwm.xmart.streaming.source.tdx.event.TDXSourceEvent;
import com.rbs.datafabric.client.DataFabricClient;
import com.rbs.datafabric.client.DataFabricClientFactory;
import com.rbs.datafabric.common.DataFabricSerializerException;
import com.rbs.datafabric.common.serialization.DataFabricSerializer;
import com.rbs.datafabric.domain.*;
import com.rbs.datafabric.domain.client.builder.DropCollectionRequestBuilder;
import com.rbs.datafabric.domain.client.builder.InsertRequestBuilder;
import com.rbs.datafabric.domain.client.builder.ScanRequestBuilder;
import org.apache.flink.util.ExceptionUtils;

import java.time.LocalDateTime;
import java.util.*;

/**
 * Created by gardlex on 29/03/2018.
 */
public class CheckTDXAPISinkCollection {

    public static void main(String[] args) throws Exception {
        CheckTDXAPISinkCollection checkRdxSinkCollection = new CheckTDXAPISinkCollection();
//        checkRdxSinkCollection.validateState();
        checkRdxSinkCollection.deleteColl();
//        checkRdxSinkCollection.testInsert();
    }

    private void testInsert() throws Exception {
        ObjectNode json = null;
        TDXSourceEvent sourceEvent = new TDXSourceEvent(
                new JSONDocumentTraverser(json),
                "1",
                "testCollection",
                System.currentTimeMillis(),
                0,
                LocalDateTime.of(2019,01,01,0,0,0),
                LocalDateTime.of(2019,02,01,0,0,0)
        );
        final DataFabricClient dataFabricClient = getDFC();
        Document document = dataFabricClient.getDataFabricSerializer()
                .withDocumentFormat(DocumentFormat.BSON)
                .serialize(sourceEvent);
        dataFabricClient.insert(InsertRequestBuilder.create("bdx-db", "tdx-api-source-test-1").withDocument(document));

    }

    private void deleteColl() throws Exception {
        final DataFabricClient dataFabricClient = getDFC();
        final DataFabricSerializer dataFabricSerializer = dataFabricClient.getDataFabricSerializer();
        dataFabricClient.dropCollection(DropCollectionRequestBuilder.create("bdx-db", "tdx-api-source-test-1"));
        Thread.sleep(3000);

        dataFabricClient.close();
    }


    public void validateState() throws Exception {
        final DataFabricClient dataFabricClient = getDFC();
        final DataFabricSerializer dataFabricSerializer = dataFabricClient.getDataFabricSerializer();


//        "bdx-db", "bdx-rdx-test"

        //                                .withExpression("integerValue = 2 and doubleValue > 1.2 and stringValue = 'Hello, world!'")

        ScanExpression scanExpression = new ScanExpression()
                .withDatabaseName("bdx-db")
                .withCollectionName("bdx-kdb-enquiry-2")
                .withPageLimit(1000000)
                .withWhereExpression(
                        new WhereExpression()//.withExpression("kdbsortKey is not null")
                );

        // here are the records we wanted
        Iterable<Record> foundRecords = dataFabricClient.scan(
                ScanRequestBuilder.create(scanExpression) //.withComment("Hello World Scan"));
        );

        // EPOCH TIME
//        List<Long> list = new ArrayList<>();
//
//        int count = 0;
//        for (Record foundRecord : foundRecords) {
//            long value = getEpochDateTime(dataFabricSerializer, foundRecord);
//            if (value == 0) {
//                count++;
//            }
//            list.add(value);
//        }


        List<String> list = new ArrayList<>();

        int count = 0;
        for (Record foundRecord : foundRecords) {
            String value = getDateTime(dataFabricSerializer, foundRecord);

            list.add(value);
        }

        System.out.println("count = " + count + "  list size " + list.size());
        checkDateTime(list);



        Thread.sleep(3000);

        dataFabricClient.close();
    }

    private void checkEpochTime(List<Long> list) {
        Collections.sort(list);

        HashMap<Long,Integer> dupes = new HashMap<>();

        Long lastValue = null;

        for (Long l : list) {
            if (lastValue == null) {
                lastValue = l;
            } else {
                if (l.longValue() < lastValue.longValue()) {
                }
                if (l.longValue() - lastValue.longValue() == 0) {
                    Integer cachedCount = dupes.get(l);
                    if ( cachedCount == null) {
                        dupes.put(l,2);
                    } else {
                        dupes.put(l,cachedCount.intValue() +1);
                    }
                }
                lastValue = l;
            }
        }

        printLongDupes(dupes);
    }

    private void checkDateTime(List<String> list) {
        Collections.sort(list);

        HashMap<String,Integer> dupes = new HashMap<>();

        String lastValue = null;

        for (String l : list) {
            if (lastValue == null) {
                lastValue = l;
            } else {
                if (l.equals(lastValue)) {
                    Integer cachedCount = dupes.get(l);
                    if ( cachedCount == null) {
                        dupes.put(l,2);
                    } else {
                        dupes.put(l,cachedCount.intValue() +1);
                    }
                }
                lastValue = l;
            }
        }

        printStringDupes(dupes);
    }

    private void printLongDupes(HashMap<Long, Integer> map) {
        for (Map.Entry<Long,Integer> value : map.entrySet()) {
        }
    }

    private void printStringDupes(HashMap<String, Integer> map) {

        for (Map.Entry<String,Integer> value : map.entrySet()) {
        }
    }

    private void checkForDuplicates(List<Long> list) {

    }


    private DataFabricClient getDFC() throws Exception {
        // TST
        ClientConfiguration clientConfiguration = new ClientConfiguration().withCredentials(new Credentials().withUsername("svc-XMartAppUat")
                .withPassword("As03!#rV12"))
                .withHost("DATAFABRIC-TST")
                .withAccessToken("631d6bb8-feb9-4504-b725-fd069c3ebedf");
        // DEV
//        ClientConfiguration clientConfiguration = new ClientConfiguration().withCredentials(new Credentials().withUsername("svc-XMartAppDev")
//                .withPassword("$zt[o3XM"))
//                .withHost("datafabric-dev")
//                .withAccessToken("631d6bb8-feb9-4504-b725-fd069c3ebedf");

        DataFabricClient dataFabricClient = DataFabricClientFactory.createDataFabricClient(clientConfiguration);
        return dataFabricClient;
    }

    private long getEpochDateTime(DataFabricSerializer dataFabricSerializer, Record record) throws Exception {
//        KDBSourceEvent event = null;
        Map event = null;
        try {
             event = dataFabricSerializer.deserialize(record.getDocument(), Map.class) ; //KDBSourceEvent.class);
        } catch (DataFabricSerializerException e) {

        }

        Map eventValue = (Map)event.get("kdbsortKey");
//        eventValue.get()

        long sortKeyValue = (long)eventValue.get("sortKeyValue");

//        if (event == null) {
////            throw new Exception("event was NULL");
//        }

//        if (event.getKDBSortKey() == null) {
//            return 0;
//        }
        return sortKeyValue; //(long)event.getKDBSortKey().getSortKeyValue();
    }

    private String getDateTime(DataFabricSerializer dataFabricSerializer, Record record) throws Exception {
        Map event = null;
        try {
            event = dataFabricSerializer.deserialize(record.getDocument(), Map.class) ; //KDBSourceEvent.class);
        } catch (DataFabricSerializerException e) {

        }

        String dateTime = (String)event.get("dateTime");

        return dateTime;
    }
}
