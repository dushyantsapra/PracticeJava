package com.nwm.xmart.streaming.source.xml;

/**
 * Created by gardlex on 18/10/2018.
 */
public class XmlTraverserRuntimeException extends RuntimeException {

    public XmlTraverserRuntimeException() {
        super();
    }

    public XmlTraverserRuntimeException(String msg) {
        super(msg);
    }

    public XmlTraverserRuntimeException(String msg, Throwable t) {
        super(msg, t);
    }
}
