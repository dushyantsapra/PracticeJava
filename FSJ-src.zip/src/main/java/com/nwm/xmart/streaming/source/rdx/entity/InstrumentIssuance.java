
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AnnouncementDate",
    "Country",
    "Currency",
    "PrivatePlacementIndicator",
    "IssueDate",
    "IssuePrice",
    "ReopenSettle",
    "ReopenAuction",
    "ReopenAnnouncement",
    "OffshoreCurrency"
})
public class InstrumentIssuance {

    @JsonProperty("AnnouncementDate")
    private Object announcementDate;
    @JsonProperty("Country")
    private Object country;
    @JsonProperty("Currency")
    private String currency;
    @JsonProperty("PrivatePlacementIndicator")
    private Boolean privatePlacementIndicator;
    @JsonProperty("IssueDate")
    private String issueDate;
    @JsonProperty("IssuePrice")
    private Double issuePrice;
    @JsonProperty("ReopenSettle")
    private Object reopenSettle;
    @JsonProperty("ReopenAuction")
    private Object reopenAuction;
    @JsonProperty("ReopenAnnouncement")
    private Object reopenAnnouncement;
    @JsonProperty("OffshoreCurrency")
    private Object offshoreCurrency;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("AnnouncementDate")
    public Object getAnnouncementDate() {
        return announcementDate;
    }

    @JsonProperty("AnnouncementDate")
    public void setAnnouncementDate(Object announcementDate) {
        this.announcementDate = announcementDate;
    }

    @JsonProperty("Country")
    public Object getCountry() {
        return country;
    }

    @JsonProperty("Country")
    public void setCountry(Object country) {
        this.country = country;
    }

    @JsonProperty("Currency")
    public String getCurrency() {
        return currency;
    }

    @JsonProperty("Currency")
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @JsonProperty("PrivatePlacementIndicator")
    public Boolean getPrivatePlacementIndicator() {
        return privatePlacementIndicator;
    }

    @JsonProperty("PrivatePlacementIndicator")
    public void setPrivatePlacementIndicator(Boolean privatePlacementIndicator) {
        this.privatePlacementIndicator = privatePlacementIndicator;
    }

    @JsonProperty("IssueDate")
    public String getIssueDate() {
        return issueDate;
    }

    @JsonProperty("IssueDate")
    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    @JsonProperty("IssuePrice")
    public Double getIssuePrice() {
        return issuePrice;
    }

    @JsonProperty("IssuePrice")
    public void setIssuePrice(Double issuePrice) {
        this.issuePrice = issuePrice;
    }

    @JsonProperty("ReopenSettle")
    public Object getReopenSettle() {
        return reopenSettle;
    }

    @JsonProperty("ReopenSettle")
    public void setReopenSettle(Object reopenSettle) {
        this.reopenSettle = reopenSettle;
    }

    @JsonProperty("ReopenAuction")
    public Object getReopenAuction() {
        return reopenAuction;
    }

    @JsonProperty("ReopenAuction")
    public void setReopenAuction(Object reopenAuction) {
        this.reopenAuction = reopenAuction;
    }

    @JsonProperty("ReopenAnnouncement")
    public Object getReopenAnnouncement() {
        return reopenAnnouncement;
    }

    @JsonProperty("ReopenAnnouncement")
    public void setReopenAnnouncement(Object reopenAnnouncement) {
        this.reopenAnnouncement = reopenAnnouncement;
    }

    @JsonProperty("OffshoreCurrency")
    public Object getOffshoreCurrency() {
        return offshoreCurrency;
    }

    @JsonProperty("OffshoreCurrency")
    public void setOffshoreCurrency(Object offshoreCurrency) {
        this.offshoreCurrency = offshoreCurrency;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("announcementDate", announcementDate).append("country", country).append("currency", currency).append("privatePlacementIndicator", privatePlacementIndicator).append("issueDate", issueDate).append("issuePrice", issuePrice).append("reopenSettle", reopenSettle).append("reopenAuction", reopenAuction).append("reopenAnnouncement", reopenAnnouncement).append("offshoreCurrency", offshoreCurrency).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(country).append(privatePlacementIndicator).append(reopenSettle).append(issuePrice).append(reopenAuction).append(announcementDate).append(currency).append(offshoreCurrency).append(additionalProperties).append(issueDate).append(reopenAnnouncement).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InstrumentIssuance) == false) {
            return false;
        }
        InstrumentIssuance rhs = ((InstrumentIssuance) other);
        return new EqualsBuilder().append(country, rhs.country).append(privatePlacementIndicator, rhs.privatePlacementIndicator).append(reopenSettle, rhs.reopenSettle).append(issuePrice, rhs.issuePrice).append(reopenAuction, rhs.reopenAuction).append(announcementDate, rhs.announcementDate).append(currency, rhs.currency).append(offshoreCurrency, rhs.offshoreCurrency).append(additionalProperties, rhs.additionalProperties).append(issueDate, rhs.issueDate).append(reopenAnnouncement, rhs.reopenAnnouncement).isEquals();
    }

}
