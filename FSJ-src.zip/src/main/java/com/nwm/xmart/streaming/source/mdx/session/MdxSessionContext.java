package com.nwm.xmart.streaming.source.mdx.session;

import rbs.gbm.mdx.webService.interfaces.IMdxSession;
import rbs.gbm.mdx.webService.interfaces.IMdxTimeSeriesSession;
import rbs.gbm.mdx.webService.interfaces.MdxException;

import java.util.concurrent.atomic.AtomicReference;

/**
 * Holder for TimeSeries and SeriesView MDX sessions.
 *
 * Created by gardlex on 20/04/2018.
 */
public class MdxSessionContext {
    private AtomicReference<IMdxSession> mdxSeriesViewSession = new AtomicReference<>();
    private AtomicReference<IMdxTimeSeriesSession> mdxTimeSeriesSession = new AtomicReference<>();

    public void setMdxSeriesViewSession(IMdxSession mdxSession) {
        this.mdxSeriesViewSession.set(mdxSession);
    }

    public void setMdxTimeSeriesSession(IMdxTimeSeriesSession timeSeriesSession) {
        this.mdxTimeSeriesSession.set(timeSeriesSession);
    }

    public IMdxSession getMdxSeriesViewSession() {
        if (mdxSeriesViewSession.get() == null) {
            throw new MdxSessionBuilderException("mdxSeriesViewSession has not been specified for this MdxSessionContext");
        }
        return mdxSeriesViewSession.get();
    }

    public IMdxTimeSeriesSession getMdxTimeSeriesSession() {
        if (mdxTimeSeriesSession.get() == null) {
            throw new MdxSessionBuilderException("mdxTimeSeriesSession has not been specified for this MdxSessionContext");
        }
        return mdxTimeSeriesSession.get();
    }

    public void close() {
        try {
            if (mdxSeriesViewSession.get() != null) {
                mdxSeriesViewSession.get().close();
            }
        } catch (MdxException e) {
        }

        try {
            if (mdxTimeSeriesSession.get() != null) {
                mdxTimeSeriesSession.get().close();
            }
        } catch (MdxException e) {
        }
    }
}
