package com.nwm.xmart.streaming.source.rdx.session;

import com.nwm.xmart.streaming.source.kdb.session.KDBSession;
import com.nwm.xmart.util.MDCUtil;
import org.apache.flink.api.java.utils.ParameterTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.dx.webService.impl.RdxSessionFactory;
import rbs.gbm.dx.webService.interfaces.IRdxSession;
import rbs.gbm.mdx.webService.interfaces.MdxException;

import java.util.concurrent.*;

/**
 * Created by gardlex on 22/05/2018.
 */
public class RDXSessionContext {
    private static Logger logger = LoggerFactory.getLogger(RDXSessionContext.class);
    private volatile String ssoToken;
    private volatile String applicationName;
    private volatile String applicationVersion;
    private volatile String rdxEnvironmentName;
    private final RdxSessionFactory factory;
    private volatile IRdxSession rdxSession;
    private transient ExecutorService executorService;
    private volatile RDXSessionContextType rdxSessionContextType;
    private volatile ParameterTool flinkParameters;

    public RDXSessionContext() throws Exception {
        factory = new RdxSessionFactory();
        this.executorService = Executors.newSingleThreadExecutor(
                new ThreadFactory() {
                    @Override
                    public Thread newThread(Runnable r) {
                        Thread t = new Thread(r);

                        t.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                            @Override
                            public void uncaughtException(Thread t, Throwable e) {
                                LoggerFactory.getLogger(t.getName()).error("RDXSessionContext thread for RDXSessionContextType [ " + rdxSessionContextType + " ], is no longer running", e.getMessage(), e);
                            }
                        });

                        return t;
                    }
                }
        );
    }

    public RDXSessionContext withRDXSessionContextType(RDXSessionContextType rdxSessionContextType) {
        this.rdxSessionContextType = rdxSessionContextType;
        return this;
    }

    public RDXSessionContext withRdxEnvironmentName(String rdxEnvironmentName) {
        this.rdxEnvironmentName = rdxEnvironmentName;
        return this;
    }

    public RDXSessionContext withApplicationVersion(String applicationVersion) {
        this.applicationVersion = applicationVersion;
        return this;
    }

    public RDXSessionContext withApplicationName(String applicationName) {
        this.applicationName = applicationName;
        return this;
    }

    public RDXSessionContext withSsoToken(String ssoToken) {
        this.ssoToken = ssoToken;
        return this;
    }

    public RDXSessionContext withFlinkParameters(ParameterTool flinkParameters){
        this.flinkParameters = flinkParameters;
        return this;
    }

    public void build() throws Exception {
        if (rdxSession == null) {
            buildRdxSession();
        }
    }

    public void buildNewSession() throws Exception {
        buildRdxSession();
    }

    private void buildRdxSession() throws InterruptedException, Exception {
        try {
            Future<IRdxSession> sessionFuture = executorService.submit(new Callable<IRdxSession>() {
                @Override
                public IRdxSession call() throws Exception {
                    MDCUtil.putJobNameInMDC(flinkParameters);
                    return factory.createSession(applicationName, applicationVersion, rdxEnvironmentName, ssoToken);
                }
            });
            rdxSession = sessionFuture.get(flinkParameters.getLong("rdx.session.build.timeout.secs", 300), TimeUnit.SECONDS);
        } catch (InterruptedException i) {
            Thread.currentThread().interrupt();
            logger.error("Building of IRdxSession was interrupted", i);
            executorService.shutdownNow();
            throw i;
        } catch (Exception e) {
            logger.error("Building of IRdxSession failed", e);
            throw e;
        }
    }

    public IRdxSession getRdxSession() {
        return rdxSession;
    }

    public void close() {
        try {
            rdxSession.close();
            executorService.shutdownNow();
        } catch (MdxException e) {
            logger.warn("Error whilst closing RDX Session", e);
        }
    }
}
