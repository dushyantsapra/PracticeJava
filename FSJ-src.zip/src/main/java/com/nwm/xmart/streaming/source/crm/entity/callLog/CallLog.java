package com.nwm.xmart.streaming.source.crm.entity.callLog;

import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Id", "Call_Id", "CallSeq", "Call_Classification", "State", "Started_On", "Ended_On", "Duration",
                     "callLogParticipants" })

public class CallLog implements Serializable {
    private static final long serialVersionUID = -7679493837479846638L;

    @JsonProperty("Id")
    private String id;
    @JsonProperty("Call_Id")
    private String callId;
    @JsonProperty("CallSeq")
    private Long callSeq;
    @JsonProperty("Call_Classification")
    private String callClassification;
    @JsonProperty("State")
    private String state;
    @JsonProperty("Started_On")
    private String startedOn;
    @JsonProperty("Ended_On")
    private String endedOn;
    @JsonProperty("Duration")
    private Long duration;
    @JsonProperty("callLogParticipants")
    private List<CallLogParticipant> callLogParticipants = null;

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("Call_Id")
    public String getCallId() {
        return callId;
    }

    @JsonProperty("Call_Id")
    public void setCallId(String callId) {
        this.callId = callId;
    }

    @JsonProperty("CallSeq")
    public Long getCallSeq() {
        return callSeq;
    }

    @JsonProperty("CallSeq")
    public void setCallSeq(Long callSeq) {
        this.callSeq = callSeq;
    }

    @JsonProperty("Call_Classification")
    public String getCallClassification() {
        return callClassification;
    }

    @JsonProperty("Call_Classification")
    public void setCallClassification(String callClassification) {
        this.callClassification = callClassification;
    }

    @JsonProperty("State")
    public String getState() {
        return state;
    }

    @JsonProperty("State")
    public void setState(String state) {
        this.state = state;
    }

    @JsonProperty("Started_On")
    public String getStartedOn() {
        return startedOn;
    }

    @JsonProperty("Started_On")
    public void setStartedOn(String startedOn) {
        this.startedOn = startedOn;
    }

    @JsonProperty("Ended_On")
    public String getEndedOn() {
        return endedOn;
    }

    @JsonProperty("Ended_On")
    public void setEndedOn(String endedOn) {
        this.endedOn = endedOn;
    }

    @JsonProperty("Duration")
    public Long getDuration() {
        return duration;
    }

    @JsonProperty("Duration")
    public void setDuration(Long duration) {
        this.duration = duration;
    }

    @JsonProperty("CallLogParticipants")
    public List<CallLogParticipant> getCallLogParticipants() {
        return callLogParticipants;
    }

    @JsonProperty("CallLogParticipants")
    public void setCallLogParticipants(List<CallLogParticipant> callLogParticipants) {
        this.callLogParticipants = callLogParticipants;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CallLog{");
        sb.append("id=").append(id);
        sb.append(", callId='").append(callId).append('\'');
        sb.append(", callSeq=").append(callSeq);
        sb.append(", callClassification='").append(callClassification).append('\'');
        sb.append(", state='").append(state).append('\'');
        sb.append(", startedOn='").append(startedOn).append('\'');
        sb.append(", endedOn='").append(endedOn).append('\'');
        sb.append(", duration=").append(duration);
        sb.append(", callLogParticipants=").append(callLogParticipants);
        sb.append('}');
        return sb.toString();
    }
}
