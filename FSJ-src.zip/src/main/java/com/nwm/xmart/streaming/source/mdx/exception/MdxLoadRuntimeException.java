package com.nwm.xmart.streaming.source.mdx.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class MdxLoadRuntimeException extends RuntimeException {

    public MdxLoadRuntimeException() {
        super();
    }

    public MdxLoadRuntimeException(String msg) {
        super(msg);
    }

    public MdxLoadRuntimeException(String msg, Throwable t) {
        super(msg, t);
    }
}
