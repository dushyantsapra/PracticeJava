package com.nwm.xmart.streaming.monitor;

import java.io.IOException;
import java.io.Serializable;

/**
 * Created by gardlex on 20/11/2017.
 */
public interface InactivityMonitor extends Serializable {
    public InactivityStatus getLastInactivityStatus();
    public void updateStreamPosition(long position) throws IOException;
}
