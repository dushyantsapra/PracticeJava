package com.nwm.xmart.streaming.source.df.event;

/**
 * Created by gardlex on 24/10/2017.
 */
public abstract class StreamEvent<T> {
    final protected T eventPayload;
    final protected long timestamp;
    final protected String topic;
    final protected int partition;
    final protected long streamPosition;
    final protected String dfKey;
    final protected long dfVersion;

    public StreamEvent(T eventPayload, long timestamp, String topic, int partition, long streamPosition, String dfKey, long dfVersion) {
        this.eventPayload = eventPayload;
        this.timestamp = timestamp;
        this.topic = topic;
        this.partition = partition;
        this.streamPosition = streamPosition;
        this.dfKey = dfKey;
        this.dfVersion = dfVersion;
    }

    public T getEventPayload() {
        return eventPayload;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getTopic() {
        return topic;
    }

    public int getPartition() {
        return partition;
    }

    public long getStreamPosition() {
        return streamPosition;
    }

    public String getDfKey() {
        return dfKey;
    }

    public long getDfVersion() {
        return dfVersion;
    }

    @Override
    public String toString() {
        return "StreamEvent{" +
                ", eventPayload=" + eventPayload +
                ", timestamp=" + timestamp +
                ", topic='" + topic + '\'' +
                ", partition=" + partition +
                ", streamPosition=" + streamPosition +
                ", dfKey='" + dfKey + '\'' +
                ", dfVersion=" + dfVersion +
                '}';
    }
}
