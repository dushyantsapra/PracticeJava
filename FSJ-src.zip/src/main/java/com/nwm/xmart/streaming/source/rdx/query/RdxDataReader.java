package com.nwm.xmart.streaming.source.rdx.query;

import com.nwm.xmart.streaming.source.rdx.json.Alia;
import com.nwm.xmart.streaming.source.rdx.json.RdxFixedIncome;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by gardlex on 23/05/2018.
 */
public class RdxDataReader {
    private static Logger logger = LoggerFactory.getLogger(RdxDataReader.class);

    public static String getIsinFromAliasFor(RdxFixedIncome rdxFixedIncome) {
        List<Alia> aliasList = rdxFixedIncome.getFacets().getAlias();
        String isinValue = null;
        for (Alia alia : aliasList) {
            if ("ISIN".equals(alia.getAliasType())) {
                isinValue = alia.getAliasValue();
                break;
            }
        }

        return isinValue;
    }

    public static String getExceptionDetailsFrom(RdxFixedIncome rdxFixedIncome) {
        Integer changeID = rdxFixedIncome.getRdxChangeId();
        String rdxId = rdxFixedIncome.getRdxId();
        String seriesId = rdxFixedIncome.getRdxSeriesId();
        String valuationDate = rdxFixedIncome.getValuationDate();
        Integer version = rdxFixedIncome.getVersion();
        return "changeID = " + changeID + ", rdxId = " + rdxId
                + ", seriesId = " + seriesId + ", valuationDate = " + valuationDate + ", version = " + version;
    }
}
