package com.nwm.xmart.streaming.source.kdb;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * NOT ThreadSafe
 *
 * Created by gardlex on 08/08/2018.
 */
public class KDBProcessingResultTracker {

    private static Logger logger = LoggerFactory.getLogger(KDBSource.class);

    // Records of each days processing
    private final List<String> daysFailedProcessing = new ArrayList<>();
    private final List<String> daysSuccessfullyProcessed = new ArrayList<>();
    private final List<String> daysNoDataAvailable = new ArrayList<>();
    private final List<String> daysNoAnalyticSession = new ArrayList<>();
    private final String functionName;

    public KDBProcessingResultTracker(String functionName) {
        this.functionName = functionName;
    }

    public void addDayFailedProcessing(String dayFailed) {
        daysFailedProcessing.add(dayFailed);
    }

    public void addDaySuccessfullyProcessed(String daySucceeded) {
        daysSuccessfullyProcessed.add(daySucceeded);
    }

    public void addDayNoDataAvailable(String dayNoData) {
        daysNoDataAvailable.add(dayNoData);
    }

    public void addDayNoAnalyticSession(String dayNoAnalyticSession) {
        daysNoAnalyticSession.add(dayNoAnalyticSession);
    }

    public void print() {
        logger.info("Function [ " + functionName + " ], Processing Status: no of daysFailedProcessing [ " + daysFailedProcessing.size() + " ]");
        logger.info("Function [ " + functionName + " ], Processing Status: no of daysSuccessfullyProcessed [ " + daysSuccessfullyProcessed.size() + " ]");
        logger.info("Function [ " + functionName + " ], Processing Status: no of daysNoDataAvailable [ " + daysNoDataAvailable.size() + " ]");
        logger.info("Function [ " + functionName + " ], Processing Status: no of daysNoAnalyticSession [ " + daysNoAnalyticSession.size() + " ]");

        for (String failedProcessingDay : daysFailedProcessing) {
            logger.error("Function [ " + functionName + " ], Failed to process day [ " + failedProcessingDay + " ]");
        }

        for (String successfulProcessingDay : daysSuccessfullyProcessed) {
            logger.info("Function [ " + functionName + " ], Successfully processed day [ " + successfulProcessingDay + " ]");
        }

        for (String noDataAvailableDay : daysNoDataAvailable) {
            logger.warn("Function [ " + functionName + " ], No KDB data available for day [ " + noDataAvailableDay + " ]");
        }

        for (String failedAnalyticSessionDay : daysNoAnalyticSession) {
            logger.error("Function [ " + functionName + " ], Failed to build anayltics session for day [ " + failedAnalyticSessionDay + " ]");
        }
    }
}
