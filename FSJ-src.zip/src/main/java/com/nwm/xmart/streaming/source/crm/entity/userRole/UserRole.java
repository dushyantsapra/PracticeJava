package com.nwm.xmart.streaming.source.crm.entity.userRole;

import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(
        { "CaseAccessForAccountOwner", "ContactAccessForAccountOwner", "DeveloperName", "ForecastUserId", "Id",
          "LastModifiedById", "LastModifiedDate", "MayForecastManagerShare", "Name", "OpportunityAccessForAccountOwner",
          "ParentRoleId", "PortalAccountId", "PortalAccountOwnerId", "PortalType", "RollupDescription",
          "SystemModstamp" })

public class UserRole implements Serializable {
    private static final long serialVersionUID = -2880436714498375978L;

    @JsonProperty("CaseAccessForAccountOwner")
    private String caseAccessForAccountOwner;
    @JsonProperty("ContactAccessForAccountOwner")
    private String contactAccessForAccountOwner;
    @JsonProperty("DeveloperName")
    private String developerName;
    @JsonProperty("ForecastUserId")
    private Object forecastUserId;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("MayForecastManagerShare")
    private Boolean mayForecastManagerShare;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("OpportunityAccessForAccountOwner")
    private String opportunityAccessForAccountOwner;
    @JsonProperty("ParentRoleId")
    private String parentRoleId;
    @JsonProperty("PortalAccountId")
    private Object portalAccountId;
    @JsonProperty("PortalAccountOwnerId")
    private Object portalAccountOwnerId;
    @JsonProperty("PortalType")
    private String portalType;
    @JsonProperty("RollupDescription")
    private String rollupDescription;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;

    @JsonProperty("CaseAccessForAccountOwner")
    public String getCaseAccessForAccountOwner() {
        return caseAccessForAccountOwner;
    }

    @JsonProperty("CaseAccessForAccountOwner")
    public void setCaseAccessForAccountOwner(String caseAccessForAccountOwner) {
        this.caseAccessForAccountOwner = caseAccessForAccountOwner;
    }

    @JsonProperty("ContactAccessForAccountOwner")
    public String getContactAccessForAccountOwner() {
        return contactAccessForAccountOwner;
    }

    @JsonProperty("ContactAccessForAccountOwner")
    public void setContactAccessForAccountOwner(String contactAccessForAccountOwner) {
        this.contactAccessForAccountOwner = contactAccessForAccountOwner;
    }

    @JsonProperty("DeveloperName")
    public String getDeveloperName() {
        return developerName;
    }

    @JsonProperty("DeveloperName")
    public void setDeveloperName(String developerName) {
        this.developerName = developerName;
    }

    @JsonProperty("ForecastUserId")
    public Object getForecastUserId() {
        return forecastUserId;
    }

    @JsonProperty("ForecastUserId")
    public void setForecastUserId(Object forecastUserId) {
        this.forecastUserId = forecastUserId;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("MayForecastManagerShare")
    public Boolean getMayForecastManagerShare() {
        return mayForecastManagerShare;
    }

    @JsonProperty("MayForecastManagerShare")
    public void setMayForecastManagerShare(Boolean mayForecastManagerShare) {
        this.mayForecastManagerShare = mayForecastManagerShare;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("OpportunityAccessForAccountOwner")
    public String getOpportunityAccessForAccountOwner() {
        return opportunityAccessForAccountOwner;
    }

    @JsonProperty("OpportunityAccessForAccountOwner")
    public void setOpportunityAccessForAccountOwner(String opportunityAccessForAccountOwner) {
        this.opportunityAccessForAccountOwner = opportunityAccessForAccountOwner;
    }

    @JsonProperty("ParentRoleId")
    public String getParentRoleId() {
        return parentRoleId;
    }

    @JsonProperty("ParentRoleId")
    public void setParentRoleId(String parentRoleId) {
        this.parentRoleId = parentRoleId;
    }

    @JsonProperty("PortalAccountId")
    public Object getPortalAccountId() {
        return portalAccountId;
    }

    @JsonProperty("PortalAccountId")
    public void setPortalAccountId(Object portalAccountId) {
        this.portalAccountId = portalAccountId;
    }

    @JsonProperty("PortalAccountOwnerId")
    public Object getPortalAccountOwnerId() {
        return portalAccountOwnerId;
    }

    @JsonProperty("PortalAccountOwnerId")
    public void setPortalAccountOwnerId(Object portalAccountOwnerId) {
        this.portalAccountOwnerId = portalAccountOwnerId;
    }

    @JsonProperty("PortalType")
    public String getPortalType() {
        return portalType;
    }

    @JsonProperty("PortalType")
    public void setPortalType(String portalType) {
        this.portalType = portalType;
    }

    @JsonProperty("RollupDescription")
    public String getRollupDescription() {
        return rollupDescription;
    }

    @JsonProperty("RollupDescription")
    public void setRollupDescription(String rollupDescription) {
        this.rollupDescription = rollupDescription;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("UserRole{");
        sb.append("caseAccessForAccountOwner='").append(caseAccessForAccountOwner).append('\'');
        sb.append(", contactAccessForAccountOwner='").append(contactAccessForAccountOwner).append('\'');
        sb.append(", developerName='").append(developerName).append('\'');
        sb.append(", forecastUserId=").append(forecastUserId);
        sb.append(", id='").append(id).append('\'');
        sb.append(", lastModifiedById='").append(lastModifiedById).append('\'');
        sb.append(", lastModifiedDate='").append(lastModifiedDate).append('\'');
        sb.append(", mayForecastManagerShare=").append(mayForecastManagerShare);
        sb.append(", name='").append(name).append('\'');
        sb.append(", opportunityAccessForAccountOwner='").append(opportunityAccessForAccountOwner).append('\'');
        sb.append(", parentRoleId='").append(parentRoleId).append('\'');
        sb.append(", portalAccountId=").append(portalAccountId);
        sb.append(", portalAccountOwnerId=").append(portalAccountOwnerId);
        sb.append(", portalType='").append(portalType).append('\'');
        sb.append(", rollupDescription='").append(rollupDescription).append('\'');
        sb.append(", systemModstamp='").append(systemModstamp).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
