package com.nwm.xmart.streaming.source.mdx.util;

import com.nwm.xmart.streaming.source.mdx.event.MdxEventType;
import com.nwm.xmart.streaming.source.mdx.event.ProcessingType;
import com.nwm.xmart.streaming.source.mdx.exception.MdxLoadFailureException;
import com.nwm.xmart.streaming.source.mdx.pull.*;
import com.nwm.xmart.streaming.source.mdx.session.MDXSessionType;
import com.nwm.xmart.streaming.source.mdx.session.MdxSessionBuilderException;
import com.nwm.xmart.streaming.source.mdx.session.MdxSessionContext;
import com.nwm.xmart.streaming.source.mdx.session.MdxSessionContextBuilder;
import com.nwm.xmart.streaming.source.mdx.subscription.*;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.java.utils.ParameterTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.dx.webService.impl.regulatory.RdxRegulationSessionFactory;
import rbs.gbm.dx.webService.interfaces.regulatory.IRdxRegulationSession;
import rbs.gbm.mdx.webService.impl.MdxSessionFactory;
import rbs.gbm.mdx.webService.impl.MdxTimeSeriesSessionFactory;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicLong;

import static com.nwm.xmart.streaming.sso.GenerateSSOToken.getSsoToken;

/**
 * Created by gardlex on 19/04/2018.
 */
public class MDXUtil<MdxSourceEvent> implements Serializable {

    private final static Logger logger = LoggerFactory.getLogger(MDXUtil.class);

    private final Class<MdxSourceEvent> sourceEventClass;

    public MDXUtil(Class<MdxSourceEvent> sourceEventClass) {
        this.sourceEventClass = sourceEventClass;
    }

    public static IRdxRegulationSession getRdxRegulationSession(ParameterTool params) throws Exception {
        IRdxRegulationSession session = new RdxRegulationSessionFactory()
                .createSession(params.get("mdx.applicationName"), params.get("mdx.applicationVersion"),
                        params.get("mdx.environmentName"), getSsoToken(params));
        return session;
    }

    public MdxReader createMdxDocumentStoreFetcher(MdxEventType mdxEventType,
            ParameterTool params,
            MdxSessionContext mdxSessionContext,
            String mdxInitialLoadIdentifier,
            IntCounter invalidMdxDocumentCtr,
            String sourceID,
            AtomicLong currentJobEventIDCounter) throws Exception {
        switch(mdxEventType) {
            case SERIES_VIEW:
                return createSeriesViewMdxDocumentStoreFetcher(params, mdxSessionContext, mdxInitialLoadIdentifier, invalidMdxDocumentCtr, sourceID, currentJobEventIDCounter);
            case TIME_SERIES:
                return createTimeSeriesMdxDocumentStoreFetcher(params, mdxSessionContext, mdxInitialLoadIdentifier, invalidMdxDocumentCtr, sourceID, currentJobEventIDCounter);
            default:
                throw new MdxLoadFailureException("createMdxDocumentStoreFetcher: unknown MdxEventType: " + mdxEventType);
        }
    }


    private MdxReader createSeriesViewMdxDocumentStoreFetcher(ParameterTool params,
                    MdxSessionContext mdxSessionContext,
                    String mdxInitialLoadIdentifier,
                    IntCounter invalidMdxDocumentCtr,
                    String sourceID,
                    AtomicLong currentJobEventIDCounter) {

        return new SeriesMdxReader.Builder(sourceID)
                                .withMdxSessionContext(mdxSessionContext)
                                .withMdxIdentifier(mdxInitialLoadIdentifier)
                                .withCurrentJobEventIDCounter(currentJobEventIDCounter)
                                .withInvalidDocumentCounter(invalidMdxDocumentCtr)
                                .withReadBatchSize(params.getInt("mdx.readBatchSize"))
                                .build();

    }

    private MdxReader createTimeSeriesMdxDocumentStoreFetcher(ParameterTool params,
            MdxSessionContext mdxSessionContext,
            String mdxInitialLoadIdentifier,
            IntCounter invalidMdxDocumentCtr,
            String sourceID,
            AtomicLong currentJobEventIDCounter) {
        return new TimeSeriesMdxReader.Builder(sourceID)
                .withMdxSessionContext(mdxSessionContext)
                .withMdxIdentifier(mdxInitialLoadIdentifier)
                .withCurrentJobEventIDCounter(currentJobEventIDCounter)
                .withInvalidDocumentCounter(invalidMdxDocumentCtr)
                .withReadBatchSize(params.getInt("mdx.readBatchSize"))
                .build();
    }

    public MdxPullRequestDocumentLoader<MdxSourceEvent> getMdxPullRequestEventExchange(MdxEventType mdxEventType, String mdxInitialLoadIdentifier) {
        switch(mdxEventType) {
            case SERIES_VIEW:
                return getSeriesViewMdxPullRequestDocumentLoader(mdxInitialLoadIdentifier);
            case TIME_SERIES:
                return getTimeSeriesMdxPullRequestDocumentLoader(mdxInitialLoadIdentifier);
            default:
                logger.error("Invalid MDX Event Type {}", mdxEventType);
                throw new IllegalArgumentException("Invalid MDX Event Type " + mdxEventType);
        }
    }

    @SuppressWarnings("unchecked")
    private MdxPullRequestDocumentLoader<MdxSourceEvent> getSeriesViewMdxPullRequestDocumentLoader(String mdxInitialLoadIdentifier) {
        return (MdxPullRequestDocumentLoader<MdxSourceEvent>) new SeriesViewMdxLoader()
                .withMdxIdentifier(mdxInitialLoadIdentifier);
    }

    @SuppressWarnings("unchecked")  //
    private MdxPullRequestDocumentLoader<MdxSourceEvent> getTimeSeriesMdxPullRequestDocumentLoader(String mdxInitialLoadIdentifier) {

        return (MdxPullRequestDocumentLoader<MdxSourceEvent>) new TimeSeriesMdxLoader()
                .withMdxIdentifier(mdxInitialLoadIdentifier);
    }


    public MdxSubscription<MdxSourceEvent> createMdxSubscription(MdxEventType mdxEventType,
                                                                 ParameterTool params,
                                                                 MdxRealTimeEventExchange<MdxSourceEvent> mdxSubscriptionEventExchange,
                                                                 String mdxSubscriptionIdentifier,
                                                                 String mdxSubscriptionIdentifierWildcard,
                                                                 String sourceID,
                                                                 AtomicLong currentJobEventIDCounter) throws Exception {
        switch(mdxEventType) {
            case SERIES_VIEW:
                return createSeriesViewMdxSubscription(mdxSubscriptionEventExchange, mdxSubscriptionIdentifier, mdxSubscriptionIdentifierWildcard, sourceID, currentJobEventIDCounter);
            case TIME_SERIES:
                return createTimeSeriesMdxSubscription(mdxSubscriptionEventExchange, mdxSubscriptionIdentifier, mdxSubscriptionIdentifierWildcard, sourceID, currentJobEventIDCounter);
            default:
                throw new MdxLoadFailureException("getMdxPullRequestEventExchange: unknown MdxEventType: " + mdxEventType);
        }
    }


    @SuppressWarnings("unchecked")
    private MdxSubscription<MdxSourceEvent> createSeriesViewMdxSubscription(MdxRealTimeEventExchange<MdxSourceEvent> mdxSubscriptionEventExchange,
                                                                            String mdxSubscriptionIdentifier,
                                                                            String mdxSubscriptionIdentifierWildcard,
                                                                            String sourceID,
                                                                            AtomicLong currentJobEventIDCounter) throws Exception {
        return new SeriesViewMdxSubscription(sourceEventClass, sourceID, currentJobEventIDCounter)
                .withMdxEventExchange(mdxSubscriptionEventExchange)
                .withMdxIdentifier(mdxSubscriptionIdentifier)
                .withMdxIdentifierWildcard(mdxSubscriptionIdentifierWildcard);
    }

    @SuppressWarnings("unchecked")
    private MdxSubscription<MdxSourceEvent> createTimeSeriesMdxSubscription(MdxRealTimeEventExchange<MdxSourceEvent> mdxSubscriptionEventExchange,
                                                                            String mdxSubscriptionIdentifier,
                                                                            String mdxSubscriptionIdentifierWildcard,
                                                                            String sourceID,
                                                                            AtomicLong currentJobEventIDCounter) throws Exception {
        return new TimeSeriesMdxSubscription(sourceEventClass, sourceID, currentJobEventIDCounter)
                .withMdxEventExchange(mdxSubscriptionEventExchange)
                .withMdxIdentifier(mdxSubscriptionIdentifier)
                .withMdxIdentifierWildcard(mdxSubscriptionIdentifierWildcard);
    }

    @SuppressWarnings("unchecked")
    public MdxRealTimeEventExchange<MdxSourceEvent> getMdxRealTimeEventExchange(ParameterTool params) {
        return (MdxRealTimeEventExchange<MdxSourceEvent>) new MdxSubscriptionEventExchange<MdxSourceEvent>()
                .withInitialCapacity(params.getInt("mdx.subscription.initialCapacity"));
    }

    public static MdxSessionContext getMdxSessionContextFor(ParameterTool params, MdxEventType mdxEventType,
            ProcessingType processingType, MDXSessionType mdxSessionType) throws Exception {
        MdxSessionContextBuilder builder = new MdxSessionContextBuilder();
        String ssoToken = getSsoToken(params);

        switch(mdxEventType) {
        // NOTE, Series view only ever needs series view session for initial load & subscription
        case SERIES_VIEW:
            builder
                    .withApplicationName(params.get("mdx.applicationName"))
                    .withApplicationVersion(params.get("mdx.applicationVersion"))
                    .withMdxEnvironmentName(params.get("mdx.environmentName"))
                    .withMdxSessionTimeout(params.getInt("mdx.sessionTimeout"))
                    .withSeriesViewMdxSessionFactory(new MdxSessionFactory());
            switch (mdxSessionType) {
            case MDX_ACCESS:
                builder.withSeriesViewMdxSession();
                break;
            case SSO:
                builder.withSSOToken(ssoToken);
                builder.withSSOSeriesViewMdxSession();
                break;
            default:
                throw new MdxSessionBuilderException("Unsupported type: " + mdxSessionType);
            }

            return builder.build();
        case TIME_SERIES:
            switch(processingType) {
            case LOAD:
                builder
                        .withApplicationName(params.get("mdx.applicationName"))
                        .withApplicationVersion(params.get("mdx.applicationVersion"))
                        .withMdxEnvironmentName(params.get("mdx.environmentName"))
                        .withMdxSessionTimeout(params.getInt("mdx.sessionTimeout"))
                        .withSeriesViewMdxSessionFactory(new MdxSessionFactory())
                        .withTimeSeriesMdxSessionFactory(new MdxTimeSeriesSessionFactory());
                switch (mdxSessionType) {
                case MDX_ACCESS:
                    builder.withSeriesViewMdxSession();
                    builder.withTimeSeriesMdxSession();
                    break;
                case SSO:
                    builder.withSSOToken(ssoToken);
                    builder.withSSOSeriesViewMdxSession();
                    builder.withSSOTimeSeriesMdxSession();
                    break;
                default:
                    throw new MdxSessionBuilderException("Unsupported type: " + mdxSessionType);
                }
                return builder.build();
            case SUBSCRIPTION:
                builder
                        .withApplicationName(params.get("mdx.applicationName"))
                        .withApplicationVersion(params.get("mdx.applicationVersion"))
                        .withMdxEnvironmentName(params.get("mdx.environmentName"))
                        .withTimeSeriesMdxSessionFactory(new MdxTimeSeriesSessionFactory());
                switch (mdxSessionType) {
                case MDX_ACCESS:
                    builder.withTimeSeriesMdxSession();
                    break;
                case SSO:
                    builder.withSSOToken(ssoToken);
                    builder.withSSOTimeSeriesMdxSession();
                    break;
                default:
                    throw new MdxSessionBuilderException("Unsupported type: " + mdxSessionType);
                }
                return builder.build();
            }
        default:
            throw new MdxLoadFailureException("getMdxPullRequestEventExchange: unknown MdxEventType: " + mdxEventType);
        }


    }
}
