package com.nwm.xmart.streaming.source.crm.entity.contactCoverage;

import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Name", "Category", "Description", "Expiry_Date", "Inactive", "Sub_Category" })
public class Product implements Serializable {
    private static final long serialVersionUID = 6030447487575803919L;

    @JsonProperty("Name")
    private String name;
    @JsonProperty("Category")
    private String category;
    @JsonProperty("Description")
    private String description;
    @JsonProperty("Expiry_Date")
    private String expiryDate;
    @JsonProperty("Inactive")
    private Boolean inactive;
    @JsonProperty("Sub_Category")
    private String subCategory;

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("Category")
    public String getCategory() {
        return category;
    }

    @JsonProperty("Category")
    public void setCategory(String category) {
        this.category = category;
    }

    @JsonProperty("Description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("Description")
    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty("Expiry_Date")
    public String getExpiryDate() {
        return expiryDate;
    }

    @JsonProperty("Expiry_Date")
    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    @JsonProperty("Inactive")
    public Boolean getInactive() {
        return inactive;
    }

    @JsonProperty("Inactive")
    public void setInactive(Boolean inactive) {
        this.inactive = inactive;
    }

    @JsonProperty("Sub_Category")
    public String getSubCategory() {
        return subCategory;
    }

    @JsonProperty("Sub_Category")
    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Product{");
        sb.append("name='").append(name).append('\'');
        sb.append(", category='").append(category).append('\'');
        sb.append(", description='").append(description).append('\'');
        sb.append(", expiryDate='").append(expiryDate).append('\'');
        sb.append(", inactive=").append(inactive);
        sb.append(", subCategory='").append(subCategory).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
