package com.nwm.xmart.streaming.database.statements.processstate;

import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.nwm.xmart.streaming.database.statements.StatementParameters;
import com.nwm.xmart.streaming.database.statements.XmartStatement;

import java.sql.SQLException;

public class LastRunReadStatement extends XmartStatement {


    public LastRunReadStatement() {
        super();

        statementName = "fn_GetProcessState";
        PROC_COMMAND = "SELECT Isnull(convert(varchar(max), fwk.fn_GetProcessState(?)), '') as results";
    }

    @Override
    public SQLServerCallableStatement getPreparedStatement(Object obj) throws SQLException {

        preparedStatement.clearParameters();
        SQLServerCallableStatement sqlServerCallableStatement = (SQLServerCallableStatement) preparedStatement;

        StatementParameters statementParameters = (StatementParameters) obj;

        int index = 1;

        preparedStatement.setObject(index++, statementParameters.get("functionName"));

        preparedStatement.addBatch();
        return preparedStatement;
    }
}
