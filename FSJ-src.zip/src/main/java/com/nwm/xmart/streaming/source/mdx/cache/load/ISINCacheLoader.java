package com.nwm.xmart.streaming.source.mdx.cache.load;

import com.nwm.xmart.streaming.database.exceptions.SqlServerConnectorException;

import java.util.Set;

/**
 * Created by gardlex on 13/05/2018.
 */
public interface ISINCacheLoader {
    Set<String> getLatestISINs() throws SqlServerConnectorException;
    void close();
}
