package com.nwm.xmart.streaming.source.crm.entity.accountCoverage;

import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(
        { "Name", "City_Code", "Country", "Default_Color", "Display_Colour", "Inactive", "Meeting_Template", "Region",
          "State", "Time_Zone" })
public class DefaultCity implements Serializable {
    private static final long serialVersionUID = 8653832620783090485L;

    @JsonProperty("Name")
    private String name;
    @JsonProperty("City_Code")
    private String cityCode;
    @JsonProperty("Country")
    private String country;
    @JsonProperty("Default_Color")
    private String defaultColor;
    @JsonProperty("Display_Colour")
    private String displayColour;
    @JsonProperty("Inactive")
    private Boolean inactive;
    @JsonProperty("Meeting_Template")
    private String meetingTemplate;
    @JsonProperty("Region")
    private String region;
    @JsonProperty("State")
    private String state;
    @JsonProperty("Time_Zone")
    private TimeZone timeZone;

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("City_Code")
    public String getCityCode() {
        return cityCode;
    }

    @JsonProperty("City_Code")
    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    @JsonProperty("Country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("Country")
    public void setCountry(String country) {
        this.country = country;
    }

    @JsonProperty("Default_Color")
    public String getDefaultColor() {
        return defaultColor;
    }

    @JsonProperty("Default_Color")
    public void setDefaultColor(String defaultColor) {
        this.defaultColor = defaultColor;
    }

    @JsonProperty("Display_Colour")
    public String getDisplayColour() {
        return displayColour;
    }

    @JsonProperty("Display_Colour")
    public void setDisplayColour(String displayColour) {
        this.displayColour = displayColour;
    }

    @JsonProperty("Inactive")
    public Boolean getInactive() {
        return inactive;
    }

    @JsonProperty("Inactive")
    public void setInactive(Boolean inactive) {
        this.inactive = inactive;
    }

    @JsonProperty("Meeting_Template")
    public String getMeetingTemplate() {
        return meetingTemplate;
    }

    @JsonProperty("Meeting_Template")
    public void setMeetingTemplate(String meetingTemplate) {
        this.meetingTemplate = meetingTemplate;
    }

    @JsonProperty("Region")
    public String getRegion() {
        return region;
    }

    @JsonProperty("Region")
    public void setRegion(String region) {
        this.region = region;
    }

    @JsonProperty("State")
    public String getState() {
        return state;
    }

    @JsonProperty("State")
    public void setState(String state) {
        this.state = state;
    }

    @JsonProperty("Time_Zone")
    public TimeZone getTimeZone() {
        return timeZone;
    }

    @JsonProperty("Time_Zone")
    public void setTimeZone(TimeZone timeZone) {
        this.timeZone = timeZone;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("DefaultCity{");
        sb.append("name='").append(name).append('\'');
        sb.append(", cityCode='").append(cityCode).append('\'');
        sb.append(", country='").append(country).append('\'');
        sb.append(", defaultColor='").append(defaultColor).append('\'');
        sb.append(", displayColour='").append(displayColour).append('\'');
        sb.append(", inactive=").append(inactive);
        sb.append(", meetingTemplate='").append(meetingTemplate).append('\'');
        sb.append(", region='").append(region).append('\'');
        sb.append(", state='").append(state).append('\'');
        sb.append(", timeZone=").append(timeZone);
        sb.append('}');
        return sb.toString();
    }
}
