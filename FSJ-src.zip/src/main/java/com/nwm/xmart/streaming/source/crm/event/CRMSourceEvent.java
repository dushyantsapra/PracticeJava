package com.nwm.xmart.streaming.source.crm.event;

import com.nwm.xmart.streaming.source.crm.entity.accountCoverage.AccountCoverage;
import com.nwm.xmart.streaming.source.crm.entity.accountDesk.AccountDesk;
import com.nwm.xmart.streaming.source.crm.entity.callLog.CallLog;
import com.nwm.xmart.streaming.source.crm.entity.callReport.CallReport;
import com.nwm.xmart.streaming.source.crm.entity.contact.Contact;
import com.nwm.xmart.streaming.source.crm.entity.contactCoverage.ContactCoverage;
import com.nwm.xmart.streaming.source.crm.entity.interest.Interest;
import com.nwm.xmart.streaming.source.crm.entity.organization.Organization;
import com.nwm.xmart.streaming.source.crm.entity.user.User;
import com.nwm.xmart.streaming.source.crm.entity.userRole.UserRole;

import java.io.Serializable;

public class CRMSourceEvent implements Serializable {
    private static final long serialVersionUID = -3395604315589045323L;

    private AccountCoverage accountCoverage;
    private CallLog callLog;
    private CallReport callReport;
    private Contact contact;
    private ContactCoverage contactCoverage;
    private Organization organization;
    private User user;
    private UserRole userRole;
    private Interest interest;
    private AccountDesk accountDesk;

    private CRMSourceEventType crmSourceEventType;
    private long timeStamp;
    private int partitionId;
    private long offset;
    private Long dfVersion;
    private String key;

    public CRMSourceEvent(long timeStamp, int partitionId, long offset, Long dfVersion,
            CRMSourceEventType crmSourceEventType, String key) {
        this.timeStamp = timeStamp;
        this.partitionId = partitionId;
        this.offset = offset;
        this.dfVersion = dfVersion;
        this.crmSourceEventType = crmSourceEventType;
        this.key = key;
    }

    public AccountCoverage getAccountCoverage() {
        return accountCoverage;
    }

    public CRMSourceEvent setAccountCoverage(AccountCoverage accountCoverage) {
        this.accountCoverage = accountCoverage;
        return this;
    }

    public CallLog getCallLog() {
        return callLog;
    }

    public CRMSourceEvent setCallLog(CallLog callLog) {
        this.callLog = callLog;
        return this;
    }

    public CallReport getCallReport() {
        return callReport;
    }

    public CRMSourceEvent setCallReport(CallReport callReport) {
        this.callReport = callReport;
        return this;
    }

    public Contact getContact() {
        return contact;
    }

    public CRMSourceEvent setContact(Contact contact) {
        this.contact = contact;
        return this;
    }

    public ContactCoverage getContactCoverage() {
        return contactCoverage;
    }

    public CRMSourceEvent setContactCoverage(ContactCoverage contactCoverage) {
        this.contactCoverage = contactCoverage;
        return this;
    }

    public Organization getOrganization() {
        return organization;
    }

    public CRMSourceEvent setOrganization(Organization organization) {
        this.organization = organization;
        return this;
    }

    public User getUser() {
        return user;
    }

    public CRMSourceEvent setUser(User user) {
        this.user = user;
        return this;
    }

    public UserRole getUserRole() {
        return userRole;
    }

    public CRMSourceEvent setUserRole(UserRole userRole) {
        this.userRole = userRole;
        return this;
    }

    public Interest getInterest() {
        return interest;
    }

    public CRMSourceEvent setInterest(Interest interest) {
        this.interest = interest;
        return this;
    }

    public AccountDesk getAccountDesk() {
        return accountDesk;
    }

    public CRMSourceEvent setAccountDesk(AccountDesk accountDesk) {
        this.accountDesk = accountDesk;
        return this;
    }

    public CRMSourceEventType getCrmSourceEventType() {
        return crmSourceEventType;
    }

    public void setCrmSourceEventType(CRMSourceEventType crmSourceEventType) {
        this.crmSourceEventType = crmSourceEventType;
    }

    public long getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }

    public int getPartitionId() {
        return partitionId;
    }

    public void setPartitionId(int partitionId) {
        this.partitionId = partitionId;
    }

    public long getOffset() {
        return offset;
    }

    public void setOffset(long offset) {
        this.offset = offset;
    }

    public Long getDfVersion() {
        return dfVersion;
    }

    public void setDfVersion(Long dfVersion) {
        this.dfVersion = dfVersion;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CRMSourceEvent{");
        sb.append("accountCoverage=").append(accountCoverage);
        sb.append(", callLog=").append(callLog);
        sb.append(", callReport=").append(callReport);
        sb.append(", contact=").append(contact);
        sb.append(", contactCoverage=").append(contactCoverage);
        sb.append(", organization=").append(organization);
        sb.append(", user=").append(user);
        sb.append(", userRole=").append(userRole);
        sb.append(", interest=").append(interest);
        sb.append(", accountDesk=").append(accountDesk);
        sb.append(", crmSourceEventType=").append(crmSourceEventType);
        sb.append(", timeStamp=").append(timeStamp);
        sb.append(", partitionId=").append(partitionId);
        sb.append(", offset=").append(offset);
        sb.append(", dfVersion=").append(dfVersion);
        sb.append(", key='").append(key).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
