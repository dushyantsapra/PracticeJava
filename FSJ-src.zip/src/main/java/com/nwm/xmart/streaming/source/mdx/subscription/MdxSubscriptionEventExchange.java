package com.nwm.xmart.streaming.source.mdx.subscription;

import com.nwm.xmart.streaming.source.mdx.sorting.WriteTimeComparator;
import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;

import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Created by gardlex on 13/04/2018.
 */
public class MdxSubscriptionEventExchange<MdxSourceEvent> implements MdxRealTimeEventExchange<MdxSourceEvent> {

    private AtomicReference<PriorityBlockingQueue<MdxSourceEvent>> priorityQRef = new AtomicReference<>();
    private volatile int initialCapacity;
    private volatile long lastXmlWriteTimeEpoch;

    @Override
    public MdxSourceEvent getNextMdxDocumentEvent() throws MdxSubscriptionFailureException {
        try {
            return priorityQRef.get().take();
        } catch (InterruptedException e) {
            throw new MdxSubscriptionFailureException("MdxSubscriptionEventExchange: getNextMdxDocumentEvent() was interrupted", e);
        }
    }

    @Override
    public void putMdxDocumentEvent(MdxSourceEvent mdxSourceEvent) {
        MdxDocumentEvent event = (MdxDocumentEvent) mdxSourceEvent;
        if (event.getEpochMdxDataStoreWriteTime() >= lastXmlWriteTimeEpoch) {
            priorityQRef.get().put(mdxSourceEvent);
        }
    }

    @Override
    public MdxRealTimeEventExchange withInitialCapacity(int capacity) {
        this.initialCapacity = capacity;
        return this;
    }

    @Override
    public MdxRealTimeEventExchange startWithXmlWriteTimeEpoch(long xmlWriteTimeEpoch) {
        this.lastXmlWriteTimeEpoch = xmlWriteTimeEpoch;
        return this;
    }

    @Override
    public void build() {
        priorityQRef.set(new PriorityBlockingQueue<MdxSourceEvent>(initialCapacity, new WriteTimeComparator<MdxSourceEvent>()));
    }
}
