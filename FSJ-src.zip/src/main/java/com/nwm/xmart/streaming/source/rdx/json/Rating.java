
package com.nwm.xmart.streaming.source.rdx.json;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "MdxIdentifier",
    "EURatedIndicator",
    "EUEndorsementIndicator",
    "RatingAgency",
    "RatingEffectiveDate",
    "RatingType",
    "RatingValue",
    "AgencyRatingTypeId",
    "AgencyRatingType",
    "RatingDuration",
    "RatingDurationShortDescription"
})
public class Rating {

    @JsonProperty("MdxIdentifier")
    private String mdxIdentifier;
    @JsonProperty("EURatedIndicator")
    private String eURatedIndicator;
    @JsonProperty("EUEndorsementIndicator")
    private String eUEndorsementIndicator;
    @JsonProperty("RatingAgency")
    private String ratingAgency;
    @JsonProperty("RatingEffectiveDate")
    private String ratingEffectiveDate;
    @JsonProperty("RatingType")
    private String ratingType;
    @JsonProperty("RatingValue")
    private String ratingValue;
    @JsonProperty("AgencyRatingTypeId")
    private String agencyRatingTypeId;
    @JsonProperty("AgencyRatingType")
    private String agencyRatingType;
    @JsonProperty("RatingDuration")
    private String ratingDuration;
    @JsonProperty("RatingDurationShortDescription")
    private String ratingDurationShortDescription;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("MdxIdentifier")
    public String getMdxIdentifier() {
        return mdxIdentifier;
    }

    @JsonProperty("MdxIdentifier")
    public void setMdxIdentifier(String mdxIdentifier) {
        this.mdxIdentifier = mdxIdentifier;
    }

    @JsonProperty("EURatedIndicator")
    public String getEURatedIndicator() {
        return eURatedIndicator;
    }

    @JsonProperty("EURatedIndicator")
    public void setEURatedIndicator(String eURatedIndicator) {
        this.eURatedIndicator = eURatedIndicator;
    }

    @JsonProperty("EUEndorsementIndicator")
    public String getEUEndorsementIndicator() {
        return eUEndorsementIndicator;
    }

    @JsonProperty("EUEndorsementIndicator")
    public void setEUEndorsementIndicator(String eUEndorsementIndicator) {
        this.eUEndorsementIndicator = eUEndorsementIndicator;
    }

    @JsonProperty("RatingAgency")
    public String getRatingAgency() {
        return ratingAgency;
    }

    @JsonProperty("RatingAgency")
    public void setRatingAgency(String ratingAgency) {
        this.ratingAgency = ratingAgency;
    }

    @JsonProperty("RatingEffectiveDate")
    public String getRatingEffectiveDate() {
        return ratingEffectiveDate;
    }

    @JsonProperty("RatingEffectiveDate")
    public void setRatingEffectiveDate(String ratingEffectiveDate) {
        this.ratingEffectiveDate = ratingEffectiveDate;
    }

    @JsonProperty("RatingType")
    public String getRatingType() {
        return ratingType;
    }

    @JsonProperty("RatingType")
    public void setRatingType(String ratingType) {
        this.ratingType = ratingType;
    }

    @JsonProperty("RatingValue")
    public String getRatingValue() {
        return ratingValue;
    }

    @JsonProperty("RatingValue")
    public void setRatingValue(String ratingValue) {
        this.ratingValue = ratingValue;
    }

    @JsonProperty("AgencyRatingTypeId")
    public String getAgencyRatingTypeId() {
        return agencyRatingTypeId;
    }

    @JsonProperty("AgencyRatingTypeId")
    public void setAgencyRatingTypeId(String agencyRatingTypeId) {
        this.agencyRatingTypeId = agencyRatingTypeId;
    }

    @JsonProperty("AgencyRatingType")
    public String getAgencyRatingType() {
        return agencyRatingType;
    }

    @JsonProperty("AgencyRatingType")
    public void setAgencyRatingType(String agencyRatingType) {
        this.agencyRatingType = agencyRatingType;
    }

    @JsonProperty("RatingDuration")
    public String getRatingDuration() {
        return ratingDuration;
    }

    @JsonProperty("RatingDuration")
    public void setRatingDuration(String ratingDuration) {
        this.ratingDuration = ratingDuration;
    }

    @JsonProperty("RatingDurationShortDescription")
    public String getRatingDurationShortDescription() {
        return ratingDurationShortDescription;
    }

    @JsonProperty("RatingDurationShortDescription")
    public void setRatingDurationShortDescription(String ratingDurationShortDescription) {
        this.ratingDurationShortDescription = ratingDurationShortDescription;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("mdxIdentifier", mdxIdentifier).append("eURatedIndicator", eURatedIndicator).append("eUEndorsementIndicator", eUEndorsementIndicator).append("ratingAgency", ratingAgency).append("ratingEffectiveDate", ratingEffectiveDate).append("ratingType", ratingType).append("ratingValue", ratingValue).append("agencyRatingTypeId", agencyRatingTypeId).append("agencyRatingType", agencyRatingType).append("ratingDuration", ratingDuration).append("ratingDurationShortDescription", ratingDurationShortDescription).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(agencyRatingType).append(ratingAgency).append(eUEndorsementIndicator).append(agencyRatingTypeId).append(mdxIdentifier).append(ratingType).append(ratingValue).append(eURatedIndicator).append(ratingEffectiveDate).append(ratingDuration).append(additionalProperties).append(ratingDurationShortDescription).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Rating) == false) {
            return false;
        }
        Rating rhs = ((Rating) other);
        return new EqualsBuilder().append(agencyRatingType, rhs.agencyRatingType).append(ratingAgency, rhs.ratingAgency).append(eUEndorsementIndicator, rhs.eUEndorsementIndicator).append(agencyRatingTypeId, rhs.agencyRatingTypeId).append(mdxIdentifier, rhs.mdxIdentifier).append(ratingType, rhs.ratingType).append(ratingValue, rhs.ratingValue).append(eURatedIndicator, rhs.eURatedIndicator).append(ratingEffectiveDate, rhs.ratingEffectiveDate).append(ratingDuration, rhs.ratingDuration).append(additionalProperties, rhs.additionalProperties).append(ratingDurationShortDescription, rhs.ratingDurationShortDescription).isEquals();
    }

}
