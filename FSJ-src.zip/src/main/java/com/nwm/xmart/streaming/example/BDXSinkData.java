package com.nwm.xmart.streaming.example;

/**
 * Created by gardlex on 05/12/2017.
 */
public class BDXSinkData {
    private final String version;
    private final String sourceSystemTransactionId;
    private final String sourceSystemId;

    public BDXSinkData(String version, String sourceSystemTransactionId, String sourceSystemId) {
        this.version = version;
        this.sourceSystemTransactionId = sourceSystemTransactionId;
        this.sourceSystemId = sourceSystemId;
    }

    public String getVersion() {
        return version;
    }

    public String getSourceSystemTransactionId() {
        return sourceSystemTransactionId;
    }

    public String getSourceSystemId() {
        return sourceSystemId;
    }
}
