
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CommentDate",
    "CommentText",
    "CommentType",
    "CommentWriter"
})
public class InstrumentComment {

    @JsonProperty("CommentDate")
    private Object commentDate;
    @JsonProperty("CommentText")
    private Object commentText;
    @JsonProperty("CommentType")
    private Object commentType;
    @JsonProperty("CommentWriter")
    private String commentWriter;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("CommentDate")
    public Object getCommentDate() {
        return commentDate;
    }

    @JsonProperty("CommentDate")
    public void setCommentDate(Object commentDate) {
        this.commentDate = commentDate;
    }

    @JsonProperty("CommentText")
    public Object getCommentText() {
        return commentText;
    }

    @JsonProperty("CommentText")
    public void setCommentText(Object commentText) {
        this.commentText = commentText;
    }

    @JsonProperty("CommentType")
    public Object getCommentType() {
        return commentType;
    }

    @JsonProperty("CommentType")
    public void setCommentType(Object commentType) {
        this.commentType = commentType;
    }

    @JsonProperty("CommentWriter")
    public String getCommentWriter() {
        return commentWriter;
    }

    @JsonProperty("CommentWriter")
    public void setCommentWriter(String commentWriter) {
        this.commentWriter = commentWriter;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("commentDate", commentDate).append("commentText", commentText).append("commentType", commentType).append("commentWriter", commentWriter).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(commentType).append(commentWriter).append(additionalProperties).append(commentText).append(commentDate).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InstrumentComment) == false) {
            return false;
        }
        InstrumentComment rhs = ((InstrumentComment) other);
        return new EqualsBuilder().append(commentType, rhs.commentType).append(commentWriter, rhs.commentWriter).append(additionalProperties, rhs.additionalProperties).append(commentText, rhs.commentText).append(commentDate, rhs.commentDate).isEquals();
    }

}
