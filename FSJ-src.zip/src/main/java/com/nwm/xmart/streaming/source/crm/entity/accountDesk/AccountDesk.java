package com.nwm.xmart.streaming.source.crm.entity.accountDesk;

import com.nwm.xmart.streaming.source.crm.entity.common.Account;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Account", "Desk_Description", "Direct_Line_ID", "Id", "LastModifiedDate" })
public class AccountDesk implements Serializable {
    private static final long serialVersionUID = 8102133178799054931L;

    @JsonProperty("Account")
    private Account account;
    @JsonProperty("Desk_Description")
    private String deskDescription;
    @JsonProperty("Direct_Line_ID")
    private String directLineID;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;

    @JsonProperty("Account")
    public Account getAccount() {
        return account;
    }

    @JsonProperty("Account")
    public void setAccount(Account account) {
        this.account = account;
    }

    @JsonProperty("Desk_Description")
    public String getDeskDescription() {
        return deskDescription;
    }

    @JsonProperty("Desk_Description")
    public void setDeskDescription(String deskDescription) {
        this.deskDescription = deskDescription;
    }

    @JsonProperty("Direct_Line_ID")
    public String getDirectLineID() {
        return directLineID;
    }

    @JsonProperty("Direct_Line_ID")
    public void setDirectLineID(String directLineID) {
        this.directLineID = directLineID;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("AccountDesk{");
        sb.append("account=").append(account);
        sb.append(", deskDescription=").append(deskDescription);
        sb.append(", directLineID='").append(directLineID).append('\'');
        sb.append(", id='").append(id).append('\'');
        sb.append(", lastModifiedDate='").append(lastModifiedDate).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
