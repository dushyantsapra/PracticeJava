package com.nwm.xmart.streaming.source.rdx.json;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Created by gardlex on 22/05/2018.
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "EventType",
        "EventDate",
        "EventProvider",
        "EventPercentage"
})
public class MortgageFactorHistory {
    @JsonProperty("EventType")
    private String eventType;
    @JsonProperty("EventDate")
    private String eventDate;
    @JsonProperty("EventProvider")
    private String eventProvider;
    @JsonProperty("EventPercentage")
    private Double eventPercentage;

    @JsonProperty("EventType")
    public String getEventType() {
        return eventType;
    }

    @JsonProperty("EventType")
    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    @JsonProperty("EventDate")
    public String getEventDate() {
        return eventDate;
    }

    @JsonProperty("EventDate")
    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    @JsonProperty("EventProvider")
    public String getEventProvider() {
        return eventProvider;
    }

    @JsonProperty("EventProvider")
    public void setEventProvider(String eventProvider) {
        this.eventProvider = eventProvider;
    }

    @JsonProperty("EventPercentage")
    public Double getEventPercentage() {
        return eventPercentage;
    }

    @JsonProperty("EventPercentage")
    public void setEventPercentage(Double eventPercentage) {
        this.eventPercentage = eventPercentage;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("MortgageFactorHistory{");
        sb.append("eventType='").append(eventType).append('\'');
        sb.append(", eventDate='").append(eventDate).append('\'');
        sb.append(", eventProvider='").append(eventProvider).append('\'');
        sb.append(", eventPercentage=").append(eventPercentage);
        sb.append('}');
        return sb.toString();
    }
}
