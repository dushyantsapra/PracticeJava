package com.nwm.xmart.streaming.source.mdx.event;

/**
 * Created by gardlex on 23/04/2018.
 */
public enum ProcessingType {
    LOAD, SUBSCRIPTION;
}
