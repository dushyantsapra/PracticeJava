
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AmortisationScheduleEntry",
    "Analytics",
    "AssetBackedSecurity",
    "Bond",
    "Clearing",
    "ClearingSystems",
    "Debt",
    "GeographicDistribution",
    "Hqla",
    "Instrument",
    "InstrumentClassification",
    "InstrumentComment",
    "InstrumentEligibility",
    "InstrumentIssuance",
    "InstrumentMarketConvention",
    "InstrumentParty",
    "InstrumentScheduleEntry",
    "InstrumentTax",
    "InstrumentVendorData",
    "Interest",
    "Listing",
    "Underlyer",
    "Underwriter",
    "CallScheduleEntry",
    "CashFlowScheduleEntry",
    "Disabled",
    "ExDvdSchedule",
    "FloaterAccrualSchedule",
    "FloaterCouponHistory",
    "InstrumentGroupDescription",
    "MortgageCashFlowSchedule",
    "MortgageCouponHistory",
    "MortgageFactorHistory",
    "MultiCouponSchedule",
    "PutSchedule",
    "Ratings",
    "StepUpCouponSchedule",
    "StructuredCoupon",
    "InterestRateCalendar",
    "UsSecRegExemption",
    "Alias"
})
public class Facets {

    @JsonProperty("AmortisationScheduleEntry")
    private List<Object> amortisationScheduleEntry = new ArrayList<Object>();
    @JsonProperty("Analytics")
    private List<Analytic> analytics = new ArrayList<Analytic>();
    @JsonProperty("AssetBackedSecurity")
    private List<AssetBackedSecurity> assetBackedSecurity = new ArrayList<AssetBackedSecurity>();
    @JsonProperty("Bond")
    private List<Bond> bond = new ArrayList<Bond>();
    @JsonProperty("Clearing")
    private List<Clearing> clearing = new ArrayList<Clearing>();
    @JsonProperty("ClearingSystems")
    private List<Object> clearingSystems = new ArrayList<Object>();
    @JsonProperty("Debt")
    private List<Debt> debt = new ArrayList<Debt>();
    @JsonProperty("GeographicDistribution")
    private List<GeographicDistribution> geographicDistribution = new ArrayList<GeographicDistribution>();
    @JsonProperty("Hqla")
    private List<Hqla> hqla = new ArrayList<Hqla>();
    @JsonProperty("Instrument")
    private List<Instrument> instrument = new ArrayList<Instrument>();
    @JsonProperty("InstrumentClassification")
    private List<InstrumentClassification> instrumentClassification = new ArrayList<InstrumentClassification>();
    @JsonProperty("InstrumentComment")
    private List<InstrumentComment> instrumentComment = new ArrayList<InstrumentComment>();
    @JsonProperty("InstrumentEligibility")
    private List<InstrumentEligibility> instrumentEligibility = new ArrayList<InstrumentEligibility>();
    @JsonProperty("InstrumentIssuance")
    private List<InstrumentIssuance> instrumentIssuance = new ArrayList<InstrumentIssuance>();
    @JsonProperty("InstrumentMarketConvention")
    private List<Object> instrumentMarketConvention = new ArrayList<Object>();
    @JsonProperty("InstrumentParty")
    private List<InstrumentParty> instrumentParty = new ArrayList<InstrumentParty>();
    @JsonProperty("InstrumentScheduleEntry")
    private List<Object> instrumentScheduleEntry = new ArrayList<Object>();
    @JsonProperty("InstrumentTax")
    private List<InstrumentTax> instrumentTax = new ArrayList<InstrumentTax>();
    @JsonProperty("InstrumentVendorData")
    private List<InstrumentVendorDatum> instrumentVendorData = new ArrayList<InstrumentVendorDatum>();
    @JsonProperty("Interest")
    private List<Interest> interest = new ArrayList<Interest>();
    @JsonProperty("Listing")
    private List<Object> listing = new ArrayList<Object>();
    @JsonProperty("Underlyer")
    private List<Underlyer> underlyer = new ArrayList<Underlyer>();
    @JsonProperty("Underwriter")
    private List<Object> underwriter = new ArrayList<Object>();
    @JsonProperty("CallScheduleEntry")
    private List<Object> callScheduleEntry = new ArrayList<Object>();
    @JsonProperty("CashFlowScheduleEntry")
    private List<Object> cashFlowScheduleEntry = new ArrayList<Object>();
    @JsonProperty("Disabled")
    private List<Object> disabled = new ArrayList<Object>();
    @JsonProperty("ExDvdSchedule")
    private List<Object> exDvdSchedule = new ArrayList<Object>();
    @JsonProperty("FloaterAccrualSchedule")
    private List<Object> floaterAccrualSchedule = new ArrayList<Object>();
    @JsonProperty("FloaterCouponHistory")
    private List<Object> floaterCouponHistory = new ArrayList<Object>();
    @JsonProperty("InstrumentGroupDescription")
    private List<Object> instrumentGroupDescription = new ArrayList<Object>();
    @JsonProperty("MortgageCashFlowSchedule")
    private List<Object> mortgageCashFlowSchedule = new ArrayList<Object>();
    @JsonProperty("MortgageCouponHistory")
    private List<Object> mortgageCouponHistory = new ArrayList<Object>();
    @JsonProperty("MortgageFactorHistory")
    private List<Object> mortgageFactorHistory = new ArrayList<Object>();
    @JsonProperty("MultiCouponSchedule")
    private List<Object> multiCouponSchedule = new ArrayList<Object>();
    @JsonProperty("PutSchedule")
    private List<Object> putSchedule = new ArrayList<Object>();
    @JsonProperty("Ratings")
    private List<Object> ratings = new ArrayList<Object>();
    @JsonProperty("StepUpCouponSchedule")
    private List<Object> stepUpCouponSchedule = new ArrayList<Object>();
    @JsonProperty("StructuredCoupon")
    private List<Object> structuredCoupon = new ArrayList<Object>();
    @JsonProperty("InterestRateCalendar")
    private List<Object> interestRateCalendar = new ArrayList<Object>();
    @JsonProperty("UsSecRegExemption")
    private List<Object> usSecRegExemption = new ArrayList<Object>();
    @JsonProperty("Alias")
    private List<Alia> alias = new ArrayList<Alia>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("AmortisationScheduleEntry")
    public List<Object> getAmortisationScheduleEntry() {
        return amortisationScheduleEntry;
    }

    @JsonProperty("AmortisationScheduleEntry")
    public void setAmortisationScheduleEntry(List<Object> amortisationScheduleEntry) {
        this.amortisationScheduleEntry = amortisationScheduleEntry;
    }

    @JsonProperty("Analytics")
    public List<Analytic> getAnalytics() {
        return analytics;
    }

    @JsonProperty("Analytics")
    public void setAnalytics(List<Analytic> analytics) {
        this.analytics = analytics;
    }

    @JsonProperty("AssetBackedSecurity")
    public List<AssetBackedSecurity> getAssetBackedSecurity() {
        return assetBackedSecurity;
    }

    @JsonProperty("AssetBackedSecurity")
    public void setAssetBackedSecurity(List<AssetBackedSecurity> assetBackedSecurity) {
        this.assetBackedSecurity = assetBackedSecurity;
    }

    @JsonProperty("Bond")
    public List<Bond> getBond() {
        return bond;
    }

    @JsonProperty("Bond")
    public void setBond(List<Bond> bond) {
        this.bond = bond;
    }

    @JsonProperty("Clearing")
    public List<Clearing> getClearing() {
        return clearing;
    }

    @JsonProperty("Clearing")
    public void setClearing(List<Clearing> clearing) {
        this.clearing = clearing;
    }

    @JsonProperty("ClearingSystems")
    public List<Object> getClearingSystems() {
        return clearingSystems;
    }

    @JsonProperty("ClearingSystems")
    public void setClearingSystems(List<Object> clearingSystems) {
        this.clearingSystems = clearingSystems;
    }

    @JsonProperty("Debt")
    public List<Debt> getDebt() {
        return debt;
    }

    @JsonProperty("Debt")
    public void setDebt(List<Debt> debt) {
        this.debt = debt;
    }

    @JsonProperty("GeographicDistribution")
    public List<GeographicDistribution> getGeographicDistribution() {
        return geographicDistribution;
    }

    @JsonProperty("GeographicDistribution")
    public void setGeographicDistribution(List<GeographicDistribution> geographicDistribution) {
        this.geographicDistribution = geographicDistribution;
    }

    @JsonProperty("Hqla")
    public List<Hqla> getHqla() {
        return hqla;
    }

    @JsonProperty("Hqla")
    public void setHqla(List<Hqla> hqla) {
        this.hqla = hqla;
    }

    @JsonProperty("Instrument")
    public List<Instrument> getInstrument() {
        return instrument;
    }

    @JsonProperty("Instrument")
    public void setInstrument(List<Instrument> instrument) {
        this.instrument = instrument;
    }

    @JsonProperty("InstrumentClassification")
    public List<InstrumentClassification> getInstrumentClassification() {
        return instrumentClassification;
    }

    @JsonProperty("InstrumentClassification")
    public void setInstrumentClassification(List<InstrumentClassification> instrumentClassification) {
        this.instrumentClassification = instrumentClassification;
    }

    @JsonProperty("InstrumentComment")
    public List<InstrumentComment> getInstrumentComment() {
        return instrumentComment;
    }

    @JsonProperty("InstrumentComment")
    public void setInstrumentComment(List<InstrumentComment> instrumentComment) {
        this.instrumentComment = instrumentComment;
    }

    @JsonProperty("InstrumentEligibility")
    public List<InstrumentEligibility> getInstrumentEligibility() {
        return instrumentEligibility;
    }

    @JsonProperty("InstrumentEligibility")
    public void setInstrumentEligibility(List<InstrumentEligibility> instrumentEligibility) {
        this.instrumentEligibility = instrumentEligibility;
    }

    @JsonProperty("InstrumentIssuance")
    public List<InstrumentIssuance> getInstrumentIssuance() {
        return instrumentIssuance;
    }

    @JsonProperty("InstrumentIssuance")
    public void setInstrumentIssuance(List<InstrumentIssuance> instrumentIssuance) {
        this.instrumentIssuance = instrumentIssuance;
    }

    @JsonProperty("InstrumentMarketConvention")
    public List<Object> getInstrumentMarketConvention() {
        return instrumentMarketConvention;
    }

    @JsonProperty("InstrumentMarketConvention")
    public void setInstrumentMarketConvention(List<Object> instrumentMarketConvention) {
        this.instrumentMarketConvention = instrumentMarketConvention;
    }

    @JsonProperty("InstrumentParty")
    public List<InstrumentParty> getInstrumentParty() {
        return instrumentParty;
    }

    @JsonProperty("InstrumentParty")
    public void setInstrumentParty(List<InstrumentParty> instrumentParty) {
        this.instrumentParty = instrumentParty;
    }

    @JsonProperty("InstrumentScheduleEntry")
    public List<Object> getInstrumentScheduleEntry() {
        return instrumentScheduleEntry;
    }

    @JsonProperty("InstrumentScheduleEntry")
    public void setInstrumentScheduleEntry(List<Object> instrumentScheduleEntry) {
        this.instrumentScheduleEntry = instrumentScheduleEntry;
    }

    @JsonProperty("InstrumentTax")
    public List<InstrumentTax> getInstrumentTax() {
        return instrumentTax;
    }

    @JsonProperty("InstrumentTax")
    public void setInstrumentTax(List<InstrumentTax> instrumentTax) {
        this.instrumentTax = instrumentTax;
    }

    @JsonProperty("InstrumentVendorData")
    public List<InstrumentVendorDatum> getInstrumentVendorData() {
        return instrumentVendorData;
    }

    @JsonProperty("InstrumentVendorData")
    public void setInstrumentVendorData(List<InstrumentVendorDatum> instrumentVendorData) {
        this.instrumentVendorData = instrumentVendorData;
    }

    @JsonProperty("Interest")
    public List<Interest> getInterest() {
        return interest;
    }

    @JsonProperty("Interest")
    public void setInterest(List<Interest> interest) {
        this.interest = interest;
    }

    @JsonProperty("Listing")
    public List<Object> getListing() {
        return listing;
    }

    @JsonProperty("Listing")
    public void setListing(List<Object> listing) {
        this.listing = listing;
    }

    @JsonProperty("Underlyer")
    public List<Underlyer> getUnderlyer() {
        return underlyer;
    }

    @JsonProperty("Underlyer")
    public void setUnderlyer(List<Underlyer> underlyer) {
        this.underlyer = underlyer;
    }

    @JsonProperty("Underwriter")
    public List<Object> getUnderwriter() {
        return underwriter;
    }

    @JsonProperty("Underwriter")
    public void setUnderwriter(List<Object> underwriter) {
        this.underwriter = underwriter;
    }

    @JsonProperty("CallScheduleEntry")
    public List<Object> getCallScheduleEntry() {
        return callScheduleEntry;
    }

    @JsonProperty("CallScheduleEntry")
    public void setCallScheduleEntry(List<Object> callScheduleEntry) {
        this.callScheduleEntry = callScheduleEntry;
    }

    @JsonProperty("CashFlowScheduleEntry")
    public List<Object> getCashFlowScheduleEntry() {
        return cashFlowScheduleEntry;
    }

    @JsonProperty("CashFlowScheduleEntry")
    public void setCashFlowScheduleEntry(List<Object> cashFlowScheduleEntry) {
        this.cashFlowScheduleEntry = cashFlowScheduleEntry;
    }

    @JsonProperty("Disabled")
    public List<Object> getDisabled() {
        return disabled;
    }

    @JsonProperty("Disabled")
    public void setDisabled(List<Object> disabled) {
        this.disabled = disabled;
    }

    @JsonProperty("ExDvdSchedule")
    public List<Object> getExDvdSchedule() {
        return exDvdSchedule;
    }

    @JsonProperty("ExDvdSchedule")
    public void setExDvdSchedule(List<Object> exDvdSchedule) {
        this.exDvdSchedule = exDvdSchedule;
    }

    @JsonProperty("FloaterAccrualSchedule")
    public List<Object> getFloaterAccrualSchedule() {
        return floaterAccrualSchedule;
    }

    @JsonProperty("FloaterAccrualSchedule")
    public void setFloaterAccrualSchedule(List<Object> floaterAccrualSchedule) {
        this.floaterAccrualSchedule = floaterAccrualSchedule;
    }

    @JsonProperty("FloaterCouponHistory")
    public List<Object> getFloaterCouponHistory() {
        return floaterCouponHistory;
    }

    @JsonProperty("FloaterCouponHistory")
    public void setFloaterCouponHistory(List<Object> floaterCouponHistory) {
        this.floaterCouponHistory = floaterCouponHistory;
    }

    @JsonProperty("InstrumentGroupDescription")
    public List<Object> getInstrumentGroupDescription() {
        return instrumentGroupDescription;
    }

    @JsonProperty("InstrumentGroupDescription")
    public void setInstrumentGroupDescription(List<Object> instrumentGroupDescription) {
        this.instrumentGroupDescription = instrumentGroupDescription;
    }

    @JsonProperty("MortgageCashFlowSchedule")
    public List<Object> getMortgageCashFlowSchedule() {
        return mortgageCashFlowSchedule;
    }

    @JsonProperty("MortgageCashFlowSchedule")
    public void setMortgageCashFlowSchedule(List<Object> mortgageCashFlowSchedule) {
        this.mortgageCashFlowSchedule = mortgageCashFlowSchedule;
    }

    @JsonProperty("MortgageCouponHistory")
    public List<Object> getMortgageCouponHistory() {
        return mortgageCouponHistory;
    }

    @JsonProperty("MortgageCouponHistory")
    public void setMortgageCouponHistory(List<Object> mortgageCouponHistory) {
        this.mortgageCouponHistory = mortgageCouponHistory;
    }

    @JsonProperty("MortgageFactorHistory")
    public List<Object> getMortgageFactorHistory() {
        return mortgageFactorHistory;
    }

    @JsonProperty("MortgageFactorHistory")
    public void setMortgageFactorHistory(List<Object> mortgageFactorHistory) {
        this.mortgageFactorHistory = mortgageFactorHistory;
    }

    @JsonProperty("MultiCouponSchedule")
    public List<Object> getMultiCouponSchedule() {
        return multiCouponSchedule;
    }

    @JsonProperty("MultiCouponSchedule")
    public void setMultiCouponSchedule(List<Object> multiCouponSchedule) {
        this.multiCouponSchedule = multiCouponSchedule;
    }

    @JsonProperty("PutSchedule")
    public List<Object> getPutSchedule() {
        return putSchedule;
    }

    @JsonProperty("PutSchedule")
    public void setPutSchedule(List<Object> putSchedule) {
        this.putSchedule = putSchedule;
    }

    @JsonProperty("Ratings")
    public List<Object> getRatings() {
        return ratings;
    }

    @JsonProperty("Ratings")
    public void setRatings(List<Object> ratings) {
        this.ratings = ratings;
    }

    @JsonProperty("StepUpCouponSchedule")
    public List<Object> getStepUpCouponSchedule() {
        return stepUpCouponSchedule;
    }

    @JsonProperty("StepUpCouponSchedule")
    public void setStepUpCouponSchedule(List<Object> stepUpCouponSchedule) {
        this.stepUpCouponSchedule = stepUpCouponSchedule;
    }

    @JsonProperty("StructuredCoupon")
    public List<Object> getStructuredCoupon() {
        return structuredCoupon;
    }

    @JsonProperty("StructuredCoupon")
    public void setStructuredCoupon(List<Object> structuredCoupon) {
        this.structuredCoupon = structuredCoupon;
    }

    @JsonProperty("InterestRateCalendar")
    public List<Object> getInterestRateCalendar() {
        return interestRateCalendar;
    }

    @JsonProperty("InterestRateCalendar")
    public void setInterestRateCalendar(List<Object> interestRateCalendar) {
        this.interestRateCalendar = interestRateCalendar;
    }

    @JsonProperty("UsSecRegExemption")
    public List<Object> getUsSecRegExemption() {
        return usSecRegExemption;
    }

    @JsonProperty("UsSecRegExemption")
    public void setUsSecRegExemption(List<Object> usSecRegExemption) {
        this.usSecRegExemption = usSecRegExemption;
    }

    @JsonProperty("Alias")
    public List<Alia> getAlias() {
        return alias;
    }

    @JsonProperty("Alias")
    public void setAlias(List<Alia> alias) {
        this.alias = alias;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("amortisationScheduleEntry", amortisationScheduleEntry).append("analytics", analytics).append("assetBackedSecurity", assetBackedSecurity).append("bond", bond).append("clearing", clearing).append("clearingSystems", clearingSystems).append("debt", debt).append("geographicDistribution", geographicDistribution).append("hqla", hqla).append("instrument", instrument).append("instrumentClassification", instrumentClassification).append("instrumentComment", instrumentComment).append("instrumentEligibility", instrumentEligibility).append("instrumentIssuance", instrumentIssuance).append("instrumentMarketConvention", instrumentMarketConvention).append("instrumentParty", instrumentParty).append("instrumentScheduleEntry", instrumentScheduleEntry).append("instrumentTax", instrumentTax).append("instrumentVendorData", instrumentVendorData).append("interest", interest).append("listing", listing).append("underlyer", underlyer).append("underwriter", underwriter).append("callScheduleEntry", callScheduleEntry).append("cashFlowScheduleEntry", cashFlowScheduleEntry).append("disabled", disabled).append("exDvdSchedule", exDvdSchedule).append("floaterAccrualSchedule", floaterAccrualSchedule).append("floaterCouponHistory", floaterCouponHistory).append("instrumentGroupDescription", instrumentGroupDescription).append("mortgageCashFlowSchedule", mortgageCashFlowSchedule).append("mortgageCouponHistory", mortgageCouponHistory).append("mortgageFactorHistory", mortgageFactorHistory).append("multiCouponSchedule", multiCouponSchedule).append("putSchedule", putSchedule).append("ratings", ratings).append("stepUpCouponSchedule", stepUpCouponSchedule).append("structuredCoupon", structuredCoupon).append("interestRateCalendar", interestRateCalendar).append("usSecRegExemption", usSecRegExemption).append("alias", alias).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(instrumentParty).append(floaterCouponHistory).append(interestRateCalendar).append(geographicDistribution).append(instrumentEligibility).append(floaterAccrualSchedule).append(instrumentScheduleEntry).append(instrument).append(stepUpCouponSchedule).append(hqla).append(instrumentVendorData).append(analytics).append(usSecRegExemption).append(interest).append(ratings).append(underlyer).append(instrumentGroupDescription).append(mortgageCouponHistory).append(alias).append(instrumentTax).append(callScheduleEntry).append(disabled).append(exDvdSchedule).append(listing).append(clearingSystems).append(instrumentComment).append(putSchedule).append(multiCouponSchedule).append(amortisationScheduleEntry).append(instrumentMarketConvention).append(assetBackedSecurity).append(bond).append(clearing).append(structuredCoupon).append(cashFlowScheduleEntry).append(instrumentIssuance).append(mortgageCashFlowSchedule).append(mortgageFactorHistory).append(additionalProperties).append(debt).append(underwriter).append(instrumentClassification).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Facets) == false) {
            return false;
        }
        Facets rhs = ((Facets) other);
        return new EqualsBuilder().append(instrumentParty, rhs.instrumentParty).append(floaterCouponHistory, rhs.floaterCouponHistory).append(interestRateCalendar, rhs.interestRateCalendar).append(geographicDistribution, rhs.geographicDistribution).append(instrumentEligibility, rhs.instrumentEligibility).append(floaterAccrualSchedule, rhs.floaterAccrualSchedule).append(instrumentScheduleEntry, rhs.instrumentScheduleEntry).append(instrument, rhs.instrument).append(stepUpCouponSchedule, rhs.stepUpCouponSchedule).append(hqla, rhs.hqla).append(instrumentVendorData, rhs.instrumentVendorData).append(analytics, rhs.analytics).append(usSecRegExemption, rhs.usSecRegExemption).append(interest, rhs.interest).append(ratings, rhs.ratings).append(underlyer, rhs.underlyer).append(instrumentGroupDescription, rhs.instrumentGroupDescription).append(mortgageCouponHistory, rhs.mortgageCouponHistory).append(alias, rhs.alias).append(instrumentTax, rhs.instrumentTax).append(callScheduleEntry, rhs.callScheduleEntry).append(disabled, rhs.disabled).append(exDvdSchedule, rhs.exDvdSchedule).append(listing, rhs.listing).append(clearingSystems, rhs.clearingSystems).append(instrumentComment, rhs.instrumentComment).append(putSchedule, rhs.putSchedule).append(multiCouponSchedule, rhs.multiCouponSchedule).append(amortisationScheduleEntry, rhs.amortisationScheduleEntry).append(instrumentMarketConvention, rhs.instrumentMarketConvention).append(assetBackedSecurity, rhs.assetBackedSecurity).append(bond, rhs.bond).append(clearing, rhs.clearing).append(structuredCoupon, rhs.structuredCoupon).append(cashFlowScheduleEntry, rhs.cashFlowScheduleEntry).append(instrumentIssuance, rhs.instrumentIssuance).append(mortgageCashFlowSchedule, rhs.mortgageCashFlowSchedule).append(mortgageFactorHistory, rhs.mortgageFactorHistory).append(additionalProperties, rhs.additionalProperties).append(debt, rhs.debt).append(underwriter, rhs.underwriter).append(instrumentClassification, rhs.instrumentClassification).isEquals();
    }

}
