
package com.nwm.xmart.streaming.source.rdx.json;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "UnderwriterCategory",
    "UnderwriterFeedProvider",
    "UnderwriterGroupDate",
    "UnderwriterGroupReference",
    "UnderwriterName",
    "UnderwriterRoleCode",
    "UnderwriterRoleName",
    "UnderwriterShortName",
    "UnderwrittenAmount"
})
public class Underwriter {

    @JsonProperty("UnderwriterCategory")
    private String underwriterCategory;
    @JsonProperty("UnderwriterFeedProvider")
    private String underwriterFeedProvider;
    @JsonProperty("UnderwriterGroupDate")
    private String underwriterGroupDate;
    @JsonProperty("UnderwriterGroupReference")
    private String underwriterGroupReference;
    @JsonProperty("UnderwriterName")
    private String underwriterName;
    @JsonProperty("UnderwriterRoleCode")
    private String underwriterRoleCode;
    @JsonProperty("UnderwriterRoleName")
    private String underwriterRoleName;
    @JsonProperty("UnderwriterShortName")
    private String underwriterShortName;
    @JsonProperty("UnderwrittenAmount")
    private Double underwrittenAmount;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("UnderwriterCategory")
    public String getUnderwriterCategory() {
        return underwriterCategory;
    }

    @JsonProperty("UnderwriterCategory")
    public void setUnderwriterCategory(String underwriterCategory) {
        this.underwriterCategory = underwriterCategory;
    }

    @JsonProperty("UnderwriterFeedProvider")
    public String getUnderwriterFeedProvider() {
        return underwriterFeedProvider;
    }

    @JsonProperty("UnderwriterFeedProvider")
    public void setUnderwriterFeedProvider(String underwriterFeedProvider) {
        this.underwriterFeedProvider = underwriterFeedProvider;
    }

    @JsonProperty("UnderwriterGroupDate")
    public String getUnderwriterGroupDate() {
        return underwriterGroupDate;
    }

    @JsonProperty("UnderwriterGroupDate")
    public void setUnderwriterGroupDate(String underwriterGroupDate) {
        this.underwriterGroupDate = underwriterGroupDate;
    }

    @JsonProperty("UnderwriterGroupReference")
    public String getUnderwriterGroupReference() {
        return underwriterGroupReference;
    }

    @JsonProperty("UnderwriterGroupReference")
    public void setUnderwriterGroupReference(String underwriterGroupReference) {
        this.underwriterGroupReference = underwriterGroupReference;
    }

    @JsonProperty("UnderwriterName")
    public String getUnderwriterName() {
        return underwriterName;
    }

    @JsonProperty("UnderwriterName")
    public void setUnderwriterName(String underwriterName) {
        this.underwriterName = underwriterName;
    }

    @JsonProperty("UnderwriterRoleCode")
    public String getUnderwriterRoleCode() {
        return underwriterRoleCode;
    }

    @JsonProperty("UnderwriterRoleCode")
    public void setUnderwriterRoleCode(String underwriterRoleCode) {
        this.underwriterRoleCode = underwriterRoleCode;
    }

    @JsonProperty("UnderwriterRoleName")
    public String getUnderwriterRoleName() {
        return underwriterRoleName;
    }

    @JsonProperty("UnderwriterRoleName")
    public void setUnderwriterRoleName(String underwriterRoleName) {
        this.underwriterRoleName = underwriterRoleName;
    }

    @JsonProperty("UnderwriterShortName")
    public String getUnderwriterShortName() {
        return underwriterShortName;
    }

    @JsonProperty("UnderwriterShortName")
    public void setUnderwriterShortName(String underwriterShortName) {
        this.underwriterShortName = underwriterShortName;
    }

    @JsonProperty("UnderwrittenAmount")
    public Double getUnderwrittenAmount() {
        return underwrittenAmount;
    }

    @JsonProperty("UnderwrittenAmount")
    public void setUnderwrittenAmount(Double underwrittenAmount) {
        this.underwrittenAmount = underwrittenAmount;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("underwriterCategory", underwriterCategory).append("underwriterFeedProvider", underwriterFeedProvider).append("underwriterGroupDate", underwriterGroupDate).append("underwriterGroupReference", underwriterGroupReference).append("underwriterName", underwriterName).append("underwriterRoleCode", underwriterRoleCode).append("underwriterRoleName", underwriterRoleName).append("underwriterShortName", underwriterShortName).append("underwrittenAmount", underwrittenAmount).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(underwrittenAmount).append(underwriterShortName).append(underwriterCategory).append(underwriterFeedProvider).append(underwriterGroupDate).append(underwriterRoleCode).append(underwriterName).append(underwriterGroupReference).append(additionalProperties).append(underwriterRoleName).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Underwriter) == false) {
            return false;
        }
        Underwriter rhs = ((Underwriter) other);
        return new EqualsBuilder().append(underwrittenAmount, rhs.underwrittenAmount).append(underwriterShortName, rhs.underwriterShortName).append(underwriterCategory, rhs.underwriterCategory).append(underwriterFeedProvider, rhs.underwriterFeedProvider).append(underwriterGroupDate, rhs.underwriterGroupDate).append(underwriterRoleCode, rhs.underwriterRoleCode).append(underwriterName, rhs.underwriterName).append(underwriterGroupReference, rhs.underwriterGroupReference).append(additionalProperties, rhs.additionalProperties).append(underwriterRoleName, rhs.underwriterRoleName).isEquals();
    }

}
