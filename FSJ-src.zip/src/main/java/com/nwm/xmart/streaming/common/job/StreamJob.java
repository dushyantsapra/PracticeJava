package com.nwm.xmart.streaming.common.job;

import com.nwm.xmart.streaming.error.exception.FlinkJobStartUpException;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import org.slf4j.MDC;

/**
 * Created by gardlex on 30/10/2017.
 */
public abstract class StreamJob {
    protected static Logger logger = LoggerFactory.getLogger(StreamJob.class);
    protected Configuration configuration;
    protected ParameterTool parameters;

    public void run(String[] args) throws Exception {
        defineStreamProperties(args[0]);
        StreamExecutionEnvironment env = configureStreamEnvironment();
        configureAndExecuteStream(env);
    }

    private void defineStreamProperties(String propertiesFilePath) throws IOException {
        try {
            parameters = ParameterTool.fromPropertiesFile(propertiesFilePath);
            configuration = parameters.getConfiguration();
        } catch (IOException e) {
            logger.error("Could not define stream properties",e);
            throw new FlinkJobStartUpException("Could not define stream properties",e);
        }

        // Put in MDC
        String mdcJobNameKey =  parameters.get("nwm.job.param","jobName");
        String jobName = parameters.get("flink.job.name", "No Job Name Specific");
        MDC.put(mdcJobNameKey,jobName);

    }

    private StreamExecutionEnvironment configureStreamEnvironment() {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // Set Global Parameters for RichFunctions et al, that can access ExecutionConfiguration
        env.getConfig().setGlobalJobParameters(parameters);

        if (configuration.getBoolean("flink.checkpointing.enable", false)) {
            env.enableCheckpointing(configuration.getInteger("flink.checkpointing.interval", 300000), CheckpointingMode.EXACTLY_ONCE);
            env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
            env.getCheckpointConfig().setCheckpointTimeout(configuration.getInteger("flink.checkpointing.timeout", 10000));
            env.getCheckpointConfig().setMinPauseBetweenCheckpoints(configuration.getInteger("flink.checkpointing.minpause", 5000));
            logger.info("checkPointInterval = " + env.getCheckpointInterval());
            logger.info("checkPointTimeout = " + env.getCheckpointConfig().getCheckpointTimeout());
            logger.info("checkPointMinPause = " + env.getCheckpointConfig().getMinPauseBetweenCheckpoints());
            try {
                env.setStateBackend(new FsStateBackend(configuration.getString("flink.fs.state.backend","")));
            } catch (IOException e) {
                logger.error("Couldn't create Flink FsStateBackend",e);
                throw new FlinkJobStartUpException("Couldn't create Flink FsStateBackend",e);
            }
        }

        if (configuration.getBoolean("flink.enable.sysout",false)) {
            env.getConfig().enableSysoutLogging();
        }

        switch(configuration.getString("flink.restartstrategy","")) {
        case "noRestart" :
            env.getConfig().setRestartStrategy(RestartStrategies.noRestart());
            break;
        case "fixedDelay" :
            env.getConfig().setRestartStrategy(
                    RestartStrategies.fixedDelayRestart(configuration.getInteger("flink.restartstrategy.fixedDelay.restartAttempts", 0),
                            Time.seconds(configuration.getInteger("flink.restartstrategy.fixedDelay.delayInterval.seconds", 0))));
            break;
        default:
            throw new FlinkJobStartUpException("Unsupported restartStrategy specified "
                    +configuration.getString("flink.restartstrategy",""));
        }

        return env;
    }

    protected abstract void configureAndExecuteStream(StreamExecutionEnvironment env);
}
