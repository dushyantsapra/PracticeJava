package com.nwm.xmart.streaming.source.crm.entity.callReport;

import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(
        { "CreatedById", "CreatedDate", "Id", "Interaction_Type", "IsDeleted", "LastModifiedById", "LastModifiedDate",
          "Meeting_Date", "Meeting_Type", "Name", "Priority", "Sharing_Reasons", "Subject_Objectives", "SystemModstamp",
          "Status", "Call_Report", "Contact", "Email", "Non_Compliance_Reason", "Phone", "Title" })
public class ExternalAttendee implements Serializable {
    private static final long serialVersionUID = 7716998008464482103L;

    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("Interaction_Type")
    private String interactionType;
    @JsonProperty("IsDeleted")
    private Boolean isDeleted;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("Meeting_Date")
    private String meetingDate;
    @JsonProperty("Meeting_Type")
    private String meetingType;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Priority")
    private String priority;
    @JsonProperty("Sharing_Reasons")
    private String sharingReasons;
    @JsonProperty("Subject_Objectives")
    private String subjectObjectives;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("Status")
    private String status;
    @JsonProperty("Call_Report")
    private String callReport;
    @JsonProperty("Contact")
    private String contact;
    @JsonProperty("Email")
    private String email;
    @JsonProperty("Non_Compliance_Reason")
    private Object nonComplianceReason;
    @JsonProperty("Phone")
    private String phone;
    @JsonProperty("Title")
    private String title;

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("Interaction_Type")
    public String getInteractionType() {
        return interactionType;
    }

    @JsonProperty("Interaction_Type")
    public void setInteractionType(String interactionType) {
        this.interactionType = interactionType;
    }

    @JsonProperty("IsDeleted")
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    @JsonProperty("IsDeleted")
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("Meeting_Date")
    public String getMeetingDate() {
        return meetingDate;
    }

    @JsonProperty("Meeting_Date")
    public void setMeetingDate(String meetingDate) {
        this.meetingDate = meetingDate;
    }

    @JsonProperty("Meeting_Type")
    public String getMeetingType() {
        return meetingType;
    }

    @JsonProperty("Meeting_Type")
    public void setMeetingType(String meetingType) {
        this.meetingType = meetingType;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("Priority")
    public String getPriority() {
        return priority;
    }

    @JsonProperty("Priority")
    public void setPriority(String priority) {
        this.priority = priority;
    }

    @JsonProperty("Sharing_Reasons")
    public String getSharingReasons() {
        return sharingReasons;
    }

    @JsonProperty("Sharing_Reasons")
    public void setSharingReasons(String sharingReasons) {
        this.sharingReasons = sharingReasons;
    }

    @JsonProperty("Subject_Objectives")
    public String getSubjectObjectives() {
        return subjectObjectives;
    }

    @JsonProperty("Subject_Objectives")
    public void setSubjectObjectives(String subjectObjectives) {
        this.subjectObjectives = subjectObjectives;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("Status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("Call_Report")
    public String getCallReport() {
        return callReport;
    }

    @JsonProperty("Call_Report")
    public void setCallReport(String callReport) {
        this.callReport = callReport;
    }

    @JsonProperty("Contact")
    public String getContact() {
        return contact;
    }

    @JsonProperty("Contact")
    public void setContact(String contact) {
        this.contact = contact;
    }

    @JsonProperty("Email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("Email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("Non_Compliance_Reason")
    public Object getNonComplianceReason() {
        return nonComplianceReason;
    }

    @JsonProperty("Non_Compliance_Reason")
    public void setNonComplianceReason(Object nonComplianceReason) {
        this.nonComplianceReason = nonComplianceReason;
    }

    @JsonProperty("Phone")
    public String getPhone() {
        return phone;
    }

    @JsonProperty("Phone")
    public void setPhone(String phone) {
        this.phone = phone;
    }

    @JsonProperty("Title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("Title")
    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ExternalAttendee{");
        sb.append("createdById='").append(createdById).append('\'');
        sb.append(", createdDate='").append(createdDate).append('\'');
        sb.append(", id='").append(id).append('\'');
        sb.append(", interactionType='").append(interactionType).append('\'');
        sb.append(", isDeleted=").append(isDeleted);
        sb.append(", lastModifiedById='").append(lastModifiedById).append('\'');
        sb.append(", lastModifiedDate='").append(lastModifiedDate).append('\'');
        sb.append(", meetingDate='").append(meetingDate).append('\'');
        sb.append(", meetingType='").append(meetingType).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", priority='").append(priority).append('\'');
        sb.append(", sharingReasons='").append(sharingReasons).append('\'');
        sb.append(", subjectObjectives='").append(subjectObjectives).append('\'');
        sb.append(", systemModstamp='").append(systemModstamp).append('\'');
        sb.append(", status=").append(status);
        sb.append(", callReport='").append(callReport).append('\'');
        sb.append(", contact='").append(contact).append('\'');
        sb.append(", email='").append(email).append('\'');
        sb.append(", nonComplianceReason=").append(nonComplianceReason);
        sb.append(", phone=").append(phone);
        sb.append(", title=").append(title);
        sb.append('}');
        return sb.toString();
    }
}
