package com.nwm.xmart.streaming.monitor;

import java.io.IOException;
import java.io.Serializable;

/**
 * Created by gardlex on 21/11/2017.
 */
public interface PersistenceFile  extends Serializable {
    public void persistOffsetInfo(InactivityStatus inactivityStatus,
                                  long currentKafkaOffset,
                                  long lastOffset,
                                  long currentTimestamp,
                                  long lastTimestamp,
                                  long lastOffsetChangeTimestamp) throws IOException;
}
