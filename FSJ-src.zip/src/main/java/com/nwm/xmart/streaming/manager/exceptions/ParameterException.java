package com.nwm.xmart.streaming.manager.exceptions;

public class ParameterException extends RuntimeException {

    public ParameterException() {
        super();
    }

    public ParameterException(String msg) {
        super(msg);
    }

    public ParameterException(String msg, Throwable t) {
        super(msg, t);
    }
}
