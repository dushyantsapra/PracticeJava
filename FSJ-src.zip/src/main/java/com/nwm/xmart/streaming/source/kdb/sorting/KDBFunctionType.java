package com.nwm.xmart.streaming.source.kdb.sorting;

/**
 * Created by gardlex on 01/05/2018.
 */
public enum KDBFunctionType {
    FI_MIFID_RFQ, FI_MIFID_QEC, FX_MIFID_RFQ, FX_MIFID_OMS, FX_MIFID_TRADE, FX_MIFID_TRADE_ISIN,
    FX_MIFID_TRADE_ELIGIBILITY, FI_MIFID_FICC;
}
