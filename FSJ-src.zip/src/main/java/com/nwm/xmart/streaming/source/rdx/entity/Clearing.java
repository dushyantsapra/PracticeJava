
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ClearingCode",
    "IsPrimaryClearing"
})
public class Clearing {

    @JsonProperty("ClearingCode")
    private Object clearingCode;
    @JsonProperty("IsPrimaryClearing")
    private Object isPrimaryClearing;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ClearingCode")
    public Object getClearingCode() {
        return clearingCode;
    }

    @JsonProperty("ClearingCode")
    public void setClearingCode(Object clearingCode) {
        this.clearingCode = clearingCode;
    }

    @JsonProperty("IsPrimaryClearing")
    public Object getIsPrimaryClearing() {
        return isPrimaryClearing;
    }

    @JsonProperty("IsPrimaryClearing")
    public void setIsPrimaryClearing(Object isPrimaryClearing) {
        this.isPrimaryClearing = isPrimaryClearing;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("clearingCode", clearingCode).append("isPrimaryClearing", isPrimaryClearing).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(clearingCode).append(additionalProperties).append(isPrimaryClearing).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Clearing) == false) {
            return false;
        }
        Clearing rhs = ((Clearing) other);
        return new EqualsBuilder().append(clearingCode, rhs.clearingCode).append(additionalProperties, rhs.additionalProperties).append(isPrimaryClearing, rhs.isPrimaryClearing).isEquals();
    }

}
