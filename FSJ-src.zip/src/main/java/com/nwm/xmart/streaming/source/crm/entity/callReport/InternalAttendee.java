package com.nwm.xmart.streaming.source.crm.entity.callReport;

import com.nwm.xmart.streaming.source.crm.entity.common.Employee;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "CreatedById", "CreatedDate", "Id", "IsDeleted", "LastModifiedById", "LastModifiedDate", "Name",
                     "Sharing_Reasons", "SystemModstamp", "Status", "Attendance_Reason", "Call_Report", "Email",
                     "Employee", "Is_Attending", "Is_Auto_Notified", "Is_Notify", "Is_Share", "Notification_Reason",
                     "Notify_By_Email", "Role" })
public class InternalAttendee implements Serializable {
    private static final long serialVersionUID = -5048921231471060341L;

    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("IsDeleted")
    private Boolean isDeleted;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Sharing_Reasons")
    private String sharingReasons;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("Status")
    private String status;
    @JsonProperty("Attendance_Reason")
    private String attendanceReason;
    @JsonProperty("Call_Report")
    private String callReport;
    @JsonProperty("Email")
    private String email;
    @JsonProperty("Employee")
    private Employee employee;
    @JsonProperty("Is_Attending")
    private Boolean isAttending;
    @JsonProperty("Is_Auto_Notified")
    private Boolean isAutoNotified;
    @JsonProperty("Is_Notify")
    private Boolean isNotify;
    @JsonProperty("Is_Share")
    private Boolean isShare;
    @JsonProperty("Notification_Reason")
    private Object notificationReason;
    @JsonProperty("Notify_By_Email")
    private Boolean notifyByEmail;
    @JsonProperty("Role")
    private String role;

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("IsDeleted")
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    @JsonProperty("IsDeleted")
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("Sharing_Reasons")
    public String getSharingReasons() {
        return sharingReasons;
    }

    @JsonProperty("Sharing_Reasons")
    public void setSharingReasons(String sharingReasons) {
        this.sharingReasons = sharingReasons;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("Status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("Attendance_Reason")
    public String getAttendanceReason() {
        return attendanceReason;
    }

    @JsonProperty("Attendance_Reason")
    public void setAttendanceReason(String attendanceReason) {
        this.attendanceReason = attendanceReason;
    }

    @JsonProperty("Call_Report")
    public String getCallReport() {
        return callReport;
    }

    @JsonProperty("Call_Report")
    public void setCallReport(String callReport) {
        this.callReport = callReport;
    }

    @JsonProperty("Email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("Email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("Employee")
    public Employee getEmployee() {
        return employee;
    }

    @JsonProperty("Employee")
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    @JsonProperty("Is_Attending")
    public Boolean getIsAttending() {
        return isAttending;
    }

    @JsonProperty("Is_Attending")
    public void setIsAttending(Boolean isAttending) {
        this.isAttending = isAttending;
    }

    @JsonProperty("Is_Auto_Notified")
    public Boolean getIsAutoNotified() {
        return isAutoNotified;
    }

    @JsonProperty("Is_Auto_Notified")
    public void setIsAutoNotified(Boolean isAutoNotified) {
        this.isAutoNotified = isAutoNotified;
    }

    @JsonProperty("Is_Notify")
    public Boolean getIsNotify() {
        return isNotify;
    }

    @JsonProperty("Is_Notify")
    public void setIsNotify(Boolean isNotify) {
        this.isNotify = isNotify;
    }

    @JsonProperty("Is_Share")
    public Boolean getIsShare() {
        return isShare;
    }

    @JsonProperty("Is_Share")
    public void setIsShare(Boolean isShare) {
        this.isShare = isShare;
    }

    @JsonProperty("Notification_Reason")
    public Object getNotificationReason() {
        return notificationReason;
    }

    @JsonProperty("Notification_Reason")
    public void setNotificationReason(Object notificationReason) {
        this.notificationReason = notificationReason;
    }

    @JsonProperty("Notify_By_Email")
    public Boolean getNotifyByEmail() {
        return notifyByEmail;
    }

    @JsonProperty("Notify_By_Email")
    public void setNotifyByEmail(Boolean notifyByEmail) {
        this.notifyByEmail = notifyByEmail;
    }

    @JsonProperty("Role")
    public String getRole() {
        return role;
    }

    @JsonProperty("Role")
    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("InternalAttendee{");
        sb.append("createdById='").append(createdById).append('\'');
        sb.append(", createdDate='").append(createdDate).append('\'');
        sb.append(", id='").append(id).append('\'');
        sb.append(", isDeleted=").append(isDeleted);
        sb.append(", lastModifiedById='").append(lastModifiedById).append('\'');
        sb.append(", lastModifiedDate='").append(lastModifiedDate).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", sharingReasons='").append(sharingReasons).append('\'');
        sb.append(", systemModstamp='").append(systemModstamp).append('\'');
        sb.append(", status=").append(status);
        sb.append(", attendanceReason='").append(attendanceReason).append('\'');
        sb.append(", callReport='").append(callReport).append('\'');
        sb.append(", email='").append(email).append('\'');
        sb.append(", employee=").append(employee);
        sb.append(", isAttending=").append(isAttending);
        sb.append(", isAutoNotified=").append(isAutoNotified);
        sb.append(", isNotify=").append(isNotify);
        sb.append(", isShare=").append(isShare);
        sb.append(", notificationReason=").append(notificationReason);
        sb.append(", notifyByEmail=").append(notifyByEmail);
        sb.append(", role=").append(role);
        sb.append('}');
        return sb.toString();
    }
}
