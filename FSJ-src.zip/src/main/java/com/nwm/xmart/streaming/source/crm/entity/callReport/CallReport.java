package com.nwm.xmart.streaming.source.crm.entity.callReport;

import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(
        { "Bookmark", "Call_Outcome", "Call_Rating_Picker", "Call_Report_LOBTxT", "Call_Report_RoleTxT", "CreatedById",
          "CreatedDate", "Id", "IsDeleted", "LastActivityDate", "LastModifiedById", "LastModifiedDate",
          "LastReferencedDate", "LastViewedDate", "Local_End_Time", "Local_Start_Time", "Name", "OwnerId",
          "Postal_Code", "Security_Level", "Sharing_Reasons", "SystemModstamp", "Exchange_Interaction",
          "Called_Contact_Number", "Call_Disposition", "Call_Rating", "Call_Report_ID", "City", "Client_Initiated",
          "Client", "Country", "Created_By_Employee", "Do_Not_Forward", "End_Time", "External_Notes",
          "External_Rich_Text_Notes", "Interaction_Type", "Location", "Lock", "Logged_By", "Logged_From",
          "Meeting_Date", "Meeting_Type", "Notes", "Notify_Attendees", "Notify_By_Email", "Notify_Coverage_Team",
          "Notify_Others", "Number_of_Relationships", "Priority", "Private", "Record_Type", "Related_Event",
          "Related_To_Id", "Related_To_Type", "Rich_Text_Notes", "Selected_Contact", "Start_Time", "State", "Status",
          "Subject_Meeting_Objectives", "Sub_Type", "Telephony_Message_Id", "Telephony_Message_Label", "Time_Spent_Hrs",
          "Time_Spent_Min", "Transaction_Id", "Visibility_Level", "Mobile__Related_Event", "Mobile__Unique_Id",
          "UserProfile", "Internal_Attendees", "External_Attendees", "Call_Report_Account" })
public class CallReport implements Serializable {
    private static final long serialVersionUID = 189295513951787579L;

    @JsonProperty("Bookmark")
    private Boolean bookmark;
    @JsonProperty("Call_Outcome")
    private String callOutcome;
    @JsonProperty("Call_Rating_Picker")
    private Object callRatingPicker;
    @JsonProperty("Call_Report_LOBTxT")
    private String callReportLOBTxT;
    @JsonProperty("Call_Report_RoleTxT")
    private String callReportRoleTxT;
    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("IsDeleted")
    private Boolean isDeleted;
    @JsonProperty("LastActivityDate")
    private String lastActivityDate;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("LastReferencedDate")
    private Object lastReferencedDate;
    @JsonProperty("LastViewedDate")
    private Object lastViewedDate;
    @JsonProperty("Local_End_Time")
    private String localEndTime;
    @JsonProperty("Local_Start_Time")
    private String localStartTime;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("OwnerId")
    private String ownerId;
    @JsonProperty("Postal_Code")
    private String postalCode;
    @JsonProperty("Security_Level")
    private String securityLevel;
    @JsonProperty("Sharing_Reasons")
    private String sharingReasons;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("Exchange_Interaction")
    private Object exchangeInteraction;
    @JsonProperty("Called_Contact_Number")
    private String calledContactNumber;
    @JsonProperty("Call_Disposition")
    private String callDisposition;
    @JsonProperty("Call_Rating")
    private String callRating;
    @JsonProperty("Call_Report_ID")
    private String callReportID;
    @JsonProperty("City")
    private String city;
    @JsonProperty("Client_Initiated")
    private Boolean clientInitiated;
    @JsonProperty("Client")
    private Client client;
    @JsonProperty("Country")
    private String country;
    @JsonProperty("Created_By_Employee")
    private String createdByEmployee;
    @JsonProperty("Do_Not_Forward")
    private Boolean doNotForward;
    @JsonProperty("End_Time")
    private String endTime;
    @JsonProperty("External_Notes")
    private Object externalNotes;
    @JsonProperty("External_Rich_Text_Notes")
    private Object externalRichTextNotes;
    @JsonProperty("Interaction_Type")
    private String interactionType;
    @JsonProperty("Location")
    private String location;
    @JsonProperty("Lock")
    private String lock;
    @JsonProperty("Logged_By")
    private LoggedBy loggedBy;
    @JsonProperty("Logged_From")
    private String loggedFrom;
    @JsonProperty("Meeting_Date")
    private String meetingDate;
    @JsonProperty("Meeting_Type")
    private String meetingType;
    @JsonProperty("Notes")
    private String notes;
    @JsonProperty("Notify_Attendees")
    private Boolean notifyAttendees;
    @JsonProperty("Notify_By_Email")
    private Boolean notifyByEmail;
    @JsonProperty("Notify_Coverage_Team")
    private Object notifyCoverageTeam;
    @JsonProperty("Notify_Others")
    private Boolean notifyOthers;
    @JsonProperty("Number_of_Relationships")
    private Integer numberOfRelationships;
    @JsonProperty("Priority")
    private String priority;
    @JsonProperty("Private")
    private Boolean _private;
    @JsonProperty("Record_Type")
    private String recordType;
    @JsonProperty("Related_Event")
    private String relatedEvent;
    @JsonProperty("Related_To_Id")
    private String relatedToId;
    @JsonProperty("Related_To_Type")
    private String relatedToType;
    @JsonProperty("Rich_Text_Notes")
    private Object richTextNotes;
    @JsonProperty("Selected_Contact")
    private String selectedContact;
    @JsonProperty("Start_Time")
    private String startTime;
    @JsonProperty("State")
    private String state;
    @JsonProperty("Status")
    private String status;
    @JsonProperty("Subject_Meeting_Objectives")
    private String subjectMeetingObjectives;
    @JsonProperty("Sub_Type")
    private String subType;
    @JsonProperty("Telephony_Message_Id")
    private Object telephonyMessageId;
    @JsonProperty("Telephony_Message_Label")
    private Object telephonyMessageLabel;
    @JsonProperty("Time_Spent_Hrs")
    private String timeSpentHrs;
    @JsonProperty("Time_Spent_Min")
    private Integer timeSpentMin;
    @JsonProperty("Transaction_Id")
    private String transactionId;
    @JsonProperty("Visibility_Level")
    private String visibilityLevel;
    @JsonProperty("Mobile__Related_Event")
    private Object mobileRelatedEvent;
    @JsonProperty("Mobile__Unique_Id")
    private Object mobileUniqueId;
    @JsonProperty("UserProfile")
    private String userProfile;
    @JsonProperty("Internal_Attendees")
    private List<InternalAttendee> internalAttendees = null;
    @JsonProperty("External_Attendees")
    private List<ExternalAttendee> externalAttendees = null;
    @JsonProperty("Call_Report_Account")
    private List<CallReportAccount> callReportAccount = null;

    @JsonProperty("Bookmark")
    public Boolean getBookmark() {
        return bookmark;
    }

    @JsonProperty("Bookmark")
    public void setBookmark(Boolean bookmark) {
        this.bookmark = bookmark;
    }

    @JsonProperty("Call_Outcome")
    public String getCallOutcome() {
        return callOutcome;
    }

    @JsonProperty("Call_Outcome")
    public void setCallOutcome(String callOutcome) {
        this.callOutcome = callOutcome;
    }

    @JsonProperty("Call_Rating_Picker")
    public Object getCallRatingPicker() {
        return callRatingPicker;
    }

    @JsonProperty("Call_Rating_Picker")
    public void setCallRatingPicker(Object callRatingPicker) {
        this.callRatingPicker = callRatingPicker;
    }

    @JsonProperty("Call_Report_LOBTxT")
    public String getCallReportLOBTxT() {
        return callReportLOBTxT;
    }

    @JsonProperty("Call_Report_LOBTxT")
    public void setCallReportLOBTxT(String callReportLOBTxT) {
        this.callReportLOBTxT = callReportLOBTxT;
    }

    @JsonProperty("Call_Report_RoleTxT")
    public String getCallReportRoleTxT() {
        return callReportRoleTxT;
    }

    @JsonProperty("Call_Report_RoleTxT")
    public void setCallReportRoleTxT(String callReportRoleTxT) {
        this.callReportRoleTxT = callReportRoleTxT;
    }

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("IsDeleted")
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    @JsonProperty("IsDeleted")
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    @JsonProperty("LastActivityDate")
    public String getLastActivityDate() {
        return lastActivityDate;
    }

    @JsonProperty("LastActivityDate")
    public void setLastActivityDate(String lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("LastReferencedDate")
    public Object getLastReferencedDate() {
        return lastReferencedDate;
    }

    @JsonProperty("LastReferencedDate")
    public void setLastReferencedDate(Object lastReferencedDate) {
        this.lastReferencedDate = lastReferencedDate;
    }

    @JsonProperty("LastViewedDate")
    public Object getLastViewedDate() {
        return lastViewedDate;
    }

    @JsonProperty("LastViewedDate")
    public void setLastViewedDate(Object lastViewedDate) {
        this.lastViewedDate = lastViewedDate;
    }

    @JsonProperty("Local_End_Time")
    public String getLocalEndTime() {
        return localEndTime;
    }

    @JsonProperty("Local_End_Time")
    public void setLocalEndTime(String localEndTime) {
        this.localEndTime = localEndTime;
    }

    @JsonProperty("Local_Start_Time")
    public String getLocalStartTime() {
        return localStartTime;
    }

    @JsonProperty("Local_Start_Time")
    public void setLocalStartTime(String localStartTime) {
        this.localStartTime = localStartTime;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("OwnerId")
    public String getOwnerId() {
        return ownerId;
    }

    @JsonProperty("OwnerId")
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    @JsonProperty("Postal_Code")
    public String getPostalCode() {
        return postalCode;
    }

    @JsonProperty("Postal_Code")
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    @JsonProperty("Security_Level")
    public String getSecurityLevel() {
        return securityLevel;
    }

    @JsonProperty("Security_Level")
    public void setSecurityLevel(String securityLevel) {
        this.securityLevel = securityLevel;
    }

    @JsonProperty("Sharing_Reasons")
    public String getSharingReasons() {
        return sharingReasons;
    }

    @JsonProperty("Sharing_Reasons")
    public void setSharingReasons(String sharingReasons) {
        this.sharingReasons = sharingReasons;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("Exchange_Interaction")
    public Object getExchangeInteraction() {
        return exchangeInteraction;
    }

    @JsonProperty("Exchange_Interaction")
    public void setExchangeInteraction(Object exchangeInteraction) {
        this.exchangeInteraction = exchangeInteraction;
    }

    @JsonProperty("Called_Contact_Number")
    public String getCalledContactNumber() {
        return calledContactNumber;
    }

    @JsonProperty("Called_Contact_Number")
    public void setCalledContactNumber(String calledContactNumber) {
        this.calledContactNumber = calledContactNumber;
    }

    @JsonProperty("Call_Disposition")
    public String getCallDisposition() {
        return callDisposition;
    }

    @JsonProperty("Call_Disposition")
    public void setCallDisposition(String callDisposition) {
        this.callDisposition = callDisposition;
    }

    @JsonProperty("Call_Rating")
    public String getCallRating() {
        return callRating;
    }

    @JsonProperty("Call_Rating")
    public void setCallRating(String callRating) {
        this.callRating = callRating;
    }

    @JsonProperty("Call_Report_ID")
    public String getCallReportID() {
        return callReportID;
    }

    @JsonProperty("Call_Report_ID")
    public void setCallReportID(String callReportID) {
        this.callReportID = callReportID;
    }

    @JsonProperty("City")
    public String getCity() {
        return city;
    }

    @JsonProperty("City")
    public void setCity(String city) {
        this.city = city;
    }

    @JsonProperty("Client_Initiated")
    public Boolean getClientInitiated() {
        return clientInitiated;
    }

    @JsonProperty("Client_Initiated")
    public void setClientInitiated(Boolean clientInitiated) {
        this.clientInitiated = clientInitiated;
    }

    @JsonProperty("Client")
    public Client getClient() {
        return client;
    }

    @JsonProperty("Client")
    public void setClient(Client client) {
        this.client = client;
    }

    @JsonProperty("Country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("Country")
    public void setCountry(String country) {
        this.country = country;
    }

    @JsonProperty("Created_By_Employee")
    public String getCreatedByEmployee() {
        return createdByEmployee;
    }

    @JsonProperty("Created_By_Employee")
    public void setCreatedByEmployee(String createdByEmployee) {
        this.createdByEmployee = createdByEmployee;
    }

    @JsonProperty("Do_Not_Forward")
    public Boolean getDoNotForward() {
        return doNotForward;
    }

    @JsonProperty("Do_Not_Forward")
    public void setDoNotForward(Boolean doNotForward) {
        this.doNotForward = doNotForward;
    }

    @JsonProperty("End_Time")
    public String getEndTime() {
        return endTime;
    }

    @JsonProperty("End_Time")
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    @JsonProperty("External_Notes")
    public Object getExternalNotes() {
        return externalNotes;
    }

    @JsonProperty("External_Notes")
    public void setExternalNotes(Object externalNotes) {
        this.externalNotes = externalNotes;
    }

    @JsonProperty("External_Rich_Text_Notes")
    public Object getExternalRichTextNotes() {
        return externalRichTextNotes;
    }

    @JsonProperty("External_Rich_Text_Notes")
    public void setExternalRichTextNotes(Object externalRichTextNotes) {
        this.externalRichTextNotes = externalRichTextNotes;
    }

    @JsonProperty("Interaction_Type")
    public String getInteractionType() {
        return interactionType;
    }

    @JsonProperty("Interaction_Type")
    public void setInteractionType(String interactionType) {
        this.interactionType = interactionType;
    }

    @JsonProperty("Location")
    public String getLocation() {
        return location;
    }

    @JsonProperty("Location")
    public void setLocation(String location) {
        this.location = location;
    }

    @JsonProperty("Lock")
    public String getLock() {
        return lock;
    }

    @JsonProperty("Lock")
    public void setLock(String lock) {
        this.lock = lock;
    }

    @JsonProperty("Logged_By")
    public LoggedBy getLoggedBy() {
        return loggedBy;
    }

    @JsonProperty("Logged_By")
    public void setLoggedBy(LoggedBy loggedBy) {
        this.loggedBy = loggedBy;
    }

    @JsonProperty("Logged_From")
    public String getLoggedFrom() {
        return loggedFrom;
    }

    @JsonProperty("Logged_From")
    public void setLoggedFrom(String loggedFrom) {
        this.loggedFrom = loggedFrom;
    }

    @JsonProperty("Meeting_Date")
    public String getMeetingDate() {
        return meetingDate;
    }

    @JsonProperty("Meeting_Date")
    public void setMeetingDate(String meetingDate) {
        this.meetingDate = meetingDate;
    }

    @JsonProperty("Meeting_Type")
    public String getMeetingType() {
        return meetingType;
    }

    @JsonProperty("Meeting_Type")
    public void setMeetingType(String meetingType) {
        this.meetingType = meetingType;
    }

    @JsonProperty("Notes")
    public String getNotes() {
        return notes;
    }

    @JsonProperty("Notes")
    public void setNotes(String notes) {
        this.notes = notes;
    }

    @JsonProperty("Notify_Attendees")
    public Boolean getNotifyAttendees() {
        return notifyAttendees;
    }

    @JsonProperty("Notify_Attendees")
    public void setNotifyAttendees(Boolean notifyAttendees) {
        this.notifyAttendees = notifyAttendees;
    }

    @JsonProperty("Notify_By_Email")
    public Boolean getNotifyByEmail() {
        return notifyByEmail;
    }

    @JsonProperty("Notify_By_Email")
    public void setNotifyByEmail(Boolean notifyByEmail) {
        this.notifyByEmail = notifyByEmail;
    }

    @JsonProperty("Notify_Coverage_Team")
    public Object getNotifyCoverageTeam() {
        return notifyCoverageTeam;
    }

    @JsonProperty("Notify_Coverage_Team")
    public void setNotifyCoverageTeam(Object notifyCoverageTeam) {
        this.notifyCoverageTeam = notifyCoverageTeam;
    }

    @JsonProperty("Notify_Others")
    public Boolean getNotifyOthers() {
        return notifyOthers;
    }

    @JsonProperty("Notify_Others")
    public void setNotifyOthers(Boolean notifyOthers) {
        this.notifyOthers = notifyOthers;
    }

    @JsonProperty("Number_of_Relationships")
    public Integer getNumberOfRelationships() {
        return numberOfRelationships;
    }

    @JsonProperty("Number_of_Relationships")
    public void setNumberOfRelationships(Integer numberOfRelationships) {
        this.numberOfRelationships = numberOfRelationships;
    }

    @JsonProperty("Priority")
    public String getPriority() {
        return priority;
    }

    @JsonProperty("Priority")
    public void setPriority(String priority) {
        this.priority = priority;
    }

    @JsonProperty("Private")
    public Boolean getPrivate() {
        return _private;
    }

    @JsonProperty("Private")
    public void setPrivate(Boolean _private) {
        this._private = _private;
    }

    @JsonProperty("Record_Type")
    public String getRecordType() {
        return recordType;
    }

    @JsonProperty("Record_Type")
    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    @JsonProperty("Related_Event")
    public String getRelatedEvent() {
        return relatedEvent;
    }

    @JsonProperty("Related_Event")
    public void setRelatedEvent(String relatedEvent) {
        this.relatedEvent = relatedEvent;
    }

    @JsonProperty("Related_To_Id")
    public String getRelatedToId() {
        return relatedToId;
    }

    @JsonProperty("Related_To_Id")
    public void setRelatedToId(String relatedToId) {
        this.relatedToId = relatedToId;
    }

    @JsonProperty("Related_To_Type")
    public String getRelatedToType() {
        return relatedToType;
    }

    @JsonProperty("Related_To_Type")
    public void setRelatedToType(String relatedToType) {
        this.relatedToType = relatedToType;
    }

    @JsonProperty("Rich_Text_Notes")
    public Object getRichTextNotes() {
        return richTextNotes;
    }

    @JsonProperty("Rich_Text_Notes")
    public void setRichTextNotes(Object richTextNotes) {
        this.richTextNotes = richTextNotes;
    }

    @JsonProperty("Selected_Contact")
    public String getSelectedContact() {
        return selectedContact;
    }

    @JsonProperty("Selected_Contact")
    public void setSelectedContact(String selectedContact) {
        this.selectedContact = selectedContact;
    }

    @JsonProperty("Start_Time")
    public String getStartTime() {
        return startTime;
    }

    @JsonProperty("Start_Time")
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    @JsonProperty("State")
    public String getState() {
        return state;
    }

    @JsonProperty("State")
    public void setState(String state) {
        this.state = state;
    }

    @JsonProperty("Status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("Subject_Meeting_Objectives")
    public String getSubjectMeetingObjectives() {
        return subjectMeetingObjectives;
    }

    @JsonProperty("Subject_Meeting_Objectives")
    public void setSubjectMeetingObjectives(String subjectMeetingObjectives) {
        this.subjectMeetingObjectives = subjectMeetingObjectives;
    }

    @JsonProperty("Sub_Type")
    public String getSubType() {
        return subType;
    }

    @JsonProperty("Sub_Type")
    public void setSubType(String subType) {
        this.subType = subType;
    }

    @JsonProperty("Telephony_Message_Id")
    public Object getTelephonyMessageId() {
        return telephonyMessageId;
    }

    @JsonProperty("Telephony_Message_Id")
    public void setTelephonyMessageId(Object telephonyMessageId) {
        this.telephonyMessageId = telephonyMessageId;
    }

    @JsonProperty("Telephony_Message_Label")
    public Object getTelephonyMessageLabel() {
        return telephonyMessageLabel;
    }

    @JsonProperty("Telephony_Message_Label")
    public void setTelephonyMessageLabel(Object telephonyMessageLabel) {
        this.telephonyMessageLabel = telephonyMessageLabel;
    }

    @JsonProperty("Time_Spent_Hrs")
    public String getTimeSpentHrs() {
        return timeSpentHrs;
    }

    @JsonProperty("Time_Spent_Hrs")
    public void setTimeSpentHrs(String timeSpentHrs) {
        this.timeSpentHrs = timeSpentHrs;
    }

    @JsonProperty("Time_Spent_Min")
    public Integer getTimeSpentMin() {
        return timeSpentMin;
    }

    @JsonProperty("Time_Spent_Min")
    public void setTimeSpentMin(Integer timeSpentMin) {
        this.timeSpentMin = timeSpentMin;
    }

    @JsonProperty("Transaction_Id")
    public String getTransactionId() {
        return transactionId;
    }

    @JsonProperty("Transaction_Id")
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    @JsonProperty("Visibility_Level")
    public String getVisibilityLevel() {
        return visibilityLevel;
    }

    @JsonProperty("Visibility_Level")
    public void setVisibilityLevel(String visibilityLevel) {
        this.visibilityLevel = visibilityLevel;
    }

    @JsonProperty("Mobile__Related_Event")
    public Object getMobileRelatedEvent() {
        return mobileRelatedEvent;
    }

    @JsonProperty("Mobile__Related_Event")
    public void setMobileRelatedEvent(Object mobileRelatedEvent) {
        this.mobileRelatedEvent = mobileRelatedEvent;
    }

    @JsonProperty("Mobile__Unique_Id")
    public Object getMobileUniqueId() {
        return mobileUniqueId;
    }

    @JsonProperty("Mobile__Unique_Id")
    public void setMobileUniqueId(Object mobileUniqueId) {
        this.mobileUniqueId = mobileUniqueId;
    }

    @JsonProperty("UserProfile")
    public String getUserProfile() {
        return userProfile;
    }

    @JsonProperty("UserProfile")
    public void setUserProfile(String userProfile) {
        this.userProfile = userProfile;
    }

    @JsonProperty("Internal_Attendees")
    public List<InternalAttendee> getInternalAttendees() {
        return internalAttendees;
    }

    @JsonProperty("Internal_Attendees")
    public void setInternalAttendees(List<InternalAttendee> internalAttendees) {
        this.internalAttendees = internalAttendees;
    }

    @JsonProperty("External_Attendees")
    public List<ExternalAttendee> getExternalAttendees() {
        return externalAttendees;
    }

    @JsonProperty("External_Attendees")
    public void setExternalAttendees(List<ExternalAttendee> externalAttendees) {
        this.externalAttendees = externalAttendees;
    }

    @JsonProperty("Call_Report_Account")
    public List<CallReportAccount> getCallReportAccount() {
        return callReportAccount;
    }

    @JsonProperty("Call_Report_Account")
    public void setCallReportAccount(List<CallReportAccount> callReportAccount) {
        this.callReportAccount = callReportAccount;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CallReport{");
        sb.append("bookmark=").append(bookmark);
        sb.append(", callOutcome=").append(callOutcome);
        sb.append(", callRatingPicker=").append(callRatingPicker);
        sb.append(", callReportLOBTxT='").append(callReportLOBTxT).append('\'');
        sb.append(", callReportRoleTxT='").append(callReportRoleTxT).append('\'');
        sb.append(", createdById='").append(createdById).append('\'');
        sb.append(", createdDate='").append(createdDate).append('\'');
        sb.append(", id='").append(id).append('\'');
        sb.append(", isDeleted=").append(isDeleted);
        sb.append(", lastActivityDate=").append(lastActivityDate);
        sb.append(", lastModifiedById='").append(lastModifiedById).append('\'');
        sb.append(", lastModifiedDate='").append(lastModifiedDate).append('\'');
        sb.append(", lastReferencedDate=").append(lastReferencedDate);
        sb.append(", lastViewedDate=").append(lastViewedDate);
        sb.append(", localEndTime=").append(localEndTime);
        sb.append(", localStartTime=").append(localStartTime);
        sb.append(", name='").append(name).append('\'');
        sb.append(", ownerId='").append(ownerId).append('\'');
        sb.append(", postalCode=").append(postalCode);
        sb.append(", securityLevel=").append(securityLevel);
        sb.append(", sharingReasons='").append(sharingReasons).append('\'');
        sb.append(", systemModstamp='").append(systemModstamp).append('\'');
        sb.append(", exchangeInteraction=").append(exchangeInteraction);
        sb.append(", calledContactNumber=").append(calledContactNumber);
        sb.append(", callDisposition=").append(callDisposition);
        sb.append(", callRating=").append(callRating);
        sb.append(", callReportID=").append(callReportID);
        sb.append(", city=").append(city);
        sb.append(", clientInitiated=").append(clientInitiated);
        sb.append(", client=").append(client);
        sb.append(", country=").append(country);
        sb.append(", createdByEmployee=").append(createdByEmployee);
        sb.append(", doNotForward=").append(doNotForward);
        sb.append(", endTime='").append(endTime).append('\'');
        sb.append(", externalNotes=").append(externalNotes);
        sb.append(", externalRichTextNotes=").append(externalRichTextNotes);
        sb.append(", interactionType='").append(interactionType).append('\'');
        sb.append(", location=").append(location);
        sb.append(", lock='").append(lock).append('\'');
        sb.append(", loggedBy=").append(loggedBy);
        sb.append(", loggedFrom='").append(loggedFrom).append('\'');
        sb.append(", meetingDate='").append(meetingDate).append('\'');
        sb.append(", meetingType='").append(meetingType).append('\'');
        sb.append(", notes='").append(notes).append('\'');
        sb.append(", notifyAttendees=").append(notifyAttendees);
        sb.append(", notifyByEmail=").append(notifyByEmail);
        sb.append(", notifyCoverageTeam=").append(notifyCoverageTeam);
        sb.append(", notifyOthers=").append(notifyOthers);
        sb.append(", numberOfRelationships=").append(numberOfRelationships);
        sb.append(", priority='").append(priority).append('\'');
        sb.append(", _private=").append(_private);
        sb.append(", recordType='").append(recordType).append('\'');
        sb.append(", relatedEvent=").append(relatedEvent);
        sb.append(", relatedToId=").append(relatedToId);
        sb.append(", relatedToType=").append(relatedToType);
        sb.append(", richTextNotes=").append(richTextNotes);
        sb.append(", selectedContact=").append(selectedContact);
        sb.append(", startTime='").append(startTime).append('\'');
        sb.append(", state=").append(state);
        sb.append(", status='").append(status).append('\'');
        sb.append(", subjectMeetingObjectives='").append(subjectMeetingObjectives).append('\'');
        sb.append(", subType=").append(subType);
        sb.append(", telephonyMessageId=").append(telephonyMessageId);
        sb.append(", telephonyMessageLabel=").append(telephonyMessageLabel);
        sb.append(", timeSpentHrs=").append(timeSpentHrs);
        sb.append(", timeSpentMin=").append(timeSpentMin);
        sb.append(", transactionId=").append(transactionId);
        sb.append(", visibilityLevel='").append(visibilityLevel).append('\'');
        sb.append(", mobileRelatedEvent=").append(mobileRelatedEvent);
        sb.append(", mobileUniqueId=").append(mobileUniqueId);
        sb.append(", userProfile='").append(userProfile).append('\'');
        sb.append(", internalAttendees=").append(internalAttendees);
        sb.append(", externalAttendees=").append(externalAttendees);
        sb.append(", callReportAccount=").append(callReportAccount);
        sb.append('}');
        return sb.toString();
    }
}
