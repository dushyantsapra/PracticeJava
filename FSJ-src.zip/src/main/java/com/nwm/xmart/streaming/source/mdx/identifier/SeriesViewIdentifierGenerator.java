package com.nwm.xmart.streaming.source.mdx.identifier;

import java.util.StringTokenizer;

/**
 * Created by gardlex on 14/05/2018.
 */
public class SeriesViewIdentifierGenerator implements IdentifierGenerator {

    private final String seriesIdentifier;

    public SeriesViewIdentifierGenerator(String seriesIdentifier) {
        this.seriesIdentifier = seriesIdentifier;
    }

    /**
     * Create an MDX full identifier used for MDX document retrieval
     *
     * @param isin
     * @return the full MDX identifier
     */
    @Override
    public String getIdentifierForISIN(String isin) {
        return seriesIdentifier + isin;
    }

    @Override
    public String extractISINFromIdentifier(String fullIdentifier) {
        // identifier in the form of 'public/Credit/EZ8ZJ7DJ70C3'
        StringTokenizer st = new StringTokenizer(fullIdentifier, "/");
        st.nextToken();st.nextToken();

        return st.nextToken();
    }
}
