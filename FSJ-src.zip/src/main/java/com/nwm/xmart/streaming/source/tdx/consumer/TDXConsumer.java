package com.nwm.xmart.streaming.source.tdx.consumer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nwm.xmart.streaming.source.json.JSONDocumentTraverser;
import com.nwm.xmart.streaming.source.tdx.event.TDXSourceEvent;
import com.tdx.client.api.streams.TDXDatasetEventConsumer;
import com.tdx.client.api.streams.TDXDatasetStreamEvent;
import com.tdx.client.api.streams.TDXDatasetStreamExistingDocumentEvent;
import com.tdx.client.api.streams.TDXDatasetStreamNewDocumentEvent;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.util.ExceptionUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.CountDownLatch;

/**
 * Created by gardlex on 08/10/2018.
 */
public class TDXConsumer implements TDXDatasetEventConsumer {
    private static Logger logger = LoggerFactory.getLogger(TDXConsumer.class);
    private final CountDownLatch countDownLatch = new CountDownLatch(1);
    private final SourceFunction.SourceContext srcCtx;
    private volatile Throwable lastError;
    private volatile TDXDatasetStreamEvent currentStreamEvent;
    private final String dataSetId;

    public TDXConsumer(SourceFunction.SourceContext srcCtx, String datasetId) {
        this.srcCtx = srcCtx;
        this.dataSetId = datasetId;
    }

    public void waitForStreamTermination() throws InterruptedException {
        logger.info("about to wait on latch");
        countDownLatch.await();
        logger.info("latch, exited / interrupted");
    }

    public void stopConsumingEvents() {
        logger.info("stopConsumingEvents called");
        countDownLatch.countDown();
    }

    /*
     * @NotThreadSafe - must be called when holding the checkpoint lock
     */
    public TDXDatasetStreamEvent getCurrentEventForSnapshot() {
        return currentStreamEvent;
    }

    @Override
    public void consume(TDXDatasetStreamEvent event) {
        ObjectNode json = null;

        try {
            int version = (int) event.getDocument().getDocumentId().getVersion().getValue();
            LocalDateTime from = convertUnixDateToDateTimeString(event.getDocument().getDocumentLifetime().getFrom());
            LocalDateTime to = convertUnixDateToDateTimeString(event.getDocument().getDocumentLifetime().getTo());

            if (event instanceof TDXDatasetStreamExistingDocumentEvent) {
                TDXDatasetStreamExistingDocumentEvent evt = (TDXDatasetStreamExistingDocumentEvent) event;
                logger.debug("offset ="+ event.getEventSequenceId());
                json = convertToJSONObject(evt);
            } else if (event instanceof TDXDatasetStreamNewDocumentEvent) {
                TDXDatasetStreamNewDocumentEvent evt = (TDXDatasetStreamNewDocumentEvent) event;
                logger.debug("offset ="+ event.getEventSequenceId());
                json = convertToJSONObject(evt);
            }

            // TODO - check foro ther types
            if (json != null) {
                TDXSourceEvent sourceEvent = new TDXSourceEvent(
                        new JSONDocumentTraverser(json), event.getEventSequenceId(), dataSetId, System.currentTimeMillis(), version, from, to);
                synchronized (srcCtx.getCheckpointLock()) {
                    srcCtx.collect(sourceEvent);
                    currentStreamEvent = event;
                }
            }
        } catch (Exception e) {
            // TODO- log error
            logger.error("ERROR occurred retrieving event with eventSequenceID" + event.getEventSequenceId() + " - "  + e);
        }
    }

    private LocalDateTime  convertUnixDateToDateTimeString(long unixDate){
        LocalDateTime date = LocalDateTime.of( 2999,12,31,0,0,0);
        if(unixDate > 0 && !Long.valueOf(unixDate).equals(Long.MAX_VALUE)){
            date = LocalDateTime.ofInstant(Instant.ofEpochMilli(unixDate), TimeZone.getDefault().toZoneId());
        }
        return date;
    }

    private ObjectNode convertToJSONObject(TDXDatasetStreamEvent evt) {
        ObjectNode json = null;
        try {
            String data = evt.getDocument().getContents().toStringUtf8();
            json = (ObjectNode) new ObjectMapper().readTree(data);
        } catch (IOException e) {
            lastError = e;
            logger.error("Could not convert UTF8 contents of TDXDocument to JSON for eventSequenceId= " + evt.getEventSequenceId(), e);
            stopConsumingEvents();
        }

        return json;
    }

    @Override
    public void onError(Throwable t) {
        lastError = t;
        logger.error("TDX dataset event stream failure, stopping the stream", t);
        stopConsumingEvents();
    }

    public Throwable getError() {
        return lastError;
    }

    public void setError(Throwable t) {
        lastError = t;
    }
}
