
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CBEligibilityHaircutLongName",
    "CBEligibilityHaircutShortName",
    "EligibilityType",
    "EligibilityProvider",
    "CBEligibilityHaircutPercentage"
})
public class InstrumentEligibility {

    @JsonProperty("CBEligibilityHaircutLongName")
    private String cBEligibilityHaircutLongName;
    @JsonProperty("CBEligibilityHaircutShortName")
    private String cBEligibilityHaircutShortName;
    @JsonProperty("EligibilityType")
    private String eligibilityType;
    @JsonProperty("EligibilityProvider")
    private String eligibilityProvider;
    @JsonProperty("CBEligibilityHaircutPercentage")
    private Double cBEligibilityHaircutPercentage;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("CBEligibilityHaircutLongName")
    public String getCBEligibilityHaircutLongName() {
        return cBEligibilityHaircutLongName;
    }

    @JsonProperty("CBEligibilityHaircutLongName")
    public void setCBEligibilityHaircutLongName(String cBEligibilityHaircutLongName) {
        this.cBEligibilityHaircutLongName = cBEligibilityHaircutLongName;
    }

    @JsonProperty("CBEligibilityHaircutShortName")
    public String getCBEligibilityHaircutShortName() {
        return cBEligibilityHaircutShortName;
    }

    @JsonProperty("CBEligibilityHaircutShortName")
    public void setCBEligibilityHaircutShortName(String cBEligibilityHaircutShortName) {
        this.cBEligibilityHaircutShortName = cBEligibilityHaircutShortName;
    }

    @JsonProperty("EligibilityType")
    public String getEligibilityType() {
        return eligibilityType;
    }

    @JsonProperty("EligibilityType")
    public void setEligibilityType(String eligibilityType) {
        this.eligibilityType = eligibilityType;
    }

    @JsonProperty("EligibilityProvider")
    public String getEligibilityProvider() {
        return eligibilityProvider;
    }

    @JsonProperty("EligibilityProvider")
    public void setEligibilityProvider(String eligibilityProvider) {
        this.eligibilityProvider = eligibilityProvider;
    }

    @JsonProperty("CBEligibilityHaircutPercentage")
    public Double getCBEligibilityHaircutPercentage() {
        return cBEligibilityHaircutPercentage;
    }

    @JsonProperty("CBEligibilityHaircutPercentage")
    public void setCBEligibilityHaircutPercentage(Double cBEligibilityHaircutPercentage) {
        this.cBEligibilityHaircutPercentage = cBEligibilityHaircutPercentage;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("cBEligibilityHaircutLongName", cBEligibilityHaircutLongName).append("cBEligibilityHaircutShortName", cBEligibilityHaircutShortName).append("eligibilityType", eligibilityType).append("eligibilityProvider", eligibilityProvider).append("cBEligibilityHaircutPercentage", cBEligibilityHaircutPercentage).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(eligibilityType).append(cBEligibilityHaircutLongName).append(cBEligibilityHaircutShortName).append(additionalProperties).append(cBEligibilityHaircutPercentage).append(eligibilityProvider).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InstrumentEligibility) == false) {
            return false;
        }
        InstrumentEligibility rhs = ((InstrumentEligibility) other);
        return new EqualsBuilder().append(eligibilityType, rhs.eligibilityType).append(cBEligibilityHaircutLongName, rhs.cBEligibilityHaircutLongName).append(cBEligibilityHaircutShortName, rhs.cBEligibilityHaircutShortName).append(additionalProperties, rhs.additionalProperties).append(cBEligibilityHaircutPercentage, rhs.cBEligibilityHaircutPercentage).append(eligibilityProvider, rhs.eligibilityProvider).isEquals();
    }

}
