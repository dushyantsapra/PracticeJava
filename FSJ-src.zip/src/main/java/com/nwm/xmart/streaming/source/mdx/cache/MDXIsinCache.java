package com.nwm.xmart.streaming.source.mdx.cache;

import com.nwm.xmart.streaming.source.mdx.cache.load.CacheItem;
import com.nwm.xmart.streaming.source.mdx.cache.load.ISINCacheLoader;
import com.nwm.xmart.streaming.source.mdx.cache.load.MDXIsinCacheItem;
import org.apache.flink.api.java.utils.ParameterTool;

/**
 * @NotThreadSafe
 *
 *
 * Created by gardlex on 11/05/2018.
 */
public class MDXIsinCache extends IsinCache {
    private final String mdxInitialLoadIdentifier;

    public MDXIsinCache(ISINCacheLoader isinCacheLoader, String sourceName, ParameterTool flinkParams, String mdxInitialLoadIdentifier) {
        super(sourceName, flinkParams, isinCacheLoader);
        this.mdxInitialLoadIdentifier = mdxInitialLoadIdentifier;
    }

    @Override
    public Integer getCachedVersionForISIN(String isin) {
        return ((MDXIsinCacheItem)isinMap.get(isin)).getVersion();
    }

    @Override
    public boolean putISINCacheItem(CacheItem newCacheItem) {

        CacheItem cachedItem = isinMap.get(newCacheItem.getIdentifier());
        MDXIsinCacheItem mdxIsinCacheItem = (cachedItem == null) ? null : (MDXIsinCacheItem) cachedItem;
        MDXIsinCacheItem newMdxIsinCacheItem = (MDXIsinCacheItem) newCacheItem;

        // if new version of mdxDocment has been received, then insert into ISIN map.
        if (mdxIsinCacheItem == null || mdxIsinCacheItem.getVersion() < newMdxIsinCacheItem.getVersion()) {
            isinMap.put(newMdxIsinCacheItem.getIdentifier(), newMdxIsinCacheItem);
//            logger.info("new cachedItem or new version: " + newCacheItem.getIdentifier() + ", version = " + newCacheItem.getVersion());
            return true;
        }

        // if it's an earlier version then reject
        if (mdxIsinCacheItem.getVersion() > newMdxIsinCacheItem.getVersion()) {
//            logger.info("earlier version rejected: " + newCacheItem.getIdentifier() + ", version = " + newCacheItem.getVersion());
            return false;
        }

        // existing item but version is the same so compare xmlWriteTime
        if (mdxIsinCacheItem.getVersion() == newMdxIsinCacheItem.getVersion()) {
            if (mdxIsinCacheItem.getEpochXmlWriteTime() < newMdxIsinCacheItem.getEpochXmlWriteTime()) {
                isinMap.put(newMdxIsinCacheItem.getIdentifier(), newMdxIsinCacheItem);
//                            logger.info("SAME version but > xmlWriteTime: " + newCacheItem.getIdentifier() + ", version = " + newCacheItem.getVersion());
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}
