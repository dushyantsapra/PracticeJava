package com.nwm.xmart.streaming.source.mdx.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class RefRegInstrumentUnderlying extends HeaderFields implements Serializable {
    private static final long serialVersionUID = 1276090948366933973L;

    private String type;
    private String underlyingInstrumentIndexProp;
    private String underlyingInstrumentISIN;
    private String underlyingInstrumentIndex;
    private String underlyingInstrumentIndexTermUnit;
    private BigDecimal underlyingInstrumentIndexTermValue;
    private String iSOUnderlyingInstrumentIndex;
    private String instrumentISIN;

    public RefRegInstrumentUnderlying(String mdxTransport, String mdxTypeName, String mdxPath, int mdxDocumentVersion,
            Date mdxWrittenOnUTC, String mdxValuationDate, String xmlWriteTime) {
        super(mdxTransport, mdxTypeName, mdxPath, mdxDocumentVersion, mdxWrittenOnUTC, mdxValuationDate, xmlWriteTime);
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUnderlyingInstrumentIndexProp() {
        return underlyingInstrumentIndexProp;
    }

    public void setUnderlyingInstrumentIndexProp(String underlyingInstrumentIndexProp) {
        this.underlyingInstrumentIndexProp = underlyingInstrumentIndexProp;
    }

    public String getUnderlyingInstrumentISIN() {
        return underlyingInstrumentISIN;
    }

    public void setUnderlyingInstrumentISIN(String underlyingInstrumentISIN) {
        this.underlyingInstrumentISIN = underlyingInstrumentISIN;
    }

    public String getUnderlyingInstrumentIndex() {
        return underlyingInstrumentIndex;
    }

    public void setUnderlyingInstrumentIndex(String underlyingInstrumentIndex) {
        this.underlyingInstrumentIndex = underlyingInstrumentIndex;
    }

    public String getUnderlyingInstrumentIndexTermUnit() {
        return underlyingInstrumentIndexTermUnit;
    }

    public void setUnderlyingInstrumentIndexTermUnit(String underlyingInstrumentIndexTermUnit) {
        this.underlyingInstrumentIndexTermUnit = underlyingInstrumentIndexTermUnit;
    }

    public BigDecimal getUnderlyingInstrumentIndexTermValue() {
        return underlyingInstrumentIndexTermValue;
    }

    public void setUnderlyingInstrumentIndexTermValue(BigDecimal underlyingInstrumentIndexTermValue) {
        this.underlyingInstrumentIndexTermValue = underlyingInstrumentIndexTermValue;
    }

    public String getiSOUnderlyingInstrumentIndex() {
        return iSOUnderlyingInstrumentIndex;
    }

    public void setiSOUnderlyingInstrumentIndex(String iSOUnderlyingInstrumentIndex) {
        this.iSOUnderlyingInstrumentIndex = iSOUnderlyingInstrumentIndex;
    }

    public String getInstrumentISIN() {
        return instrumentISIN;
    }

    public void setInstrumentISIN(String instrumentISIN) {
        this.instrumentISIN = instrumentISIN;
    }
}
