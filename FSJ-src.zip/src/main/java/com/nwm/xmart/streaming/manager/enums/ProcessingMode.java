package com.nwm.xmart.streaming.manager.enums;

public enum ProcessingMode {
    REPAIR,
    RANGE,
    DAILY
}