package com.nwm.xmart.streaming.source.mdx.cache.load;

/**
 * Created by gardlex on 21/05/2018.
 */
public interface CacheItem {
    String getIdentifier();
}
