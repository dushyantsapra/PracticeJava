package com.nwm.xmart.streaming.source.mdx.entity;

import rbs.gbm.dx.webService.impl.regulatory.ITotvStatus;

public class ReferenceRegulatory {
    private final String isin;
    private final String cfi;
    private final String instrumentLongName;
    private final Boolean isLiquid;
    private final Long postTradeSstiThreshold;
    private final Long postTradeLisThreshold;
    private final Long preTradeSstiThreshold;
    private final Long preTradeLisThreshold;
    private final ITotvStatus tradedOnTradingVenue;
    private final ITotvStatus tradedOnTradingVenueUnderlyer;

    public ReferenceRegulatory(String isin, String cfi, String instrumentLongName, Boolean isLiquid,
            Long postTradeSstiThreshold, Long postTradeLisThreshold, Long preTradeSstiThreshold,
            Long preTradeLisThreshold, ITotvStatus tradedOnTradingVenue, ITotvStatus tradedOnTradingVenueUnderlyer) {
        this.isin = isin;
        this.cfi = cfi;
        this.instrumentLongName = instrumentLongName;
        this.isLiquid = isLiquid;
        this.postTradeSstiThreshold = postTradeSstiThreshold;
        this.postTradeLisThreshold = postTradeLisThreshold;
        this.preTradeSstiThreshold = preTradeSstiThreshold;
        this.preTradeLisThreshold = preTradeLisThreshold;
        this.tradedOnTradingVenue = tradedOnTradingVenue;
        this.tradedOnTradingVenueUnderlyer = tradedOnTradingVenueUnderlyer;
    }

    public String getIsin() {
        return isin;
    }

    public String getCfi() {
        return cfi;
    }

    public String getInstrumentLongName() {
        return instrumentLongName;
    }

    public Boolean getLiquid() {
        return isLiquid;
    }

    public Long getPostTradeSstiThreshold() {
        return postTradeSstiThreshold;
    }

    public Long getPostTradeLisThreshold() {
        return postTradeLisThreshold;
    }

    public Long getPreTradeSstiThreshold() {
        return preTradeSstiThreshold;
    }

    public Long getPreTradeLisThreshold() {
        return preTradeLisThreshold;
    }

    public ITotvStatus getTradedOnTradingVenue() {
        return tradedOnTradingVenue;
    }

    public ITotvStatus getTradedOnTradingVenueUnderlyer() {
        return tradedOnTradingVenueUnderlyer;
    }
}
