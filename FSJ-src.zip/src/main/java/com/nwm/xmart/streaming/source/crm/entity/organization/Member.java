package com.nwm.xmart.streaming.source.crm.entity.organization;

import com.nwm.xmart.streaming.source.crm.entity.common.Employee;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "CreatedById", "CreatedDate", "Id", "LastModifiedById", "LastModifiedDate", "Name", "OwnerId",
                     "SystemModstamp", "Employee", "Organization_Structure", "Role", "User_Id" })

public class Member implements Serializable {
    private static final long serialVersionUID = -5507192787686752277L;

    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("OwnerId")
    private String ownerId;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("Employee")
    private Employee employee;
    @JsonProperty("Organization_Structure")
    private String organizationStructure;
    @JsonProperty("Role")
    private String role;
    @JsonProperty("User_Id")
    private String userId;

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("OwnerId")
    public String getOwnerId() {
        return ownerId;
    }

    @JsonProperty("OwnerId")
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("Employee")
    public Employee getEmployee() {
        return employee;
    }

    @JsonProperty("Employee")
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    @JsonProperty("Organization_Structure")
    public String getOrganizationStructure() {
        return organizationStructure;
    }

    @JsonProperty("Organization_Structure")
    public void setOrganizationStructure(String organizationStructure) {
        this.organizationStructure = organizationStructure;
    }

    @JsonProperty("Role")
    public String getRole() {
        return role;
    }

    @JsonProperty("Role")
    public void setRole(String role) {
        this.role = role;
    }

    @JsonProperty("User_Id")
    public String getUserId() {
        return userId;
    }

    @JsonProperty("User_Id")
    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Member{");
        sb.append("createdById='").append(createdById).append('\'');
        sb.append(", createdDate='").append(createdDate).append('\'');
        sb.append(", id='").append(id).append('\'');
        sb.append(", lastModifiedById='").append(lastModifiedById).append('\'');
        sb.append(", lastModifiedDate='").append(lastModifiedDate).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", ownerId='").append(ownerId).append('\'');
        sb.append(", systemModstamp='").append(systemModstamp).append('\'');
        sb.append(", employee=").append(employee);
        sb.append(", organizationStructure='").append(organizationStructure).append('\'');
        sb.append(", role='").append(role).append('\'');
        sb.append(", userId='").append(userId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
