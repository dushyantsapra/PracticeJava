package com.nwm.xmart.streaming.example;

/**
 * Created by gardlex on 11/09/2017.
 */
public class ExampleTradePOJO {

    // Empty for Kafka
    public ExampleTradePOJO() {
    }

    private long id;
    private long timestamp;
    private String payload;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    @Override
    public String toString() {
        return "ExampleTradePOJO{" +
                "id=" + id +
                ", timestamp=" + timestamp +
                ", payload='" + payload + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ExampleTradePOJO trade = (ExampleTradePOJO) o;

        return id == trade.id;
    }

    @Override
    public int hashCode() {
        return (int) (id ^ (id >>> 32));
    }

    public static ExampleTradePOJO createTrade(long id, long timestamp)  {
        ExampleTradePOJO t = new ExampleTradePOJO();
        t.setId(id);
        t.setTimestamp(System.nanoTime());
        return t;
    }
}
