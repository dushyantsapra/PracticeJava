
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ARMInitialFixedPeriodinMonths",
    "BondRecoveryRate",
    "BenchmarkBondIdentifier",
    "SeriesOfBond",
    "IsCallable",
    "BondCalledIndicator",
    "CFICode",
    "CalledPrice",
    "IsConvertible",
    "ConvStartDate",
    "CurrentPercentageAnnuityPayment",
    "IsExchangeable",
    "FirstPaymentDate",
    "FixToFloatChangeIndicator",
    "InflationLag",
    "InflationLagPeriod",
    "IsAssetBackedSecurity",
    "IsBearerBond",
    "IsBrady",
    "IsCapitalContingent",
    "CollectiveActionClause",
    "ContingentConversion",
    "DirtyCleanIndicator",
    "IsCovered",
    "CreditLinkedIndicator",
    "IsCurrentGovernmentBond",
    "DimSumBondIndicator",
    "EMTNIndicator",
    "ExtendibleMaturityDateIndicator",
    "FormosaIndicator",
    "BulletMaturityTypeIndicator",
    "InflationLinkedIndicator",
    "IsMostSenior",
    "MTNIndicator",
    "IsRegulationS",
    "IsResecuritised",
    "IsSecured",
    "IsSecuritised",
    "IsSenior",
    "IsFlatTraded",
    "IsZeroCoupon",
    "LastPayment",
    "BASECPI",
    "PreferredSecurityIndicator",
    "IsPutable",
    "ShortSellLimit",
    "IsSinkable",
    "IsSLREligible",
    "StructuredNotesIndicator",
    "IsSubordinated",
    "UnitTradedIndicator",
    "IsUnsecuredObligation",
    "ARMWeightedAverageMonthstoPastInitialReset",
    "ARMWeightedAverageMonthstoInitialReset",
    "PutDaysNotice",
    "PutDaysnoticeMultiplier",
    "PutDaysNoticeScheme",
    "PutDaysNoticeType",
    "NextPutPrice",
    "NextPutDate",
    "NextCallPrice",
    "NextCallDate",
    "ReconventionDate",
    "ConversionPrice",
    "ConvertibleUntil",
    "MtgeClassCallDate",
    "CalledDate",
    "NoticePeriodDayTypeCall",
    "CallDaysNotice",
    "CallDaysNoticeScheme",
    "CallDaysNoticeType",
    "CallAnnouncementDate",
    "WeightedAverageMaturity",
    "PrepaymentSpeed",
    "PrepaymentType",
    "FinalMaturity",
    "ResetFrequency",
    "AuctionDate",
    "CloEquityTranche",
    "GteCollateralType",
    "MtgeDealCallDate",
    "WorkoutDateMidToWorst",
    "MtgePrepayType",
    "MtgePrepaySpeed",
    "MtgePrepaySouce",
    "MtgePrepaySpeedType",
    "MtgeEquivalentPsa",
    "MtgeEquivalentCpr"
})
public class Bond {

    @JsonProperty("ARMInitialFixedPeriodinMonths")
    private Object aRMInitialFixedPeriodinMonths;
    @JsonProperty("BondRecoveryRate")
    private Object bondRecoveryRate;
    @JsonProperty("BenchmarkBondIdentifier")
    private Object benchmarkBondIdentifier;
    @JsonProperty("SeriesOfBond")
    private Object seriesOfBond;
    @JsonProperty("IsCallable")
    private Boolean isCallable;
    @JsonProperty("BondCalledIndicator")
    private Boolean bondCalledIndicator;
    @JsonProperty("CFICode")
    private Object cFICode;
    @JsonProperty("CalledPrice")
    private Object calledPrice;
    @JsonProperty("IsConvertible")
    private Object isConvertible;
    @JsonProperty("ConvStartDate")
    private Object convStartDate;
    @JsonProperty("CurrentPercentageAnnuityPayment")
    private Object currentPercentageAnnuityPayment;
    @JsonProperty("IsExchangeable")
    private Boolean isExchangeable;
    @JsonProperty("FirstPaymentDate")
    private Object firstPaymentDate;
    @JsonProperty("FixToFloatChangeIndicator")
    private Object fixToFloatChangeIndicator;
    @JsonProperty("InflationLag")
    private Object inflationLag;
    @JsonProperty("InflationLagPeriod")
    private String inflationLagPeriod;
    @JsonProperty("IsAssetBackedSecurity")
    private Boolean isAssetBackedSecurity;
    @JsonProperty("IsBearerBond")
    private Boolean isBearerBond;
    @JsonProperty("IsBrady")
    private Object isBrady;
    @JsonProperty("IsCapitalContingent")
    private Object isCapitalContingent;
    @JsonProperty("CollectiveActionClause")
    private Object collectiveActionClause;
    @JsonProperty("ContingentConversion")
    private Object contingentConversion;
    @JsonProperty("DirtyCleanIndicator")
    private Object dirtyCleanIndicator;
    @JsonProperty("IsCovered")
    private Object isCovered;
    @JsonProperty("CreditLinkedIndicator")
    private Object creditLinkedIndicator;
    @JsonProperty("IsCurrentGovernmentBond")
    private Object isCurrentGovernmentBond;
    @JsonProperty("DimSumBondIndicator")
    private Object dimSumBondIndicator;
    @JsonProperty("EMTNIndicator")
    private Object eMTNIndicator;
    @JsonProperty("ExtendibleMaturityDateIndicator")
    private Boolean extendibleMaturityDateIndicator;
    @JsonProperty("FormosaIndicator")
    private Object formosaIndicator;
    @JsonProperty("BulletMaturityTypeIndicator")
    private Object bulletMaturityTypeIndicator;
    @JsonProperty("InflationLinkedIndicator")
    private Boolean inflationLinkedIndicator;
    @JsonProperty("IsMostSenior")
    private Boolean isMostSenior;
    @JsonProperty("MTNIndicator")
    private Object mTNIndicator;
    @JsonProperty("IsRegulationS")
    private Object isRegulationS;
    @JsonProperty("IsResecuritised")
    private Object isResecuritised;
    @JsonProperty("IsSecured")
    private Object isSecured;
    @JsonProperty("IsSecuritised")
    private Object isSecuritised;
    @JsonProperty("IsSenior")
    private Boolean isSenior;
    @JsonProperty("IsFlatTraded")
    private Object isFlatTraded;
    @JsonProperty("IsZeroCoupon")
    private Object isZeroCoupon;
    @JsonProperty("LastPayment")
    private Object lastPayment;
    @JsonProperty("BASECPI")
    private Object bASECPI;
    @JsonProperty("PreferredSecurityIndicator")
    private Object preferredSecurityIndicator;
    @JsonProperty("IsPutable")
    private Boolean isPutable;
    @JsonProperty("ShortSellLimit")
    private Object shortSellLimit;
    @JsonProperty("IsSinkable")
    private Boolean isSinkable;
    @JsonProperty("IsSLREligible")
    private Object isSLREligible;
    @JsonProperty("StructuredNotesIndicator")
    private Boolean structuredNotesIndicator;
    @JsonProperty("IsSubordinated")
    private Object isSubordinated;
    @JsonProperty("UnitTradedIndicator")
    private Boolean unitTradedIndicator;
    @JsonProperty("IsUnsecuredObligation")
    private Object isUnsecuredObligation;
    @JsonProperty("ARMWeightedAverageMonthstoPastInitialReset")
    private Object aRMWeightedAverageMonthstoPastInitialReset;
    @JsonProperty("ARMWeightedAverageMonthstoInitialReset")
    private Object aRMWeightedAverageMonthstoInitialReset;
    @JsonProperty("PutDaysNotice")
    private Object putDaysNotice;
    @JsonProperty("PutDaysnoticeMultiplier")
    private Object putDaysnoticeMultiplier;
    @JsonProperty("PutDaysNoticeScheme")
    private String putDaysNoticeScheme;
    @JsonProperty("PutDaysNoticeType")
    private String putDaysNoticeType;
    @JsonProperty("NextPutPrice")
    private Object nextPutPrice;
    @JsonProperty("NextPutDate")
    private Object nextPutDate;
    @JsonProperty("NextCallPrice")
    private Object nextCallPrice;
    @JsonProperty("NextCallDate")
    private Object nextCallDate;
    @JsonProperty("ReconventionDate")
    private Object reconventionDate;
    @JsonProperty("ConversionPrice")
    private Object conversionPrice;
    @JsonProperty("ConvertibleUntil")
    private Object convertibleUntil;
    @JsonProperty("MtgeClassCallDate")
    private Object mtgeClassCallDate;
    @JsonProperty("CalledDate")
    private Object calledDate;
    @JsonProperty("NoticePeriodDayTypeCall")
    private Object noticePeriodDayTypeCall;
    @JsonProperty("CallDaysNotice")
    private Object callDaysNotice;
    @JsonProperty("CallDaysNoticeScheme")
    private String callDaysNoticeScheme;
    @JsonProperty("CallDaysNoticeType")
    private String callDaysNoticeType;
    @JsonProperty("CallAnnouncementDate")
    private Object callAnnouncementDate;
    @JsonProperty("WeightedAverageMaturity")
    private Object weightedAverageMaturity;
    @JsonProperty("PrepaymentSpeed")
    private Object prepaymentSpeed;
    @JsonProperty("PrepaymentType")
    private Object prepaymentType;
    @JsonProperty("FinalMaturity")
    private String finalMaturity;
    @JsonProperty("ResetFrequency")
    private Object resetFrequency;
    @JsonProperty("AuctionDate")
    private Object auctionDate;
    @JsonProperty("CloEquityTranche")
    private Object cloEquityTranche;
    @JsonProperty("GteCollateralType")
    private Object gteCollateralType;
    @JsonProperty("MtgeDealCallDate")
    private Object mtgeDealCallDate;
    @JsonProperty("WorkoutDateMidToWorst")
    private Object workoutDateMidToWorst;
    @JsonProperty("MtgePrepayType")
    private Object mtgePrepayType;
    @JsonProperty("MtgePrepaySpeed")
    private Object mtgePrepaySpeed;
    @JsonProperty("MtgePrepaySouce")
    private Object mtgePrepaySouce;
    @JsonProperty("MtgePrepaySpeedType")
    private Object mtgePrepaySpeedType;
    @JsonProperty("MtgeEquivalentPsa")
    private Object mtgeEquivalentPsa;
    @JsonProperty("MtgeEquivalentCpr")
    private Object mtgeEquivalentCpr;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ARMInitialFixedPeriodinMonths")
    public Object getARMInitialFixedPeriodinMonths() {
        return aRMInitialFixedPeriodinMonths;
    }

    @JsonProperty("ARMInitialFixedPeriodinMonths")
    public void setARMInitialFixedPeriodinMonths(Object aRMInitialFixedPeriodinMonths) {
        this.aRMInitialFixedPeriodinMonths = aRMInitialFixedPeriodinMonths;
    }

    @JsonProperty("BondRecoveryRate")
    public Object getBondRecoveryRate() {
        return bondRecoveryRate;
    }

    @JsonProperty("BondRecoveryRate")
    public void setBondRecoveryRate(Object bondRecoveryRate) {
        this.bondRecoveryRate = bondRecoveryRate;
    }

    @JsonProperty("BenchmarkBondIdentifier")
    public Object getBenchmarkBondIdentifier() {
        return benchmarkBondIdentifier;
    }

    @JsonProperty("BenchmarkBondIdentifier")
    public void setBenchmarkBondIdentifier(Object benchmarkBondIdentifier) {
        this.benchmarkBondIdentifier = benchmarkBondIdentifier;
    }

    @JsonProperty("SeriesOfBond")
    public Object getSeriesOfBond() {
        return seriesOfBond;
    }

    @JsonProperty("SeriesOfBond")
    public void setSeriesOfBond(Object seriesOfBond) {
        this.seriesOfBond = seriesOfBond;
    }

    @JsonProperty("IsCallable")
    public Boolean getIsCallable() {
        return isCallable;
    }

    @JsonProperty("IsCallable")
    public void setIsCallable(Boolean isCallable) {
        this.isCallable = isCallable;
    }

    @JsonProperty("BondCalledIndicator")
    public Boolean getBondCalledIndicator() {
        return bondCalledIndicator;
    }

    @JsonProperty("BondCalledIndicator")
    public void setBondCalledIndicator(Boolean bondCalledIndicator) {
        this.bondCalledIndicator = bondCalledIndicator;
    }

    @JsonProperty("CFICode")
    public Object getCFICode() {
        return cFICode;
    }

    @JsonProperty("CFICode")
    public void setCFICode(Object cFICode) {
        this.cFICode = cFICode;
    }

    @JsonProperty("CalledPrice")
    public Object getCalledPrice() {
        return calledPrice;
    }

    @JsonProperty("CalledPrice")
    public void setCalledPrice(Object calledPrice) {
        this.calledPrice = calledPrice;
    }

    @JsonProperty("IsConvertible")
    public Object getIsConvertible() {
        return isConvertible;
    }

    @JsonProperty("IsConvertible")
    public void setIsConvertible(Object isConvertible) {
        this.isConvertible = isConvertible;
    }

    @JsonProperty("ConvStartDate")
    public Object getConvStartDate() {
        return convStartDate;
    }

    @JsonProperty("ConvStartDate")
    public void setConvStartDate(Object convStartDate) {
        this.convStartDate = convStartDate;
    }

    @JsonProperty("CurrentPercentageAnnuityPayment")
    public Object getCurrentPercentageAnnuityPayment() {
        return currentPercentageAnnuityPayment;
    }

    @JsonProperty("CurrentPercentageAnnuityPayment")
    public void setCurrentPercentageAnnuityPayment(Object currentPercentageAnnuityPayment) {
        this.currentPercentageAnnuityPayment = currentPercentageAnnuityPayment;
    }

    @JsonProperty("IsExchangeable")
    public Boolean getIsExchangeable() {
        return isExchangeable;
    }

    @JsonProperty("IsExchangeable")
    public void setIsExchangeable(Boolean isExchangeable) {
        this.isExchangeable = isExchangeable;
    }

    @JsonProperty("FirstPaymentDate")
    public Object getFirstPaymentDate() {
        return firstPaymentDate;
    }

    @JsonProperty("FirstPaymentDate")
    public void setFirstPaymentDate(Object firstPaymentDate) {
        this.firstPaymentDate = firstPaymentDate;
    }

    @JsonProperty("FixToFloatChangeIndicator")
    public Object getFixToFloatChangeIndicator() {
        return fixToFloatChangeIndicator;
    }

    @JsonProperty("FixToFloatChangeIndicator")
    public void setFixToFloatChangeIndicator(Object fixToFloatChangeIndicator) {
        this.fixToFloatChangeIndicator = fixToFloatChangeIndicator;
    }

    @JsonProperty("InflationLag")
    public Object getInflationLag() {
        return inflationLag;
    }

    @JsonProperty("InflationLag")
    public void setInflationLag(Object inflationLag) {
        this.inflationLag = inflationLag;
    }

    @JsonProperty("InflationLagPeriod")
    public String getInflationLagPeriod() {
        return inflationLagPeriod;
    }

    @JsonProperty("InflationLagPeriod")
    public void setInflationLagPeriod(String inflationLagPeriod) {
        this.inflationLagPeriod = inflationLagPeriod;
    }

    @JsonProperty("IsAssetBackedSecurity")
    public Boolean getIsAssetBackedSecurity() {
        return isAssetBackedSecurity;
    }

    @JsonProperty("IsAssetBackedSecurity")
    public void setIsAssetBackedSecurity(Boolean isAssetBackedSecurity) {
        this.isAssetBackedSecurity = isAssetBackedSecurity;
    }

    @JsonProperty("IsBearerBond")
    public Boolean getIsBearerBond() {
        return isBearerBond;
    }

    @JsonProperty("IsBearerBond")
    public void setIsBearerBond(Boolean isBearerBond) {
        this.isBearerBond = isBearerBond;
    }

    @JsonProperty("IsBrady")
    public Object getIsBrady() {
        return isBrady;
    }

    @JsonProperty("IsBrady")
    public void setIsBrady(Object isBrady) {
        this.isBrady = isBrady;
    }

    @JsonProperty("IsCapitalContingent")
    public Object getIsCapitalContingent() {
        return isCapitalContingent;
    }

    @JsonProperty("IsCapitalContingent")
    public void setIsCapitalContingent(Object isCapitalContingent) {
        this.isCapitalContingent = isCapitalContingent;
    }

    @JsonProperty("CollectiveActionClause")
    public Object getCollectiveActionClause() {
        return collectiveActionClause;
    }

    @JsonProperty("CollectiveActionClause")
    public void setCollectiveActionClause(Object collectiveActionClause) {
        this.collectiveActionClause = collectiveActionClause;
    }

    @JsonProperty("ContingentConversion")
    public Object getContingentConversion() {
        return contingentConversion;
    }

    @JsonProperty("ContingentConversion")
    public void setContingentConversion(Object contingentConversion) {
        this.contingentConversion = contingentConversion;
    }

    @JsonProperty("DirtyCleanIndicator")
    public Object getDirtyCleanIndicator() {
        return dirtyCleanIndicator;
    }

    @JsonProperty("DirtyCleanIndicator")
    public void setDirtyCleanIndicator(Object dirtyCleanIndicator) {
        this.dirtyCleanIndicator = dirtyCleanIndicator;
    }

    @JsonProperty("IsCovered")
    public Object getIsCovered() {
        return isCovered;
    }

    @JsonProperty("IsCovered")
    public void setIsCovered(Object isCovered) {
        this.isCovered = isCovered;
    }

    @JsonProperty("CreditLinkedIndicator")
    public Object getCreditLinkedIndicator() {
        return creditLinkedIndicator;
    }

    @JsonProperty("CreditLinkedIndicator")
    public void setCreditLinkedIndicator(Object creditLinkedIndicator) {
        this.creditLinkedIndicator = creditLinkedIndicator;
    }

    @JsonProperty("IsCurrentGovernmentBond")
    public Object getIsCurrentGovernmentBond() {
        return isCurrentGovernmentBond;
    }

    @JsonProperty("IsCurrentGovernmentBond")
    public void setIsCurrentGovernmentBond(Object isCurrentGovernmentBond) {
        this.isCurrentGovernmentBond = isCurrentGovernmentBond;
    }

    @JsonProperty("DimSumBondIndicator")
    public Object getDimSumBondIndicator() {
        return dimSumBondIndicator;
    }

    @JsonProperty("DimSumBondIndicator")
    public void setDimSumBondIndicator(Object dimSumBondIndicator) {
        this.dimSumBondIndicator = dimSumBondIndicator;
    }

    @JsonProperty("EMTNIndicator")
    public Object getEMTNIndicator() {
        return eMTNIndicator;
    }

    @JsonProperty("EMTNIndicator")
    public void setEMTNIndicator(Object eMTNIndicator) {
        this.eMTNIndicator = eMTNIndicator;
    }

    @JsonProperty("ExtendibleMaturityDateIndicator")
    public Boolean getExtendibleMaturityDateIndicator() {
        return extendibleMaturityDateIndicator;
    }

    @JsonProperty("ExtendibleMaturityDateIndicator")
    public void setExtendibleMaturityDateIndicator(Boolean extendibleMaturityDateIndicator) {
        this.extendibleMaturityDateIndicator = extendibleMaturityDateIndicator;
    }

    @JsonProperty("FormosaIndicator")
    public Object getFormosaIndicator() {
        return formosaIndicator;
    }

    @JsonProperty("FormosaIndicator")
    public void setFormosaIndicator(Object formosaIndicator) {
        this.formosaIndicator = formosaIndicator;
    }

    @JsonProperty("BulletMaturityTypeIndicator")
    public Object getBulletMaturityTypeIndicator() {
        return bulletMaturityTypeIndicator;
    }

    @JsonProperty("BulletMaturityTypeIndicator")
    public void setBulletMaturityTypeIndicator(Object bulletMaturityTypeIndicator) {
        this.bulletMaturityTypeIndicator = bulletMaturityTypeIndicator;
    }

    @JsonProperty("InflationLinkedIndicator")
    public Boolean getInflationLinkedIndicator() {
        return inflationLinkedIndicator;
    }

    @JsonProperty("InflationLinkedIndicator")
    public void setInflationLinkedIndicator(Boolean inflationLinkedIndicator) {
        this.inflationLinkedIndicator = inflationLinkedIndicator;
    }

    @JsonProperty("IsMostSenior")
    public Boolean getIsMostSenior() {
        return isMostSenior;
    }

    @JsonProperty("IsMostSenior")
    public void setIsMostSenior(Boolean isMostSenior) {
        this.isMostSenior = isMostSenior;
    }

    @JsonProperty("MTNIndicator")
    public Object getMTNIndicator() {
        return mTNIndicator;
    }

    @JsonProperty("MTNIndicator")
    public void setMTNIndicator(Object mTNIndicator) {
        this.mTNIndicator = mTNIndicator;
    }

    @JsonProperty("IsRegulationS")
    public Object getIsRegulationS() {
        return isRegulationS;
    }

    @JsonProperty("IsRegulationS")
    public void setIsRegulationS(Object isRegulationS) {
        this.isRegulationS = isRegulationS;
    }

    @JsonProperty("IsResecuritised")
    public Object getIsResecuritised() {
        return isResecuritised;
    }

    @JsonProperty("IsResecuritised")
    public void setIsResecuritised(Object isResecuritised) {
        this.isResecuritised = isResecuritised;
    }

    @JsonProperty("IsSecured")
    public Object getIsSecured() {
        return isSecured;
    }

    @JsonProperty("IsSecured")
    public void setIsSecured(Object isSecured) {
        this.isSecured = isSecured;
    }

    @JsonProperty("IsSecuritised")
    public Object getIsSecuritised() {
        return isSecuritised;
    }

    @JsonProperty("IsSecuritised")
    public void setIsSecuritised(Object isSecuritised) {
        this.isSecuritised = isSecuritised;
    }

    @JsonProperty("IsSenior")
    public Boolean getIsSenior() {
        return isSenior;
    }

    @JsonProperty("IsSenior")
    public void setIsSenior(Boolean isSenior) {
        this.isSenior = isSenior;
    }

    @JsonProperty("IsFlatTraded")
    public Object getIsFlatTraded() {
        return isFlatTraded;
    }

    @JsonProperty("IsFlatTraded")
    public void setIsFlatTraded(Object isFlatTraded) {
        this.isFlatTraded = isFlatTraded;
    }

    @JsonProperty("IsZeroCoupon")
    public Object getIsZeroCoupon() {
        return isZeroCoupon;
    }

    @JsonProperty("IsZeroCoupon")
    public void setIsZeroCoupon(Object isZeroCoupon) {
        this.isZeroCoupon = isZeroCoupon;
    }

    @JsonProperty("LastPayment")
    public Object getLastPayment() {
        return lastPayment;
    }

    @JsonProperty("LastPayment")
    public void setLastPayment(Object lastPayment) {
        this.lastPayment = lastPayment;
    }

    @JsonProperty("BASECPI")
    public Object getBASECPI() {
        return bASECPI;
    }

    @JsonProperty("BASECPI")
    public void setBASECPI(Object bASECPI) {
        this.bASECPI = bASECPI;
    }

    @JsonProperty("PreferredSecurityIndicator")
    public Object getPreferredSecurityIndicator() {
        return preferredSecurityIndicator;
    }

    @JsonProperty("PreferredSecurityIndicator")
    public void setPreferredSecurityIndicator(Object preferredSecurityIndicator) {
        this.preferredSecurityIndicator = preferredSecurityIndicator;
    }

    @JsonProperty("IsPutable")
    public Boolean getIsPutable() {
        return isPutable;
    }

    @JsonProperty("IsPutable")
    public void setIsPutable(Boolean isPutable) {
        this.isPutable = isPutable;
    }

    @JsonProperty("ShortSellLimit")
    public Object getShortSellLimit() {
        return shortSellLimit;
    }

    @JsonProperty("ShortSellLimit")
    public void setShortSellLimit(Object shortSellLimit) {
        this.shortSellLimit = shortSellLimit;
    }

    @JsonProperty("IsSinkable")
    public Boolean getIsSinkable() {
        return isSinkable;
    }

    @JsonProperty("IsSinkable")
    public void setIsSinkable(Boolean isSinkable) {
        this.isSinkable = isSinkable;
    }

    @JsonProperty("IsSLREligible")
    public Object getIsSLREligible() {
        return isSLREligible;
    }

    @JsonProperty("IsSLREligible")
    public void setIsSLREligible(Object isSLREligible) {
        this.isSLREligible = isSLREligible;
    }

    @JsonProperty("StructuredNotesIndicator")
    public Boolean getStructuredNotesIndicator() {
        return structuredNotesIndicator;
    }

    @JsonProperty("StructuredNotesIndicator")
    public void setStructuredNotesIndicator(Boolean structuredNotesIndicator) {
        this.structuredNotesIndicator = structuredNotesIndicator;
    }

    @JsonProperty("IsSubordinated")
    public Object getIsSubordinated() {
        return isSubordinated;
    }

    @JsonProperty("IsSubordinated")
    public void setIsSubordinated(Object isSubordinated) {
        this.isSubordinated = isSubordinated;
    }

    @JsonProperty("UnitTradedIndicator")
    public Boolean getUnitTradedIndicator() {
        return unitTradedIndicator;
    }

    @JsonProperty("UnitTradedIndicator")
    public void setUnitTradedIndicator(Boolean unitTradedIndicator) {
        this.unitTradedIndicator = unitTradedIndicator;
    }

    @JsonProperty("IsUnsecuredObligation")
    public Object getIsUnsecuredObligation() {
        return isUnsecuredObligation;
    }

    @JsonProperty("IsUnsecuredObligation")
    public void setIsUnsecuredObligation(Object isUnsecuredObligation) {
        this.isUnsecuredObligation = isUnsecuredObligation;
    }

    @JsonProperty("ARMWeightedAverageMonthstoPastInitialReset")
    public Object getARMWeightedAverageMonthstoPastInitialReset() {
        return aRMWeightedAverageMonthstoPastInitialReset;
    }

    @JsonProperty("ARMWeightedAverageMonthstoPastInitialReset")
    public void setARMWeightedAverageMonthstoPastInitialReset(Object aRMWeightedAverageMonthstoPastInitialReset) {
        this.aRMWeightedAverageMonthstoPastInitialReset = aRMWeightedAverageMonthstoPastInitialReset;
    }

    @JsonProperty("ARMWeightedAverageMonthstoInitialReset")
    public Object getARMWeightedAverageMonthstoInitialReset() {
        return aRMWeightedAverageMonthstoInitialReset;
    }

    @JsonProperty("ARMWeightedAverageMonthstoInitialReset")
    public void setARMWeightedAverageMonthstoInitialReset(Object aRMWeightedAverageMonthstoInitialReset) {
        this.aRMWeightedAverageMonthstoInitialReset = aRMWeightedAverageMonthstoInitialReset;
    }

    @JsonProperty("PutDaysNotice")
    public Object getPutDaysNotice() {
        return putDaysNotice;
    }

    @JsonProperty("PutDaysNotice")
    public void setPutDaysNotice(Object putDaysNotice) {
        this.putDaysNotice = putDaysNotice;
    }

    @JsonProperty("PutDaysnoticeMultiplier")
    public Object getPutDaysnoticeMultiplier() {
        return putDaysnoticeMultiplier;
    }

    @JsonProperty("PutDaysnoticeMultiplier")
    public void setPutDaysnoticeMultiplier(Object putDaysnoticeMultiplier) {
        this.putDaysnoticeMultiplier = putDaysnoticeMultiplier;
    }

    @JsonProperty("PutDaysNoticeScheme")
    public String getPutDaysNoticeScheme() {
        return putDaysNoticeScheme;
    }

    @JsonProperty("PutDaysNoticeScheme")
    public void setPutDaysNoticeScheme(String putDaysNoticeScheme) {
        this.putDaysNoticeScheme = putDaysNoticeScheme;
    }

    @JsonProperty("PutDaysNoticeType")
    public String getPutDaysNoticeType() {
        return putDaysNoticeType;
    }

    @JsonProperty("PutDaysNoticeType")
    public void setPutDaysNoticeType(String putDaysNoticeType) {
        this.putDaysNoticeType = putDaysNoticeType;
    }

    @JsonProperty("NextPutPrice")
    public Object getNextPutPrice() {
        return nextPutPrice;
    }

    @JsonProperty("NextPutPrice")
    public void setNextPutPrice(Object nextPutPrice) {
        this.nextPutPrice = nextPutPrice;
    }

    @JsonProperty("NextPutDate")
    public Object getNextPutDate() {
        return nextPutDate;
    }

    @JsonProperty("NextPutDate")
    public void setNextPutDate(Object nextPutDate) {
        this.nextPutDate = nextPutDate;
    }

    @JsonProperty("NextCallPrice")
    public Object getNextCallPrice() {
        return nextCallPrice;
    }

    @JsonProperty("NextCallPrice")
    public void setNextCallPrice(Object nextCallPrice) {
        this.nextCallPrice = nextCallPrice;
    }

    @JsonProperty("NextCallDate")
    public Object getNextCallDate() {
        return nextCallDate;
    }

    @JsonProperty("NextCallDate")
    public void setNextCallDate(Object nextCallDate) {
        this.nextCallDate = nextCallDate;
    }

    @JsonProperty("ReconventionDate")
    public Object getReconventionDate() {
        return reconventionDate;
    }

    @JsonProperty("ReconventionDate")
    public void setReconventionDate(Object reconventionDate) {
        this.reconventionDate = reconventionDate;
    }

    @JsonProperty("ConversionPrice")
    public Object getConversionPrice() {
        return conversionPrice;
    }

    @JsonProperty("ConversionPrice")
    public void setConversionPrice(Object conversionPrice) {
        this.conversionPrice = conversionPrice;
    }

    @JsonProperty("ConvertibleUntil")
    public Object getConvertibleUntil() {
        return convertibleUntil;
    }

    @JsonProperty("ConvertibleUntil")
    public void setConvertibleUntil(Object convertibleUntil) {
        this.convertibleUntil = convertibleUntil;
    }

    @JsonProperty("MtgeClassCallDate")
    public Object getMtgeClassCallDate() {
        return mtgeClassCallDate;
    }

    @JsonProperty("MtgeClassCallDate")
    public void setMtgeClassCallDate(Object mtgeClassCallDate) {
        this.mtgeClassCallDate = mtgeClassCallDate;
    }

    @JsonProperty("CalledDate")
    public Object getCalledDate() {
        return calledDate;
    }

    @JsonProperty("CalledDate")
    public void setCalledDate(Object calledDate) {
        this.calledDate = calledDate;
    }

    @JsonProperty("NoticePeriodDayTypeCall")
    public Object getNoticePeriodDayTypeCall() {
        return noticePeriodDayTypeCall;
    }

    @JsonProperty("NoticePeriodDayTypeCall")
    public void setNoticePeriodDayTypeCall(Object noticePeriodDayTypeCall) {
        this.noticePeriodDayTypeCall = noticePeriodDayTypeCall;
    }

    @JsonProperty("CallDaysNotice")
    public Object getCallDaysNotice() {
        return callDaysNotice;
    }

    @JsonProperty("CallDaysNotice")
    public void setCallDaysNotice(Object callDaysNotice) {
        this.callDaysNotice = callDaysNotice;
    }

    @JsonProperty("CallDaysNoticeScheme")
    public String getCallDaysNoticeScheme() {
        return callDaysNoticeScheme;
    }

    @JsonProperty("CallDaysNoticeScheme")
    public void setCallDaysNoticeScheme(String callDaysNoticeScheme) {
        this.callDaysNoticeScheme = callDaysNoticeScheme;
    }

    @JsonProperty("CallDaysNoticeType")
    public String getCallDaysNoticeType() {
        return callDaysNoticeType;
    }

    @JsonProperty("CallDaysNoticeType")
    public void setCallDaysNoticeType(String callDaysNoticeType) {
        this.callDaysNoticeType = callDaysNoticeType;
    }

    @JsonProperty("CallAnnouncementDate")
    public Object getCallAnnouncementDate() {
        return callAnnouncementDate;
    }

    @JsonProperty("CallAnnouncementDate")
    public void setCallAnnouncementDate(Object callAnnouncementDate) {
        this.callAnnouncementDate = callAnnouncementDate;
    }

    @JsonProperty("WeightedAverageMaturity")
    public Object getWeightedAverageMaturity() {
        return weightedAverageMaturity;
    }

    @JsonProperty("WeightedAverageMaturity")
    public void setWeightedAverageMaturity(Object weightedAverageMaturity) {
        this.weightedAverageMaturity = weightedAverageMaturity;
    }

    @JsonProperty("PrepaymentSpeed")
    public Object getPrepaymentSpeed() {
        return prepaymentSpeed;
    }

    @JsonProperty("PrepaymentSpeed")
    public void setPrepaymentSpeed(Object prepaymentSpeed) {
        this.prepaymentSpeed = prepaymentSpeed;
    }

    @JsonProperty("PrepaymentType")
    public Object getPrepaymentType() {
        return prepaymentType;
    }

    @JsonProperty("PrepaymentType")
    public void setPrepaymentType(Object prepaymentType) {
        this.prepaymentType = prepaymentType;
    }

    @JsonProperty("FinalMaturity")
    public String getFinalMaturity() {
        return finalMaturity;
    }

    @JsonProperty("FinalMaturity")
    public void setFinalMaturity(String finalMaturity) {
        this.finalMaturity = finalMaturity;
    }

    @JsonProperty("ResetFrequency")
    public Object getResetFrequency() {
        return resetFrequency;
    }

    @JsonProperty("ResetFrequency")
    public void setResetFrequency(Object resetFrequency) {
        this.resetFrequency = resetFrequency;
    }

    @JsonProperty("AuctionDate")
    public Object getAuctionDate() {
        return auctionDate;
    }

    @JsonProperty("AuctionDate")
    public void setAuctionDate(Object auctionDate) {
        this.auctionDate = auctionDate;
    }

    @JsonProperty("CloEquityTranche")
    public Object getCloEquityTranche() {
        return cloEquityTranche;
    }

    @JsonProperty("CloEquityTranche")
    public void setCloEquityTranche(Object cloEquityTranche) {
        this.cloEquityTranche = cloEquityTranche;
    }

    @JsonProperty("GteCollateralType")
    public Object getGteCollateralType() {
        return gteCollateralType;
    }

    @JsonProperty("GteCollateralType")
    public void setGteCollateralType(Object gteCollateralType) {
        this.gteCollateralType = gteCollateralType;
    }

    @JsonProperty("MtgeDealCallDate")
    public Object getMtgeDealCallDate() {
        return mtgeDealCallDate;
    }

    @JsonProperty("MtgeDealCallDate")
    public void setMtgeDealCallDate(Object mtgeDealCallDate) {
        this.mtgeDealCallDate = mtgeDealCallDate;
    }

    @JsonProperty("WorkoutDateMidToWorst")
    public Object getWorkoutDateMidToWorst() {
        return workoutDateMidToWorst;
    }

    @JsonProperty("WorkoutDateMidToWorst")
    public void setWorkoutDateMidToWorst(Object workoutDateMidToWorst) {
        this.workoutDateMidToWorst = workoutDateMidToWorst;
    }

    @JsonProperty("MtgePrepayType")
    public Object getMtgePrepayType() {
        return mtgePrepayType;
    }

    @JsonProperty("MtgePrepayType")
    public void setMtgePrepayType(Object mtgePrepayType) {
        this.mtgePrepayType = mtgePrepayType;
    }

    @JsonProperty("MtgePrepaySpeed")
    public Object getMtgePrepaySpeed() {
        return mtgePrepaySpeed;
    }

    @JsonProperty("MtgePrepaySpeed")
    public void setMtgePrepaySpeed(Object mtgePrepaySpeed) {
        this.mtgePrepaySpeed = mtgePrepaySpeed;
    }

    @JsonProperty("MtgePrepaySouce")
    public Object getMtgePrepaySouce() {
        return mtgePrepaySouce;
    }

    @JsonProperty("MtgePrepaySouce")
    public void setMtgePrepaySouce(Object mtgePrepaySouce) {
        this.mtgePrepaySouce = mtgePrepaySouce;
    }

    @JsonProperty("MtgePrepaySpeedType")
    public Object getMtgePrepaySpeedType() {
        return mtgePrepaySpeedType;
    }

    @JsonProperty("MtgePrepaySpeedType")
    public void setMtgePrepaySpeedType(Object mtgePrepaySpeedType) {
        this.mtgePrepaySpeedType = mtgePrepaySpeedType;
    }

    @JsonProperty("MtgeEquivalentPsa")
    public Object getMtgeEquivalentPsa() {
        return mtgeEquivalentPsa;
    }

    @JsonProperty("MtgeEquivalentPsa")
    public void setMtgeEquivalentPsa(Object mtgeEquivalentPsa) {
        this.mtgeEquivalentPsa = mtgeEquivalentPsa;
    }

    @JsonProperty("MtgeEquivalentCpr")
    public Object getMtgeEquivalentCpr() {
        return mtgeEquivalentCpr;
    }

    @JsonProperty("MtgeEquivalentCpr")
    public void setMtgeEquivalentCpr(Object mtgeEquivalentCpr) {
        this.mtgeEquivalentCpr = mtgeEquivalentCpr;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("aRMInitialFixedPeriodinMonths", aRMInitialFixedPeriodinMonths).append("bondRecoveryRate", bondRecoveryRate).append("benchmarkBondIdentifier", benchmarkBondIdentifier).append("seriesOfBond", seriesOfBond).append("isCallable", isCallable).append("bondCalledIndicator", bondCalledIndicator).append("cFICode", cFICode).append("calledPrice", calledPrice).append("isConvertible", isConvertible).append("convStartDate", convStartDate).append("currentPercentageAnnuityPayment", currentPercentageAnnuityPayment).append("isExchangeable", isExchangeable).append("firstPaymentDate", firstPaymentDate).append("fixToFloatChangeIndicator", fixToFloatChangeIndicator).append("inflationLag", inflationLag).append("inflationLagPeriod", inflationLagPeriod).append("isAssetBackedSecurity", isAssetBackedSecurity).append("isBearerBond", isBearerBond).append("isBrady", isBrady).append("isCapitalContingent", isCapitalContingent).append("collectiveActionClause", collectiveActionClause).append("contingentConversion", contingentConversion).append("dirtyCleanIndicator", dirtyCleanIndicator).append("isCovered", isCovered).append("creditLinkedIndicator", creditLinkedIndicator).append("isCurrentGovernmentBond", isCurrentGovernmentBond).append("dimSumBondIndicator", dimSumBondIndicator).append("eMTNIndicator", eMTNIndicator).append("extendibleMaturityDateIndicator", extendibleMaturityDateIndicator).append("formosaIndicator", formosaIndicator).append("bulletMaturityTypeIndicator", bulletMaturityTypeIndicator).append("inflationLinkedIndicator", inflationLinkedIndicator).append("isMostSenior", isMostSenior).append("mTNIndicator", mTNIndicator).append("isRegulationS", isRegulationS).append("isResecuritised", isResecuritised).append("isSecured", isSecured).append("isSecuritised", isSecuritised).append("isSenior", isSenior).append("isFlatTraded", isFlatTraded).append("isZeroCoupon", isZeroCoupon).append("lastPayment", lastPayment).append("bASECPI", bASECPI).append("preferredSecurityIndicator", preferredSecurityIndicator).append("isPutable", isPutable).append("shortSellLimit", shortSellLimit).append("isSinkable", isSinkable).append("isSLREligible", isSLREligible).append("structuredNotesIndicator", structuredNotesIndicator).append("isSubordinated", isSubordinated).append("unitTradedIndicator", unitTradedIndicator).append("isUnsecuredObligation", isUnsecuredObligation).append("aRMWeightedAverageMonthstoPastInitialReset", aRMWeightedAverageMonthstoPastInitialReset).append("aRMWeightedAverageMonthstoInitialReset", aRMWeightedAverageMonthstoInitialReset).append("putDaysNotice", putDaysNotice).append("putDaysnoticeMultiplier", putDaysnoticeMultiplier).append("putDaysNoticeScheme", putDaysNoticeScheme).append("putDaysNoticeType", putDaysNoticeType).append("nextPutPrice", nextPutPrice).append("nextPutDate", nextPutDate).append("nextCallPrice", nextCallPrice).append("nextCallDate", nextCallDate).append("reconventionDate", reconventionDate).append("conversionPrice", conversionPrice).append("convertibleUntil", convertibleUntil).append("mtgeClassCallDate", mtgeClassCallDate).append("calledDate", calledDate).append("noticePeriodDayTypeCall", noticePeriodDayTypeCall).append("callDaysNotice", callDaysNotice).append("callDaysNoticeScheme", callDaysNoticeScheme).append("callDaysNoticeType", callDaysNoticeType).append("callAnnouncementDate", callAnnouncementDate).append("weightedAverageMaturity", weightedAverageMaturity).append("prepaymentSpeed", prepaymentSpeed).append("prepaymentType", prepaymentType).append("finalMaturity", finalMaturity).append("resetFrequency", resetFrequency).append("auctionDate", auctionDate).append("cloEquityTranche", cloEquityTranche).append("gteCollateralType", gteCollateralType).append("mtgeDealCallDate", mtgeDealCallDate).append("workoutDateMidToWorst", workoutDateMidToWorst).append("mtgePrepayType", mtgePrepayType).append("mtgePrepaySpeed", mtgePrepaySpeed).append("mtgePrepaySouce", mtgePrepaySouce).append("mtgePrepaySpeedType", mtgePrepaySpeedType).append("mtgeEquivalentPsa", mtgeEquivalentPsa).append("mtgeEquivalentCpr", mtgeEquivalentCpr).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(mtgeEquivalentPsa).append(callDaysNotice).append(callAnnouncementDate).append(mtgeDealCallDate).append(extendibleMaturityDateIndicator).append(isResecuritised).append(isUnsecuredObligation).append(putDaysNoticeType).append(seriesOfBond).append(convStartDate).append(collectiveActionClause).append(isZeroCoupon).append(bASECPI).append(workoutDateMidToWorst).append(cloEquityTranche).append(isConvertible).append(isExchangeable).append(putDaysnoticeMultiplier).append(nextPutDate).append(isCovered).append(eMTNIndicator).append(isSecured).append(mtgeClassCallDate).append(isSinkable).append(calledDate).append(noticePeriodDayTypeCall).append(putDaysNotice).append(nextPutPrice).append(callDaysNoticeType).append(isRegulationS).append(callDaysNoticeScheme).append(preferredSecurityIndicator).append(isBearerBond).append(prepaymentSpeed).append(auctionDate).append(formosaIndicator).append(conversionPrice).append(aRMInitialFixedPeriodinMonths).append(mTNIndicator).append(shortSellLimit).append(nextCallDate).append(mtgeEquivalentCpr).append(isSubordinated).append(additionalProperties).append(isPutable).append(currentPercentageAnnuityPayment).append(finalMaturity).append(unitTradedIndicator).append(bondCalledIndicator).append(mtgePrepaySpeedType).append(benchmarkBondIdentifier).append(resetFrequency).append(firstPaymentDate).append(contingentConversion).append(isSecuritised).append(convertibleUntil).append(weightedAverageMaturity).append(dirtyCleanIndicator).append(isCapitalContingent).append(cFICode).append(gteCollateralType).append(dimSumBondIndicator).append(isSenior).append(putDaysNoticeScheme).append(bondRecoveryRate).append(isBrady).append(isFlatTraded).append(isSLREligible).append(inflationLinkedIndicator).append(structuredNotesIndicator).append(inflationLagPeriod).append(isMostSenior).append(inflationLag).append(isAssetBackedSecurity).append(isCallable).append(mtgePrepayType).append(mtgePrepaySouce).append(calledPrice).append(isCurrentGovernmentBond).append(aRMWeightedAverageMonthstoInitialReset).append(reconventionDate).append(bulletMaturityTypeIndicator).append(aRMWeightedAverageMonthstoPastInitialReset).append(lastPayment).append(nextCallPrice).append(prepaymentType).append(creditLinkedIndicator).append(mtgePrepaySpeed).append(fixToFloatChangeIndicator).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Bond) == false) {
            return false;
        }
        Bond rhs = ((Bond) other);
        return new EqualsBuilder().append(mtgeEquivalentPsa, rhs.mtgeEquivalentPsa).append(callDaysNotice, rhs.callDaysNotice).append(callAnnouncementDate, rhs.callAnnouncementDate).append(mtgeDealCallDate, rhs.mtgeDealCallDate).append(extendibleMaturityDateIndicator, rhs.extendibleMaturityDateIndicator).append(isResecuritised, rhs.isResecuritised).append(isUnsecuredObligation, rhs.isUnsecuredObligation).append(putDaysNoticeType, rhs.putDaysNoticeType).append(seriesOfBond, rhs.seriesOfBond).append(convStartDate, rhs.convStartDate).append(collectiveActionClause, rhs.collectiveActionClause).append(isZeroCoupon, rhs.isZeroCoupon).append(bASECPI, rhs.bASECPI).append(workoutDateMidToWorst, rhs.workoutDateMidToWorst).append(cloEquityTranche, rhs.cloEquityTranche).append(isConvertible, rhs.isConvertible).append(isExchangeable, rhs.isExchangeable).append(putDaysnoticeMultiplier, rhs.putDaysnoticeMultiplier).append(nextPutDate, rhs.nextPutDate).append(isCovered, rhs.isCovered).append(eMTNIndicator, rhs.eMTNIndicator).append(isSecured, rhs.isSecured).append(mtgeClassCallDate, rhs.mtgeClassCallDate).append(isSinkable, rhs.isSinkable).append(calledDate, rhs.calledDate).append(noticePeriodDayTypeCall, rhs.noticePeriodDayTypeCall).append(putDaysNotice, rhs.putDaysNotice).append(nextPutPrice, rhs.nextPutPrice).append(callDaysNoticeType, rhs.callDaysNoticeType).append(isRegulationS, rhs.isRegulationS).append(callDaysNoticeScheme, rhs.callDaysNoticeScheme).append(preferredSecurityIndicator, rhs.preferredSecurityIndicator).append(isBearerBond, rhs.isBearerBond).append(prepaymentSpeed, rhs.prepaymentSpeed).append(auctionDate, rhs.auctionDate).append(formosaIndicator, rhs.formosaIndicator).append(conversionPrice, rhs.conversionPrice).append(aRMInitialFixedPeriodinMonths, rhs.aRMInitialFixedPeriodinMonths).append(mTNIndicator, rhs.mTNIndicator).append(shortSellLimit, rhs.shortSellLimit).append(nextCallDate, rhs.nextCallDate).append(mtgeEquivalentCpr, rhs.mtgeEquivalentCpr).append(isSubordinated, rhs.isSubordinated).append(additionalProperties, rhs.additionalProperties).append(isPutable, rhs.isPutable).append(currentPercentageAnnuityPayment, rhs.currentPercentageAnnuityPayment).append(finalMaturity, rhs.finalMaturity).append(unitTradedIndicator, rhs.unitTradedIndicator).append(bondCalledIndicator, rhs.bondCalledIndicator).append(mtgePrepaySpeedType, rhs.mtgePrepaySpeedType).append(benchmarkBondIdentifier, rhs.benchmarkBondIdentifier).append(resetFrequency, rhs.resetFrequency).append(firstPaymentDate, rhs.firstPaymentDate).append(contingentConversion, rhs.contingentConversion).append(isSecuritised, rhs.isSecuritised).append(convertibleUntil, rhs.convertibleUntil).append(weightedAverageMaturity, rhs.weightedAverageMaturity).append(dirtyCleanIndicator, rhs.dirtyCleanIndicator).append(isCapitalContingent, rhs.isCapitalContingent).append(cFICode, rhs.cFICode).append(gteCollateralType, rhs.gteCollateralType).append(dimSumBondIndicator, rhs.dimSumBondIndicator).append(isSenior, rhs.isSenior).append(putDaysNoticeScheme, rhs.putDaysNoticeScheme).append(bondRecoveryRate, rhs.bondRecoveryRate).append(isBrady, rhs.isBrady).append(isFlatTraded, rhs.isFlatTraded).append(isSLREligible, rhs.isSLREligible).append(inflationLinkedIndicator, rhs.inflationLinkedIndicator).append(structuredNotesIndicator, rhs.structuredNotesIndicator).append(inflationLagPeriod, rhs.inflationLagPeriod).append(isMostSenior, rhs.isMostSenior).append(inflationLag, rhs.inflationLag).append(isAssetBackedSecurity, rhs.isAssetBackedSecurity).append(isCallable, rhs.isCallable).append(mtgePrepayType, rhs.mtgePrepayType).append(mtgePrepaySouce, rhs.mtgePrepaySouce).append(calledPrice, rhs.calledPrice).append(isCurrentGovernmentBond, rhs.isCurrentGovernmentBond).append(aRMWeightedAverageMonthstoInitialReset, rhs.aRMWeightedAverageMonthstoInitialReset).append(reconventionDate, rhs.reconventionDate).append(bulletMaturityTypeIndicator, rhs.bulletMaturityTypeIndicator).append(aRMWeightedAverageMonthstoPastInitialReset, rhs.aRMWeightedAverageMonthstoPastInitialReset).append(lastPayment, rhs.lastPayment).append(nextCallPrice, rhs.nextCallPrice).append(prepaymentType, rhs.prepaymentType).append(creditLinkedIndicator, rhs.creditLinkedIndicator).append(mtgePrepaySpeed, rhs.mtgePrepaySpeed).append(fixToFloatChangeIndicator, rhs.fixToFloatChangeIndicator).isEquals();
    }

}
