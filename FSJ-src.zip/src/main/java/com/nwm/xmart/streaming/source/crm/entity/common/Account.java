package com.nwm.xmart.streaming.source.crm.entity.common;

import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "External_Account_Number" })
public class Account implements Serializable {
    private static final long serialVersionUID = 3010948626329314976L;

    @JsonProperty("External_Account_Number")
    private String externalAccountNumber;

    @JsonProperty("External_Account_Number")
    public String getExternalAccountNumber() {
        return externalAccountNumber;
    }

    @JsonProperty("External_Account_Number")
    public void setExternalAccountNumber(String externalAccountNumber) {
        this.externalAccountNumber = externalAccountNumber;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Account{");
        sb.append("externalAccountNumber='").append(externalAccountNumber).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
