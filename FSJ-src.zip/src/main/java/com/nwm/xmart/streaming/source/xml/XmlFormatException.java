package com.nwm.xmart.streaming.source.xml;

/**
 * Created by gardlex on 18/10/2018.
 */
public class XmlFormatException extends Exception {

    public XmlFormatException() {
        super();
    }

    public XmlFormatException(String msg) {
        super(msg);
    }

    public XmlFormatException(String msg, Throwable t) {
        super(msg, t);
    }
}
