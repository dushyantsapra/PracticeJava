package com.nwm.xmart.streaming.source.kdb.sorting;

import com.nwm.xmart.streaming.source.kdb.event.KDBSourceEvent;

import java.util.Comparator;

/**
 * Compares the date+time of two {@link DateTimeSortKey}'s. The date+time values are converted
 * to a long timestamp (EpochMilli) and ordered in ascending order.
 *
 * Created by gardlex on 09/04/2018.
 */
public class DateTimeComparator implements Comparator<KDBSourceEvent> {
    @Override
    public int compare(KDBSourceEvent o1, KDBSourceEvent o2) {
        return Long.compare((long)o1.getKDBSortKey().getSortKeyValue(), (long)o2.getKDBSortKey().getSortKeyValue());
    }
}
