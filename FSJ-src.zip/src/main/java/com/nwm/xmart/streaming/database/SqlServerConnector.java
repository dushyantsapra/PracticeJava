package com.nwm.xmart.streaming.database;

import com.microsoft.sqlserver.jdbc.SQLServerConnection;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import com.nwm.xmart.streaming.database.exceptions.SqlServerConnectorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;

public class SqlServerConnector {

    @SuppressWarnings("unused")
    private static final long serialVersionUID = -9138275687038624138L;
    private static final Logger logger = LoggerFactory.getLogger(SqlServerConnector.class);

    private final SqlServerConnectionDetails connectionDetails;

    public SqlServerConnector(SqlServerConnectionDetails connectionDetails) {
        this.connectionDetails = connectionDetails;
    }

    public SQLServerConnection getConnection() throws SqlServerConnectorException {

        logger.debug("Entering getConnection");

        SQLServerConnection connection = null;

        int retryCounter = 0;
        boolean isComplete = false;

        while (!isComplete && retryCounter < connectionDetails.getRetryLimit()) {

            if (logger.isDebugEnabled()) {
                logger.debug("Attempt {} to connect to SQL Server: {}", retryCounter + 1, connectionDetails.getURL());
            }

            try {

                connection = (SQLServerConnection) connectionDetails.getDataSource().getConnection();

                if (checkConnection(connection)) {
                    isComplete = true;
                } else {
                    logger.info("Invalid connection returned by SQL Data Source");
                }
            } catch (SQLServerException e) {
                logger.error("Error getting SQL Server connection:", e);
            }

            if (!isComplete) {

                retryCounter++;

                try {

                    Thread.sleep(connectionDetails.getRetryPeriod());
                } catch (InterruptedException ie) {

                    logger.error("Interrupt before retrying SQL Server connection:", ie);
                    Thread.currentThread().interrupt();

                    isComplete = true;
                }
            }
        }

        if (!isComplete) {
            throw new SqlServerConnectorException("SQL Server connection attempts exceeded retry limit.");
        }

        return connection;
    }

    public boolean checkConnection(SQLServerConnection connection) {

        logger.debug("Entering checkConnection() " + connection);


        if (connection == null) {
            logger.error("SQL Server connection is invalid (null).");
            return false;
        }

        Boolean isValid = false;
        try {
            if (connection.isValid(connectionDetails.getTimeoutSec())) {
                logger.debug("SQL Server connection is valid: {}", connection.toString());
                isValid = true;
            } else {
                logger.error("SQL Server connection is invalid.");
            }
        } catch (SQLException e) {
            logger.error("SQL Exception checking connection:", e);
        } finally {
            if (!isValid) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    logger.error("SQL Exception checking connection:", e);
                }
            }
        }

        return isValid;
    }
}
