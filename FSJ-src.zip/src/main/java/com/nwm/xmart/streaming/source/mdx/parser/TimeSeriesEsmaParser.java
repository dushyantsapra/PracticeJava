package com.nwm.xmart.streaming.source.mdx.parser;

import com.nwm.xmart.streaming.source.mdx.entity.TimeSeriesEsma;
import rbs.gbm.mdx.webService.impl.MdxTimePointContent;

import java.math.BigDecimal;

public class TimeSeriesEsmaParser {

    public static TimeSeriesEsma buildTimeSeriesEsma(String identifier, MdxTimePointContent mdxTimePointContent) {
        TimeSeriesEsma timeSeriesEsma = new TimeSeriesEsma("", "", "", mdxTimePointContent.getVersion(),
                mdxTimePointContent.getWriteTime(), null, mdxTimePointContent.getWriteTime().toString());
        String identifiers[] = identifier.split("/");

        timeSeriesEsma.setInstrumentName(identifiers[4]);
        timeSeriesEsma.setValue(new BigDecimal(mdxTimePointContent.getValue()));
        timeSeriesEsma.setTradingVenues(mdxTimePointContent.getMetadata().get("TradingVenues"));
        timeSeriesEsma.setFirstTradeDate(mdxTimePointContent.getMetadata().get("FirstTradeDate"));
        timeSeriesEsma.setIssuer(mdxTimePointContent.getMetadata().get("Issuer"));
        return timeSeriesEsma;
    }
}
