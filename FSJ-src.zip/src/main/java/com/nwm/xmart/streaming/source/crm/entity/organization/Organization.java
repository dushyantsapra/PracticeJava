package com.nwm.xmart.streaming.source.crm.entity.organization;

import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(
        { "CreatedById", "CreatedDate", "External_ID", "Id", "LastModifiedById", "LastModifiedDate", "Name", "OwnerId",
          "Private_Side", "RecordType", "Role_Id", "SharingTeam_Group", "Short_Name", "SystemModstamp", "Description",
          "Is_Top", "Parent", "Type", "Members" })
public class Organization implements Serializable {
    private static final long serialVersionUID = 4203396443891156408L;

    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("External_ID")
    private String externalID;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("OwnerId")
    private String ownerId;
    @JsonProperty("Private_Side")
    private Boolean privateSide;
    @JsonProperty("RecordType")
    private RecordType recordType;
    @JsonProperty("Role_Id")
    private String roleId;
    @JsonProperty("SharingTeam_Group")
    private String sharingTeamGroup;
    @JsonProperty("Short_Name")
    private String shortName;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("Description")
    private String description;
    @JsonProperty("Is_Top")
    private Boolean isTop;
    @JsonProperty("Parent")
    private String parent;
    @JsonProperty("Type")
    private String type;
    @JsonProperty("Members")
    private List<Member> members = null;

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("External_ID")
    public String getExternalID() {
        return externalID;
    }

    @JsonProperty("External_ID")
    public void setExternalID(String externalID) {
        this.externalID = externalID;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("OwnerId")
    public String getOwnerId() {
        return ownerId;
    }

    @JsonProperty("OwnerId")
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    @JsonProperty("Private_Side")
    public Boolean getPrivateSide() {
        return privateSide;
    }

    @JsonProperty("Private_Side")
    public void setPrivateSide(Boolean privateSide) {
        this.privateSide = privateSide;
    }

    @JsonProperty("RecordType")
    public RecordType getRecordType() {
        return recordType;
    }

    @JsonProperty("RecordType")
    public void setRecordType(RecordType recordType) {
        this.recordType = recordType;
    }

    @JsonProperty("Role_Id")
    public String getRoleId() {
        return roleId;
    }

    @JsonProperty("Role_Id")
    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    @JsonProperty("SharingTeam_Group")
    public String getSharingTeamGroup() {
        return sharingTeamGroup;
    }

    @JsonProperty("SharingTeam_Group")
    public void setSharingTeamGroup(String sharingTeamGroup) {
        this.sharingTeamGroup = sharingTeamGroup;
    }

    @JsonProperty("Short_Name")
    public String getShortName() {
        return shortName;
    }

    @JsonProperty("Short_Name")
    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("Description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("Description")
    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty("Is_Top")
    public Boolean getIsTop() {
        return isTop;
    }

    @JsonProperty("Is_Top")
    public void setIsTop(Boolean isTop) {
        this.isTop = isTop;
    }

    @JsonProperty("Parent")
    public String getParent() {
        return parent;
    }

    @JsonProperty("Parent")
    public void setParent(String parent) {
        this.parent = parent;
    }

    @JsonProperty("Type")
    public String getType() {
        return type;
    }

    @JsonProperty("Type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("Members")
    public List<Member> getMembers() {
        return members;
    }

    @JsonProperty("Members")
    public void setMembers(List<Member> members) {
        this.members = members;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Organization{");
        sb.append("createdById='").append(createdById).append('\'');
        sb.append(", createdDate='").append(createdDate).append('\'');
        sb.append(", externalID='").append(externalID).append('\'');
        sb.append(", id='").append(id).append('\'');
        sb.append(", lastModifiedById='").append(lastModifiedById).append('\'');
        sb.append(", lastModifiedDate='").append(lastModifiedDate).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", ownerId='").append(ownerId).append('\'');
        sb.append(", privateSide=").append(privateSide);
        sb.append(", recordType=").append(recordType);
        sb.append(", roleId='").append(roleId).append('\'');
        sb.append(", sharingTeamGroup='").append(sharingTeamGroup).append('\'');
        sb.append(", shortName='").append(shortName).append('\'');
        sb.append(", systemModstamp='").append(systemModstamp).append('\'');
        sb.append(", description='").append(description).append('\'');
        sb.append(", isTop=").append(isTop);
        sb.append(", parent='").append(parent).append('\'');
        sb.append(", type='").append(type).append('\'');
        sb.append(", members=").append(members);
        sb.append('}');
        return sb.toString();
    }
}
