package com.nwm.xmart.streaming.database.exceptions;

/**
 * Created by gardlex on 15/11/2017.
 */
public class SqlServerConnectorException extends Exception {

    public SqlServerConnectorException() {
        super();
    }

    public SqlServerConnectorException(String msg) {
        super(msg);
    }

    public SqlServerConnectorException(String msg, Throwable t) {
        super(msg, t);
    }
}
