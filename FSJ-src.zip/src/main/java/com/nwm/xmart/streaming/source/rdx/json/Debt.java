
package com.nwm.xmart.streaming.source.rdx.json;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CollateralType",
    "RatingProvisionIndicator",
    "CouponFixedtoVariableIndicator",
    "SpreadtoTreasuryIssue",
    "MinimumIncrement",
    "ParAmount",
    "WeightedAverageOriginalcoupon",
    "PoolWAL",
    "MtgeWALCalled",
    "AmountStripped",
    "TotalIssue",
    "AmountUnstripped",
    "USBondOnTheRunIndicator",
    "SpreadCurveIdentifier",
    "WeightedAverageLifeAsofAssurance",
    "BillsIndicator"
})
public class Debt {

    @JsonProperty("CollateralType")
    private String collateralType;
    @JsonProperty("RatingProvisionIndicator")
    private Boolean ratingProvisionIndicator;
    @JsonProperty("CouponFixedtoVariableIndicator")
    private Boolean couponFixedtoVariableIndicator;
    @JsonProperty("SpreadtoTreasuryIssue")
    private Object spreadtoTreasuryIssue;
    @JsonProperty("MinimumIncrement")
    private Double minimumIncrement;
    @JsonProperty("ParAmount")
    private Double parAmount;
    @JsonProperty("WeightedAverageOriginalcoupon")
    private Object weightedAverageOriginalcoupon;
    @JsonProperty("PoolWAL")
    private Object poolWAL;
    @JsonProperty("MtgeWALCalled")
    private Object mtgeWALCalled;
    @JsonProperty("AmountStripped")
    private Object amountStripped;
    @JsonProperty("TotalIssue")
    private Double totalIssue;
    @JsonProperty("AmountUnstripped")
    private Object amountUnstripped;
    @JsonProperty("USBondOnTheRunIndicator")
    private Integer uSBondOnTheRunIndicator;
    @JsonProperty("SpreadCurveIdentifier")
    private Object spreadCurveIdentifier;
    @JsonProperty("WeightedAverageLifeAsofAssurance")
    private Object weightedAverageLifeAsofAssurance;
    @JsonProperty("BillsIndicator")
    private Object billsIndicator;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("CollateralType")
    public String getCollateralType() {
        return collateralType;
    }

    @JsonProperty("CollateralType")
    public void setCollateralType(String collateralType) {
        this.collateralType = collateralType;
    }

    @JsonProperty("RatingProvisionIndicator")
    public Boolean getRatingProvisionIndicator() {
        return ratingProvisionIndicator;
    }

    @JsonProperty("RatingProvisionIndicator")
    public void setRatingProvisionIndicator(Boolean ratingProvisionIndicator) {
        this.ratingProvisionIndicator = ratingProvisionIndicator;
    }

    @JsonProperty("CouponFixedtoVariableIndicator")
    public Boolean getCouponFixedtoVariableIndicator() {
        return couponFixedtoVariableIndicator;
    }

    @JsonProperty("CouponFixedtoVariableIndicator")
    public void setCouponFixedtoVariableIndicator(Boolean couponFixedtoVariableIndicator) {
        this.couponFixedtoVariableIndicator = couponFixedtoVariableIndicator;
    }

    @JsonProperty("SpreadtoTreasuryIssue")
    public Object getSpreadtoTreasuryIssue() {
        return spreadtoTreasuryIssue;
    }

    @JsonProperty("SpreadtoTreasuryIssue")
    public void setSpreadtoTreasuryIssue(Object spreadtoTreasuryIssue) {
        this.spreadtoTreasuryIssue = spreadtoTreasuryIssue;
    }

    @JsonProperty("MinimumIncrement")
    public Double getMinimumIncrement() {
        return minimumIncrement;
    }

    @JsonProperty("MinimumIncrement")
    public void setMinimumIncrement(Double minimumIncrement) {
        this.minimumIncrement = minimumIncrement;
    }

    @JsonProperty("ParAmount")
    public Double getParAmount() {
        return parAmount;
    }

    @JsonProperty("ParAmount")
    public void setParAmount(Double parAmount) {
        this.parAmount = parAmount;
    }

    @JsonProperty("WeightedAverageOriginalcoupon")
    public Object getWeightedAverageOriginalcoupon() {
        return weightedAverageOriginalcoupon;
    }

    @JsonProperty("WeightedAverageOriginalcoupon")
    public void setWeightedAverageOriginalcoupon(Object weightedAverageOriginalcoupon) {
        this.weightedAverageOriginalcoupon = weightedAverageOriginalcoupon;
    }

    @JsonProperty("PoolWAL")
    public Object getPoolWAL() {
        return poolWAL;
    }

    @JsonProperty("PoolWAL")
    public void setPoolWAL(Object poolWAL) {
        this.poolWAL = poolWAL;
    }

    @JsonProperty("MtgeWALCalled")
    public Object getMtgeWALCalled() {
        return mtgeWALCalled;
    }

    @JsonProperty("MtgeWALCalled")
    public void setMtgeWALCalled(Object mtgeWALCalled) {
        this.mtgeWALCalled = mtgeWALCalled;
    }

    @JsonProperty("AmountStripped")
    public Object getAmountStripped() {
        return amountStripped;
    }

    @JsonProperty("AmountStripped")
    public void setAmountStripped(Object amountStripped) {
        this.amountStripped = amountStripped;
    }

    @JsonProperty("TotalIssue")
    public Double getTotalIssue() {
        return totalIssue;
    }

    @JsonProperty("TotalIssue")
    public void setTotalIssue(Double totalIssue) {
        this.totalIssue = totalIssue;
    }

    @JsonProperty("AmountUnstripped")
    public Object getAmountUnstripped() {
        return amountUnstripped;
    }

    @JsonProperty("AmountUnstripped")
    public void setAmountUnstripped(Object amountUnstripped) {
        this.amountUnstripped = amountUnstripped;
    }

    @JsonProperty("USBondOnTheRunIndicator")
    public Integer getUSBondOnTheRunIndicator() {
        return uSBondOnTheRunIndicator;
    }

    @JsonProperty("USBondOnTheRunIndicator")
    public void setUSBondOnTheRunIndicator(Integer uSBondOnTheRunIndicator) {
        this.uSBondOnTheRunIndicator = uSBondOnTheRunIndicator;
    }

    @JsonProperty("SpreadCurveIdentifier")
    public Object getSpreadCurveIdentifier() {
        return spreadCurveIdentifier;
    }

    @JsonProperty("SpreadCurveIdentifier")
    public void setSpreadCurveIdentifier(Object spreadCurveIdentifier) {
        this.spreadCurveIdentifier = spreadCurveIdentifier;
    }

    @JsonProperty("WeightedAverageLifeAsofAssurance")
    public Object getWeightedAverageLifeAsofAssurance() {
        return weightedAverageLifeAsofAssurance;
    }

    @JsonProperty("WeightedAverageLifeAsofAssurance")
    public void setWeightedAverageLifeAsofAssurance(Object weightedAverageLifeAsofAssurance) {
        this.weightedAverageLifeAsofAssurance = weightedAverageLifeAsofAssurance;
    }

    @JsonProperty("BillsIndicator")
    public Object getBillsIndicator() {
        return billsIndicator;
    }

    @JsonProperty("BillsIndicator")
    public void setBillsIndicator(Object billsIndicator) {
        this.billsIndicator = billsIndicator;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("collateralType", collateralType).append("ratingProvisionIndicator", ratingProvisionIndicator).append("couponFixedtoVariableIndicator", couponFixedtoVariableIndicator).append("spreadtoTreasuryIssue", spreadtoTreasuryIssue).append("minimumIncrement", minimumIncrement).append("parAmount", parAmount).append("weightedAverageOriginalcoupon", weightedAverageOriginalcoupon).append("poolWAL", poolWAL).append("mtgeWALCalled", mtgeWALCalled).append("amountStripped", amountStripped).append("totalIssue", totalIssue).append("amountUnstripped", amountUnstripped).append("uSBondOnTheRunIndicator", uSBondOnTheRunIndicator).append("spreadCurveIdentifier", spreadCurveIdentifier).append("weightedAverageLifeAsofAssurance", weightedAverageLifeAsofAssurance).append("billsIndicator", billsIndicator).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(uSBondOnTheRunIndicator).append(spreadtoTreasuryIssue).append(collateralType).append(ratingProvisionIndicator).append(amountStripped).append(spreadCurveIdentifier).append(weightedAverageLifeAsofAssurance).append(couponFixedtoVariableIndicator).append(minimumIncrement).append(totalIssue).append(weightedAverageOriginalcoupon).append(parAmount).append(billsIndicator).append(poolWAL).append(amountUnstripped).append(mtgeWALCalled).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Debt) == false) {
            return false;
        }
        Debt rhs = ((Debt) other);
        return new EqualsBuilder().append(uSBondOnTheRunIndicator, rhs.uSBondOnTheRunIndicator).append(spreadtoTreasuryIssue, rhs.spreadtoTreasuryIssue).append(collateralType, rhs.collateralType).append(ratingProvisionIndicator, rhs.ratingProvisionIndicator).append(amountStripped, rhs.amountStripped).append(spreadCurveIdentifier, rhs.spreadCurveIdentifier).append(weightedAverageLifeAsofAssurance, rhs.weightedAverageLifeAsofAssurance).append(couponFixedtoVariableIndicator, rhs.couponFixedtoVariableIndicator).append(minimumIncrement, rhs.minimumIncrement).append(totalIssue, rhs.totalIssue).append(weightedAverageOriginalcoupon, rhs.weightedAverageOriginalcoupon).append(parAmount, rhs.parAmount).append(billsIndicator, rhs.billsIndicator).append(poolWAL, rhs.poolWAL).append(amountUnstripped, rhs.amountUnstripped).append(mtgeWALCalled, rhs.mtgeWALCalled).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
