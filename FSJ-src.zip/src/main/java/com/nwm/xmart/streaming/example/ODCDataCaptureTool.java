package com.nwm.xmart.streaming.example;

import com.nwm.xmart.sso.EncryptDecryptAES;
import com.nwm.xmart.streaming.common.job.StreamJob;
import com.nwm.xmart.streaming.monitor.GeneosPersistenceFile;
import com.nwm.xmart.streaming.monitor.InactiveKafkaMonitor;
import com.nwm.xmart.streaming.monitor.InactivityMonitor;
import com.nwm.xmart.streaming.source.df.DataFabricFlinkKafkaSource;
import com.nwm.xmart.streaming.source.df.KafkaProperties;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.nwm.xmart.streaming.source.df.serialisation.FlinkDeserializer;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import com.rbs.datafabric.client.DataFabricClient;
import com.rbs.datafabric.client.DataFabricClientFactory;
import com.rbs.datafabric.common.serialization.DataFabricSerializer;
import com.rbs.datafabric.domain.ClientConfiguration;
import com.rbs.datafabric.domain.Credentials;
import com.rbs.datafabric.domain.Document;
import com.rbs.odc.core.domain.ODCValue;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.flink.streaming.util.serialization.KeyedDeserializationSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Created by gardlex on 18/10/2017.
 */
public class ODCDataCaptureTool {

    private static Logger logger = LoggerFactory.getLogger(ODCDataCaptureTool.class);

    public static void main(String[] args) throws Exception {

        // Populate cache with 10 stream events
        ODCDataCaptureTool t = new ODCDataCaptureTool();
        t.buildStream(args);

    }

    public void buildStream(String[] args) throws Exception {
        // StreamJob implementation can override any abstract methid as long as it calls super() first
        ODCDataCaptureTool.KafkaTestStreamJob streamJob = new ODCDataCaptureTool.KafkaTestStreamJob();
        streamJob.run(args);
    }

    public DataFabricClient getDataFabricClient() throws Exception {
        // TST
        ClientConfiguration clientConfiguration = new ClientConfiguration().withCredentials(new Credentials().withUsername("svc-XMartAppUat")
                .withPassword(EncryptDecryptAES.decrypt("FH+VI380zghSFhzIcvbC9A==")))
                .withHost("DATAFABRIC-TST")
                .withAccessToken(EncryptDecryptAES.decrypt("9k1IyB07YGjc1r5rQf1MgrdZH6XNdr1WT0UEWLz1XmVX7tupKZdtPA2t/iljneNe"));
        // DEV
//        ClientConfiguration clientConfiguration = new ClientConfiguration().withCredentials(new Credentials().withUsername("svc-XMartAppDev")
//                .withPassword(EncryptDecryptAES.decrypt("FH+VI380zghSFhzIcvbC9A==")))
//                .withHost("datafabric-dev")
//                .withAccessToken(EncryptDecryptAES.decrypt("9k1IyB07YGjc1r5rQf1MgrdZH6XNdr1WT0UEWLz1XmVX7tupKZdtPA2t/iljneNe"));

        DataFabricClient dataFabricClient = DataFabricClientFactory.createDataFabricClient(clientConfiguration);
        return dataFabricClient;
    }

    class KafkaTestStreamJob extends StreamJob {

        @Override
        protected void configureAndExecuteStream(StreamExecutionEnvironment env) {

            try {

                DataFabricUtil dataFabricUtil = new DataFabricUtil(configuration);

                // Type info reqd for the FlinkDeserializer
            final TypeInformation<DataFabricStreamEvent<ODCValue>> info = TypeInformation.of(new TypeHint<DataFabricStreamEvent<ODCValue>>(){});
            Class<DataFabricStreamEvent<ODCValue>> sourceClassRef = info.getTypeClass();

            // Crate the DataFabricSource
            DataFabricFlinkKafkaSource flinkKafkaSource = getSource(configuration, dataFabricUtil, sourceClassRef);

            // Configuration of the stream
            DataStream<DataFabricStreamEvent<ODCValue>> input = env
                    .addSource(flinkKafkaSource, info)
                    .uid(configuration.getString("operator.trade.source.name",""))
                    .name(configuration.getString("operator.trade.source.name", ""))
                    .setParallelism(1);
            input.addSink(new TestSink(dataFabricUtil))
                    .uid(configuration.getString("operator.datafabric.sink.name",""))
                    .name(configuration.getString("operator.datafabric.sink.name",""))
                    .setParallelism(1);
            env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);


                String execPlan = env.getExecutionPlan();
                logger.info("EXECUTION PLAN = " + execPlan);
                env.execute(configuration.getString("flink.job.name",""));
            } catch (Exception e) {
                logger.error("Exception running the ExampleODCFlinkJob",e);
                throw new RuntimeException(e);
            }
        }
    }

    private static DataFabricFlinkKafkaSource getSource(Configuration configuration, DataFabricUtil dataFabricUtil, Class<DataFabricStreamEvent<ODCValue>> sourceClassRef) {

        InactivityMonitor inactivityMonitor = new InactiveKafkaMonitor(configuration, new GeneosPersistenceFile(configuration));

        // The deserializer itself
        KeyedDeserializationSchema<DataFabricStreamEvent<ODCValue>> deserialiser =
                new FlinkDeserializer<DataFabricStreamEvent<ODCValue>, ODCValue, Document>(
                        dataFabricUtil,
                        sourceClassRef,
                        ODCValue.class,
                        inactivityMonitor,
                        configuration);
        DataFabricFlinkKafkaSource sourceFunction = new DataFabricFlinkKafkaSource<DataFabricStreamEvent<ODCValue>>(dataFabricUtil, configuration, new KafkaProperties(configuration), deserialiser);

        return sourceFunction;
    }


    class TestSink extends RichSinkFunction<DataFabricStreamEvent<ODCValue>> implements CheckpointListener {

        private Logger logger = LoggerFactory.getLogger(TestSink.class);

        private DataFabricClient sinkDataFabricClient;
        private DataFabricSerializer sinkDataFabricSerializer;
        private final String sinkDATABASE = "session-db";
        private final String sinkCOLLECTION = "session-kafka-offset-del-sink";
        private final DataFabricUtil dataFabricUtil;
        private int ctr;

        public TestSink(DataFabricUtil dataFabricUtil) throws IOException {
            this.dataFabricUtil = dataFabricUtil;
        }

        @Override
        public void notifyCheckpointComplete(long checkpointId) throws Exception {
            logger.info("Checkpoint RECD = " + checkpointId);
        }

        @Override
        public void invoke(DataFabricStreamEvent<ODCValue> testStreamErrorEvent) throws Exception {

            ODCValue odcValue = testStreamErrorEvent.getEventPayload();
            ctr++;
            try {
                // File to serialize object to
                String fileName = "C:\\DEV\\odcdata\\ODCTrade-3.8.25-" + testStreamErrorEvent.getStreamPosition() + ".ser";
                FileOutputStream fos = new FileOutputStream(fileName);
                SerializationUtils.serialize(odcValue, fos);
                fos.flush();
                fos.close();
//                FileInputStream fis = new FileInputStream(fileName);
//                ODCValue ser = (ODCValue) SerializationUtils.deserialize(fis);
//                if (!odcValue.equals(ser)) {
//                    throw new RuntimeException("NOT EQUAL");
//                }
//                fis.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (ctr > 100) {
                this.close();
            }
        }

        @Override
        public void open(Configuration parameters) throws Exception {
            try {
                if (this.sinkDataFabricSerializer == null) {
                    this.sinkDataFabricClient = dataFabricUtil.createDataFabricClient("svc-XMartAppUat", "As03!#rV12", "DATAFABRIC-TST", "631d6bb8-feb9-4504-b725-fd069c3ebedf");
                    this.sinkDataFabricSerializer = this.sinkDataFabricClient.getDataFabricSerializer();
                }
            } catch (Exception e) {
                throw e;
            }
        }
    }

}
