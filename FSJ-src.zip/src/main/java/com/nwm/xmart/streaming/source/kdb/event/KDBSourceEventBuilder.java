package com.nwm.xmart.streaming.source.kdb.event;

import com.nwm.xmart.streaming.source.kdb.sorting.KDBFunctionType;
import com.nwm.xmart.streaming.source.kdb.sorting.SortKeyI;

/**
 * NOT ThreadSafe
 *
 *
 * Created by gardlex on 30/04/2018.
 */
public class KDBSourceEventBuilder {

    private final String sourceID;
    private final String functionName;
    private final String tableName;
    private final boolean success;
    private final String message;
    private final String tag;
    private final String[] columnNames;
    private long documentReceivedTimestampNanos;
    private SortKeyI sortKey;
    private Object[] recordData;
    private long recordIndex;
    private String dateTime;
    private final KDBFunctionType kdbFunctionType;

    public KDBSourceEventBuilder(String sourceID,
                                 String functionName,
                                 String tableName,
                                 boolean success,
                                 String message,
                                 String tag,
                                 String[] columnNames,
                                 KDBFunctionType kdbFunctionType) {
        this.sourceID = sourceID;
        this.functionName = functionName;
        this.tableName = tableName;
        this.success = success;
        this.message = message;
        this.tag = tag;
        this.columnNames = columnNames;
        this.kdbFunctionType = kdbFunctionType;
    }

    public KDBSourceEventBuilder withDocumentReceivedTimestamp(long documentReceivedTimestampNanos) {
        this.documentReceivedTimestampNanos = documentReceivedTimestampNanos;
        return this;
    }

    public KDBSourceEventBuilder withSortKey(SortKeyI sortKey) {
        this.sortKey = sortKey;
        return this;
    }

    public KDBSourceEventBuilder withRecordData(Object[] recordData) {
        this.recordData = recordData;
        return this;
    }

    public KDBSourceEventBuilder withRecordIndex(long recordIndex) {
        this.recordIndex = recordIndex;
        return this;
    }

    public KDBSourceEventBuilder withDateTime(String dateTime) {
        this.dateTime = dateTime;
        return this;
    }

    public KDBSourceEvent build() {
        return new KDBSourceEvent(
                sourceID,
                functionName,
                tableName,
                success,
                message,
                tag,
                columnNames,
                recordData,
                recordIndex,
                sortKey,
                kdbFunctionType,
                dateTime);
    }
}
