package com.nwm.xmart.streaming.source.rdx.query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Created by gardlex on 22/05/2018.
 */
public class RequestedFacetPropertyParser {

    private static final Logger logger = LoggerFactory.getLogger(RequestedFacetPropertyParser.class);

    public static void main(String[] args) {
        List<RequestedFacet> list =
                RequestedFacetPropertyParser.getRequestedFacetsFromString("Alias|AliasType|AliasValue,Analytics|OutstandingAmount,AssetBackedSecurity|AssetPoolGroup|AssetPoolSeries|TrancheTypeDescription|WeightedAverageCoupon,Bond|CFICode|CreditLinkedIndicator|FinalMaturity|IsBrady|IsCallable|IsConvertible|IsCovered|IsSinkable|IsSubordinated|IsZeroCoupon|NextCallDate|PrepaymentType|SeriesOfBond,Debt|CollateralType|ParAmount|TotalIssue,InstrumentIssuance|IssuePrice|AnnouncementDate|Currency|IssueDate,Instrument|AssetClassSubType|CountryOfDomicile|CountryOfIssue|CountryOfRisk|DayCountDescription|InstrumentLongName|InstrumentName|InstrumentShortName|IsPerpetual|MaturityDate|MinimumLot|StrikePrice,InstrumentClassification|IssuerType|bdlIndustryGroup|bdlIndustrySector|bdlIssuerIndustry|bdlMrketSector|BdlSecurityType|BdlSecurityType2|CouponType|IndustrySubgroup,InstrumentParty|CountryOfIncorporationId|CountryOfIncorporationName|CountryOfRiskName|PartyName|PartyNameVendor|PartyRoleType|PartyCode,Interest|CalculationType|CouponRate,MortgageFactorHistory|EventType|EventDate|EventProvider|EventPercentage,Rating|MdxIndentifier,Ratings|RatingAgency|RatingType|RatingValue,Underwriter|UnderwriterRoleCode|UnderwriterShortName|UnderwriterRoleName|UnderwriterName");
        for (RequestedFacet facet : list) {
            logger.info(facet.toString());
        }
        int x = 0;
    }

    public static List<RequestedFacet> getRequestedFacetsFromString(String requestedFacets) {
        StringTokenizer requestedFacetTokenizer = new StringTokenizer(requestedFacets, ",");
        List<RequestedFacet> requestedFacetList = new ArrayList<>();

        while (requestedFacetTokenizer.hasMoreTokens()) {
            String instrumentAndFields = requestedFacetTokenizer.nextToken();
            StringTokenizer instrumentFieldTokenizer = new StringTokenizer(instrumentAndFields, "|");

            String requestedFacetName = null;
            if (instrumentFieldTokenizer.hasMoreTokens()) {
                requestedFacetName = instrumentFieldTokenizer.nextToken();
            }
            List<String> fieldNamesList = new ArrayList<>();
            while (instrumentFieldTokenizer.hasMoreTokens()) {
                fieldNamesList.add(instrumentFieldTokenizer.nextToken());
            }

            String[] fieldNamesArray = new String[fieldNamesList.size()];
            fieldNamesList.toArray(fieldNamesArray);
            requestedFacetList.add(new RequestedFacet(requestedFacetName, fieldNamesArray));
        }

        return requestedFacetList;
    }

}
