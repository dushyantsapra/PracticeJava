package com.nwm.xmart.streaming.source.mdx.event;

import java.util.HashMap;
import java.util.Map;

public enum MdxSeriesTypeName {
    mdxRefRegInstrument("reference.regulatory.instrument", "mdxRefRegInstrument"),
    mdxFxSpotRate("fx.spotrate", "mdxFxSpotRate"),
    mdxRefReg("reference.regulatory", "mdxRefReg");

    private static final Map<String, MdxSeriesTypeName> lookup = new HashMap<String, MdxSeriesTypeName>();

    static {
        for (MdxSeriesTypeName mdxSeriesTypeName : MdxSeriesTypeName.values()) {
            lookup.put(mdxSeriesTypeName.getSeriesTypeName(), mdxSeriesTypeName);
        }
    }

    private String seriesTypeName;
    private String rootName;

    MdxSeriesTypeName(String seriesTypeName, String rootName) {
        this.seriesTypeName = seriesTypeName;
        this.rootName = rootName;
    }

    public static MdxSeriesTypeName get(String seriesTypeName) {
        return lookup.get(seriesTypeName);
    }

    public String getSeriesTypeName() {
        return seriesTypeName;
    }

    public String getRootName() {
        return rootName;
    }
}
