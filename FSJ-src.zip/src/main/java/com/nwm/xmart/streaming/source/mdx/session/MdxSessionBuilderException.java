package com.nwm.xmart.streaming.source.mdx.session;

/**
 * Created by gardlex on 15/11/2017.
 */
public class MdxSessionBuilderException extends RuntimeException {

    public MdxSessionBuilderException() {
        super();
    }

    public MdxSessionBuilderException(String msg) {
        super(msg);
    }

    public MdxSessionBuilderException(String msg, Throwable t) {
        super(msg, t);
    }
}
