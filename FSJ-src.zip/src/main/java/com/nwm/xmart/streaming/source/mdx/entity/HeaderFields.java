package com.nwm.xmart.streaming.source.mdx.entity;

import java.io.Serializable;
import java.util.Date;

public class HeaderFields implements Serializable {
    private static final long serialVersionUID = 6449864959123513756L;

    private String mdxTransport;
    private String mdxTypeName;
    private String mdxPath;
    private Integer mdxDocumentVersion;
    private Date mdxWrittenOnUTC;
    private String mdxValuationDate;
    private String xmlWriteTime;

    public HeaderFields(String mdxTransport, String mdxTypeName, String mdxPath, Integer mdxDocumentVersion,
            Date mdxWrittenOnUTC, String mdxValuationDate, String xmlWriteTime) {
        this.mdxTransport = mdxTransport;
        this.mdxTypeName = mdxTypeName;
        this.mdxPath = mdxPath;
        this.mdxDocumentVersion = mdxDocumentVersion;
        this.mdxWrittenOnUTC = mdxWrittenOnUTC;
        this.mdxValuationDate = mdxValuationDate;
        this.xmlWriteTime = xmlWriteTime;
    }

    public String getMdxTransport() {
        return mdxTransport;
    }

    public void setMdxTransport(String mdxTransport) {
        this.mdxTransport = mdxTransport;
    }

    public String getMdxTypeName() {
        return mdxTypeName;
    }

    public void setMdxTypeName(String mdxTypeName) {
        this.mdxTypeName = mdxTypeName;
    }

    public String getMdxPath() {
        return mdxPath;
    }

    public void setMdxPath(String mdxPath) {
        this.mdxPath = mdxPath;
    }

    public Integer getMdxDocumentVersion() {
        return mdxDocumentVersion;
    }

    public void setMdxDocumentVersion(Integer mdxDocumentVersion) {
        this.mdxDocumentVersion = mdxDocumentVersion;
    }

    public Date getMdxWrittenOnUTC() {
        return mdxWrittenOnUTC;
    }

    public void setMdxWrittenOnUTC(Date mdxWrittenOnUTC) {
        this.mdxWrittenOnUTC = mdxWrittenOnUTC;
    }

    public String getMdxValuationDate() {
        return mdxValuationDate;
    }

    public void setMdxValuationDate(String mdxValuationDate) {
        this.mdxValuationDate = mdxValuationDate;
    }

    public String getXmlWriteTime() {
        return xmlWriteTime;
    }

    public void setXmlWriteTime(String xmlWriteTime) {
        this.xmlWriteTime = xmlWriteTime;
    }
}
