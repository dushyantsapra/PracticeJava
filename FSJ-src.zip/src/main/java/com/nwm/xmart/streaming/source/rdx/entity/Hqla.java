
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "HQLAAustralianEligible",
    "HQLABASEL3Eligible",
    "HQLACanadianEligible",
    "HQLAEUEligible",
    "HQLAFR2052AEligible",
    "HQLA30dayPriceDrop",
    "HQLA30dayDropStartDate",
    "HQLA30dayPriceDropDate",
    "HQLAJapaneseEligible",
    "OECDMemberCORClass",
    "IsOECDMember",
    "HQLAUSEligible",
    "Basel3USRiskWeight",
    "Bsl3RiskWeightExpTyp",
    "EUBASEL3RiskWeight",
    "EUBASEL3RiskWeightType",
    "HQLAEBAEligible"
})
public class Hqla {

    @JsonProperty("HQLAAustralianEligible")
    private String hQLAAustralianEligible;
    @JsonProperty("HQLABASEL3Eligible")
    private String hQLABASEL3Eligible;
    @JsonProperty("HQLACanadianEligible")
    private String hQLACanadianEligible;
    @JsonProperty("HQLAEUEligible")
    private String hQLAEUEligible;
    @JsonProperty("HQLAFR2052AEligible")
    private String hQLAFR2052AEligible;
    @JsonProperty("HQLA30dayPriceDrop")
    private Double hQLA30dayPriceDrop;
    @JsonProperty("HQLA30dayDropStartDate")
    private String hQLA30dayDropStartDate;
    @JsonProperty("HQLA30dayPriceDropDate")
    private String hQLA30dayPriceDropDate;
    @JsonProperty("HQLAJapaneseEligible")
    private String hQLAJapaneseEligible;
    @JsonProperty("OECDMemberCORClass")
    private String oECDMemberCORClass;
    @JsonProperty("IsOECDMember")
    private String isOECDMember;
    @JsonProperty("HQLAUSEligible")
    private String hQLAUSEligible;
    @JsonProperty("Basel3USRiskWeight")
    private Double basel3USRiskWeight;
    @JsonProperty("Bsl3RiskWeightExpTyp")
    private Object bsl3RiskWeightExpTyp;
    @JsonProperty("EUBASEL3RiskWeight")
    private Double eUBASEL3RiskWeight;
    @JsonProperty("EUBASEL3RiskWeightType")
    private String eUBASEL3RiskWeightType;
    @JsonProperty("HQLAEBAEligible")
    private Object hQLAEBAEligible;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("HQLAAustralianEligible")
    public String getHQLAAustralianEligible() {
        return hQLAAustralianEligible;
    }

    @JsonProperty("HQLAAustralianEligible")
    public void setHQLAAustralianEligible(String hQLAAustralianEligible) {
        this.hQLAAustralianEligible = hQLAAustralianEligible;
    }

    @JsonProperty("HQLABASEL3Eligible")
    public String getHQLABASEL3Eligible() {
        return hQLABASEL3Eligible;
    }

    @JsonProperty("HQLABASEL3Eligible")
    public void setHQLABASEL3Eligible(String hQLABASEL3Eligible) {
        this.hQLABASEL3Eligible = hQLABASEL3Eligible;
    }

    @JsonProperty("HQLACanadianEligible")
    public String getHQLACanadianEligible() {
        return hQLACanadianEligible;
    }

    @JsonProperty("HQLACanadianEligible")
    public void setHQLACanadianEligible(String hQLACanadianEligible) {
        this.hQLACanadianEligible = hQLACanadianEligible;
    }

    @JsonProperty("HQLAEUEligible")
    public String getHQLAEUEligible() {
        return hQLAEUEligible;
    }

    @JsonProperty("HQLAEUEligible")
    public void setHQLAEUEligible(String hQLAEUEligible) {
        this.hQLAEUEligible = hQLAEUEligible;
    }

    @JsonProperty("HQLAFR2052AEligible")
    public String getHQLAFR2052AEligible() {
        return hQLAFR2052AEligible;
    }

    @JsonProperty("HQLAFR2052AEligible")
    public void setHQLAFR2052AEligible(String hQLAFR2052AEligible) {
        this.hQLAFR2052AEligible = hQLAFR2052AEligible;
    }

    @JsonProperty("HQLA30dayPriceDrop")
    public Double getHQLA30dayPriceDrop() {
        return hQLA30dayPriceDrop;
    }

    @JsonProperty("HQLA30dayPriceDrop")
    public void setHQLA30dayPriceDrop(Double hQLA30dayPriceDrop) {
        this.hQLA30dayPriceDrop = hQLA30dayPriceDrop;
    }

    @JsonProperty("HQLA30dayDropStartDate")
    public String getHQLA30dayDropStartDate() {
        return hQLA30dayDropStartDate;
    }

    @JsonProperty("HQLA30dayDropStartDate")
    public void setHQLA30dayDropStartDate(String hQLA30dayDropStartDate) {
        this.hQLA30dayDropStartDate = hQLA30dayDropStartDate;
    }

    @JsonProperty("HQLA30dayPriceDropDate")
    public String getHQLA30dayPriceDropDate() {
        return hQLA30dayPriceDropDate;
    }

    @JsonProperty("HQLA30dayPriceDropDate")
    public void setHQLA30dayPriceDropDate(String hQLA30dayPriceDropDate) {
        this.hQLA30dayPriceDropDate = hQLA30dayPriceDropDate;
    }

    @JsonProperty("HQLAJapaneseEligible")
    public String getHQLAJapaneseEligible() {
        return hQLAJapaneseEligible;
    }

    @JsonProperty("HQLAJapaneseEligible")
    public void setHQLAJapaneseEligible(String hQLAJapaneseEligible) {
        this.hQLAJapaneseEligible = hQLAJapaneseEligible;
    }

    @JsonProperty("OECDMemberCORClass")
    public String getOECDMemberCORClass() {
        return oECDMemberCORClass;
    }

    @JsonProperty("OECDMemberCORClass")
    public void setOECDMemberCORClass(String oECDMemberCORClass) {
        this.oECDMemberCORClass = oECDMemberCORClass;
    }

    @JsonProperty("IsOECDMember")
    public String getIsOECDMember() {
        return isOECDMember;
    }

    @JsonProperty("IsOECDMember")
    public void setIsOECDMember(String isOECDMember) {
        this.isOECDMember = isOECDMember;
    }

    @JsonProperty("HQLAUSEligible")
    public String getHQLAUSEligible() {
        return hQLAUSEligible;
    }

    @JsonProperty("HQLAUSEligible")
    public void setHQLAUSEligible(String hQLAUSEligible) {
        this.hQLAUSEligible = hQLAUSEligible;
    }

    @JsonProperty("Basel3USRiskWeight")
    public Double getBasel3USRiskWeight() {
        return basel3USRiskWeight;
    }

    @JsonProperty("Basel3USRiskWeight")
    public void setBasel3USRiskWeight(Double basel3USRiskWeight) {
        this.basel3USRiskWeight = basel3USRiskWeight;
    }

    @JsonProperty("Bsl3RiskWeightExpTyp")
    public Object getBsl3RiskWeightExpTyp() {
        return bsl3RiskWeightExpTyp;
    }

    @JsonProperty("Bsl3RiskWeightExpTyp")
    public void setBsl3RiskWeightExpTyp(Object bsl3RiskWeightExpTyp) {
        this.bsl3RiskWeightExpTyp = bsl3RiskWeightExpTyp;
    }

    @JsonProperty("EUBASEL3RiskWeight")
    public Double getEUBASEL3RiskWeight() {
        return eUBASEL3RiskWeight;
    }

    @JsonProperty("EUBASEL3RiskWeight")
    public void setEUBASEL3RiskWeight(Double eUBASEL3RiskWeight) {
        this.eUBASEL3RiskWeight = eUBASEL3RiskWeight;
    }

    @JsonProperty("EUBASEL3RiskWeightType")
    public String getEUBASEL3RiskWeightType() {
        return eUBASEL3RiskWeightType;
    }

    @JsonProperty("EUBASEL3RiskWeightType")
    public void setEUBASEL3RiskWeightType(String eUBASEL3RiskWeightType) {
        this.eUBASEL3RiskWeightType = eUBASEL3RiskWeightType;
    }

    @JsonProperty("HQLAEBAEligible")
    public Object getHQLAEBAEligible() {
        return hQLAEBAEligible;
    }

    @JsonProperty("HQLAEBAEligible")
    public void setHQLAEBAEligible(Object hQLAEBAEligible) {
        this.hQLAEBAEligible = hQLAEBAEligible;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("hQLAAustralianEligible", hQLAAustralianEligible).append("hQLABASEL3Eligible", hQLABASEL3Eligible).append("hQLACanadianEligible", hQLACanadianEligible).append("hQLAEUEligible", hQLAEUEligible).append("hQLAFR2052AEligible", hQLAFR2052AEligible).append("hQLA30dayPriceDrop", hQLA30dayPriceDrop).append("hQLA30dayDropStartDate", hQLA30dayDropStartDate).append("hQLA30dayPriceDropDate", hQLA30dayPriceDropDate).append("hQLAJapaneseEligible", hQLAJapaneseEligible).append("oECDMemberCORClass", oECDMemberCORClass).append("isOECDMember", isOECDMember).append("hQLAUSEligible", hQLAUSEligible).append("basel3USRiskWeight", basel3USRiskWeight).append("bsl3RiskWeightExpTyp", bsl3RiskWeightExpTyp).append("eUBASEL3RiskWeight", eUBASEL3RiskWeight).append("eUBASEL3RiskWeightType", eUBASEL3RiskWeightType).append("hQLAEBAEligible", hQLAEBAEligible).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(hQLAAustralianEligible).append(hQLAFR2052AEligible).append(isOECDMember).append(eUBASEL3RiskWeightType).append(hQLABASEL3Eligible).append(eUBASEL3RiskWeight).append(hQLA30dayPriceDropDate).append(hQLA30dayPriceDrop).append(oECDMemberCORClass).append(basel3USRiskWeight).append(bsl3RiskWeightExpTyp).append(hQLAEUEligible).append(hQLA30dayDropStartDate).append(hQLAUSEligible).append(hQLAJapaneseEligible).append(additionalProperties).append(hQLACanadianEligible).append(hQLAEBAEligible).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Hqla) == false) {
            return false;
        }
        Hqla rhs = ((Hqla) other);
        return new EqualsBuilder().append(hQLAAustralianEligible, rhs.hQLAAustralianEligible).append(hQLAFR2052AEligible, rhs.hQLAFR2052AEligible).append(isOECDMember, rhs.isOECDMember).append(eUBASEL3RiskWeightType, rhs.eUBASEL3RiskWeightType).append(hQLABASEL3Eligible, rhs.hQLABASEL3Eligible).append(eUBASEL3RiskWeight, rhs.eUBASEL3RiskWeight).append(hQLA30dayPriceDropDate, rhs.hQLA30dayPriceDropDate).append(hQLA30dayPriceDrop, rhs.hQLA30dayPriceDrop).append(oECDMemberCORClass, rhs.oECDMemberCORClass).append(basel3USRiskWeight, rhs.basel3USRiskWeight).append(bsl3RiskWeightExpTyp, rhs.bsl3RiskWeightExpTyp).append(hQLAEUEligible, rhs.hQLAEUEligible).append(hQLA30dayDropStartDate, rhs.hQLA30dayDropStartDate).append(hQLAUSEligible, rhs.hQLAUSEligible).append(hQLAJapaneseEligible, rhs.hQLAJapaneseEligible).append(additionalProperties, rhs.additionalProperties).append(hQLACanadianEligible, rhs.hQLACanadianEligible).append(hQLAEBAEligible, rhs.hQLAEBAEligible).isEquals();
    }

}
