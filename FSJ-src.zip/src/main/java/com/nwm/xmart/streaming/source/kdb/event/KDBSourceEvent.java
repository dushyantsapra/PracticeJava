package com.nwm.xmart.streaming.source.kdb.event;

import com.nwm.xmart.streaming.source.kdb.sorting.KDBFunctionType;
import com.nwm.xmart.streaming.source.kdb.sorting.SortKeyI;

import java.util.Arrays;

/**
 * Created by gardlex on 30/04/2018.
 */
public class KDBSourceEvent {

    private String sourceID;
    private String functionName;
    private String tableName;
    private long documentReceivedTimestamp;
    private boolean success;
    private String message;
    private String tag;
    private String[] columnNames;
    private Object[] recordData;
    private long recordIndex;
    private SortKeyI sortKey;
    private KDBFunctionType kdbFunctionType;
    private String dateTime;
    private long currentJobEventID;

    public KDBSourceEvent(String sourceID,
                          String functionName,
                          String tableName,
                          boolean success,
                          String message,
                          String tag,
                          String[] columnNames,
                          Object[] recordData,
                          long recordIndex,
                          SortKeyI sortKey,
                          KDBFunctionType kdbFunctionType,
                          String dateTime) {
        this.sourceID = sourceID;
        this.functionName = functionName;
        this.tableName = tableName;
        this.success = success;
        this.message = message;
        this.tag = tag;
        this.columnNames = columnNames;
        this.recordData = recordData;
        this.recordIndex = recordIndex;
        this.sortKey = sortKey;
        this.kdbFunctionType = kdbFunctionType;
        this.dateTime = dateTime;
    }

    public void setDocumentReceivedTimestamp(long documentReceivedTimestamp) {
        this.documentReceivedTimestamp = documentReceivedTimestamp;
    }

    public void setCurrentJobEventID(long currentJobEventID) {
        this.currentJobEventID = currentJobEventID;
    }

    public String getSourceID() {
        return sourceID;
    }

    public String getFunctionName() {
        return functionName;
    }

    public long getDocumentReceivedTimestamp() {
        return documentReceivedTimestamp;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public String getTag() {
        return tag;
    }

    public String[] getColumnNames() {
        return Arrays.copyOf(columnNames, columnNames.length);
    }

    public Object[] getRecordData() {
        return recordData;
    }

    public long getRecordIndex() {
        return recordIndex;
    }

    public Object getIndexedValue(int index) {
        return recordData[index];
    }

    public SortKeyI getKDBSortKey() {
        return sortKey;
    }

    public KDBFunctionType getKdbFunctionType() {
        return kdbFunctionType;
    }

    public String getDateTime() {
        return dateTime;
    }

    public long getCurrentJobEventID() {
        return currentJobEventID;
    }

    public String toCSVFormet() {
        StringBuilder sb = new StringBuilder();
        for (int i=0; i < recordData.length; i++) {
            sb.append(recordData[i]);
            if (i < (recordData.length - 1)) {
                sb.append(',');
            }
        }

        return sb.toString();
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
}
