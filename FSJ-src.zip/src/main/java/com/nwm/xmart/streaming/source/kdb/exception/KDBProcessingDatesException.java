package com.nwm.xmart.streaming.source.kdb.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class KDBProcessingDatesException extends RuntimeException {

    public KDBProcessingDatesException() {
        super();
    }

    public KDBProcessingDatesException(String msg) {
        super(msg);
    }

    public KDBProcessingDatesException(String msg, Throwable t) {
        super(msg, t);
    }
}
