package com.nwm.xmart.streaming.source.df;

import com.nwm.xmart.streaming.error.exception.FlinkJobStartUpException;
import org.apache.commons.lang.StringUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.LaxRedirectStrategy;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Properties;

/**
 * Created by gardlex on 29/10/2017.
 */
public class KafkaProperties {
    private final Properties kafkaProps;
    private final Configuration configuration;
    protected static Logger logger = LoggerFactory.getLogger(KafkaProperties.class);

    public KafkaProperties(Configuration configuration) {
        this.configuration = configuration;
        kafkaProps = new Properties();

        kafkaProps.setProperty("group.id", configuration.getString("kafka.consumer.group.id",""));
        String clientId = configuration.getString("kafka.client.id","");
        if (StringUtils.isEmpty(clientId)) {
            throw new FlinkJobStartUpException("Kafka property client.id is MANDATORY");
        }
        kafkaProps.setProperty("client.id", clientId);
        kafkaProps.setProperty("enable.auto.commit", "false");
        kafkaProps.setProperty("auto.offset.reset", "earliest");
        kafkaProps.setProperty("max.poll.records", configuration.getString("kafka.max.poll.records",""));
        kafkaProps.setProperty("max.partition.fetch.bytes", configuration.getString("kafka.max.partition.fetch.bytes",""));
        kafkaProps.setProperty("max.poll.interval.ms", configuration.getString("kafka.max.poll.interval.ms",""));
        kafkaProps.setProperty("fetch.max.bytes", configuration.getString("kafka.fetch.max.bytes",""));
        kafkaProps.setProperty("fetch.max.wait.ms", configuration.getString("kafka.fetch.max.wait.ms",""));
        kafkaProps.setProperty("fetch.min.bytes", configuration.getString("kafka.fetch.min.bytes",""));

        captureKafkaBootstrapServers();

        kafkaProps.setProperty("bootstrap.servers", configuration.getString("kafka.bootstrap.servers",""));

    }

    public Properties getProperties() {
        Properties p = new Properties();
        kafkaProps.forEach((key, value) -> {
            p.setProperty((String) key, (String) value);
        });

        return p;
    }

    private void captureKafkaBootstrapServers() {

        CloseableHttpClient httpClient = HttpClients.custom().setRedirectStrategy(new LaxRedirectStrategy()).build();
        String kafkaServerURLs = configuration.getString("kafka.bootstrap.servers.url","");

        if (StringUtils.isBlank(kafkaServerURLs)) {
            throw new FlinkJobStartUpException("PROPERTY MISSING for Flink Job [ kafka.bootstrap.servers.url ]");
        }

        logger.info("Using KafkaServerURL={}", kafkaServerURLs);

        HttpGet request = new HttpGet(kafkaServerURLs);

        CloseableHttpResponse response = null;

        try {
            response = httpClient.execute(request);

            // Check the status
            if (200 != response.getStatusLine().getStatusCode()) {
                throw new FlinkJobStartUpException("KAFKA BOOTSTRAP SERVERS ARE NOT ACCESSIBLE: Http Response Status Code [ " + response.getStatusLine().getStatusCode() + " ]");
            }

            String kafkaBootStrapServersList = EntityUtils.toString(response.getEntity());
            if (StringUtils.isBlank(kafkaBootStrapServersList)) {
                throw new FlinkJobStartUpException("Response from Kafka Bootstrap servers is EMPTY");
            }

            // set the kafka servers list prop
            kafkaBootStrapServersList = kafkaBootStrapServersList.replaceAll("\"", ""); // StringUtils.removeEnd(StringUtils.removeStart(kafkaBootStrapServersList, "\""), "\"");
            logger.info("Using KafkaBootstrapServerList={}", kafkaBootStrapServersList);

            configuration.setString("kafka.bootstrap.servers", kafkaBootStrapServersList);

        } catch (IOException e) {
            throw new FlinkJobStartUpException("Could not retrieve the Kafka bootstrap servers", e);
        }  finally {
            try {
                response.close();
            } catch (IOException e) {
                // do nothing but log
                logger.warn("Could not close the CloseableHttpResponse whilst obtaining the Kafka bootstrap servers");
            }
            try {
                httpClient.close();
            } catch (IOException e) {
                // do nothing but log
                logger.warn("Could not close the CloseableHttpClient whilst obtaining the Kafka bootstrap servers");
            }
        }
    }

}
