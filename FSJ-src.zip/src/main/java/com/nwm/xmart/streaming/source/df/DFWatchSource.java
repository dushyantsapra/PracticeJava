package com.nwm.xmart.streaming.source.df;

import com.nwm.xmart.streaming.source.df.event.DataFabricWatchEvent;
import com.nwm.xmart.streaming.source.df.exception.DFSourceException;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import com.nwm.xmart.util.MDCParameter;
import com.nwm.xmart.util.MDCUtil;
import com.rbs.datafabric.client.DataFabricClient;
import com.rbs.datafabric.domain.OffsetCommitter;
import com.rbs.datafabric.domain.WatchContext;
import com.rbs.datafabric.domain.client.StartFrom;
import com.rbs.datafabric.domain.client.builder.ConsumerConfigurationBuilder;
import com.rbs.datafabric.domain.client.builder.ResumeDurableWatchScanRequestBuilder;
import com.rbs.datafabric.domain.event.ContinuousQueryEvent;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.CountDownLatch;

import static java.lang.String.format;
import static java.util.Objects.isNull;

public class DFWatchSource extends RichParallelSourceFunction<DataFabricWatchEvent> implements CheckpointedFunction, CheckpointListener {

    private static final long serialVersionUID = 4651674868729296792L;
    private Logger logger = LoggerFactory.getLogger(DFWatchSource.class);

    private final DFWatchSourceConnectionDetails connectionDetails;
    private final DataFabricUtil dataFabricUtil;

    private transient WatchContext<ContinuousQueryEvent> watchContext;
    private transient OffsetCommitter offsetCommitter;
    private final IntCounter accumulatorEventCount = new IntCounter();
    private volatile Long offsetTracker;
    private transient ListState<Long> offsetState;

    private transient CountDownLatch isRunningCountDownLatch;

    private DFSubscriber dfSubscriber;

    public DFWatchSource(DFWatchSourceConnectionDetails connectionDetails, DataFabricUtil dataFabricUtil) {
        this.connectionDetails = connectionDetails;
        this.dataFabricUtil = dataFabricUtil;
    }

    @Override
    public void run(SourceContext<DataFabricWatchEvent> ctx) {
        //MDC for logging
        MDCParameter parameter = MDCParameter.jobNameFrom((ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters());
        MDCUtil.putInMDC(parameter);

        isRunningCountDownLatch = new CountDownLatch(1);

        startSubscription(ctx, parameter);

        waitForStreamTermination();

        closeConnections();
    }

    protected void startSubscription(SourceContext<DataFabricWatchEvent> ctx, MDCParameter parameter) {
        logger.warn("Source starting subscription, source={}, topic={}", connectionDetails.getSourceName(), connectionDetails.getWatchId());
        dfSubscriber = new DFSubscriber(this, ctx, watchContext, connectionDetails.getSourceName(), parameter);
        dfSubscriber.startSubscription();
    }

    protected void waitForStreamTermination() {
        logger.warn("Source run waiting for completion, source={}, topic={}", connectionDetails.getSourceName(), connectionDetails.getWatchId());
        try {
            isRunningCountDownLatch.await();
        } catch (InterruptedException e) {
            logger.warn("Source run interrupted, source={}, topic={}, offsetTracker = {}", connectionDetails.getSourceName(), connectionDetails.getWatchId(), offsetTracker);
            cancel();
        }
        logger.warn("Source run completed, source={}, topic={}", connectionDetails.getSourceName(), connectionDetails.getWatchId());
    }

    void incrementOffsetTracker(long latestOffset) {
        offsetTracker = latestOffset;
        this.accumulatorEventCount.add(1);
        logger.debug("Offset tracker updated in data source, source={}, topic={}, offsetTracker = {}", connectionDetails.getSourceName(), connectionDetails.getWatchId(), offsetTracker);
    }

    @Override
    public void open(Configuration configuration) throws Exception {
        MDCParameter parameter = MDCParameter.jobNameFrom((ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters());
        MDCUtil.putInMDC(parameter);

        DataFabricClient dataFabricClient = dataFabricUtil.getDataFabricClient();
        logger.info("DataFabric client initialized, version = {}, for watch id = {}", dataFabricClient.getClientVersion().getBuildVersion(), connectionDetails.getWatchId());

        ConsumerConfigurationBuilder consumerConfiguration = getConsumerConfiguration();

        watchContext = resumeWatchContext(dataFabricClient, consumerConfiguration);

        offsetCommitter = watchContext.getOffsetCommitter();

        getRuntimeContext().addAccumulator("numberOfSourceEvents_" + connectionDetails.getSourceName(), this.accumulatorEventCount);

    }

    private ConsumerConfigurationBuilder getConsumerConfiguration() {
        ConsumerConfigurationBuilder consumerConfiguration = ConsumerConfigurationBuilder.create()
                                                                                         .withGroupId(connectionDetails.getConsumerGroupId())
                                                                                         .withAutoCommit(false)
                                                                                         /*.withSessionTimeoutInMs(Integer.MAX_VALUE)
                                                                                         .withRequestTimeoutInMs(Integer.MAX_VALUE)*/;

        if (connectionDetails.isStartFromOffset()) {
            logger.info("Starting DF consumer with user specified offset {}, source={}, topic={}", connectionDetails.getSpecificOffset(), connectionDetails.getSourceName(), connectionDetails.getWatchId());
            consumerConfiguration.withStartOffset(connectionDetails.getSpecificOffset());
        } else if (!isNull(offsetTracker)) {
            logger.info("Starting DF consumer with restored offset {}, source={}, topic={}", offsetTracker, connectionDetails.getSourceName(), connectionDetails.getWatchId());
            consumerConfiguration.withStartOffset(offsetTracker);
        } else {
            logger.info("Starting DF consumer from beginning, source={}, topic={}", connectionDetails.getSourceName(), connectionDetails.getWatchId());
            consumerConfiguration.withStartFrom(StartFrom.BEGINNING);
        }
        return consumerConfiguration;
    }

    private WatchContext<ContinuousQueryEvent> resumeWatchContext(DataFabricClient dataFabricClient, ConsumerConfigurationBuilder consumerConfiguration) {

        logger.info("Resuming durable watch scan, source={}, topic={}, offsetTracker = {}", connectionDetails.getSourceName(), connectionDetails.getWatchId(), offsetTracker);

        try {
            watchContext = dataFabricClient.resumeDurableWatchScan(ResumeDurableWatchScanRequestBuilder.create(connectionDetails.getWatchId())
                                                                                                       .withConsumerConfiguration(
                                                                                                               consumerConfiguration
                                                                                                                       .build()));
        } catch (Exception e) {
            throw new DFSourceException(format("Failed to resume durable watch scan, source=%s, topic=%s, offsetTracker = %s", connectionDetails.getSourceName(), connectionDetails.getWatchId(), offsetTracker), e);
        }

        logger.info("Durable watch scan resumed, source={}, topic={}, offsetTracker = {}", connectionDetails.getSourceName(), connectionDetails.getWatchId(), offsetTracker);

        return watchContext;

    }

    @Override
    public void notifyCheckpointComplete(long l) {
        if (!isNull(offsetTracker)) {
            logger.info("Checkpoint complete, now committing to df, source={}, topic={}, offsetTracker = {}", connectionDetails.getSourceName(), connectionDetails.getWatchId(), offsetTracker);
            try {
                offsetCommitter.commit(offsetTracker);
            } catch (Exception e) {
                throw new DFSourceException(format("Offset commit to DF failed, source=%s, topic=%s, offsetTracker = %s", connectionDetails.getSourceName(), connectionDetails.getWatchId(), offsetTracker), e);
            }
            logger.info("Offset committed to DF, source={}, topic={}, offsetTracker = {}", connectionDetails.getSourceName(), connectionDetails.getWatchId(), offsetTracker);
        }
    }

    @Override
    public void snapshotState(FunctionSnapshotContext functionSnapshotContext) {
        try {
            if (!isNull(offsetTracker)) {
                offsetState.clear();
                logger.info("Checkpoint requested, source={}, topic={}, offsetTracker = {}", connectionDetails.getSourceName(), connectionDetails.getWatchId(), offsetTracker);
                offsetState.add(offsetTracker);
                logger.info("Checkpoint Saved, source={}, topic={}, offsetTracker = {}", connectionDetails.getSourceName(), connectionDetails.getWatchId(), offsetTracker);
            } else {
                logger.info("Checkpoint requested, but no update to offsetState, source={}, topic={}, offsetTracker = {}", connectionDetails.getSourceName(), connectionDetails.getWatchId(), offsetTracker);
            }
        } catch (Exception e) {
            throw new DFSourceException(format("snapshotState error source=%s, topic=%s, offsetTracker = %s", connectionDetails.getSourceName(), connectionDetails.getWatchId(), offsetTracker), e);
        }
    }

    @Override
    public void initializeState(FunctionInitializationContext context) {
        try {
            offsetState = context.getOperatorStateStore().getListState(new ListStateDescriptor<>(connectionDetails.getSourceName(), Long.class));
        } catch (Exception e) {
            throw new DFSourceException(format("initializeState error, source=%s, topic=%s", connectionDetails.getSourceName(), connectionDetails.getWatchId()), e);
        }

        if (context.isRestored()) {

            offsetTracker = getRestoreOffset();

            logger.info("State restored, source={}, topic={}, offsetTracker = {}", connectionDetails.getSourceName(), connectionDetails.getWatchId(), offsetTracker);

        } else {
            logger.info("State initialized but isRestored is false, source={}, topic={}", connectionDetails.getSourceName(), connectionDetails.getWatchId());
        }
    }

    private Long getRestoreOffset() {

        Long restoreOffset = null;

        try {
            for (Long offset : offsetState.get()) {
                restoreOffset = offset;
            }
        } catch (Exception e) {
            throw new DFSourceException(format("initializeState error, source=%s, topic=%s", connectionDetails.getSourceName(), connectionDetails.getWatchId()), e);
        }

        if (isNull(restoreOffset)) {
            throw new DFSourceException(format("initializeState called but no offset available, source=%s, topic=%s", connectionDetails.getSourceName(), connectionDetails.getWatchId()));
        }

        return restoreOffset;
    }

    @Override
    public void cancel() {
        logger.info("Source cancelled, source={}, topic={}", connectionDetails.getSourceName(), connectionDetails.getWatchId());
        isRunningCountDownLatch.countDown();
        closeConnections();
    }

    private void closeConnections() {
        if (dfSubscriber != null) {
            try {
                dfSubscriber.getSubscription().unsubscribe();
            } catch (Exception e) {
                logger.error(format("Exception occurred while unsubscribe, source=%s, topic=%s", connectionDetails.getSourceName(), connectionDetails.getWatchId()), e);
            }
        }
        dataFabricUtil.close();
    }
}
