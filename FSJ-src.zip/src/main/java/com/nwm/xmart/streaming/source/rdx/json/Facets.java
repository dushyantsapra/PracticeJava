
package com.nwm.xmart.streaming.source.rdx.json;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Instrument",
    "Alias",
    "Analytics",
    "AssetBackedSecurity",
    "Bond",
    "Debt",
    "InstrumentIssuance",
    "InstrumentClassification",
    "InstrumentParty",
    "Interest",
    "MortgageFactorHistory",
    "Ratings",
    "Underwriter"
})
public class Facets {

    @JsonProperty("Instrument")
    private List<Instrument> instrument = new ArrayList<Instrument>();
    @JsonProperty("Alias")
    private List<Alia> alias = new ArrayList<Alia>();
    @JsonProperty("Analytics")
    private List<Analytic> analytics = new ArrayList<Analytic>();
    @JsonProperty("AssetBackedSecurity")
    private List<AssetBackedSecurity> assetBackedSecurity = new ArrayList<AssetBackedSecurity>();
    @JsonProperty("Bond")
    private List<Bond> bond = new ArrayList<Bond>();
    @JsonProperty("Debt")
    private List<Debt> debt = new ArrayList<Debt>();
    @JsonProperty("InstrumentIssuance")
    private List<InstrumentIssuance> instrumentIssuance = new ArrayList<InstrumentIssuance>();
    @JsonProperty("InstrumentClassification")
    private List<InstrumentClassification> instrumentClassification = new ArrayList<InstrumentClassification>();
    @JsonProperty("InstrumentParty")
    private List<InstrumentParty> instrumentParty = new ArrayList<InstrumentParty>();
    @JsonProperty("Interest")
    private List<Interest> interest = new ArrayList<Interest>();
    @JsonProperty("MortgageFactorHistory")
    private List<MortgageFactorHistory> mortgageFactorHistory = new ArrayList<MortgageFactorHistory>();
    @JsonProperty("Ratings")
    private List<Rating> ratings = new ArrayList<Rating>();
    @JsonProperty("Underwriter")
    private List<Underwriter> underwriter = new ArrayList<Underwriter>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("Instrument")
    public List<Instrument> getInstrument() {
        return instrument;
    }

    @JsonProperty("Instrument")
    public void setInstrument(List<Instrument> instrument) {
        this.instrument = instrument;
    }

    @JsonProperty("Alias")
    public List<Alia> getAlias() {
        return alias;
    }

    @JsonProperty("Alias")
    public void setAlias(List<Alia> alias) {
        this.alias = alias;
    }

    @JsonProperty("Analytics")
    public List<Analytic> getAnalytics() {
        return analytics;
    }

    @JsonProperty("Analytics")
    public void setAnalytics(List<Analytic> analytics) {
        this.analytics = analytics;
    }

    @JsonProperty("AssetBackedSecurity")
    public List<AssetBackedSecurity> getAssetBackedSecurity() {
        return assetBackedSecurity;
    }

    @JsonProperty("AssetBackedSecurity")
    public void setAssetBackedSecurity(List<AssetBackedSecurity> assetBackedSecurity) {
        this.assetBackedSecurity = assetBackedSecurity;
    }

    @JsonProperty("Bond")
    public List<Bond> getBond() {
        return bond;
    }

    @JsonProperty("Bond")
    public void setBond(List<Bond> bond) {
        this.bond = bond;
    }

    @JsonProperty("Debt")
    public List<Debt> getDebt() {
        return debt;
    }

    @JsonProperty("Debt")
    public void setDebt(List<Debt> debt) {
        this.debt = debt;
    }

    @JsonProperty("InstrumentIssuance")
    public List<InstrumentIssuance> getInstrumentIssuance() {
        return instrumentIssuance;
    }

    @JsonProperty("InstrumentIssuance")
    public void setInstrumentIssuance(List<InstrumentIssuance> instrumentIssuance) {
        this.instrumentIssuance = instrumentIssuance;
    }

    @JsonProperty("InstrumentClassification")
    public List<InstrumentClassification> getInstrumentClassification() {
        return instrumentClassification;
    }

    @JsonProperty("InstrumentClassification")
    public void setInstrumentClassification(List<InstrumentClassification> instrumentClassification) {
        this.instrumentClassification = instrumentClassification;
    }

    @JsonProperty("InstrumentParty")
    public List<InstrumentParty> getInstrumentParty() {
        return instrumentParty;
    }

    @JsonProperty("InstrumentParty")
    public void setInstrumentParty(List<InstrumentParty> instrumentParty) {
        this.instrumentParty = instrumentParty;
    }

    @JsonProperty("Interest")
    public List<Interest> getInterest() {
        return interest;
    }

    @JsonProperty("Interest")
    public void setInterest(List<Interest> interest) {
        this.interest = interest;
    }

    @JsonProperty("MortgageFactorHistory")
    public List<MortgageFactorHistory> getMortgageFactorHistory() {
        return mortgageFactorHistory;
    }

    @JsonProperty("MortgageFactorHistory")
    public void setMortgageFactorHistory(List<MortgageFactorHistory> mortgageFactorHistory) {
        this.mortgageFactorHistory = mortgageFactorHistory;
    }

    @JsonProperty("Ratings")
    public List<Rating> getRatings() {
        return ratings;
    }

    @JsonProperty("Ratings")
    public void setRatings(List<Rating> ratings) {
        this.ratings = ratings;
    }

    @JsonProperty("Underwriter")
    public List<Underwriter> getUnderwriter() {
        return underwriter;
    }

    @JsonProperty("Underwriter")
    public void setUnderwriter(List<Underwriter> underwriter) {
        this.underwriter = underwriter;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("instrument", instrument).append("alias", alias).append("analytics", analytics).append("assetBackedSecurity", assetBackedSecurity).append("bond", bond).append("debt", debt).append("instrumentIssuance", instrumentIssuance).append("instrumentClassification", instrumentClassification).append("instrumentParty", instrumentParty).append("interest", interest).append("mortgageFactorHistory", mortgageFactorHistory).append("ratings", ratings).append("underwriter", underwriter).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(instrumentParty).append(instrument).append(assetBackedSecurity).append(bond).append(analytics).append(interest).append(ratings).append(alias).append(instrumentIssuance).append(mortgageFactorHistory).append(additionalProperties).append(debt).append(underwriter).append(instrumentClassification).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Facets) == false) {
            return false;
        }
        Facets rhs = ((Facets) other);
        return new EqualsBuilder().append(instrumentParty, rhs.instrumentParty).append(instrument, rhs.instrument).append(assetBackedSecurity, rhs.assetBackedSecurity).append(bond, rhs.bond).append(analytics, rhs.analytics).append(interest, rhs.interest).append(ratings, rhs.ratings).append(alias, rhs.alias).append(instrumentIssuance, rhs.instrumentIssuance).append(mortgageFactorHistory, rhs.mortgageFactorHistory).append(additionalProperties, rhs.additionalProperties).append(debt, rhs.debt).append(underwriter, rhs.underwriter).append(instrumentClassification, rhs.instrumentClassification).isEquals();
    }

}
