package com.nwm.xmart.streaming.database.exceptions;

/**
 * Created by gardlex on 15/11/2017.
 */
public class XmartSqlServerException extends Exception {

    public XmartSqlServerException() {
        super();
    }

    public XmartSqlServerException(String msg) {
        super(msg);
    }

    public XmartSqlServerException(String msg, Throwable t) {
        super(msg, t);
    }
}
