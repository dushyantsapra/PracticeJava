package com.nwm.xmart.streaming.source.kdb.session;

import com.nwm.xmart.streaming.source.kdb.exception.KDBSessionException;
import com.nwm.xmart.streaming.source.mdx.session.MDXSessionType;
import com.nwm.xmart.util.MDCUtil;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.util.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import rbs.gbm.mdx.Analytics.AnalyticSessionFactory;
import rbs.gbm.mdx.Analytics.IAnalyticsSession;
import rbs.gbm.mdx.utils.analytics.IAnalyticResult;
import rbs.gbm.mdx.utils.interfaces.IAnalyticRequestIdentifierBuilder;
import rbs.gbm.mdx.webService.interfaces.*;

import java.util.Map;
import java.util.concurrent.*;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

/**
 * Created by gardlex on 30/04/2018.
 */
public class KDBSession {

    private static Logger logger = LoggerFactory.getLogger(KDBSession.class);
    private volatile IAnalyticsSession analyticsSession;
    private volatile IMdxDailyAnalyticSession mdxDailyAnalyticsSession;
    private volatile IAnalyticRequestIdentifierBuilder analyticRequestIdentifierBuilder;
    private volatile String applicationName;
    private volatile String applicationVersion;
    private volatile String mdxEnvironmentName;
    private volatile String kdbEnvironmentName;
    private volatile String kdbFunctionName;
    private final ConcurrentMap<String,String> parameters = new ConcurrentHashMap<>();
    private volatile String kdbQuery;
    private volatile MDXSessionType kdbSessionType;
    private volatile String ssoToken;
    private ExecutorService executorService;
    private ParameterTool flinkParameters;

    public KDBSession() {
        this.executorService = Executors.newSingleThreadExecutor(
                new ThreadFactory() {
                    @Override
                    public Thread newThread(Runnable r) {
                        Thread t = new Thread(r);

                        t.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                            @Override
                            public void uncaughtException(Thread t, Throwable e) {
                                LoggerFactory.getLogger(t.getName()).error("KDBSession Thread for KdbSourceFunction [ " + kdbFunctionName + " ], is no longer running", e.getMessage(), e);
                            }
                        });

                        return t;
                    }
                }
        );
    }

    public KDBSession withApplicationName(String applicationName) {
        this.applicationName = applicationName;
        return this;
    }

    public KDBSession withApplicationVersion(String applicationVersion) {
        this.applicationVersion = applicationVersion;
        return this;
    }

    public KDBSession withMdxEnvironmentName(String mdxEnvironmentName) {
        this.mdxEnvironmentName = mdxEnvironmentName;
        return this;
    }

    public KDBSession withKdbEnvironmentName(String kdbEnvironmentName) {
        this.kdbEnvironmentName = kdbEnvironmentName;
        return this;
    }

    public KDBSession withKdbFunctionName(String kdbFunctionName) {
        this.kdbFunctionName = kdbFunctionName;
        return this;
    }

    public KDBSession withParameter(String key, String value) {
        this.parameters.put(key, value);
        return this;
    }

    public KDBSession withKDBSessionType(MDXSessionType kdbSessionType) {
        this.kdbSessionType = kdbSessionType;
        return this;
    }

    public KDBSession withSSOToken(String ssoToken) {
        this.ssoToken = ssoToken;
        return this;
    }

    public KDBSession withIAnalyticRequestIdentifierBuilder(IAnalyticRequestIdentifierBuilder analyticRequestIdentifierBuilder) {
        this.analyticRequestIdentifierBuilder = analyticRequestIdentifierBuilder;
        return this;
    }

    public KDBSession withFlinkParameters(ParameterTool flinkParameters){
        this.flinkParameters = flinkParameters;
        return this;
    }

    public IAnalyticResult getMDXAccessKDBData() throws InterruptedException, ExecutionException {
        Future<IAnalyticResult> sessionFuture = executorService.submit(new Callable<IAnalyticResult>() {
            @Override
            public IAnalyticResult call() throws Exception {
                MDCUtil.putJobNameInMDC(flinkParameters);
                return analyticsSession.CallAnalytic(kdbQuery);
            }
        });
        return sessionFuture.get();
    }

    public boolean build() throws InterruptedException, ExecutionException {
        if (analyticsSession == null) {
            Future<IAnalyticsSession> sessionFuture = executorService.submit(new Callable<IAnalyticsSession>() {
                @Override
                public IAnalyticsSession call() throws Exception {
                    MDCUtil.putJobNameInMDC(flinkParameters);

                    IAnalyticsSession analyticSession = null;
                    switch (kdbSessionType) {
                        case SSO:
                            analyticSession = new AnalyticSessionFactory().createTickAnalyticSession(applicationName, applicationVersion, mdxEnvironmentName, ssoToken);
                            break;
                        case MDX_ACCESS:
                            analyticSession = new AnalyticSessionFactory().createTickAnalyticSession(applicationName, applicationVersion, mdxEnvironmentName);
                            break;
                        default:
                            throw new KDBSessionException("Unsupported kdbSessionType: " + kdbSessionType);
                    }

                    return analyticSession;
                }
            });

            try {
                analyticsSession = sessionFuture.get();
                if (analyticsSession == null) {
                    return false;
                }
            } catch (InterruptedException | ExecutionException e) {
                Thread.currentThread().interrupt();
                analyticsSession = null;
                logger.error("Creation of IAnalyticsSession was interrupted", e);
                executorService.shutdownNow();
                throw e;
            } catch (Exception f) {
                analyticsSession = null;
                logger.error("Creation of IAnalyticsSession caused Exception", f);
                return false;
            }
        }

        // Construct builder
        analyticRequestIdentifierBuilder
                .environment(kdbEnvironmentName)
                .function(kdbFunctionName);
        for (Map.Entry<String, String> entry : parameters.entrySet()) {
            analyticRequestIdentifierBuilder
                    .parameter(entry.getKey(), entry.getValue());
        }
        kdbQuery = analyticRequestIdentifierBuilder.build();

        return true;
    }

    public void close() {
        if (!executorService.isShutdown() || !executorService.isTerminated()) {
            try {
                executorService.shutdownNow();
            } catch (Exception e) {
                logger.warn("close() : could not shutdown executorService cleanly, however Flink Job will be terminated");
            }
        }
    }

    public String getKdbFunctionName() {
        return kdbFunctionName;
    }
}
