
package com.nwm.xmart.streaming.source.rdx.json;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "RdxType",
    "Status",
    "RdxChangeId",
    "Facets",
    "ProxySeriesIds",
    "RdxId",
    "RdxSeriesId",
    "ValuationDate",
    "Version"
})
public class RdxFixedIncome {

    @JsonProperty("RdxType")
    private RdxType rdxType;
    @JsonProperty("Status")
    private String status;
    @JsonProperty("RdxChangeId")
    private Integer rdxChangeId;
    @JsonProperty("Facets")
    private Facets facets;
    @JsonProperty("ProxySeriesIds")
    private List<Object> proxySeriesIds = new ArrayList<Object>();
    @JsonProperty("RdxId")
    private String rdxId;
    @JsonProperty("RdxSeriesId")
    private String rdxSeriesId;
    @JsonProperty("ValuationDate")
    private String valuationDate;
    @JsonProperty("Version")
    private Integer version;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("RdxType")
    public RdxType getRdxType() {
        return rdxType;
    }

    @JsonProperty("RdxType")
    public void setRdxType(RdxType rdxType) {
        this.rdxType = rdxType;
    }

    @JsonProperty("Status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("RdxChangeId")
    public Integer getRdxChangeId() {
        return rdxChangeId;
    }

    @JsonProperty("RdxChangeId")
    public void setRdxChangeId(Integer rdxChangeId) {
        this.rdxChangeId = rdxChangeId;
    }

    @JsonProperty("Facets")
    public Facets getFacets() {
        return facets;
    }

    @JsonProperty("Facets")
    public void setFacets(Facets facets) {
        this.facets = facets;
    }

    @JsonProperty("ProxySeriesIds")
    public List<Object> getProxySeriesIds() {
        return proxySeriesIds;
    }

    @JsonProperty("ProxySeriesIds")
    public void setProxySeriesIds(List<Object> proxySeriesIds) {
        this.proxySeriesIds = proxySeriesIds;
    }

    @JsonProperty("RdxId")
    public String getRdxId() {
        return rdxId;
    }

    @JsonProperty("RdxId")
    public void setRdxId(String rdxId) {
        this.rdxId = rdxId;
    }

    @JsonProperty("RdxSeriesId")
    public String getRdxSeriesId() {
        return rdxSeriesId;
    }

    @JsonProperty("RdxSeriesId")
    public void setRdxSeriesId(String rdxSeriesId) {
        this.rdxSeriesId = rdxSeriesId;
    }

    @JsonProperty("ValuationDate")
    public String getValuationDate() {
        return valuationDate;
    }

    @JsonProperty("ValuationDate")
    public void setValuationDate(String valuationDate) {
        this.valuationDate = valuationDate;
    }

    @JsonProperty("Version")
    public Integer getVersion() {
        return version;
    }

    @JsonProperty("Version")
    public void setVersion(Integer version) {
        this.version = version;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("rdxType", rdxType).append("status", status).append("rdxChangeId", rdxChangeId).append("facets", facets).append("proxySeriesIds", proxySeriesIds).append("rdxId", rdxId).append("rdxSeriesId", rdxSeriesId).append("valuationDate", valuationDate).append("version", version).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(valuationDate).append(proxySeriesIds).append(rdxId).append(rdxChangeId).append(rdxSeriesId).append(additionalProperties).append(version).append(rdxType).append(status).append(facets).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RdxFixedIncome) == false) {
            return false;
        }
        RdxFixedIncome rhs = ((RdxFixedIncome) other);
        return new EqualsBuilder().append(valuationDate, rhs.valuationDate).append(proxySeriesIds, rhs.proxySeriesIds).append(rdxId, rhs.rdxId).append(rdxChangeId, rhs.rdxChangeId).append(rdxSeriesId, rhs.rdxSeriesId).append(additionalProperties, rhs.additionalProperties).append(version, rhs.version).append(rdxType, rhs.rdxType).append(status, rhs.status).append(facets, rhs.facets).isEquals();
    }

}
