package com.nwm.xmart.streaming.example;

import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.rbs.datafabric.api.exception.InsertException;
import com.rbs.datafabric.client.DataFabricClient;
import com.rbs.datafabric.client.DataFabricClientFactory;
import com.rbs.datafabric.common.DataFabricSerializerException;
import com.rbs.datafabric.domain.ClientConfiguration;
import com.rbs.datafabric.domain.Credentials;
import com.rbs.datafabric.domain.Document;
import com.rbs.datafabric.domain.client.builder.InsertRequestBuilder;
import com.rbs.odc.access.domain.TransactionId;
import com.rbs.odc.core.domain.ODCValue;
import com.rbs.odc.core.domain.TransactionImpl;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.nwm.xmart.sso.EncryptDecryptAES;

import java.util.Objects;

/**
 * Created by gardlex on 21/09/2017.
 */
public class ExampleOdcDFSink extends RichSinkFunction<DataFabricStreamEvent<ODCValue>> {

    private static final Logger logger = LoggerFactory.getLogger(ExampleOdcDFSink.class);

    private DataFabricClient dataFabricClient;
    private final String database;
    private final String collection;
    private final Configuration configuration;

    public ExampleOdcDFSink(Configuration configuration) {
        this.configuration = configuration;

        this.database = configuration.getString("operator.datafabric.sink.database", "");
        this.collection = configuration.getString("operator.datafabric.sink.collection", "");
    }

    @Override
    public void invoke(DataFabricStreamEvent<ODCValue> trade) throws Exception {
        try {
            TransactionId transactionId = (TransactionId)trade.getEventPayload().getId();
            TransactionImpl transaction = (TransactionImpl)trade.getEventPayload().getDomainObject();
            BDXSinkData bdxSinkData = new BDXSinkData(
                    transaction.getVersion(),
                    transaction.getId().getSourceSystemTransactionId(),
                    Objects.toString(transaction.getId().getSourceSystemId()));
            Document document = dataFabricClient.getDataFabricSerializer().serialize(bdxSinkData);
            dataFabricClient.insert(InsertRequestBuilder.create(database, collection).withDocument(document));
        } catch (DataFabricSerializerException | InsertException e) {
            logger.error("Exception ", e);
        }
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        ClientConfiguration clientConfiguration = new ClientConfiguration().withCredentials(
                new Credentials().withUsername(configuration.getString("error.datafabric.credentials.username", ""))
                                 .withPassword(EncryptDecryptAES.decrypt(
                                         configuration.getString("error.datafabric.credentials.password", ""))))
                                                                           .withHost(configuration.getString(
                                                                                   "error.datafabric.credentials.host",
                                                                                   "")).withAccessToken(
                        EncryptDecryptAES.decrypt(configuration.getString("error.datafabric.credentials.accesstoken",
                                "")));

        dataFabricClient = DataFabricClientFactory.createDataFabricClient(clientConfiguration);
    }

    @Override
    public void close() throws Exception {
        super.close();
        dataFabricClient.close();
    }

}
