package com.nwm.xmart.streaming.source.mdx.event;

/**
 * Created by gardlex on 19/04/2018.
 */
public enum MdxEventType {
    SERIES_VIEW, TIME_SERIES;
}
