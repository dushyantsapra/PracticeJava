package com.nwm.xmart.streaming.source.rdx.event;

import com.nwm.xmart.streaming.source.mdx.event.ProcessingType;
import com.nwm.xmart.streaming.source.rdx.json.RdxFixedIncome;
import rbs.gbm.dx.webService.impl.DxValuationDate;

/**
 * Created by gardlex on 26/03/2018.
 */
public class RDXSourceEvent {
    private final RdxFixedIncome rdxFixedIncome;
    private final long changeID;
    private final String rdxId;
    private final String rdxSeriesId;
    private final DxValuationDate valuationDate;
    private final int version;
    private final ProcessingType processingType;
    private long timeReceivedFromSource;

    public RDXSourceEvent(RdxFixedIncome rdxFixedIncome, long changeID, String rdxId, String rdxSeriesId, DxValuationDate valuationDate, int version, ProcessingType processingType, long timeReceivedFromSource) {
        this.rdxFixedIncome = rdxFixedIncome;
        this.changeID = changeID;
        this.rdxId = rdxId;
        this.rdxSeriesId = rdxSeriesId;
        this.valuationDate = valuationDate;
        this.version = version;
        this.processingType = processingType;
        this.timeReceivedFromSource = timeReceivedFromSource;
    }

    public RdxFixedIncome getRdxFixedIncome() {
        return rdxFixedIncome;
    }

    public long getChangeID() {
        return changeID;
    }

    public String getRdxId() {
        return rdxId;
    }

    public String getRdxSeriesId() {
        return rdxSeriesId;
    }

    public DxValuationDate getValuationDate() {
        return valuationDate;
    }

    public int getVersion() {
        return version;
    }

    public ProcessingType getProcessingType() {
        return processingType;
    }

    public long getTimeReceivedFromSource() {
        return timeReceivedFromSource;
    }
}
