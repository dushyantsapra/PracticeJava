package com.nwm.xmart.streaming.database.statements;

import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerConnection;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.CallableStatement;
import java.sql.SQLException;

/**
 * THIS IS A SLIM COPY OF THE SAME CLASS IN APP-STREAMING
 * THIS IS ONLY INTENDED TO BE USED UNTIL WE MERGE THE TWO PROJECTS
 */
public abstract class XmartStatement {

    private static final long serialVersionUID = 8548391047048079120L;
    private static final Logger logger = LoggerFactory.getLogger(XmartStatement.class);

    protected String PROC_COMMAND;
    protected String statementName;

    protected SQLServerCallableStatement preparedStatement;

    public void open(SQLServerConnection connection) throws SQLServerException {
        logger.debug("Opening Xmart prepared statement - {}", statementName);
        preparedStatement = (SQLServerCallableStatement) connection.prepareCall(PROC_COMMAND);
    }

    public void close(){
        logger.debug("Closing XMart prepared statement - {}", statementName);
        try {
            preparedStatement.close();
        } catch (SQLServerException e) {
            logger.warn("Closing XMart prepared statement failed - {}", statementName, e);
        }
    }

    public void clearPreparedStatement() throws SQLException {
        preparedStatement.clearParameters();
    }

    public String getName(){
        return statementName;
    }

    public abstract SQLServerCallableStatement getPreparedStatement(Object object) throws SQLException;

}

