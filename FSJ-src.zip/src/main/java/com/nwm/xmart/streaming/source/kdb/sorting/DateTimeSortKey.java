package com.nwm.xmart.streaming.source.kdb.sorting;

import com.nwm.xmart.streaming.source.kdb.exception.KDBMatrixDataParsingException;

import java.sql.Date;
import java.sql.Time;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by gardlex on 01/05/2018.
 */
public class DateTimeSortKey implements SortKeyI {

    private final Object[] sortKeyValues;
    private final int[] columnSortKeyIndexes;
    private long epochMillisSortKey;


    public DateTimeSortKey(int[] columnSortKeyIndexes) {
        this.columnSortKeyIndexes = columnSortKeyIndexes;
        sortKeyValues = new Object[columnSortKeyIndexes.length];
    }

    @Override
    public int[] getColumnSortKeyIndexes() {
        return Arrays.copyOf(columnSortKeyIndexes, columnSortKeyIndexes.length);
    }

    @Override
    public void setSortKeyColumnValue(Object o, int index) {
        boolean indexIsValid = false;

        int indexPosn = 0;
        for (int sortKeyIndex : columnSortKeyIndexes) {
            if (sortKeyIndex == index) {
                sortKeyValues[indexPosn] = o;
                indexIsValid = true;
            }
            indexPosn++;
        }

        if (!indexIsValid) {
            throw new KDBMatrixDataParsingException("Valid column indexes for this sort key are [ " + columnSortKeyIndexes + " ]");
        }
    }

    @Override
    public Object getSortKeyValue() {
        // check sort key values complete
        if (!(sortKeyValues[0] != null && sortKeyValues[1] != null)) {
            List<Integer> missingKeyColumns = new ArrayList<>();

            for (int i=0; i < 2; i++) {
                if (sortKeyValues[i] == null) {
                    missingKeyColumns.add(i);
                }
            }
            throw new KDBMatrixDataParsingException("Sort Key cannot be generated: missing key values [ " + missingKeyColumns + " ]");
        }
        Instant instant = null;
        try {
            instant = Instant.parse((Date)sortKeyValues[0] + "T" + (Time)sortKeyValues[1] + ".00z");
        } catch (Exception e) {
            throw new KDBMatrixDataParsingException("Could not parse time from the sorted key value "
                    +sortKeyValues[0]+" "+sortKeyValues[1], e);

        }
        epochMillisSortKey = instant.toEpochMilli();

        return epochMillisSortKey;
    }

    @Override
    public Object[] getSortKeyIndexValues() {
        return sortKeyValues;
    }

    @Override
    public boolean isSortKeyIndex(int index) {
        for (int sortKeyIndex : columnSortKeyIndexes) {
            if (sortKeyIndex == index) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "Date: " + (Date)sortKeyValues[0] + " Time: " + (Time)sortKeyValues[1];
    }
}
