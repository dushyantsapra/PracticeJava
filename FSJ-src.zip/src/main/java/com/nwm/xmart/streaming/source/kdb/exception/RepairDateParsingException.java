package com.nwm.xmart.streaming.source.kdb.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class RepairDateParsingException extends RuntimeException {

    public RepairDateParsingException() {
        super();
    }

    public RepairDateParsingException(String msg) {
        super(msg);
    }

    public RepairDateParsingException(String msg, Throwable t) {
        super(msg, t);
    }
}
