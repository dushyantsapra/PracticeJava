package com.nwm.xmart.streaming.source.df.event;

/**
 * Created by gardlex on 26/10/2017.
 */
public class DataFabricStreamEvent<T> extends StreamEvent<T> {

    public DataFabricStreamEvent(T payload, long timestamp, String topic, int partition, long streamPosition, String dfKey, long dfVersion) {
        super(payload, timestamp, topic, partition, streamPosition, dfKey, dfVersion);
    }
}
