package com.nwm.xmart.streaming.source.kdb.data;

/**
 * Created by gardlex on 26/06/2018.
 */
public class ProcessingResult {
    private boolean validKDResponseStatus;
    private boolean kdbDataAvailable;
    private boolean dataProcessedSuccessfully;

    public ProcessingResult(boolean validKDResponseStatus, boolean kdbDataAvailable) {
        this.validKDResponseStatus = validKDResponseStatus;
        this.kdbDataAvailable = kdbDataAvailable;
        this.dataProcessedSuccessfully = dataProcessedSuccessfully;
    }

    public boolean isValidKDResponseStatus() {
        return validKDResponseStatus;
    }

    public boolean isKdbDataAvailable() {
        return kdbDataAvailable;
    }

    public void setDataProcessedSuccessfully(boolean dataProcessedSuccessfully) {
        this.dataProcessedSuccessfully = dataProcessedSuccessfully;
    }

    public boolean isDataProcessedSuccessfully() {
        return dataProcessedSuccessfully;
    }
}
