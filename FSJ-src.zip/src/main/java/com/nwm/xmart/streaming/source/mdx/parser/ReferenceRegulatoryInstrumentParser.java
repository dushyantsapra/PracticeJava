package com.nwm.xmart.streaming.source.mdx.parser;

import com.nwm.xmart.streaming.source.mdx.entity.*;
import com.nwm.xmart.streaming.util.XmlXPathParser;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import rbs.gbm.mdx.webService.interfaces.IMdxDocument;

import java.math.BigDecimal;
import java.util.Date;

public class ReferenceRegulatoryInstrumentParser {

    public static RefRegInstrument buildRefRegInstrument(IMdxDocument iMdxDocument) {
        RefRegInstrument refRegInstrument = null;

        NodeList templateVersionList = XmlXPathParser
                .getAttributeNodeList(iMdxDocument.getContent().asString(), "Instrument/TemplateVersion");
        refRegInstrument = parseInstrumentHeader(iMdxDocument);
        parseInstrumentHeaderFields(iMdxDocument, refRegInstrument);
        parseInstrumentAttributesFields(iMdxDocument, refRegInstrument);
        parseInstrumentIsinFields(iMdxDocument, refRegInstrument);
        refRegInstrument.setTemplateVersion(Integer.valueOf(templateVersionList.item(0).getTextContent()));
        parseInstrumentDerivedFields(iMdxDocument, refRegInstrument);
        return refRegInstrument;
    }

    static RefRegInstrument parseInstrumentHeader(IMdxDocument iMdxDocument) {
        RefRegInstrument refRegInstrument = null;

        String mdxTransport = iMdxDocument.getHeader().getTransport();
        String mdxTypeName = iMdxDocument.getHeader().getTypeName();
        String mdxPath = iMdxDocument.getHeader().getPath();
        Integer mdxDocumentVersion = iMdxDocument.getHeader().getVersion();
        String mdxValuationDate = null;
        if (iMdxDocument.getHeader().getValuationDate() != null) {
            mdxValuationDate = iMdxDocument.getHeader().getValuationDate().getYear() + "-" + iMdxDocument.getHeader()
                                                                                                         .getValuationDate()
                                                                                                         .getMonth()
                    + "-" + iMdxDocument.getHeader().getValuationDate().getDay();
        }

        Date mdxWrittenOnUTC = iMdxDocument.getHeader().getWriteTime();

        String xmlWriteTime = iMdxDocument.getHeader().getXmlWriteTime();

        refRegInstrument = new RefRegInstrument(mdxTransport, mdxTypeName, mdxPath, mdxDocumentVersion, mdxWrittenOnUTC,
                mdxValuationDate, xmlWriteTime);
        return refRegInstrument;
    }

    static void parseInstrumentHeaderFields(IMdxDocument iMdxDocument, RefRegInstrument refRegInstrument) {
        NodeList headerNodeList = XmlXPathParser
                .getAttributeNodeList(iMdxDocument.getContent().asString(), "Instrument/Header");

        RefRegInstrumentHeaderFields refRegInstrumentHeaderFields = new RefRegInstrumentHeaderFields();
        refRegInstrument.setRefRegInstrumentHeaderFields(refRegInstrumentHeaderFields);
        NodeList childNodes = headerNodeList.item(0).getChildNodes();
        for (int iLoop = 0; iLoop < childNodes.getLength(); iLoop++) {
            Node headerChildNode = childNodes.item(iLoop);
            switch (headerChildNode.getNodeName()) {
            case "AssetClass":
                refRegInstrumentHeaderFields.setAssetClass(headerChildNode.getTextContent());
                break;
            case "InstrumentType":
                refRegInstrumentHeaderFields.setInstrumentType(headerChildNode.getTextContent());
                break;
            case "UseCase":
                refRegInstrumentHeaderFields.setUseCase(headerChildNode.getTextContent());
                break;
            case "Level":
                refRegInstrumentHeaderFields.setLevel(headerChildNode.getTextContent());
                break;
            }
        }
    }

    static void parseInstrumentGenericFields(NodeList nodeList,
            RefRegInstrumentGenericFields refRegInstrumentGenericFields) {
        Node node = nodeList.item(0);
        if (node.getNodeType() != Node.ELEMENT_NODE) {
            return;
        }

        NodeList nodeChildList = node.getChildNodes();
        for (int nodeChildLoop = 0; nodeChildLoop < nodeChildList.getLength(); nodeChildLoop++) {
            Node childNode = nodeChildList.item(nodeChildLoop);
            switch (childNode.getNodeName()) {
            case "NotionalCurrency":
                refRegInstrumentGenericFields.setNotionalCurrency(childNode.getTextContent());
                break;
            case "ExpiryDate":
                refRegInstrumentGenericFields.setExpiryDate(childNode.getTextContent());
                break;
            case "ReferenceRate":
                refRegInstrumentGenericFields.setReferenceRate(childNode.getTextContent());
                break;
            case "ReferenceRateTermValue":
                refRegInstrumentGenericFields.setReferenceRateTermValue(new BigDecimal(childNode.getTextContent()));
                break;
            case "ReferenceRateTermUnit":
                refRegInstrumentGenericFields.setReferenceRateTermUnit(childNode.getTextContent());
                break;
            case "NotionalSchedule":
                refRegInstrumentGenericFields.setNotionalSchedule(childNode.getTextContent());
                break;
            case "DeliveryType":
                refRegInstrumentGenericFields.setDeliveryType(childNode.getTextContent());
                break;
            case "PriceMultiplier":
                refRegInstrumentGenericFields.setPriceMultiplier(new BigDecimal(childNode.getTextContent()));
                break;
            case "OptionType":
                refRegInstrumentGenericFields.setOptionType(childNode.getTextContent());
                break;
            case "OtherNotionalCurrency":
                refRegInstrumentGenericFields.setOtherNotionalCurrency(childNode.getTextContent());
                break;
            case "OptionExerciseStyle":
                refRegInstrumentGenericFields.setOptionExerciseStyle(childNode.getTextContent());
                break;
            case "ValuationMethodorTrigger":
                refRegInstrumentGenericFields.setValuationMethodorTrigger(childNode.getTextContent());
                break;
            case "SettlementCurrency":
                refRegInstrumentGenericFields.setSettlementCurrency(childNode.getTextContent());
                break;
            case "ReturnorPayoutTrigger":
                refRegInstrumentGenericFields.setReturnorPayoutTrigger(childNode.getTextContent());
                break;
            case "DebtSeniority":
                refRegInstrumentGenericFields.setDebtSeniority(childNode.getTextContent());
                break;
            case "StrikePrice":
                refRegInstrumentGenericFields.setStrikePrice(childNode.getTextContent());
                break;
            case "BaseProduct":
                refRegInstrumentGenericFields.setBaseProduct(childNode.getTextContent());
                break;
            case "SubProduct":
                refRegInstrumentGenericFields.setSubProduct(childNode.getTextContent());
                break;
            case "AdditionalSubProduct":
                refRegInstrumentGenericFields.setAdditionalSubProduct(childNode.getTextContent());
                break;
            case "TransactionType":
                refRegInstrumentGenericFields.setTransactionType(childNode.getTextContent());
                break;
            case "FinalPriceType":
                refRegInstrumentGenericFields.setFinalPriceType(childNode.getTextContent());
                break;
            case "OtherBaseProduct":
                refRegInstrumentGenericFields.setOtherBaseProduct(childNode.getTextContent());
                break;
            case "OtherSubProduct":
                refRegInstrumentGenericFields.setOtherSubProduct(childNode.getTextContent());
                break;
            case "OtherAdditionalSubProduct":
                refRegInstrumentGenericFields.setOtherAdditionalSubProduct(childNode.getTextContent());
                break;
            case "OtherReferenceRate":
                refRegInstrumentGenericFields.setOtherReferenceRate(childNode.getTextContent());
                break;
            case "InstrumentISINNearLeg":
                refRegInstrumentGenericFields.setInstrumentISINNearLeg(childNode.getTextContent());
                break;
            case "InstrumentISINFarLeg":
                refRegInstrumentGenericFields.setInstrumentISINFarLeg(childNode.getTextContent());
                break;
            case "PlaceofSettlement":
                refRegInstrumentGenericFields.setPlaceofSettlement(childNode.getTextContent());
                break;
            case "UnderlyingAssetType":
                refRegInstrumentGenericFields.setUnderlyingAssetType(childNode.getTextContent());
                break;
            }
        }
    }

    static void parseInstrumentAttributesFields(IMdxDocument iMdxDocument, RefRegInstrument refRegInstrument) {
        RefRegInstrumentAttributesFields refRegInstrumentAttributesFields = new RefRegInstrumentAttributesFields();
        RefRegInstrumentGenericFields refRegInstrumentGenericFields = new RefRegInstrumentGenericFields();
        refRegInstrumentAttributesFields.setRefRegInstrumentGenericFields(refRegInstrumentGenericFields);
        refRegInstrument.setRefRegInstrumentAttributesFields(refRegInstrumentAttributesFields);

        NodeList attributesNodeList = XmlXPathParser
                .getAttributeNodeList(iMdxDocument.getContent().asString(), "Instrument/Attributes");
        parseInstrumentGenericFields(attributesNodeList, refRegInstrumentGenericFields);
    }

    static void parseInstrumentIsinFields(IMdxDocument iMdxDocument, RefRegInstrument refRegInstrument) {
        NodeList isinNodeList = XmlXPathParser
                .getAttributeNodeList(iMdxDocument.getContent().asString(), "Instrument/ISIN");

        RefRegInstrumentIsinFields refRegInstrumentIsinFields = new RefRegInstrumentIsinFields();
        refRegInstrument.setRefRegInstrumentIsinFields(refRegInstrumentIsinFields);
        Node isinNode = isinNodeList.item(0);
        if (isinNode.getNodeType() != Node.ELEMENT_NODE) {
            return;
        }

        NodeList isinChildNodeList = isinNode.getChildNodes();
        for (int isinChildNodeLoop = 0; isinChildNodeLoop < isinChildNodeList.getLength(); isinChildNodeLoop++) {
            Node isinChildNode = isinChildNodeList.item(isinChildNodeLoop);
            switch (isinChildNode.getNodeName()) {
            case "ISIN":
                refRegInstrumentIsinFields.setiSIN(isinChildNode.getTextContent());
                break;
            case "Status":
                refRegInstrumentIsinFields.setStatus(isinChildNode.getTextContent());
                break;
            case "StatusReason":
                refRegInstrumentIsinFields.setStatusReason(isinChildNode.getTextContent());
                break;
            case "LastUpdateDateTime":
                refRegInstrumentIsinFields.setLastUpdateDateTime(isinChildNode.getTextContent());
                break;
            }
        }
    }

    static void parseInstrumentDerivedFields(IMdxDocument iMdxDocument, RefRegInstrument refRegInstrument) {
        NodeList derivedNodeList = XmlXPathParser
                .getAttributeNodeList(iMdxDocument.getContent().asString(), "Instrument/Derived");

        RefRegInstrumentDerivedFields refRegInstrumentDerivedFields = new RefRegInstrumentDerivedFields();
        RefRegInstrumentGenericFields refRegInstrumentGenericFields = new RefRegInstrumentGenericFields();
        refRegInstrumentDerivedFields.setRefRegInstrumentGenericFields(refRegInstrumentGenericFields);
        refRegInstrument.setRefRegInstrumentDerivedFields(refRegInstrumentDerivedFields);

        parseInstrumentGenericFields(derivedNodeList, refRegInstrumentGenericFields);
        Node derivedNode = derivedNodeList.item(0);
        if (derivedNode.getNodeType() != Node.ELEMENT_NODE) {
            return;
        }

        NodeList derivedChildNodeList = derivedNode.getChildNodes();
        for (int derivedChildNodeLoop = 0; derivedChildNodeLoop < derivedChildNodeList.getLength();
             derivedChildNodeLoop++) {
            Node derivedChildNode = derivedChildNodeList.item(derivedChildNodeLoop);
            switch (derivedChildNode.getNodeName()) {
            case "IssuerorOperatoroftheTradingVenueIdentifier":
                refRegInstrumentDerivedFields
                        .setIssuerorOperatoroftheTradingVenueIdentifier(derivedChildNode.getTextContent());
                break;
            case "CommodityDerivativeIndicator":
                refRegInstrumentDerivedFields.setCommodityDerivativeIndicator(derivedChildNode.getTextContent());
                break;
            case "FXType":
                refRegInstrumentDerivedFields.setfXType(derivedChildNode.getTextContent());
                break;
            case "FullName":
                refRegInstrumentDerivedFields.setFullName(derivedChildNode.getTextContent());
                break;
            case "ShortName":
                refRegInstrumentDerivedFields.setDerivedShortName(derivedChildNode.getTextContent());
                break;
            case "ClassificationType":
                refRegInstrumentDerivedFields.setClassificationType(derivedChildNode.getTextContent());
                break;
            case "ISOReferenceRate":
                refRegInstrumentDerivedFields.setiSOReferenceRate(derivedChildNode.getTextContent());
                break;
            case "SingleorMultiCurrency":
                refRegInstrumentDerivedFields.setSingleorMultiCurrency(derivedChildNode.getTextContent());
                break;
            }
        }
    }
}
