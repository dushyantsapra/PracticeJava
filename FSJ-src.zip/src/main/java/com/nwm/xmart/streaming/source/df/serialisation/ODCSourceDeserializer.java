package com.nwm.xmart.streaming.source.df.serialisation;

import com.nwm.xmart.streaming.error.exception.DeserialisationException;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import com.rbs.datafabric.domain.Record;
import com.rbs.datafabric.domain.event.RecordModifiedEvent;
import com.rbs.odc.datafabric.OdcDataFabricRecordSerialiser;
import com.rbs.odc.datafabric.OdcTypeUtils;
import com.rbs.odc.datafabric.wrapper.DataFabricTypeReference;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by gardlex on 30/10/2017.
 */
public class ODCSourceDeserializer implements SourceDeserializer {

    private static Logger logger = LoggerFactory.getLogger(DFSourceDeserializer.class);
    private OdcDataFabricRecordSerialiser odcDataFabricRecordSerialiser;
    private final DataFabricTypeReference dataFabricTypeReference;
    private final DataFabricUtil dataFabricUtil;

    public ODCSourceDeserializer(DataFabricUtil dataFabricUtil, Configuration configuration) {
        this.dataFabricUtil = dataFabricUtil;

        // Define the ODC domain types
        try {
            Class idType = Class.forName(configuration.getString("flink.datafabric.client.odc.serialiser.idType.class", ""));
            Class domainType = Class.forName(configuration.getString("flink.datafabric.client.odc.serialiser.domainType.class", ""));
            dataFabricTypeReference = OdcTypeUtils.odcValueType(idType, domainType);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("ODCSourceDeserializer Error instantiating typeReference", e);
        }
    }

    @Override
    public  <Target> Target deserialize(RecordModifiedEvent rme, Class<Target> targetClass) {
        Target target = null;

        try {
            checkDataFabricInstanceExists();
            target =  (Target) odcDataFabricRecordSerialiser.deserialise(rme.getRecord(), dataFabricTypeReference);
        } catch (Exception e) {
            logger.error("ODCSourceDeserializer error", e);
            throw new DeserialisationException("ODCSourceDeserializer: could not deserialise DF Record", e);
        }

        return target;
    }

    @Override
    public  <Target> Target deserialize(Record record, Class<Target> targetClass) {
        Target target = null;

        try {
            checkDataFabricInstanceExists();
            target =  (Target) odcDataFabricRecordSerialiser.deserialise(record, dataFabricTypeReference);
        } catch (Exception e) {
            logger.error("ODCSourceDeserializer error", e);
            throw new DeserialisationException("ODCSourceDeserializer: could not deserialise DF Record", e);
        }

        return target;
    }

    private void checkDataFabricInstanceExists() {
        if (odcDataFabricRecordSerialiser == null) {
            this.odcDataFabricRecordSerialiser = dataFabricUtil.getODCDeserializerInstance();
        }
    }
}
