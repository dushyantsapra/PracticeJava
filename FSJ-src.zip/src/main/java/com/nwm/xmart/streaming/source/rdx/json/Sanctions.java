
package com.nwm.xmart.streaming.source.rdx.json;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "IsCanadaSanctioned",
    "IsEUSanctioned",
    "IsHongKongSanctioned",
    "IsJapanSanctioned",
    "IsOFACSanctioned",
    "IsSanctioned",
    "IsSingaporeSanctioned",
    "IsUKSanctioned",
    "IsUNSanctioned"
})
public class Sanctions {

    @JsonProperty("IsCanadaSanctioned")
    private String isCanadaSanctioned;
    @JsonProperty("IsEUSanctioned")
    private String isEUSanctioned;
    @JsonProperty("IsHongKongSanctioned")
    private String isHongKongSanctioned;
    @JsonProperty("IsJapanSanctioned")
    private String isJapanSanctioned;
    @JsonProperty("IsOFACSanctioned")
    private String isOFACSanctioned;
    @JsonProperty("IsSanctioned")
    private String isSanctioned;
    @JsonProperty("IsSingaporeSanctioned")
    private String isSingaporeSanctioned;
    @JsonProperty("IsUKSanctioned")
    private String isUKSanctioned;
    @JsonProperty("IsUNSanctioned")
    private String isUNSanctioned;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("IsCanadaSanctioned")
    public String getIsCanadaSanctioned() {
        return isCanadaSanctioned;
    }

    @JsonProperty("IsCanadaSanctioned")
    public void setIsCanadaSanctioned(String isCanadaSanctioned) {
        this.isCanadaSanctioned = isCanadaSanctioned;
    }

    @JsonProperty("IsEUSanctioned")
    public String getIsEUSanctioned() {
        return isEUSanctioned;
    }

    @JsonProperty("IsEUSanctioned")
    public void setIsEUSanctioned(String isEUSanctioned) {
        this.isEUSanctioned = isEUSanctioned;
    }

    @JsonProperty("IsHongKongSanctioned")
    public String getIsHongKongSanctioned() {
        return isHongKongSanctioned;
    }

    @JsonProperty("IsHongKongSanctioned")
    public void setIsHongKongSanctioned(String isHongKongSanctioned) {
        this.isHongKongSanctioned = isHongKongSanctioned;
    }

    @JsonProperty("IsJapanSanctioned")
    public String getIsJapanSanctioned() {
        return isJapanSanctioned;
    }

    @JsonProperty("IsJapanSanctioned")
    public void setIsJapanSanctioned(String isJapanSanctioned) {
        this.isJapanSanctioned = isJapanSanctioned;
    }

    @JsonProperty("IsOFACSanctioned")
    public String getIsOFACSanctioned() {
        return isOFACSanctioned;
    }

    @JsonProperty("IsOFACSanctioned")
    public void setIsOFACSanctioned(String isOFACSanctioned) {
        this.isOFACSanctioned = isOFACSanctioned;
    }

    @JsonProperty("IsSanctioned")
    public String getIsSanctioned() {
        return isSanctioned;
    }

    @JsonProperty("IsSanctioned")
    public void setIsSanctioned(String isSanctioned) {
        this.isSanctioned = isSanctioned;
    }

    @JsonProperty("IsSingaporeSanctioned")
    public String getIsSingaporeSanctioned() {
        return isSingaporeSanctioned;
    }

    @JsonProperty("IsSingaporeSanctioned")
    public void setIsSingaporeSanctioned(String isSingaporeSanctioned) {
        this.isSingaporeSanctioned = isSingaporeSanctioned;
    }

    @JsonProperty("IsUKSanctioned")
    public String getIsUKSanctioned() {
        return isUKSanctioned;
    }

    @JsonProperty("IsUKSanctioned")
    public void setIsUKSanctioned(String isUKSanctioned) {
        this.isUKSanctioned = isUKSanctioned;
    }

    @JsonProperty("IsUNSanctioned")
    public String getIsUNSanctioned() {
        return isUNSanctioned;
    }

    @JsonProperty("IsUNSanctioned")
    public void setIsUNSanctioned(String isUNSanctioned) {
        this.isUNSanctioned = isUNSanctioned;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("isCanadaSanctioned", isCanadaSanctioned).append("isEUSanctioned", isEUSanctioned).append("isHongKongSanctioned", isHongKongSanctioned).append("isJapanSanctioned", isJapanSanctioned).append("isOFACSanctioned", isOFACSanctioned).append("isSanctioned", isSanctioned).append("isSingaporeSanctioned", isSingaporeSanctioned).append("isUKSanctioned", isUKSanctioned).append("isUNSanctioned", isUNSanctioned).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(isCanadaSanctioned).append(isEUSanctioned).append(isHongKongSanctioned).append(isJapanSanctioned).append(isOFACSanctioned).append(isSanctioned).append(isSingaporeSanctioned).append(isUKSanctioned).append(isUNSanctioned).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Sanctions) == false) {
            return false;
        }
        Sanctions rhs = ((Sanctions) other);
        return new EqualsBuilder().append(isCanadaSanctioned, rhs.isCanadaSanctioned).append(isEUSanctioned, rhs.isEUSanctioned).append(isHongKongSanctioned, rhs.isHongKongSanctioned).append(isJapanSanctioned, rhs.isJapanSanctioned).append(isOFACSanctioned, rhs.isOFACSanctioned).append(isSanctioned, rhs.isSanctioned).append(isSingaporeSanctioned, rhs.isSingaporeSanctioned).append(isUKSanctioned, rhs.isUKSanctioned).append(isUNSanctioned, rhs.isUNSanctioned).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
