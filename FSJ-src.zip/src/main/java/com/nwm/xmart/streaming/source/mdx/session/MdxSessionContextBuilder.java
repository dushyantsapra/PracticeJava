package com.nwm.xmart.streaming.source.mdx.session;

import rbs.gbm.mdx.webService.interfaces.*;

import java.util.concurrent.atomic.AtomicReference;

/**
 * Created by gardlex on 20/04/2018.
 */
public class MdxSessionContextBuilder {
    private volatile String applicationName;
    private volatile String applicationVersion;
    private volatile String mdxEnvironmentName;
    private volatile int timeout;
    private volatile String ssoToken;
    private AtomicReference<IMdxSession> mdxSeriesViewSession = new AtomicReference<>();
    private AtomicReference<IMdxTimeSeriesSession> mdxTimeSeriesSession = new AtomicReference<>();
    private AtomicReference<IMdxSessionFactory> mdxSeriesViewSessionFactory = new AtomicReference<>();
    private AtomicReference<IMdxTimeSeriesSessionFactory> mdxTimeSeriesSessionFactory = new AtomicReference<>();

    public MdxSessionContextBuilder withMdxEnvironmentName(String mdxEnvironmentName) {
        this.mdxEnvironmentName = mdxEnvironmentName;
        return this;
    }

    public MdxSessionContextBuilder withApplicationVersion(String applicationVersion) {
        this.applicationVersion = applicationVersion;
        return this;
    }

    public MdxSessionContextBuilder withApplicationName(String applicationName) {
        this.applicationName = applicationName;
        return this;
    }

    public MdxSessionContextBuilder withMdxSessionTimeout(int timeout) {
        this.timeout = timeout;
        return this;
    }

    public MdxSessionContextBuilder withSeriesViewMdxSessionFactory(IMdxSessionFactory mdxSessionFactory) {
        this.mdxSeriesViewSessionFactory.set(mdxSessionFactory);
        return this;
    }

    public MdxSessionContextBuilder withTimeSeriesMdxSessionFactory(IMdxTimeSeriesSessionFactory timeSeriesMdxSessionFactory) {
        this.mdxTimeSeriesSessionFactory.set(timeSeriesMdxSessionFactory);
        return this;
    }

    public MdxSessionContextBuilder withSeriesViewMdxSession() throws Exception {
        final IMdxSession service = mdxSeriesViewSessionFactory.get().createSession(applicationName, applicationVersion, mdxEnvironmentName, SessionType.DEFAULT);
        service.setTimeoutInSeconds(timeout);
        mdxSeriesViewSession.set(service);
        return this;
    }

    public MdxSessionContextBuilder withSSOSeriesViewMdxSession() throws Exception {
        final IMdxSession service = mdxSeriesViewSessionFactory.get().createSession(applicationName, applicationVersion, mdxEnvironmentName, SessionType.DEFAULT, null, ssoToken);
        service.setTimeoutInSeconds(timeout);
        mdxSeriesViewSession.set(service);
        return this;
    }

    public MdxSessionContextBuilder withTimeSeriesMdxSession() throws Exception {
        final IMdxTimeSeriesSession service = mdxTimeSeriesSessionFactory.get().createSession(applicationName, applicationVersion, mdxEnvironmentName);
        mdxTimeSeriesSession.set(service);
        return this;
    }

    public MdxSessionContextBuilder withSSOTimeSeriesMdxSession() throws Exception {
        final IMdxTimeSeriesSession service = mdxTimeSeriesSessionFactory.get().createSession(applicationName, applicationVersion, mdxEnvironmentName, ssoToken);
        mdxTimeSeriesSession.set(service);
        return this;
    }

    public MdxSessionContextBuilder withSSOToken(String ssoToken) {
        this.ssoToken = ssoToken;
        return this;
    }

    public MdxSessionContext build() {
        MdxSessionContext sessionContext = new MdxSessionContext();
        sessionContext.setMdxSeriesViewSession(mdxSeriesViewSession.get());
        sessionContext.setMdxTimeSeriesSession(mdxTimeSeriesSession.get());

        return sessionContext;
    }
}
