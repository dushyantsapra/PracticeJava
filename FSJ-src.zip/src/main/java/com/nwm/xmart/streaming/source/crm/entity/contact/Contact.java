package com.nwm.xmart.streaming.source.crm.entity.contact;

import com.nwm.xmart.streaming.source.crm.entity.common.Account;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Account", "Account_Type", "All_Marketing_opt_out", "AssistantName", "AssistantPhone",
                     "Assistant_Email_Address", "Birthdate", "Bloomberg_Email_Address", "Business_Email_Address",
                     "Business_Phone", "Chat_Opt_Out", "Contact_note", "Country", "Coverage_Ids2", "Coverage_Ids3",
                     "Coverage_Ids4", "Coverage_Ids5", "Coverage_Ids6", "Coverage_Ids", "CreatedById", "CreatedDate",
                     "CTI_AssistantPhone", "CTI_Business_Phone", "CTI_MobilePhone", "CTI_Other_Phone_Number",
                     "Data_Migration_ID_Source", "Deactivated_By", "Deactivation_Date", "Dealer_Board_Direct_Line",
                     "Department", "Id", "Description", "Desk_Strategy_Opt_Out", "Division", "DoNotCall", "ECD_Id",
                     "Email", "EmailBouncedDate", "EmailBouncedReason", "Fax", "FirstName", "Greenwich_Voter",
                     "HasOptedOutOfEmail", "Home_Email", "HomePhone", "Incoming_Call_Number", "IsEmailBounced",
                     "Is_My_Coverage", "Jigsaw", "JigsawContactId", "Job_Role", "LastActivityDate", "LastCURequestDate",
                     "LastCUUpdateDate", "LastModifiedById", "LastModifiedDate", "LastName", "LeadSource",
                     "MailingAddress", "Mandate", "Marketing_Opt_Out", "MasterRecordId", "MiddleName", "MobilePhone",
                     "Name", "OtherAddress", "OtherPhone", "Other_Business_Email_Address", "Other_Phone_Number",
                     "OwnerId", "PEP_PO", "Phone", "PhotoUrl", "Postal_Opt_Out", "Preferred_Name", "ReportsToId",
                     "Roadshow_and_Events_Opt_Out", "Role", "Salutation", "Senior_RBS_Sponsor", "SystemModstamp",
                     "AEM__Data_Migration_Id", "AEM__Icon", "AEM__Languages", "AEM__Level", "AEM__Tier", "BVM_Opt_Out",
                     "Has_Priority_Coverage", "Inactive_Comments", "Inactive", "Interaction_Exists", "Is_Away",
                     "Job_Function", "Last_User_Interaction_Date_Today", "Last_User_Interaction_Date",
                     "Latest_Interaction_Date", "Mailing_Address_Id", "Number_of_Phone_Numbers",
                     "Number_of_Priority_Relationships", "Photo", "Preferred_Assistant_Phone",
                     "Preferred_Business_Contact_Email", "Preferred_Business_Phone", "Preferred_Direct_Phone",
                     "Preferred_Home_Phone", "Preferred_Mobile_Phone", "Preferred_Personal_Contact_Email",
                     "Preferred_Research_Contact_Email", "Preferred_Voice_Blast_Phone", "Telephony_Last_Modified_Date",
                     "User_Contact_Interaction_Modified_Date", "User_Contact_Interaction", "User",
                     "Voice_Blast_Extension", "Voice_Blast_Id", "Voice_Blast_Phone", "Mobile__Activity_Score",
                     "Mobile__Unique_Activity_Score", "Title", "US_Persons" })
public class Contact implements Serializable {
    private static final long serialVersionUID = -818964727580526574L;

    @JsonProperty("Account")
    private Account account;
    @JsonProperty("Account_Type")
    private String accountType;
    @JsonProperty("All_Marketing_opt_out")
    private Boolean allMarketingOptOut;
    @JsonProperty("AssistantName")
    private String assistantName;
    @JsonProperty("AssistantPhone")
    private String assistantPhone;
    @JsonProperty("Assistant_Email_Address")
    private String assistantEmailAddress;
    @JsonProperty("Birthdate")
    private Object birthdate;
    @JsonProperty("Bloomberg_Email_Address")
    private String bloombergEmailAddress;
    @JsonProperty("Business_Email_Address")
    private String businessEmailAddress;
    @JsonProperty("Business_Phone")
    private String businessPhone;
    @JsonProperty("Chat_Opt_Out")
    private Boolean chatOptOut;
    @JsonProperty("Contact_note")
    private Object contactNote;
    @JsonProperty("Country")
    private String country;
    @JsonProperty("Coverage_Ids2")
    private Object coverageIds2;
    @JsonProperty("Coverage_Ids3")
    private Object coverageIds3;
    @JsonProperty("Coverage_Ids4")
    private Object coverageIds4;
    @JsonProperty("Coverage_Ids5")
    private Object coverageIds5;
    @JsonProperty("Coverage_Ids6")
    private Object coverageIds6;
    @JsonProperty("Coverage_Ids")
    private Object coverageIds;
    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("CTI_AssistantPhone")
    private String cTIAssistantPhone;
    @JsonProperty("CTI_Business_Phone")
    private String cTIBusinessPhone;
    @JsonProperty("CTI_MobilePhone")
    private String cTIMobilePhone;
    @JsonProperty("CTI_Other_Phone_Number")
    private String cTIOtherPhoneNumber;
    @JsonProperty("Data_Migration_ID_Source")
    private Object dataMigrationIDSource;
    @JsonProperty("Deactivated_By")
    private String deactivatedBy;
    @JsonProperty("Deactivation_Date")
    private String deactivationDate;
    @JsonProperty("Dealer_Board_Direct_Line")
    private Object dealerBoardDirectLine;
    @JsonProperty("Department")
    private String department;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("Description")
    private String description;
    @JsonProperty("Desk_Strategy_Opt_Out")
    private Boolean deskStrategyOptOut;
    @JsonProperty("Division")
    private String division;
    @JsonProperty("DoNotCall")
    private Boolean doNotCall;
    @JsonProperty("ECD_Id")
    private String eCDId;
    @JsonProperty("Email")
    private String email;
    @JsonProperty("EmailBouncedDate")
    private Object emailBouncedDate;
    @JsonProperty("EmailBouncedReason")
    private Object emailBouncedReason;
    @JsonProperty("Fax")
    private Object fax;
    @JsonProperty("FirstName")
    private String firstName;
    @JsonProperty("Greenwich_Voter")
    private Boolean greenwichVoter;
    @JsonProperty("HasOptedOutOfEmail")
    private Boolean hasOptedOutOfEmail;
    @JsonProperty("Home_Email")
    private String homeEmail;
    @JsonProperty("HomePhone")
    private String homePhone;
    @JsonProperty("Incoming_Call_Number")
    private String incomingCallNumber;
    @JsonProperty("IsEmailBounced")
    private Boolean isEmailBounced;
    @JsonProperty("Is_My_Coverage")
    private Boolean isMyCoverage;
    @JsonProperty("Jigsaw")
    private Object jigsaw;
    @JsonProperty("JigsawContactId")
    private Object jigsawContactId;
    @JsonProperty("Job_Role")
    private String jobRole;
    @JsonProperty("LastActivityDate")
    private Object lastActivityDate;
    @JsonProperty("LastCURequestDate")
    private Object lastCURequestDate;
    @JsonProperty("LastCUUpdateDate")
    private Object lastCUUpdateDate;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("LastName")
    private String lastName;
    @JsonProperty("LeadSource")
    private Object leadSource;
    @JsonProperty("MailingAddress")
    private MailingAddress mailingAddress;
    @JsonProperty("Mandate")
    private Object mandate;
    @JsonProperty("Marketing_Opt_Out")
    private Boolean marketingOptOut;
    @JsonProperty("MasterRecordId")
    private Object masterRecordId;
    @JsonProperty("MiddleName")
    private String middleName;
    @JsonProperty("MobilePhone")
    private String mobilePhone;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("OtherAddress")
    private MailingAddress otherAddress;
    @JsonProperty("OtherPhone")
    private Object otherPhone;
    @JsonProperty("Other_Business_Email_Address")
    private String otherBusinessEmailAddress;
    @JsonProperty("Other_Phone_Number")
    private String otherPhoneNumber;
    @JsonProperty("OwnerId")
    private String ownerId;
    @JsonProperty("PEP_PO")
    private Boolean pEPPO;
    @JsonProperty("Phone")
    private String phone;
    @JsonProperty("PhotoUrl")
    private Object photoUrl;
    @JsonProperty("Postal_Opt_Out")
    private Boolean postalOptOut;
    @JsonProperty("Preferred_Name")
    private Object preferredName;
    @JsonProperty("ReportsToId")
    private Object reportsToId;
    @JsonProperty("Roadshow_and_Events_Opt_Out")
    private Boolean roadshowAndEventsOptOut;
    @JsonProperty("Role")
    private String role;
    @JsonProperty("Salutation")
    private String salutation;
    @JsonProperty("Senior_RBS_Sponsor")
    private Object seniorRBSSponsor;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("AEM__Data_Migration_Id")
    private Object aEMDataMigrationId;
    @JsonProperty("AEM__Icon")
    private Object aEMIcon;
    @JsonProperty("AEM__Languages")
    private Object aEMLanguages;
    @JsonProperty("AEM__Level")
    private Object aEMLevel;
    @JsonProperty("AEM__Tier")
    private Object aEMTier;
    @JsonProperty("BVM_Opt_Out")
    private Boolean bVMOptOut;
    @JsonProperty("Has_Priority_Coverage")
    private Boolean hasPriorityCoverage;
    @JsonProperty("Inactive_Comments")
    private String inactiveComments;
    @JsonProperty("Inactive")
    private Boolean inactive;
    @JsonProperty("Interaction_Exists")
    private Boolean interactionExists;
    @JsonProperty("Is_Away")
    private Boolean isAway;
    @JsonProperty("Job_Function")
    private String jobFunction;
    @JsonProperty("Last_User_Interaction_Date_Today")
    private Object lastUserInteractionDateToday;
    @JsonProperty("Last_User_Interaction_Date")
    private Object lastUserInteractionDate;
    @JsonProperty("Latest_Interaction_Date")
    private Object latestInteractionDate;
    @JsonProperty("Mailing_Address_Id")
    private Object mailingAddressId;
    @JsonProperty("Number_of_Phone_Numbers")
    private Integer numberOfPhoneNumbers;
    @JsonProperty("Number_of_Priority_Relationships")
    private Integer numberOfPriorityRelationships;
    @JsonProperty("Photo")
    private Object photo;
    @JsonProperty("Preferred_Assistant_Phone")
    private Object preferredAssistantPhone;
    @JsonProperty("Preferred_Business_Contact_Email")
    private Object preferredBusinessContactEmail;
    @JsonProperty("Preferred_Business_Phone")
    private Object preferredBusinessPhone;
    @JsonProperty("Preferred_Direct_Phone")
    private Object preferredDirectPhone;
    @JsonProperty("Preferred_Home_Phone")
    private Object preferredHomePhone;
    @JsonProperty("Preferred_Mobile_Phone")
    private Object preferredMobilePhone;
    @JsonProperty("Preferred_Personal_Contact_Email")
    private Object preferredPersonalContactEmail;
    @JsonProperty("Preferred_Research_Contact_Email")
    private Object preferredResearchContactEmail;
    @JsonProperty("Preferred_Voice_Blast_Phone")
    private Object preferredVoiceBlastPhone;
    @JsonProperty("Telephony_Last_Modified_Date")
    private Object telephonyLastModifiedDate;
    @JsonProperty("User_Contact_Interaction_Modified_Date")
    private Object userContactInteractionModifiedDate;
    @JsonProperty("User_Contact_Interaction")
    private Object userContactInteraction;
    @JsonProperty("User")
    private String user;
    @JsonProperty("Voice_Blast_Extension")
    private Object voiceBlastExtension;
    @JsonProperty("Voice_Blast_Id")
    private Object voiceBlastId;
    @JsonProperty("Voice_Blast_Phone")
    private Object voiceBlastPhone;
    @JsonProperty("Mobile__Activity_Score")
    private Integer mobileActivityScore;
    @JsonProperty("Mobile__Unique_Activity_Score")
    private Object mobileUniqueActivityScore;
    @JsonProperty("Title")
    private String title;
    @JsonProperty("US_Persons")
    private Boolean uSPersons;

    @JsonProperty("Account")
    public Account getAccount() {
        return account;
    }

    @JsonProperty("Account")
    public void setAccount(Account account) {
        this.account = account;
    }

    @JsonProperty("Account_Type")
    public String getAccountType() {
        return accountType;
    }

    @JsonProperty("Account_Type")
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    @JsonProperty("All_Marketing_opt_out")
    public Boolean getAllMarketingOptOut() {
        return allMarketingOptOut;
    }

    @JsonProperty("All_Marketing_opt_out")
    public void setAllMarketingOptOut(Boolean allMarketingOptOut) {
        this.allMarketingOptOut = allMarketingOptOut;
    }

    @JsonProperty("AssistantName")
    public String getAssistantName() {
        return assistantName;
    }

    @JsonProperty("AssistantName")
    public void setAssistantName(String assistantName) {
        this.assistantName = assistantName;
    }

    @JsonProperty("AssistantPhone")
    public String getAssistantPhone() {
        return assistantPhone;
    }

    @JsonProperty("AssistantPhone")
    public void setAssistantPhone(String assistantPhone) {
        this.assistantPhone = assistantPhone;
    }

    @JsonProperty("Assistant_Email_Address")
    public String getAssistantEmailAddress() {
        return assistantEmailAddress;
    }

    @JsonProperty("Assistant_Email_Address")
    public void setAssistantEmailAddress(String assistantEmailAddress) {
        this.assistantEmailAddress = assistantEmailAddress;
    }

    @JsonProperty("Birthdate")
    public Object getBirthdate() {
        return birthdate;
    }

    @JsonProperty("Birthdate")
    public void setBirthdate(Object birthdate) {
        this.birthdate = birthdate;
    }

    @JsonProperty("Bloomberg_Email_Address")
    public String getBloombergEmailAddress() {
        return bloombergEmailAddress;
    }

    @JsonProperty("Bloomberg_Email_Address")
    public void setBloombergEmailAddress(String bloombergEmailAddress) {
        this.bloombergEmailAddress = bloombergEmailAddress;
    }

    @JsonProperty("Business_Email_Address")
    public String getBusinessEmailAddress() {
        return businessEmailAddress;
    }

    @JsonProperty("Business_Email_Address")
    public void setBusinessEmailAddress(String businessEmailAddress) {
        this.businessEmailAddress = businessEmailAddress;
    }

    @JsonProperty("Business_Phone")
    public String getBusinessPhone() {
        return businessPhone;
    }

    @JsonProperty("Business_Phone")
    public void setBusinessPhone(String businessPhone) {
        this.businessPhone = businessPhone;
    }

    @JsonProperty("Chat_Opt_Out")
    public Boolean getChatOptOut() {
        return chatOptOut;
    }

    @JsonProperty("Chat_Opt_Out")
    public void setChatOptOut(Boolean chatOptOut) {
        this.chatOptOut = chatOptOut;
    }

    @JsonProperty("Contact_note")
    public Object getContactNote() {
        return contactNote;
    }

    @JsonProperty("Contact_note")
    public void setContactNote(Object contactNote) {
        this.contactNote = contactNote;
    }

    @JsonProperty("Country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("Country")
    public void setCountry(String country) {
        this.country = country;
    }

    @JsonProperty("Coverage_Ids2")
    public Object getCoverageIds2() {
        return coverageIds2;
    }

    @JsonProperty("Coverage_Ids2")
    public void setCoverageIds2(Object coverageIds2) {
        this.coverageIds2 = coverageIds2;
    }

    @JsonProperty("Coverage_Ids3")
    public Object getCoverageIds3() {
        return coverageIds3;
    }

    @JsonProperty("Coverage_Ids3")
    public void setCoverageIds3(Object coverageIds3) {
        this.coverageIds3 = coverageIds3;
    }

    @JsonProperty("Coverage_Ids4")
    public Object getCoverageIds4() {
        return coverageIds4;
    }

    @JsonProperty("Coverage_Ids4")
    public void setCoverageIds4(Object coverageIds4) {
        this.coverageIds4 = coverageIds4;
    }

    @JsonProperty("Coverage_Ids5")
    public Object getCoverageIds5() {
        return coverageIds5;
    }

    @JsonProperty("Coverage_Ids5")
    public void setCoverageIds5(Object coverageIds5) {
        this.coverageIds5 = coverageIds5;
    }

    @JsonProperty("Coverage_Ids6")
    public Object getCoverageIds6() {
        return coverageIds6;
    }

    @JsonProperty("Coverage_Ids6")
    public void setCoverageIds6(Object coverageIds6) {
        this.coverageIds6 = coverageIds6;
    }

    @JsonProperty("Coverage_Ids")
    public Object getCoverageIds() {
        return coverageIds;
    }

    @JsonProperty("Coverage_Ids")
    public void setCoverageIds(Object coverageIds) {
        this.coverageIds = coverageIds;
    }

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("CTI_AssistantPhone")
    public String getCTIAssistantPhone() {
        return cTIAssistantPhone;
    }

    @JsonProperty("CTI_AssistantPhone")
    public void setCTIAssistantPhone(String cTIAssistantPhone) {
        this.cTIAssistantPhone = cTIAssistantPhone;
    }

    @JsonProperty("CTI_Business_Phone")
    public String getCTIBusinessPhone() {
        return cTIBusinessPhone;
    }

    @JsonProperty("CTI_Business_Phone")
    public void setCTIBusinessPhone(String cTIBusinessPhone) {
        this.cTIBusinessPhone = cTIBusinessPhone;
    }

    @JsonProperty("CTI_MobilePhone")
    public String getCTIMobilePhone() {
        return cTIMobilePhone;
    }

    @JsonProperty("CTI_MobilePhone")
    public void setCTIMobilePhone(String cTIMobilePhone) {
        this.cTIMobilePhone = cTIMobilePhone;
    }

    @JsonProperty("CTI_Other_Phone_Number")
    public String getCTIOtherPhoneNumber() {
        return cTIOtherPhoneNumber;
    }

    @JsonProperty("CTI_Other_Phone_Number")
    public void setCTIOtherPhoneNumber(String cTIOtherPhoneNumber) {
        this.cTIOtherPhoneNumber = cTIOtherPhoneNumber;
    }

    @JsonProperty("Data_Migration_ID_Source")
    public Object getDataMigrationIDSource() {
        return dataMigrationIDSource;
    }

    @JsonProperty("Data_Migration_ID_Source")
    public void setDataMigrationIDSource(Object dataMigrationIDSource) {
        this.dataMigrationIDSource = dataMigrationIDSource;
    }

    @JsonProperty("Deactivated_By")
    public String getDeactivatedBy() {
        return deactivatedBy;
    }

    @JsonProperty("Deactivated_By")
    public void setDeactivatedBy(String deactivatedBy) {
        this.deactivatedBy = deactivatedBy;
    }

    @JsonProperty("Deactivation_Date")
    public String getDeactivationDate() {
        return deactivationDate;
    }

    @JsonProperty("Deactivation_Date")
    public void setDeactivationDate(String deactivationDate) {
        this.deactivationDate = deactivationDate;
    }

    @JsonProperty("Dealer_Board_Direct_Line")
    public Object getDealerBoardDirectLine() {
        return dealerBoardDirectLine;
    }

    @JsonProperty("Dealer_Board_Direct_Line")
    public void setDealerBoardDirectLine(Object dealerBoardDirectLine) {
        this.dealerBoardDirectLine = dealerBoardDirectLine;
    }

    @JsonProperty("Department")
    public String getDepartment() {
        return department;
    }

    @JsonProperty("Department")
    public void setDepartment(String department) {
        this.department = department;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("Description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("Description")
    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty("Desk_Strategy_Opt_Out")
    public Boolean getDeskStrategyOptOut() {
        return deskStrategyOptOut;
    }

    @JsonProperty("Desk_Strategy_Opt_Out")
    public void setDeskStrategyOptOut(Boolean deskStrategyOptOut) {
        this.deskStrategyOptOut = deskStrategyOptOut;
    }

    @JsonProperty("Division")
    public String getDivision() {
        return division;
    }

    @JsonProperty("Division")
    public void setDivision(String division) {
        this.division = division;
    }

    @JsonProperty("DoNotCall")
    public Boolean getDoNotCall() {
        return doNotCall;
    }

    @JsonProperty("DoNotCall")
    public void setDoNotCall(Boolean doNotCall) {
        this.doNotCall = doNotCall;
    }

    @JsonProperty("ECD_Id")
    public String getECDId() {
        return eCDId;
    }

    @JsonProperty("ECD_Id")
    public void setECDId(String eCDId) {
        this.eCDId = eCDId;
    }

    @JsonProperty("Email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("Email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("EmailBouncedDate")
    public Object getEmailBouncedDate() {
        return emailBouncedDate;
    }

    @JsonProperty("EmailBouncedDate")
    public void setEmailBouncedDate(Object emailBouncedDate) {
        this.emailBouncedDate = emailBouncedDate;
    }

    @JsonProperty("EmailBouncedReason")
    public Object getEmailBouncedReason() {
        return emailBouncedReason;
    }

    @JsonProperty("EmailBouncedReason")
    public void setEmailBouncedReason(Object emailBouncedReason) {
        this.emailBouncedReason = emailBouncedReason;
    }

    @JsonProperty("Fax")
    public Object getFax() {
        return fax;
    }

    @JsonProperty("Fax")
    public void setFax(Object fax) {
        this.fax = fax;
    }

    @JsonProperty("FirstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("FirstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("Greenwich_Voter")
    public Boolean getGreenwichVoter() {
        return greenwichVoter;
    }

    @JsonProperty("Greenwich_Voter")
    public void setGreenwichVoter(Boolean greenwichVoter) {
        this.greenwichVoter = greenwichVoter;
    }

    @JsonProperty("HasOptedOutOfEmail")
    public Boolean getHasOptedOutOfEmail() {
        return hasOptedOutOfEmail;
    }

    @JsonProperty("HasOptedOutOfEmail")
    public void setHasOptedOutOfEmail(Boolean hasOptedOutOfEmail) {
        this.hasOptedOutOfEmail = hasOptedOutOfEmail;
    }

    @JsonProperty("Home_Email")
    public String getHomeEmail() {
        return homeEmail;
    }

    @JsonProperty("Home_Email")
    public void setHomeEmail(String homeEmail) {
        this.homeEmail = homeEmail;
    }

    @JsonProperty("HomePhone")
    public String getHomePhone() {
        return homePhone;
    }

    @JsonProperty("HomePhone")
    public void setHomePhone(String homePhone) {
        this.homePhone = homePhone;
    }

    @JsonProperty("Incoming_Call_Number")
    public String getIncomingCallNumber() {
        return incomingCallNumber;
    }

    @JsonProperty("Incoming_Call_Number")
    public void setIncomingCallNumber(String incomingCallNumber) {
        this.incomingCallNumber = incomingCallNumber;
    }

    @JsonProperty("IsEmailBounced")
    public Boolean getIsEmailBounced() {
        return isEmailBounced;
    }

    @JsonProperty("IsEmailBounced")
    public void setIsEmailBounced(Boolean isEmailBounced) {
        this.isEmailBounced = isEmailBounced;
    }

    @JsonProperty("Is_My_Coverage")
    public Boolean getIsMyCoverage() {
        return isMyCoverage;
    }

    @JsonProperty("Is_My_Coverage")
    public void setIsMyCoverage(Boolean isMyCoverage) {
        this.isMyCoverage = isMyCoverage;
    }

    @JsonProperty("Jigsaw")
    public Object getJigsaw() {
        return jigsaw;
    }

    @JsonProperty("Jigsaw")
    public void setJigsaw(Object jigsaw) {
        this.jigsaw = jigsaw;
    }

    @JsonProperty("JigsawContactId")
    public Object getJigsawContactId() {
        return jigsawContactId;
    }

    @JsonProperty("JigsawContactId")
    public void setJigsawContactId(Object jigsawContactId) {
        this.jigsawContactId = jigsawContactId;
    }

    @JsonProperty("Job_Role")
    public String getJobRole() {
        return jobRole;
    }

    @JsonProperty("Job_Role")
    public void setJobRole(String jobRole) {
        this.jobRole = jobRole;
    }

    @JsonProperty("LastActivityDate")
    public Object getLastActivityDate() {
        return lastActivityDate;
    }

    @JsonProperty("LastActivityDate")
    public void setLastActivityDate(Object lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }

    @JsonProperty("LastCURequestDate")
    public Object getLastCURequestDate() {
        return lastCURequestDate;
    }

    @JsonProperty("LastCURequestDate")
    public void setLastCURequestDate(Object lastCURequestDate) {
        this.lastCURequestDate = lastCURequestDate;
    }

    @JsonProperty("LastCUUpdateDate")
    public Object getLastCUUpdateDate() {
        return lastCUUpdateDate;
    }

    @JsonProperty("LastCUUpdateDate")
    public void setLastCUUpdateDate(Object lastCUUpdateDate) {
        this.lastCUUpdateDate = lastCUUpdateDate;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("LastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("LastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("LeadSource")
    public Object getLeadSource() {
        return leadSource;
    }

    @JsonProperty("LeadSource")
    public void setLeadSource(Object leadSource) {
        this.leadSource = leadSource;
    }

    @JsonProperty("MailingAddress")
    public MailingAddress getMailingAddress() {
        return mailingAddress;
    }

    @JsonProperty("MailingAddress")
    public void setMailingAddress(MailingAddress mailingAddress) {
        this.mailingAddress = mailingAddress;
    }

    @JsonProperty("Mandate")
    public Object getMandate() {
        return mandate;
    }

    @JsonProperty("Mandate")
    public void setMandate(Object mandate) {
        this.mandate = mandate;
    }

    @JsonProperty("Marketing_Opt_Out")
    public Boolean getMarketingOptOut() {
        return marketingOptOut;
    }

    @JsonProperty("Marketing_Opt_Out")
    public void setMarketingOptOut(Boolean marketingOptOut) {
        this.marketingOptOut = marketingOptOut;
    }

    @JsonProperty("MasterRecordId")
    public Object getMasterRecordId() {
        return masterRecordId;
    }

    @JsonProperty("MasterRecordId")
    public void setMasterRecordId(Object masterRecordId) {
        this.masterRecordId = masterRecordId;
    }

    @JsonProperty("MiddleName")
    public String getMiddleName() {
        return middleName;
    }

    @JsonProperty("MiddleName")
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    @JsonProperty("MobilePhone")
    public String getMobilePhone() {
        return mobilePhone;
    }

    @JsonProperty("MobilePhone")
    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("OtherAddress")
    public MailingAddress getOtherAddress() {
        return otherAddress;
    }

    @JsonProperty("OtherAddress")
    public void setOtherAddress(MailingAddress otherAddress) {
        this.otherAddress = otherAddress;
    }

    @JsonProperty("OtherPhone")
    public Object getOtherPhone() {
        return otherPhone;
    }

    @JsonProperty("OtherPhone")
    public void setOtherPhone(Object otherPhone) {
        this.otherPhone = otherPhone;
    }

    @JsonProperty("Other_Business_Email_Address")
    public String getOtherBusinessEmailAddress() {
        return otherBusinessEmailAddress;
    }

    @JsonProperty("Other_Business_Email_Address")
    public void setOtherBusinessEmailAddress(String otherBusinessEmailAddress) {
        this.otherBusinessEmailAddress = otherBusinessEmailAddress;
    }

    @JsonProperty("Other_Phone_Number")
    public String getOtherPhoneNumber() {
        return otherPhoneNumber;
    }

    @JsonProperty("Other_Phone_Number")
    public void setOtherPhoneNumber(String otherPhoneNumber) {
        this.otherPhoneNumber = otherPhoneNumber;
    }

    @JsonProperty("OwnerId")
    public String getOwnerId() {
        return ownerId;
    }

    @JsonProperty("OwnerId")
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    @JsonProperty("PEP_PO")
    public Boolean getPEPPO() {
        return pEPPO;
    }

    @JsonProperty("PEP_PO")
    public void setPEPPO(Boolean pEPPO) {
        this.pEPPO = pEPPO;
    }

    @JsonProperty("Phone")
    public String getPhone() {
        return phone;
    }

    @JsonProperty("Phone")
    public void setPhone(String phone) {
        this.phone = phone;
    }

    @JsonProperty("PhotoUrl")
    public Object getPhotoUrl() {
        return photoUrl;
    }

    @JsonProperty("PhotoUrl")
    public void setPhotoUrl(Object photoUrl) {
        this.photoUrl = photoUrl;
    }

    @JsonProperty("Postal_Opt_Out")
    public Boolean getPostalOptOut() {
        return postalOptOut;
    }

    @JsonProperty("Postal_Opt_Out")
    public void setPostalOptOut(Boolean postalOptOut) {
        this.postalOptOut = postalOptOut;
    }

    @JsonProperty("Preferred_Name")
    public Object getPreferredName() {
        return preferredName;
    }

    @JsonProperty("Preferred_Name")
    public void setPreferredName(Object preferredName) {
        this.preferredName = preferredName;
    }

    @JsonProperty("ReportsToId")
    public Object getReportsToId() {
        return reportsToId;
    }

    @JsonProperty("ReportsToId")
    public void setReportsToId(Object reportsToId) {
        this.reportsToId = reportsToId;
    }

    @JsonProperty("Roadshow_and_Events_Opt_Out")
    public Boolean getRoadshowAndEventsOptOut() {
        return roadshowAndEventsOptOut;
    }

    @JsonProperty("Roadshow_and_Events_Opt_Out")
    public void setRoadshowAndEventsOptOut(Boolean roadshowAndEventsOptOut) {
        this.roadshowAndEventsOptOut = roadshowAndEventsOptOut;
    }

    @JsonProperty("Role")
    public String getRole() {
        return role;
    }

    @JsonProperty("Role")
    public void setRole(String role) {
        this.role = role;
    }

    @JsonProperty("Salutation")
    public String getSalutation() {
        return salutation;
    }

    @JsonProperty("Salutation")
    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }

    @JsonProperty("Senior_RBS_Sponsor")
    public Object getSeniorRBSSponsor() {
        return seniorRBSSponsor;
    }

    @JsonProperty("Senior_RBS_Sponsor")
    public void setSeniorRBSSponsor(Object seniorRBSSponsor) {
        this.seniorRBSSponsor = seniorRBSSponsor;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("AEM__Data_Migration_Id")
    public Object getAEMDataMigrationId() {
        return aEMDataMigrationId;
    }

    @JsonProperty("AEM__Data_Migration_Id")
    public void setAEMDataMigrationId(Object aEMDataMigrationId) {
        this.aEMDataMigrationId = aEMDataMigrationId;
    }

    @JsonProperty("AEM__Icon")
    public Object getAEMIcon() {
        return aEMIcon;
    }

    @JsonProperty("AEM__Icon")
    public void setAEMIcon(Object aEMIcon) {
        this.aEMIcon = aEMIcon;
    }

    @JsonProperty("AEM__Languages")
    public Object getAEMLanguages() {
        return aEMLanguages;
    }

    @JsonProperty("AEM__Languages")
    public void setAEMLanguages(Object aEMLanguages) {
        this.aEMLanguages = aEMLanguages;
    }

    @JsonProperty("AEM__Level")
    public Object getAEMLevel() {
        return aEMLevel;
    }

    @JsonProperty("AEM__Level")
    public void setAEMLevel(Object aEMLevel) {
        this.aEMLevel = aEMLevel;
    }

    @JsonProperty("AEM__Tier")
    public Object getAEMTier() {
        return aEMTier;
    }

    @JsonProperty("AEM__Tier")
    public void setAEMTier(Object aEMTier) {
        this.aEMTier = aEMTier;
    }

    @JsonProperty("BVM_Opt_Out")
    public Boolean getBVMOptOut() {
        return bVMOptOut;
    }

    @JsonProperty("BVM_Opt_Out")
    public void setBVMOptOut(Boolean bVMOptOut) {
        this.bVMOptOut = bVMOptOut;
    }

    @JsonProperty("Has_Priority_Coverage")
    public Boolean getHasPriorityCoverage() {
        return hasPriorityCoverage;
    }

    @JsonProperty("Has_Priority_Coverage")
    public void setHasPriorityCoverage(Boolean hasPriorityCoverage) {
        this.hasPriorityCoverage = hasPriorityCoverage;
    }

    @JsonProperty("Inactive_Comments")
    public String getInactiveComments() {
        return inactiveComments;
    }

    @JsonProperty("Inactive_Comments")
    public void setInactiveComments(String inactiveComments) {
        this.inactiveComments = inactiveComments;
    }

    @JsonProperty("Inactive")
    public Boolean getInactive() {
        return inactive;
    }

    @JsonProperty("Inactive")
    public void setInactive(Boolean inactive) {
        this.inactive = inactive;
    }

    @JsonProperty("Interaction_Exists")
    public Boolean getInteractionExists() {
        return interactionExists;
    }

    @JsonProperty("Interaction_Exists")
    public void setInteractionExists(Boolean interactionExists) {
        this.interactionExists = interactionExists;
    }

    @JsonProperty("Is_Away")
    public Boolean getIsAway() {
        return isAway;
    }

    @JsonProperty("Is_Away")
    public void setIsAway(Boolean isAway) {
        this.isAway = isAway;
    }

    @JsonProperty("Job_Function")
    public String getJobFunction() {
        return jobFunction;
    }

    @JsonProperty("Job_Function")
    public void setJobFunction(String jobFunction) {
        this.jobFunction = jobFunction;
    }

    @JsonProperty("Last_User_Interaction_Date_Today")
    public Object getLastUserInteractionDateToday() {
        return lastUserInteractionDateToday;
    }

    @JsonProperty("Last_User_Interaction_Date_Today")
    public void setLastUserInteractionDateToday(Object lastUserInteractionDateToday) {
        this.lastUserInteractionDateToday = lastUserInteractionDateToday;
    }

    @JsonProperty("Last_User_Interaction_Date")
    public Object getLastUserInteractionDate() {
        return lastUserInteractionDate;
    }

    @JsonProperty("Last_User_Interaction_Date")
    public void setLastUserInteractionDate(Object lastUserInteractionDate) {
        this.lastUserInteractionDate = lastUserInteractionDate;
    }

    @JsonProperty("Latest_Interaction_Date")
    public Object getLatestInteractionDate() {
        return latestInteractionDate;
    }

    @JsonProperty("Latest_Interaction_Date")
    public void setLatestInteractionDate(Object latestInteractionDate) {
        this.latestInteractionDate = latestInteractionDate;
    }

    @JsonProperty("Mailing_Address_Id")
    public Object getMailingAddressId() {
        return mailingAddressId;
    }

    @JsonProperty("Mailing_Address_Id")
    public void setMailingAddressId(Object mailingAddressId) {
        this.mailingAddressId = mailingAddressId;
    }

    @JsonProperty("Number_of_Phone_Numbers")
    public Integer getNumberOfPhoneNumbers() {
        return numberOfPhoneNumbers;
    }

    @JsonProperty("Number_of_Phone_Numbers")
    public void setNumberOfPhoneNumbers(Integer numberOfPhoneNumbers) {
        this.numberOfPhoneNumbers = numberOfPhoneNumbers;
    }

    @JsonProperty("Number_of_Priority_Relationships")
    public Integer getNumberOfPriorityRelationships() {
        return numberOfPriorityRelationships;
    }

    @JsonProperty("Number_of_Priority_Relationships")
    public void setNumberOfPriorityRelationships(Integer numberOfPriorityRelationships) {
        this.numberOfPriorityRelationships = numberOfPriorityRelationships;
    }

    @JsonProperty("Photo")
    public Object getPhoto() {
        return photo;
    }

    @JsonProperty("Photo")
    public void setPhoto(Object photo) {
        this.photo = photo;
    }

    @JsonProperty("Preferred_Assistant_Phone")
    public Object getPreferredAssistantPhone() {
        return preferredAssistantPhone;
    }

    @JsonProperty("Preferred_Assistant_Phone")
    public void setPreferredAssistantPhone(Object preferredAssistantPhone) {
        this.preferredAssistantPhone = preferredAssistantPhone;
    }

    @JsonProperty("Preferred_Business_Contact_Email")
    public Object getPreferredBusinessContactEmail() {
        return preferredBusinessContactEmail;
    }

    @JsonProperty("Preferred_Business_Contact_Email")
    public void setPreferredBusinessContactEmail(Object preferredBusinessContactEmail) {
        this.preferredBusinessContactEmail = preferredBusinessContactEmail;
    }

    @JsonProperty("Preferred_Business_Phone")
    public Object getPreferredBusinessPhone() {
        return preferredBusinessPhone;
    }

    @JsonProperty("Preferred_Business_Phone")
    public void setPreferredBusinessPhone(Object preferredBusinessPhone) {
        this.preferredBusinessPhone = preferredBusinessPhone;
    }

    @JsonProperty("Preferred_Direct_Phone")
    public Object getPreferredDirectPhone() {
        return preferredDirectPhone;
    }

    @JsonProperty("Preferred_Direct_Phone")
    public void setPreferredDirectPhone(Object preferredDirectPhone) {
        this.preferredDirectPhone = preferredDirectPhone;
    }

    @JsonProperty("Preferred_Home_Phone")
    public Object getPreferredHomePhone() {
        return preferredHomePhone;
    }

    @JsonProperty("Preferred_Home_Phone")
    public void setPreferredHomePhone(Object preferredHomePhone) {
        this.preferredHomePhone = preferredHomePhone;
    }

    @JsonProperty("Preferred_Mobile_Phone")
    public Object getPreferredMobilePhone() {
        return preferredMobilePhone;
    }

    @JsonProperty("Preferred_Mobile_Phone")
    public void setPreferredMobilePhone(Object preferredMobilePhone) {
        this.preferredMobilePhone = preferredMobilePhone;
    }

    @JsonProperty("Preferred_Personal_Contact_Email")
    public Object getPreferredPersonalContactEmail() {
        return preferredPersonalContactEmail;
    }

    @JsonProperty("Preferred_Personal_Contact_Email")
    public void setPreferredPersonalContactEmail(Object preferredPersonalContactEmail) {
        this.preferredPersonalContactEmail = preferredPersonalContactEmail;
    }

    @JsonProperty("Preferred_Research_Contact_Email")
    public Object getPreferredResearchContactEmail() {
        return preferredResearchContactEmail;
    }

    @JsonProperty("Preferred_Research_Contact_Email")
    public void setPreferredResearchContactEmail(Object preferredResearchContactEmail) {
        this.preferredResearchContactEmail = preferredResearchContactEmail;
    }

    @JsonProperty("Preferred_Voice_Blast_Phone")
    public Object getPreferredVoiceBlastPhone() {
        return preferredVoiceBlastPhone;
    }

    @JsonProperty("Preferred_Voice_Blast_Phone")
    public void setPreferredVoiceBlastPhone(Object preferredVoiceBlastPhone) {
        this.preferredVoiceBlastPhone = preferredVoiceBlastPhone;
    }

    @JsonProperty("Telephony_Last_Modified_Date")
    public Object getTelephonyLastModifiedDate() {
        return telephonyLastModifiedDate;
    }

    @JsonProperty("Telephony_Last_Modified_Date")
    public void setTelephonyLastModifiedDate(Object telephonyLastModifiedDate) {
        this.telephonyLastModifiedDate = telephonyLastModifiedDate;
    }

    @JsonProperty("User_Contact_Interaction_Modified_Date")
    public Object getUserContactInteractionModifiedDate() {
        return userContactInteractionModifiedDate;
    }

    @JsonProperty("User_Contact_Interaction_Modified_Date")
    public void setUserContactInteractionModifiedDate(Object userContactInteractionModifiedDate) {
        this.userContactInteractionModifiedDate = userContactInteractionModifiedDate;
    }

    @JsonProperty("User_Contact_Interaction")
    public Object getUserContactInteraction() {
        return userContactInteraction;
    }

    @JsonProperty("User_Contact_Interaction")
    public void setUserContactInteraction(Object userContactInteraction) {
        this.userContactInteraction = userContactInteraction;
    }

    @JsonProperty("User")
    public String getUser() {
        return user;
    }

    @JsonProperty("User")
    public void setUser(String user) {
        this.user = user;
    }

    @JsonProperty("Voice_Blast_Extension")
    public Object getVoiceBlastExtension() {
        return voiceBlastExtension;
    }

    @JsonProperty("Voice_Blast_Extension")
    public void setVoiceBlastExtension(Object voiceBlastExtension) {
        this.voiceBlastExtension = voiceBlastExtension;
    }

    @JsonProperty("Voice_Blast_Id")
    public Object getVoiceBlastId() {
        return voiceBlastId;
    }

    @JsonProperty("Voice_Blast_Id")
    public void setVoiceBlastId(Object voiceBlastId) {
        this.voiceBlastId = voiceBlastId;
    }

    @JsonProperty("Voice_Blast_Phone")
    public Object getVoiceBlastPhone() {
        return voiceBlastPhone;
    }

    @JsonProperty("Voice_Blast_Phone")
    public void setVoiceBlastPhone(Object voiceBlastPhone) {
        this.voiceBlastPhone = voiceBlastPhone;
    }

    @JsonProperty("Mobile__Activity_Score")
    public Integer getMobileActivityScore() {
        return mobileActivityScore;
    }

    @JsonProperty("Mobile__Activity_Score")
    public void setMobileActivityScore(Integer mobileActivityScore) {
        this.mobileActivityScore = mobileActivityScore;
    }

    @JsonProperty("Mobile__Unique_Activity_Score")
    public Object getMobileUniqueActivityScore() {
        return mobileUniqueActivityScore;
    }

    @JsonProperty("Mobile__Unique_Activity_Score")
    public void setMobileUniqueActivityScore(Object mobileUniqueActivityScore) {
        this.mobileUniqueActivityScore = mobileUniqueActivityScore;
    }

    @JsonProperty("Title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("Title")
    public void setTitle(String title) {
        this.title = title;
    }

    @JsonProperty("US_Persons")
    public Boolean getUSPersons() {
        return uSPersons;
    }

    @JsonProperty("US_Persons")
    public void setUSPersons(Boolean uSPersons) {
        this.uSPersons = uSPersons;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Contact{");
        sb.append("account=").append(account);
        sb.append(", accountType='").append(accountType).append('\'');
        sb.append(", allMarketingOptOut=").append(allMarketingOptOut);
        sb.append(", assistantName=").append(assistantName);
        sb.append(", assistantPhone=").append(assistantPhone);
        sb.append(", assistantEmailAddress=").append(assistantEmailAddress);
        sb.append(", birthdate=").append(birthdate);
        sb.append(", bloombergEmailAddress=").append(bloombergEmailAddress);
        sb.append(", businessEmailAddress='").append(businessEmailAddress).append('\'');
        sb.append(", businessPhone=").append(businessPhone);
        sb.append(", chatOptOut=").append(chatOptOut);
        sb.append(", contactNote=").append(contactNote);
        sb.append(", country=").append(country);
        sb.append(", coverageIds2=").append(coverageIds2);
        sb.append(", coverageIds3=").append(coverageIds3);
        sb.append(", coverageIds4=").append(coverageIds4);
        sb.append(", coverageIds5=").append(coverageIds5);
        sb.append(", coverageIds6=").append(coverageIds6);
        sb.append(", coverageIds=").append(coverageIds);
        sb.append(", createdById='").append(createdById).append('\'');
        sb.append(", createdDate='").append(createdDate).append('\'');
        sb.append(", cTIAssistantPhone=").append(cTIAssistantPhone);
        sb.append(", cTIBusinessPhone=").append(cTIBusinessPhone);
        sb.append(", cTIMobilePhone='").append(cTIMobilePhone).append('\'');
        sb.append(", cTIOtherPhoneNumber=").append(cTIOtherPhoneNumber);
        sb.append(", dataMigrationIDSource=").append(dataMigrationIDSource);
        sb.append(", deactivatedBy=").append(deactivatedBy);
        sb.append(", deactivationDate=").append(deactivationDate);
        sb.append(", dealerBoardDirectLine=").append(dealerBoardDirectLine);
        sb.append(", department='").append(department).append('\'');
        sb.append(", id='").append(id).append('\'');
        sb.append(", description=").append(description);
        sb.append(", deskStrategyOptOut=").append(deskStrategyOptOut);
        sb.append(", division=").append(division);
        sb.append(", doNotCall=").append(doNotCall);
        sb.append(", eCDId=").append(eCDId);
        sb.append(", email='").append(email).append('\'');
        sb.append(", emailBouncedDate=").append(emailBouncedDate);
        sb.append(", emailBouncedReason=").append(emailBouncedReason);
        sb.append(", fax=").append(fax);
        sb.append(", firstName='").append(firstName).append('\'');
        sb.append(", greenwichVoter=").append(greenwichVoter);
        sb.append(", hasOptedOutOfEmail=").append(hasOptedOutOfEmail);
        sb.append(", homeEmail=").append(homeEmail);
        sb.append(", homePhone=").append(homePhone);
        sb.append(", incomingCallNumber=").append(incomingCallNumber);
        sb.append(", isEmailBounced=").append(isEmailBounced);
        sb.append(", isMyCoverage=").append(isMyCoverage);
        sb.append(", jigsaw=").append(jigsaw);
        sb.append(", jigsawContactId=").append(jigsawContactId);
        sb.append(", jobRole=").append(jobRole);
        sb.append(", lastActivityDate=").append(lastActivityDate);
        sb.append(", lastCURequestDate=").append(lastCURequestDate);
        sb.append(", lastCUUpdateDate=").append(lastCUUpdateDate);
        sb.append(", lastModifiedById='").append(lastModifiedById).append('\'');
        sb.append(", lastModifiedDate='").append(lastModifiedDate).append('\'');
        sb.append(", lastName='").append(lastName).append('\'');
        sb.append(", leadSource=").append(leadSource);
        sb.append(", mailingAddress=").append(mailingAddress);
        sb.append(", mandate=").append(mandate);
        sb.append(", marketingOptOut=").append(marketingOptOut);
        sb.append(", masterRecordId=").append(masterRecordId);
        sb.append(", middleName=").append(middleName);
        sb.append(", mobilePhone='").append(mobilePhone).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", otherAddress=").append(otherAddress);
        sb.append(", otherPhone=").append(otherPhone);
        sb.append(", otherBusinessEmailAddress=").append(otherBusinessEmailAddress);
        sb.append(", otherPhoneNumber=").append(otherPhoneNumber);
        sb.append(", ownerId='").append(ownerId).append('\'');
        sb.append(", pEPPO=").append(pEPPO);
        sb.append(", phone='").append(phone).append('\'');
        sb.append(", photoUrl=").append(photoUrl);
        sb.append(", postalOptOut=").append(postalOptOut);
        sb.append(", preferredName=").append(preferredName);
        sb.append(", reportsToId=").append(reportsToId);
        sb.append(", roadshowAndEventsOptOut=").append(roadshowAndEventsOptOut);
        sb.append(", role=").append(role);
        sb.append(", salutation=").append(salutation);
        sb.append(", seniorRBSSponsor=").append(seniorRBSSponsor);
        sb.append(", systemModstamp='").append(systemModstamp).append('\'');
        sb.append(", aEMDataMigrationId=").append(aEMDataMigrationId);
        sb.append(", aEMIcon=").append(aEMIcon);
        sb.append(", aEMLanguages=").append(aEMLanguages);
        sb.append(", aEMLevel=").append(aEMLevel);
        sb.append(", aEMTier=").append(aEMTier);
        sb.append(", bVMOptOut=").append(bVMOptOut);
        sb.append(", hasPriorityCoverage=").append(hasPriorityCoverage);
        sb.append(", inactiveComments=").append(inactiveComments);
        sb.append(", inactive=").append(inactive);
        sb.append(", interactionExists=").append(interactionExists);
        sb.append(", isAway=").append(isAway);
        sb.append(", jobFunction=").append(jobFunction);
        sb.append(", lastUserInteractionDateToday=").append(lastUserInteractionDateToday);
        sb.append(", lastUserInteractionDate=").append(lastUserInteractionDate);
        sb.append(", latestInteractionDate=").append(latestInteractionDate);
        sb.append(", mailingAddressId=").append(mailingAddressId);
        sb.append(", numberOfPhoneNumbers=").append(numberOfPhoneNumbers);
        sb.append(", numberOfPriorityRelationships=").append(numberOfPriorityRelationships);
        sb.append(", photo=").append(photo);
        sb.append(", preferredAssistantPhone=").append(preferredAssistantPhone);
        sb.append(", preferredBusinessContactEmail=").append(preferredBusinessContactEmail);
        sb.append(", preferredBusinessPhone=").append(preferredBusinessPhone);
        sb.append(", preferredDirectPhone=").append(preferredDirectPhone);
        sb.append(", preferredHomePhone=").append(preferredHomePhone);
        sb.append(", preferredMobilePhone=").append(preferredMobilePhone);
        sb.append(", preferredPersonalContactEmail=").append(preferredPersonalContactEmail);
        sb.append(", preferredResearchContactEmail=").append(preferredResearchContactEmail);
        sb.append(", preferredVoiceBlastPhone=").append(preferredVoiceBlastPhone);
        sb.append(", telephonyLastModifiedDate=").append(telephonyLastModifiedDate);
        sb.append(", userContactInteractionModifiedDate=").append(userContactInteractionModifiedDate);
        sb.append(", userContactInteraction=").append(userContactInteraction);
        sb.append(", user=").append(user);
        sb.append(", voiceBlastExtension=").append(voiceBlastExtension);
        sb.append(", voiceBlastId=").append(voiceBlastId);
        sb.append(", voiceBlastPhone=").append(voiceBlastPhone);
        sb.append(", mobileActivityScore=").append(mobileActivityScore);
        sb.append(", mobileUniqueActivityScore=").append(mobileUniqueActivityScore);
        sb.append(", title='").append(title).append('\'');
        sb.append(", uSPersons=").append(uSPersons);
        sb.append('}');
        return sb.toString();
    }
}
