package com.nwm.xmart.streaming.source.rdx.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class RdxSubscriptionException extends RuntimeException {

    public RdxSubscriptionException() {
        super();
    }

    public RdxSubscriptionException(String msg) {
        super(msg);
    }

    public RdxSubscriptionException(String msg, Throwable t) {
        super(msg, t);
    }
}
