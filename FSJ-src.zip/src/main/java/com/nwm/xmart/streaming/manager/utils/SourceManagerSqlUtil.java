package com.nwm.xmart.streaming.manager.utils;

import com.nwm.xmart.streaming.database.SqlServerConnectionDetails;
import com.nwm.xmart.streaming.database.dao.SqlServerDao;
import com.nwm.xmart.streaming.database.exceptions.XmartSqlServerException;
import com.nwm.xmart.streaming.database.statements.StatementParameters;
import com.nwm.xmart.streaming.database.statements.XmartStatement;
import com.nwm.xmart.streaming.database.statements.processstate.LastRunInsertStatement;
import com.nwm.xmart.streaming.database.statements.processstate.LastRunReadStatement;
import com.nwm.xmart.streaming.manager.settings.SourceManagerParameters;
import com.nwm.xmart.streaming.database.exceptions.SqlServerConnectorException;
import org.apache.flink.api.java.utils.ParameterTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class SourceManagerSqlUtil implements SourceManagerSqlUtilInterface {
    private static final Logger logger = LoggerFactory.getLogger(SourceManagerSqlUtil.class);

    // this is a temp function and will be updated in the future once the two projects are merged
    public LocalDate getLastSuccessfulDateForFunction(ParameterTool params, String functionName)
            throws XmartSqlServerException {

        DateTimeFormatter outputFormat;
        String lastSuccessDateString;
            outputFormat = SourceManagerParameters.getOutputFormat(params);
            lastSuccessDateString = SourceManagerParameters.getDailyInitialLastSuccessfulDay(params);

            XmartStatement xmartStatement = new LastRunReadStatement();

            StatementParameters statementParams = new StatementParameters();
            statementParams.add("functionName", SourceManagerParameters.getDailyJobName(params) + "-" + functionName);

            SqlServerDao dao = new SqlServerDao(xmartStatement, new SqlServerConnectionDetails(params));

            try {
                dao.open();
                ResultSet queryResults = dao.read("fn_GetProcessState", statementParams);
                while (queryResults.next()) {
                    String date = queryResults.getString("results");
                    if (date != null && !date.isEmpty()) {
                        lastSuccessDateString = date;
                    }
                }
            } catch (SQLException e) {
                logger.error("failed to get last process state from query results");
                throw new XmartSqlServerException("failed to get process state from query results", e);
            } finally{
                dao.close();
            }

        // Return lastSuccessDate using formatter
        return LocalDate.parse(lastSuccessDateString, outputFormat);
    }

    // this is a temp function and will be updated in the future once the two projects are merged
    public void insertLastSuccessfulDateForFunction(ParameterTool params, String functionName, String date)
            throws XmartSqlServerException {

        LastRunInsertStatement xmartStatement = new LastRunInsertStatement();

        StatementParameters statementParams = new StatementParameters();
        statementParams.add("functionName", SourceManagerParameters.getDailyJobName(params) + "-" + functionName);
        statementParams.add("date", date);

        SqlServerDao dao = new SqlServerDao(xmartStatement, new SqlServerConnectionDetails(params));

        dao.open();
        dao.write("usp_ProcessStateSet", statementParams);
        dao.close();

    }
}
