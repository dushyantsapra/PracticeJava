package com.nwm.xmart.streaming.manager.results;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class ProcessingResultsTracker {
    private static Logger logger = LoggerFactory.getLogger(ProcessingResultsTracker.class);

    // Records of each days processing
    private final List<String> daysFailedProcessing = new ArrayList<>();
    private final List<String> daysSuccessfullyProcessed = new ArrayList<>();
    private final List<String> daysNoDataAvailable = new ArrayList<>();
    private final List<String> daysNoConnection = new ArrayList<>();
    private final String functionName;

    public ProcessingResultsTracker(String functionName) {
        this.functionName = functionName;
    }

    public void addDayFailedProcessing(String dayFailed) {
        daysFailedProcessing.add(dayFailed);
    }

    public void addDaySuccessfullyProcessed(String daySucceeded) {
        daysSuccessfullyProcessed.add(daySucceeded);
    }

    public void addDayNoDataAvailable(String dayNoData) {
        daysNoDataAvailable.add(dayNoData);
    }

    public void addDayNoConnection(String dayNoConnection) {
        daysNoConnection.add(dayNoConnection);
    }

    public void print() {
        logger.info("Function [ " + functionName + " ], Processing Status: no of daysFailedProcessing [ " + daysFailedProcessing.size() + " ]");
        logger.info("Function [ " + functionName + " ], Processing Status: no of daysSuccessfullyProcessed [ " + daysSuccessfullyProcessed.size() + " ]");
        logger.info("Function [ " + functionName + " ], Processing Status: no of daysNoDataAvailable [ " + daysNoDataAvailable.size() + " ]");
        logger.info("Function [ " + functionName + " ], Processing Status: no of daysNoConnection [ " + daysNoConnection.size() + " ]");

        for (String failedProcessingDay : daysFailedProcessing) {
            logger.error("Function [ " + functionName + " ], Failed to process day [ " + failedProcessingDay + " ]");
        }

        for (String successfulProcessingDay : daysSuccessfullyProcessed) {
            logger.info("Function [ " + functionName + " ], Successfully processed day [ " + successfulProcessingDay + " ]");
        }

        for (String noDataAvailableDay : daysNoDataAvailable) {
            logger.warn("Function [ " + functionName + " ], No data available for day [ " + noDataAvailableDay + " ]");
        }

        for (String failedConnectionDay : daysNoConnection) {
            logger.error("Function [ " + functionName + " ], Failed to get connection for day [ " + failedConnectionDay + " ]");
        }
    }

}
