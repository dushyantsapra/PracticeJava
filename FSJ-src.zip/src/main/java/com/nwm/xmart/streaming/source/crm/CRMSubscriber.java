package com.nwm.xmart.streaming.source.crm;

import com.nwm.xmart.streaming.source.crm.entity.accountCoverage.AccountCoverage;
import com.nwm.xmart.streaming.source.crm.entity.accountDesk.AccountDesk;
import com.nwm.xmart.streaming.source.crm.entity.callLog.CallLog;
import com.nwm.xmart.streaming.source.crm.entity.callReport.CallReport;
import com.nwm.xmart.streaming.source.crm.entity.contact.Contact;
import com.nwm.xmart.streaming.source.crm.entity.contactCoverage.ContactCoverage;
import com.nwm.xmart.streaming.source.crm.entity.interest.Interest;
import com.nwm.xmart.streaming.source.crm.entity.organization.Organization;
import com.nwm.xmart.streaming.source.crm.entity.user.User;
import com.nwm.xmart.streaming.source.crm.entity.userRole.UserRole;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent;
import com.nwm.xmart.streaming.source.crm.event.CRMSourceEventType;
import com.nwm.xmart.streaming.source.crm.exception.CRMException;
import com.nwm.xmart.streaming.source.df.serialisation.DFSourceDeserializer;
import com.nwm.xmart.util.MDCUtil;
import com.rbs.datafabric.domain.Record;
import com.rbs.datafabric.domain.WatchContext;
import com.rbs.datafabric.domain.event.*;
import org.apache.flink.api.java.utils.ParameterTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Subscriber;
import rx.Subscription;

import java.io.Serializable;
import java.util.Date;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class CRMSubscriber extends Subscriber<ContinuousQueryEvent> implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(CRMSubscriber.class);
    private static final long serialVersionUID = 7742543646306023313L;

    private final CRMSource<CRMSourceEvent> sourceFunction;
    private final WatchContext<ContinuousQueryEvent> watchContext;
    private final BlockingQueue<CRMSourceEvent> eventQueue;
    private final String watchId;
    private final String watchName;
    private final DFSourceDeserializer dfSourceDeserializer;
    private Subscription subscription;
    ParameterTool parameters;

    public <CRMSourceEvent> CRMSubscriber(CRMSource<CRMSourceEvent> crmSourceEventCRMSource,
            WatchContext<ContinuousQueryEvent> watchContext, String watchId, String watchName,
            DFSourceDeserializer dfSourceDeserializer, ParameterTool parameters) {
        this.sourceFunction
                = (CRMSource<com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent>) crmSourceEventCRMSource;
        this.watchContext = watchContext;
        this.watchId = watchId;
        this.watchName = watchName;
        this.dfSourceDeserializer = dfSourceDeserializer;
        eventQueue = new LinkedBlockingQueue<>();
        this.parameters = parameters;
    }

    public void startSubscription() {
        Subscription subscription = watchContext.getSubject().subscribe(this);
        this.subscription = subscription;
    }

    @Override
    public void onCompleted() {
        logger.info("On Completed method called ");
        sourceFunction.cancel();
    }

    @Override
    public void onError(Throwable throwable) {
        logger.error("On Error method called ", (Exception) throwable);
        sourceFunction.cancel();
        throw new CRMException("On Error method called {}", (Exception) throwable);
    }

    @Override
    public void onNext(ContinuousQueryEvent event) {
        MDCUtil.putJobNameInMDC(parameters);

        CRMSourceEvent crmSourceEvent = null;
        if (event instanceof ContinuousQuerySnapshotStreamFailedEvent) {
            ContinuousQuerySnapshotStreamFailedEvent evt = (ContinuousQuerySnapshotStreamFailedEvent) event;
            logger.info("Durable watch scan initial snapshot load failed, watchName={} cause={}", watchName,
                    evt.getCause());
            return;
        } else if (event instanceof ContinuousQuerySnapshotStreamEvent) {
            ContinuousQuerySnapshotStreamEvent evt = (ContinuousQuerySnapshotStreamEvent) event;
            crmSourceEvent = createCRMEvent(evt.getCollectionName(), evt.getOffset(), evt.getRecord());
        } else if (event instanceof ContinuousQueryInsertEvent) {
            ContinuousQueryInsertEvent evt = (ContinuousQueryInsertEvent) event;
            crmSourceEvent = createCRMEvent(evt.getCollectionName(), evt.getOffset(), evt.getRecord());
        } else if (event instanceof ContinuousQueryUpdateEvent) {
            ContinuousQueryUpdateEvent evt = (ContinuousQueryUpdateEvent) event;
            crmSourceEvent = createCRMEvent(evt.getCollectionName(), evt.getOffset(), evt.getRecord());
        } else if (event instanceof ContinuousQuerySnapshotStreamEndedEvent) {
            ContinuousQuerySnapshotStreamEndedEvent evt = (ContinuousQuerySnapshotStreamEndedEvent) event;
            return;
        }
        if (crmSourceEvent != null)
            storeCRMEvent(crmSourceEvent);
    }

    private CRMSourceEvent createCRMEvent(String collectionName, long offset, Record record) {
        CRMSourceEvent crmSourceEvent = null;

        CRMSourceEventType crmSourceEventType = CRMSourceEventType.get(collectionName);

        switch (crmSourceEventType) {
        case AccountCoverage:
            AccountCoverage accountCoverage = dfSourceDeserializer.deserialize(record, AccountCoverage.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.AccountCoverage, record.getId().getKey()).setAccountCoverage(accountCoverage);
            break;
        case CallLog:
            CallLog callLog = dfSourceDeserializer.deserialize(record, CallLog.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.CallLog, record.getId().getKey()).setCallLog(callLog);
            break;
        case CallReport:
            CallReport callReport = dfSourceDeserializer.deserialize(record, CallReport.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.CallReport, record.getId().getKey()).setCallReport(callReport);
            break;
        case Contact:
            Contact contact = dfSourceDeserializer.deserialize(record, Contact.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.Contact, record.getId().getKey()).setContact(contact);
            break;
        case ContactCoverage:
            ContactCoverage contactCoverage = dfSourceDeserializer.deserialize(record, ContactCoverage.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.ContactCoverage, record.getId().getKey()).setContactCoverage(contactCoverage);
            break;
        case Organization:
            Organization organization = dfSourceDeserializer.deserialize(record, Organization.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.Organization, record.getId().getKey()).setOrganization(organization);
            break;
        case User:
            User user = dfSourceDeserializer.deserialize(record, User.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.User, record.getId().getKey()).setUser(user);
            break;
        case UserRole:
            UserRole userRole = dfSourceDeserializer.deserialize(record, UserRole.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.UserRole, record.getId().getKey()).setUserRole(userRole);
            break;
        case Interest:
            Interest interest = dfSourceDeserializer.deserialize(record, Interest.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.Interest, record.getId().getKey()).setInterest(interest);
            break;
        case AccountDesk:
            AccountDesk accountDesk = dfSourceDeserializer.deserialize(record, AccountDesk.class);
            crmSourceEvent = new CRMSourceEvent(new Date().getTime(), 1, offset, record.getId().getVersion(),
                    CRMSourceEventType.AccountDesk, record.getId().getKey()).setAccountDesk(accountDesk);
            break;
        }
        return crmSourceEvent;
    }

    private void storeCRMEvent(CRMSourceEvent crmSourceEvent) {
        try {
            eventQueue.put(crmSourceEvent);
        } catch (InterruptedException e) {
            logger.error("Interrupted while storing CRM Event to Queue", e);
            sourceFunction.cancel();
            throw new CRMException("Interrupted putting single crm event into queue", e);
        }
    }

    public CRMSourceEvent getCRMEvent() {
        try {
            return eventQueue.take();
        } catch (InterruptedException e) {
            logger.error("Interrupted while fetching CRM event", e);
            sourceFunction.cancel();
            throw new CRMException("Interrupted while fetching CRM event", e);
        }
    }

    public Subscription getSubscription() {
        return subscription;
    }
}
