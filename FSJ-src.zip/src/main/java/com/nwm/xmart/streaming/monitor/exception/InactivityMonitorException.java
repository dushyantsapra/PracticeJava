package com.nwm.xmart.streaming.monitor.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class InactivityMonitorException extends RuntimeException {

    public InactivityMonitorException() {
        super();
    }

    public InactivityMonitorException(Throwable t) {
        super(t);
    }

    public InactivityMonitorException(String msg) {
        super(msg);
    }
}
