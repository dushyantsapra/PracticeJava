package com.nwm.xmart.streaming.source.kdb.parameters;

import com.nwm.xmart.streaming.source.kdb.sorting.KDBFunctionType;
import com.nwm.xmart.streaming.source.mdx.session.MDXSessionType;

import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Created by gardlex on 06/08/2018.
 */
public class BdxKdbFunctionDetails implements Serializable {
    private volatile String sourceID;
    private volatile String functionName;
    private volatile String kdbSourceName;
    private volatile KDBFunctionType kdbFunctionType;
    private volatile MDXSessionType kdbSessionType;
    private ConcurrentMap<String,String> functionParameters;
    private String mdxEnvironment;
    private String kdbEnvironment;
    private String kdbTableName;

    public BdxKdbFunctionDetails() {
    }

    public BdxKdbFunctionDetails(String sourceID, String functionName, String kdbSourceName, KDBFunctionType kdbFunctionType, MDXSessionType kdbSessionType, ConcurrentMap<String, String> functionParameters, String mdxEnvironment, String kdbEnvironment, String kdbTableName) {
        this.sourceID = sourceID;
        this.functionName = functionName;
        this.kdbSourceName = kdbSourceName;
        this.kdbFunctionType = kdbFunctionType;
        this.kdbSessionType = kdbSessionType;
        this.functionParameters = new ConcurrentHashMap<>(functionParameters);
        this.mdxEnvironment = mdxEnvironment;
        this.kdbEnvironment = kdbEnvironment;
        this.kdbTableName = kdbTableName;
    }

    public String getSourceID() {
        return sourceID;
    }

    public String getFunctionName() {
        return functionName;
    }

    public String getKdbSourceName() {
        return kdbSourceName;
    }

    public KDBFunctionType getKdbFunctionType() {
        return kdbFunctionType;
    }

    public MDXSessionType getKdbSessionType() {
        return kdbSessionType;
    }

    public Map<String, String> getFunctionParameters() {
        return functionParameters;
    }

    public String getMdxEnvironment() {
        return mdxEnvironment;
    }

    public String getKdbEnvironment() {
        return kdbEnvironment;
    }

    public String getKdbTableName() {
        return kdbTableName;
    }
}
