package com.nwm.xmart.streaming.source.mdx.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class TimeSeriesEsma extends HeaderFields implements Serializable {
    private static final long serialVersionUID = 7223987026671882552L;

    private String instrumentName;
    private String tradingVenues;
    private String issuer;
    private String firstTradeDate;
    private BigDecimal value;

    public TimeSeriesEsma(String mdxTransport, String mdxTypeName, String mdxPath, int mdxDocumentVersion,
            Date mdxWrittenOnUTC, String mdxValuationDate, String writeTime) {
        super(mdxTransport, mdxTypeName, mdxPath, mdxDocumentVersion, mdxWrittenOnUTC, mdxValuationDate, writeTime);
    }

    public String getInstrumentName() {
        return instrumentName;
    }

    public void setInstrumentName(String instrumentName) {
        this.instrumentName = instrumentName;
    }

    public String getTradingVenues() {
        return tradingVenues;
    }

    public void setTradingVenues(String tradingVenues) {
        this.tradingVenues = tradingVenues;
    }

    public String getIssuer() {
        return issuer;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public String getFirstTradeDate() {
        return firstTradeDate;
    }

    public void setFirstTradeDate(String firstTradeDate) {
        this.firstTradeDate = firstTradeDate;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }
}
