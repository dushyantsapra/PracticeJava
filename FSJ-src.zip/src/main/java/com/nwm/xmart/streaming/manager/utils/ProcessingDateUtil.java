package com.nwm.xmart.streaming.manager.utils;

import com.nwm.xmart.streaming.database.exceptions.XmartSqlServerException;
import com.nwm.xmart.streaming.manager.exceptions.ParameterException;
import com.nwm.xmart.streaming.source.kdb.exception.FunctionParameterParsingException;
import com.nwm.xmart.streaming.source.kdb.exception.RepairDateParsingException;
import com.nwm.xmart.streaming.source.kdb.parameters.DateParameterUtil;
import org.apache.flink.api.java.utils.ParameterTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;

import static com.nwm.xmart.streaming.manager.settings.SourceManagerParameters.*;

public class ProcessingDateUtil {
    private static Logger logger = LoggerFactory.getLogger(DateParameterUtil.class);

    public static Map<String, LinkedList<String>> getProcessingDays(ParameterTool params, SourceManagerSqlUtilInterface sourceManagerSqlUtil)
            throws XmartSqlServerException {
        Map<String, LinkedList<String>> functionProcessingDays = new LinkedHashMap<>();

        for (String function : getFunctionsList(params)) {

            LinkedList<String> dates = null;
            switch (getMode(params)) {
                case REPAIR:
                    dates = getRepairModeDays(params);
                    break;
                case RANGE:
                    dates = getRangeDays(params);
                    break;
                case DAILY:
                    dates = getDailyRunDays(params, function, sourceManagerSqlUtil);
                    break;
                default:
                    break;
            }

            if (dates != null) {
                functionProcessingDays.put(function, dates);
            }
        }

        return functionProcessingDays;
    }

    private static LinkedList<String> getRepairModeDays(ParameterTool params) {
        LinkedList<String> repairDates;
        try {
            String rawRepairDates = params.get("source.manager.repair.dates");
            repairDates = getRepairDatesFrom(rawRepairDates, params);
        } catch (Exception e) {
            logger.error("Problem with parsing repair dates property", e);
            throw new RepairDateParsingException("Problem with parsing repair dates property", e);
        }

        return repairDates;
    }

    private static LinkedList<String> getRangeDays(ParameterTool params) {
        LinkedList<String> results;

        String startDate = params.get("source.manager.range.startDate");
        String endDate = params.get("source.manager.range.endDate");
        if (startDate == null || endDate == null) {
            throw new FunctionParameterParsingException("StartDate or EndDate are missing from the FunctionalParameters - unable to run in range mode");
        }

        LocalDate localStartDate = getLocalDateFor(startDate);
        LocalDate localEndDate = getLocalDateFor(endDate);

        if (!validateDateRange(localStartDate, localEndDate)) {
            throw new ParameterException("Invalid date Range specified, startDate [ " + localStartDate + " ], endDate [ " + localEndDate + " ]");
        }

        try {
            results = getDaysToLoad(localStartDate, localEndDate, params);
        } catch (Exception e) {
            logger.error("Problem with parsing SPECIFIED DATE RANGE startDate [ " + startDate + " ], endDate [ " + endDate + " ]", e);
            throw new FunctionParameterParsingException("Problem with parsing SPECIFIED DATE RANGE startDate [ " + startDate + " ], endDate [ " + endDate + " ]", e);
        }

        return results;
    }


    private static LinkedList<String> getDailyRunDays(ParameterTool params, String functionName, SourceManagerSqlUtilInterface sourceManagerSqlUtil)
            throws XmartSqlServerException {
        LocalDate lastSuccessDate = sourceManagerSqlUtil.getLastSuccessfulDateForFunction(params, functionName);
        LocalDate localStartDate = lastSuccessDate.plus(1, ChronoUnit.DAYS);

        LocalDate today = LocalDate.now();
        LocalDate localEndDate = today.minus(1, ChronoUnit.DAYS);

        LinkedList<String> defaultDateRange = getDaysToLoad(localStartDate, localEndDate, params);

        return defaultDateRange;
    }

    private static LinkedList<String> getDaysToLoad(LocalDate localStartDate, LocalDate localEndDate, ParameterTool params) {
        LinkedList<String> daysToLoadList = new LinkedList<>();
        DateTimeFormatter outputFormatter = getOutputFormat(params);
        long daysBetween = ChronoUnit.DAYS.between(localStartDate, localEndDate);
        if (daysBetween == 0) {
            daysToLoadList.add(localStartDate.format(outputFormatter));
        } else if (daysBetween > 0) {
            LocalDate currentDate = localStartDate;
            daysToLoadList.add(localStartDate.format(outputFormatter));

            for (int x = 0; x < (daysBetween); x++) {
                currentDate = currentDate.plusDays(1);
                daysToLoadList.add(currentDate.format(outputFormatter));
            }
        }

        return daysToLoadList;
    }


    private static LinkedList<String> getRepairDatesFrom(String repairDates, ParameterTool params) {
        StringTokenizer repairDatesTokenizer = new StringTokenizer(repairDates, ",");
        LinkedList<LocalDate> sortedRepairDates = new LinkedList<>();
        DateTimeFormatter outputFormatter = getOutputFormat(params);

        while (repairDatesTokenizer.hasMoreTokens()) {
            LocalDate repairDate = getLocalDateFor(repairDatesTokenizer.nextToken());
            sortedRepairDates.add(repairDate);
        }

        Collections.sort(sortedRepairDates);
        LinkedList<String> repairDatesStrList = new LinkedList<>();
        for (LocalDate date : sortedRepairDates) {
            repairDatesStrList.add(date.format(outputFormatter));
        }

        return repairDatesStrList;
    }


    private static boolean validateDateRange(LocalDate localStartDate, LocalDate localEndDate) {
        return (localEndDate.isAfter(localStartDate) || localEndDate.isEqual(localStartDate));
    }

    public static LocalDate getLocalDateFor(String date) {
        return LocalDate.parse(date.replaceAll("\\.", "-"));
    }
}
