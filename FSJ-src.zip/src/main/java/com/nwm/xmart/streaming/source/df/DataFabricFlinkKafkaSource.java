package com.nwm.xmart.streaming.source.df;


import com.nwm.xmart.streaming.util.DataFabricUtil;
import com.nwm.xmart.streaming.source.df.serialisation.FlinkDeserializer;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010;
import org.apache.flink.streaming.connectors.kafka.internals.KafkaTopicPartition;
import org.apache.flink.streaming.util.serialization.KeyedDeserializationSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by gardlex on 17/10/2017.
 */
public class DataFabricFlinkKafkaSource<T> extends FlinkKafkaConsumer010<T> {

    private static Logger logger = LoggerFactory.getLogger(DataFabricFlinkKafkaSource.class);
    private final DataFabricUtil dataFabricUtil;
    private final KeyedDeserializationSchema keyedDeserializationSchema;

    public DataFabricFlinkKafkaSource(DataFabricUtil dataFabricUtil, Configuration configuration, KafkaProperties kafkaProperties, KeyedDeserializationSchema deserializationSchema) {
        super(configuration.getString("flink.kafka.consumer.topic","")
                , deserializationSchema
                , kafkaProperties.getProperties());

        this.dataFabricUtil = new DataFabricUtil(configuration);

        this.keyedDeserializationSchema = deserializationSchema;

        if (configuration.getBoolean("flink.checkpointing.enable", false)) {
            this.setCommitOffsetsOnCheckpoints(true);
        }

        // Check if on the start of a flink job whether to start from a specific offset - DF only supports single partition currently
        if (configuration.getBoolean("flink.kafka.consumer.startFromSpecificOffset", false)) {
            Map<KafkaTopicPartition, Long> specificStartOffsets = new HashMap<>();
            specificStartOffsets.put(
                    new KafkaTopicPartition(
                            configuration.getString("flink.kafka.consumer.topic",""), 0),
                    configuration.getLong("flink.kafka.consumer.specific.offset", -1L));
            this.setStartFromSpecificOffsets(specificStartOffsets);
        } else {
            this.setStartFromGroupOffsets();
        }
    }

    @Override
    public void cancel() {
        super.cancel();
        dataFabricUtil.close();
        ((FlinkDeserializer)keyedDeserializationSchema).close();
    }
}
