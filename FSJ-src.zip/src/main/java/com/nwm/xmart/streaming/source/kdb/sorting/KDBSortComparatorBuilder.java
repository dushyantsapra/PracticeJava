package com.nwm.xmart.streaming.source.kdb.sorting;

import com.nwm.xmart.streaming.source.kdb.event.KDBSourceEvent;
import com.nwm.xmart.streaming.source.kdb.exception.KDBMatrixDataParsingException;

import java.util.Comparator;

/**
 * Created by gardlex on 01/05/2018.
 */
public class KDBSortComparatorBuilder {
    public static Comparator<KDBSourceEvent> createSortComparatorForType(KDBFunctionType kdbFunctionType) {
        switch (kdbFunctionType) {
            case FI_MIFID_RFQ:
                return new DateTimeComparator();
            default:
                throw new KDBMatrixDataParsingException("Unsupported KDBFunctionType [ " + kdbFunctionType + " ]");
        }
    }
}
