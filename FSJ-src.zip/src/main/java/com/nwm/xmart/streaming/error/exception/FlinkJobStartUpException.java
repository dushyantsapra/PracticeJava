package com.nwm.xmart.streaming.error.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class FlinkJobStartUpException extends RuntimeException {

    public FlinkJobStartUpException() {
        super();
    }

    public FlinkJobStartUpException(String msg) {
        super(msg);
    }

    public FlinkJobStartUpException(String msg, Throwable t) {
        super(msg, t);
    }
}
