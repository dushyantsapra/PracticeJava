package com.nwm.xmart.streaming.database;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.nwm.xmart.sso.EncryptDecryptAES;
import org.apache.flink.api.java.utils.ParameterTool;

/**
 * Created by heskets on 29/01/2019.
 */
public final class SqlServerConnectionDetails {

    private final int sessionRetryLimit;
    private final int sessionRetryPeriod;
    private final int retryLimit;
    private final int retryPeriod;
    private final String server;
    private final String database;
    private final String username;
    private final String encryptedPassword;
    private final int timeoutSec;

    private SqlServerConnectionDetails() {
        this.server = null;
        this.database = null;
        this.username = null;
        this.encryptedPassword = null;

        this.sessionRetryLimit = 0;
        this.sessionRetryPeriod = 0;
        this.retryLimit = 0;
        this.retryPeriod = 0;

        this.timeoutSec = 0;
    }

    public SqlServerConnectionDetails(ParameterTool parameters){
        server = parameters.get("operator.sink.sqlserver.server");
        database = parameters.get("operator.sink.sqlserver.database");
        username = parameters.get("operator.sink.sqlserver.username");
        encryptedPassword = parameters.get("operator.sink.sqlserver.password");

        this.sessionRetryLimit = parameters.getInt("source.get.session.retry.limit", 0);
        this.sessionRetryPeriod = parameters.getInt("source.get.session.retry.period.millisec", 0);
        this.retryLimit = parameters.getInt("operator.sink.sqlserver.retry.limit");
        this.retryPeriod = parameters.getInt("operator.sink.sqlserver.retry.period");

        this.timeoutSec = parameters.getInt("operator.sink.sqlserver.timeout.sec");
    }

    public int getRetryLimit() {
        return retryLimit;
    }

    public int getRetryPeriod() {
        return retryPeriod;
    }

    public String getServer() {
        return server;
    }

    public String getDatabase() {
        return database;
    }

    public String getUsername() {
        return username;
    }

    public String getEncryptedPassword() {
        return encryptedPassword;
    }

    public int getTimeoutSec() {
        return timeoutSec;
    }

    public int getSessionRetryLimit() {
        return sessionRetryLimit;
    }

    public int getSessionRetryPeriod() {
        return sessionRetryPeriod;
    }

    public String getURL() {
        return "jdbc:sqlserver://" + server + ";databaseName=" + database;
    }

    public SQLServerDataSource getDataSource() {

        String password = EncryptDecryptAES.decrypt(encryptedPassword);

        // create the SQLServer connector using the parameters above

        SQLServerDataSource ds = new SQLServerDataSource();

        ds.setURL(getURL());
        ds.setUser(username);
        ds.setPassword(password);

        return ds;
    }
}



