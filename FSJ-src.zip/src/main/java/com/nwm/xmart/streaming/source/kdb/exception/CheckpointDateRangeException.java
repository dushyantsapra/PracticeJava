package com.nwm.xmart.streaming.source.kdb.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class CheckpointDateRangeException extends RuntimeException {

    public CheckpointDateRangeException() {
        super();
    }

    public CheckpointDateRangeException(String msg) {
        super(msg);
    }

    public CheckpointDateRangeException(String msg, Throwable t) {
        super(msg, t);
    }
}
