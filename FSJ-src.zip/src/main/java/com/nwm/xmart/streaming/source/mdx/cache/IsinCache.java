package com.nwm.xmart.streaming.source.mdx.cache;

import com.nwm.xmart.streaming.database.exceptions.SqlServerConnectorException;
import com.nwm.xmart.streaming.source.mdx.cache.listener.ISINCacheListener;
import com.nwm.xmart.streaming.source.mdx.cache.load.CacheItem;
import com.nwm.xmart.streaming.source.mdx.cache.load.ISINCacheLoader;
import com.nwm.xmart.util.MDCUtil;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.util.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalTime;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.*;

/**
 * Created by gardlex on 21/05/2018.
 */
public abstract class IsinCache {
    protected static Logger logger = LoggerFactory.getLogger(IsinCache.class);
    protected final ISINCacheLoader isinCacheLoader;
    protected final String sourceName;
    protected final int refreshInterval;
    protected final ConcurrentMap<String, CacheItem> isinMap = new ConcurrentHashMap<>();
    protected volatile ISINCacheListener isinCacheListener;
    protected ScheduledExecutorService scheduledExecutorService;
    protected ParameterTool flinkParams;

    public IsinCache(String sourceName, ParameterTool flinkParams, ISINCacheLoader isinCacheLoader) {
        this.sourceName = sourceName;
        this.flinkParams = flinkParams;
        this.refreshInterval = flinkParams.getInt("mdx.isin.cache.refresh.interval.seconds",3600);
        this.isinCacheLoader = isinCacheLoader;
    }

    protected void getScehduledExecutorService(String sourceName) {
        this.scheduledExecutorService = Executors.newSingleThreadScheduledExecutor(
                new ThreadFactory() {
                    @Override
                    public Thread newThread(Runnable r) {
                        Thread t = new Thread(r);

                        t.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                            @Override
                            public void uncaughtException(Thread t, Throwable e) {
                                LoggerFactory.getLogger(t.getName()).error("ISIN Refresh Thread for SourceName [ " + sourceName + " ], is no longer running", e.getMessage(), e);
                            }
                        });

                        return t;
                    }
                }
        );
    }

    public void registerCacheListener(ISINCacheListener cacheListener) {
        this.isinCacheListener = cacheListener;
    }

    public void setRestoredISINS(Set<CacheItem> restoredISINs) {
        for (CacheItem cacheItem : restoredISINs) {
            isinMap.put(cacheItem.getIdentifier(), cacheItem);
        }

//        for (Map.Entry entry :isinMap.entrySet()) {
//        }

    }

    public abstract Integer getCachedVersionForISIN(String isin);

    /**
     * MUST BE USED when holding the Checkpoint lock other map state will not be correct
     *
     * @param newCacheItem
     * @return
     */
    public abstract boolean putISINCacheItem(CacheItem newCacheItem);

    /**
     * The full list of ISINs that have been used in transactions - load from underlying datastore
     *
     * @return
     */
    public Set<String> getISINsToLoad() throws SqlServerConnectorException {
        return isinCacheLoader.getLatestISINs();
    }

    public void startPeriodicRefreshLoad() {
        getScehduledExecutorService(sourceName);
        scheduledExecutorService.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                try {
                    // Set the job name in MDC
                    MDCUtil.putJobNameInMDC(flinkParams);
                    // get the latest ISINs
                    Set<String> latestIsins = isinCacheLoader.getLatestISINs();

                    // Work out the deltas
                    Set<String> newIsins = new HashSet<>();
                    for (String latestIsin : latestIsins) {
                        if (isinMap.get(latestIsin) == null) {
                            newIsins.add(latestIsin);
                        }
                    }

                    // call the cache listener
                    logger.info("About to call the cache listener {}", LocalTime.now());

                    isinCacheListener.setLatestISINs(latestIsins, newIsins);

                    logger.info("Finished call the cache listener {}", LocalTime.now());

                } catch (Exception e) {
                    logger.error("Error occurred whilst refreshing the ISIN cache", e);
                    throw new RuntimeException("Error occurred whilst refreshing the ISIN cache", e);
                }
            }
        }, refreshInterval, refreshInterval, TimeUnit.SECONDS);
        logger.info("Scheduled ISIN Cache Refresh cycle at interval: " + refreshInterval);
    }

    public void close() {
        scheduledExecutorService.shutdownNow();
    }

    // for checkpointing
    public Collection<CacheItem> getValues() {
        return isinMap.values();
    }
}
