package com.nwm.xmart.streaming.source.mdx.entity;

public class RefRegInstrumentIsinFields {
    private String iSIN;
    private String status;
    private String statusReason;
    private String lastUpdateDateTime;

    public String getiSIN() {
        return iSIN;
    }

    public void setiSIN(String iSIN) {
        this.iSIN = iSIN;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusReason() {
        return statusReason;
    }

    public void setStatusReason(String statusReason) {
        this.statusReason = statusReason;
    }

    public String getLastUpdateDateTime() {
        return lastUpdateDateTime;
    }

    public void setLastUpdateDateTime(String lastUpdateDateTime) {
        this.lastUpdateDateTime = lastUpdateDateTime;
    }
}
