package com.nwm.xmart.streaming.source.df.serialisation;


import com.nwm.xmart.streaming.error.exception.DeserialisationException;
import com.nwm.xmart.streaming.monitor.InactivityMonitor;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import com.nwm.xmart.util.MDCUtil;
import com.rbs.datafabric.domain.DomainObject;
import com.rbs.datafabric.domain.Record;
import com.rbs.datafabric.domain.event.*;
import com.rbs.datafabric.protocol.Datafabric;
import com.rbs.datafabric.protocol.ProtocolMessageDecoder;
import com.rbs.datafabric.protocol.exception.DecoderException;
import org.apache.commons.lang3.reflect.ConstructorUtils;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.util.serialization.KeyedDeserializationSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

/**
 * Created by gardlex on 21/09/2017.
 */
public class FlinkDeserializer<SourceEventClass, SourceEventPayloadClass, StoredErrorEventClass> implements KeyedDeserializationSchema<SourceEventClass> {
    private static Logger logger = LoggerFactory.getLogger(FlinkDeserializer.class);
    private final Class<SourceEventClass> sourceEventClass;
    private final Class<SourceEventPayloadClass> targetClass;
    private final DataFabricUtil dataFabricUtil;
    private ProtocolMessageDecoder protocolMessageDecoder;
    private SourceDeserializer sourceDeserializer;
    private final String jobName;
    private final String operatorName;
    private final String mdcJobNameKey;
    private volatile long currentOffset;
    private final long inactivityMonitorInterval;
    private ScheduledExecutorService scheduledExecutorService;
    private boolean hasInactivityMonitorStarted;
    private final InactivityMonitor inactivityMonitor;
    private final Configuration configuration;
    private String dfKey;
    private long dfVersion;

    public FlinkDeserializer(DataFabricUtil dataFabricUtil,
                             Class<SourceEventClass> sourceEventClass,
                             Class<SourceEventPayloadClass> targetClass,
                             InactivityMonitor inactivityMonitor,
                             Configuration configuration) {
        this.sourceEventClass = sourceEventClass;
        this.targetClass = targetClass;
        this.dataFabricUtil = dataFabricUtil;
        this.jobName = configuration.getString("flink.job.name", "No Job Name Specific");
        this.operatorName =  configuration.getString("operator.source.name","");
        this.mdcJobNameKey =  configuration.getString("nwm.job.param","jobName");
        this.inactivityMonitorInterval = configuration.getLong("kafka.inactivity.monitor.interval.seconds", 60);
        this.inactivityMonitor = inactivityMonitor;
        this.configuration = configuration;
    }

    @Override
    public SourceEventClass deserialize(byte[] messageKey, byte[] message, String topic, int partition, long offset) throws IOException {

        //MDC, as this is first entry point after the kafka consumer
        putJobNameInMDC(configuration);

        currentOffset = offset;
        SourceEventPayloadClass document = null;
        dfKey = null;
        dfVersion = -1;

        try {
            checkDataFabricUtlitiesExist();
            checlInactivityMonitorStarted();
            DomainObject domainObject = protocolMessageDecoder.decode(Datafabric.Message.parseFrom(message));

            // REJECT PING messages and only accept DURABLE WATCH  & DURABLE WATCH SCAN events
            if (domainObject instanceof WatchEventEnvelope) {
                WatchEventEnvelope watchEventEnvelope = (WatchEventEnvelope) domainObject;
                RecordModifiedEvent rme = watchEventEnvelope.getRecordModifiedEvent();
                dfKey = rme.getRecord().getId().getKey();
                dfVersion = rme.getRecord().getId().getVersion();
                try {
                    if (!(rme instanceof RecordDeletedEvent)) {
                        document = sourceDeserializer.deserialize(rme, targetClass);
                    }
                } catch (Exception e) {
                    logger.error("Could not deserialise RecordModifiedEvent document, topic={}, offset={}, partition={}, dfKey={}, dfVersion{}", e, topic, currentOffset, partition, dfKey, dfVersion);                        logger.error("Could not deserialise ContinuousQuerySnapshotStreamEvent document, topic={}, offset={}, partition={}, dfKey={}, dfVersion{}", e, topic, currentOffset, partition, dfKey, dfVersion);
                    throw new DeserialisationException("Could not deserialise RecordModifiedEvent document, topic=" + topic + ", offset=" + currentOffset + ", partition=" + partition + ", dfKey=" + dfKey + ", dfVersion" + dfVersion, e);
                }
            } else if (domainObject instanceof ContinuousQueryEvent) {
                if (domainObject instanceof ContinuousQuerySnapshotStreamEndedEvent) {
                    ContinuousQuerySnapshotStreamEndedEvent continuousQuerySnapshotStreamEndedEvent = (ContinuousQuerySnapshotStreamEndedEvent) domainObject;
                    logger.info("Received all events from scan, topic={}, offset={}, partition={}", topic, currentOffset, partition);
                    return null;
                } else {
                    ContinuousQuerySnapshotStreamEvent continuousQuerySnapshotStreamEvent = (ContinuousQuerySnapshotStreamEvent) domainObject;
                    Record record = continuousQuerySnapshotStreamEvent.getRecord();
                    dfKey = record.getId().getKey();
                    dfVersion = record.getId().getVersion();
                    try {
                        document = sourceDeserializer.deserialize(record, targetClass);
                    } catch (Exception e) {
                        logger.error("Could not deserialise ContinuousQuerySnapshotStreamEvent document, topic={}, offset={}, partition={}, dfKey={}, dfVersion{}", e, topic, currentOffset, partition, dfKey, dfVersion);
                        throw new DeserialisationException("Could not deserialise ContinuousQuerySnapshotStreamEvent document, topic=" + topic + ", offset=" + currentOffset + ", partition=" + partition + ", dfKey=" + dfKey + ", dfVersion" + dfVersion, e);
                    }
                }
            }

            // Other messages recd if we reached this point - possible PING msgs
            if (document == null) {
                logger.warn("Rejected Event: A NON-(Durable Watch OR Durable Watch Scan) event found, possibly a PING message");
                // returning null means that nothing is passed to the next operator in the stream, allowing the stream continues processing in spite of an error
                return null;
            }

            // Return the container class wrapping the payload class
            return ConstructorUtils.invokeConstructor(sourceEventClass, document, System.currentTimeMillis(), topic, partition, offset, dfKey, dfVersion);

        } catch (DecoderException f) {
            logger.error("Could not decode data fabric message, topic={}, offset={}, partition={}", f, topic, currentOffset, partition);
            throw new DeserialisationException("Could not decode event, topic=" + topic + ", offset=" + currentOffset + ", partition=" + partition, f);
        } catch (IllegalAccessException | NoSuchMethodException | InstantiationException | InvocationTargetException g) {
            logger.error("Could not create source event, topic={}, offset={}, partition={}, dfKey={}, dfVersion{}", g, topic, currentOffset, partition, dfKey, dfVersion);
            throw new DeserialisationException("Could not create source event, topic=" + topic + ", offset=" + currentOffset + ", partition=" + partition + ", dfKey=" + dfKey + ", dfVersion" + dfVersion, g);
        }

    }

    private void checkDataFabricUtlitiesExist() {
        if (protocolMessageDecoder == null) {
            protocolMessageDecoder = dataFabricUtil.getProtocolDecoderDeserializerInstance();
            sourceDeserializer = dataFabricUtil.getSourceDeserializerInstance();
            MDC.put(mdcJobNameKey,jobName);
        }
    }

    @Override
    public boolean isEndOfStream(SourceEventClass document) {
        return false;
    }

    @Override
    public TypeInformation<SourceEventClass> getProducedType() {
        return TypeExtractor.getForClass(sourceEventClass);
    }


    // Inactivity Monitors
    private void checlInactivityMonitorStarted() {

        if (!hasInactivityMonitorStarted) {
            try {
                // Create the thread
                logger.info("About to schedule  InactivityMonitor");
                scheduledExecutorService = Executors.newSingleThreadScheduledExecutor(
                        new ThreadFactory() {
                            @Override
                            public Thread newThread(Runnable r) {
                                Thread t = new Thread(r);

                                t.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                                    @Override
                                    public void uncaughtException(Thread t, Throwable e) {
                                        LoggerFactory.getLogger(t.getName()).error("InactivityMonitor for JobName [ " + jobName + " ], OperatorName = " + operatorName + " is no longer running", e.getMessage(), e);
                                    }
                                });

                                return t;

                            }
                        }
                );
                logger.info("About to schedule InactivityMonitor");
                scheduledExecutorService.scheduleAtFixedRate(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            inactivityMonitor.updateStreamPosition(currentOffset);
                        } catch (IOException e) {
                            logger.error("Error occurred updating the inactivityMonitor", e);
                            throw new RuntimeException("Error occurred updating the inactivityMonitor");
                        }
                    }
                }, 0, inactivityMonitorInterval, TimeUnit.SECONDS);
                logger.info("Scheduled InactivityMonitor");
                hasInactivityMonitorStarted = true;
            } catch (Exception e) {
                logger.error("Could not start inactivity monitor thread", e);
                throw new RuntimeException("Could not start inactivity monitor thread");
            }
        }
    }


    public void close() {
        scheduledExecutorService.shutdown();
    }
}
