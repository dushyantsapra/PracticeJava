package com.nwm.xmart.streaming.source.mdx.event;

import com.nwm.xmart.streaming.database.session.XmartSession;
import com.nwm.xmart.streaming.source.mdx.entity.RefRegInstrument;
import com.nwm.xmart.streaming.source.mdx.entity.RefRegInstrumentUnderlying;
import com.nwm.xmart.streaming.source.mdx.entity.ReferenceRegulatory;
import com.nwm.xmart.streaming.source.mdx.entity.TimeSeriesEsma;
import com.nwm.xmart.streaming.source.xml.XmlDocumentTraverser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.dx.webService.interfaces.regulatory.IEligibilityPayload;
import rbs.gbm.mdx.webService.impl.MdxTimePointContent;
import rbs.gbm.mdx.webService.interfaces.IMdxDocument;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

import static com.nwm.xmart.streaming.source.mdx.parser.RefRegInstrumentUnderlyingParser.buildRefRegInstrumentUnderlying;
import static com.nwm.xmart.streaming.source.mdx.parser.ReferenceRegulatoryInstrumentParser.buildRefRegInstrument;
import static com.nwm.xmart.streaming.source.mdx.parser.TimeSeriesEsmaParser.buildTimeSeriesEsma;

public class MdxDocumentEvent {
    private final static Logger logger = LoggerFactory.getLogger(MdxDocumentEvent.class);

    private final long documentReceivedTimestamp;
    private final long epochMdxDataStoreWriteTime;
    private final MdxEventType mdxEventType;
    private final String identifier;
    private final int version;
    private final ProcessingType processingType;
    private final String sourceID;
    private final long currentJobEventID;
    private final RefRegInstrument refRegInstrument;
    private final TimeSeriesEsma timeSeriesEsma;
    private final List<RefRegInstrumentUnderlying> refRegInstrumentUnderlyings;
    private final IMdxDocument iMdxDocument;
    private final XmlDocumentTraverser mdxDocumentTraverser;
    private final MdxTimePointContent mdxTimePointContent;
    private final String functionName;
    private final String seriesTypeName;
    private final ReferenceRegulatory referenceRegulatory;
    private final String loadDate;
    private final XmartSession xmartSession;

    private MdxDocumentEvent(long documentReceivedTimestamp,
            long epochMdxDataStoreWriteTime,
            MdxEventType mdxEventType,
            String identifier,
            int version,
            ProcessingType processingType,
            String sourceID,
            long currentJobEventID,
            RefRegInstrument refRegInstrument,
            TimeSeriesEsma timeSeriesEsma,
            List<RefRegInstrumentUnderlying> refRegInstrumentUnderlyings,
            IMdxDocument iMdxDocument,
            XmlDocumentTraverser mdxDocumentTraverser,
            MdxTimePointContent mdxTimePointContent,
            String functionName,
            String seriesTypeName,
            ReferenceRegulatory referenceRegulatory,
            String loadDate,
            XmartSession xmartSession) {
        this.documentReceivedTimestamp = documentReceivedTimestamp;
        this.epochMdxDataStoreWriteTime = epochMdxDataStoreWriteTime;
        this.mdxEventType = mdxEventType;
        this.identifier = identifier;
        this.version = version;
        this.processingType = processingType;
        this.sourceID = sourceID;
        this.currentJobEventID = currentJobEventID;
        this.refRegInstrument = refRegInstrument;
        this.timeSeriesEsma = timeSeriesEsma;
        this.refRegInstrumentUnderlyings = refRegInstrumentUnderlyings;
        this.iMdxDocument = iMdxDocument;
        this.mdxDocumentTraverser = mdxDocumentTraverser;
        this.mdxTimePointContent = mdxTimePointContent;
        this.functionName = functionName;
        this.seriesTypeName = seriesTypeName;
        this.referenceRegulatory = referenceRegulatory;
        this.loadDate = loadDate;
        this.xmartSession = xmartSession;
    }

    public static MdxDocumentEvent ofIMdxDocumentWithRegInstrument(String sourceID,
            long currentJobEventID,
            IMdxDocument iMdxDocument,
            long documentReceivedTimestamp,
            long epochMdxDataStoreWriteTime,
            int version,
            String identifier,
            ProcessingType processingType) {

        return new MdxDocumentEvent(documentReceivedTimestamp,
                epochMdxDataStoreWriteTime,
                MdxEventType.SERIES_VIEW,
                identifier,
                version,
                processingType,
                sourceID,
                currentJobEventID,
                buildRefRegInstrument(iMdxDocument),
                null,
                buildRefRegInstrumentUnderlying(iMdxDocument),
                iMdxDocument,
                null,
                null,
                MdxSeriesTypeName.get(iMdxDocument.getHeader().getIdentifier().getTypeName()).getRootName(),
                iMdxDocument.getHeader().getIdentifier().getTypeName(),
                null,
                null,
                 null);

    }

    public static MdxDocumentEvent ofMdxTimePointContent (String sourceID, long currentJobEventID, MdxTimePointContent mdxTimePointContent,
            long documentReceivedTimestamp, long epochMdxDataStoreWriteTime, int version, String identifier,
            ProcessingType processingType) {

        return new MdxDocumentEvent(documentReceivedTimestamp,
                epochMdxDataStoreWriteTime,
                MdxEventType.TIME_SERIES,
                identifier,
                version,
                processingType,
                sourceID,
                currentJobEventID,
                null,
                buildTimeSeriesEsma(identifier, mdxTimePointContent),
                null,
                null,
                null,
                mdxTimePointContent,
                "mdxTimePointEsma",
                null,
                null,
                null,
                null);
    }

    public static MdxDocumentEvent ofIEligibilityPayload(IEligibilityPayload iEligibilityPayload, String functionName, String seriesTypeName,
            String sourceID, long currentJobEventID, long documentReceivedTimestamp) {

        ReferenceRegulatory referenceRegulatory = new ReferenceRegulatory(iEligibilityPayload.getIsin(),
                iEligibilityPayload.getCfiCode(), iEligibilityPayload.getInstrumentLongName(),
                iEligibilityPayload.getIsLiquid(), iEligibilityPayload.getPostTradeSstiThreshold(),
                iEligibilityPayload.getPostTradeLisThreshold(), iEligibilityPayload.getPreTradeSstiThreshold(),
                iEligibilityPayload.getPreTradeLisThreshold(), iEligibilityPayload.getTradedOnTradingVenue(),
                iEligibilityPayload.getTradedOnTradingVenueUnderlyer());

        return new MdxDocumentEvent(documentReceivedTimestamp,
                0,
                MdxEventType.SERIES_VIEW,
                null,
                0,
                null,
                sourceID,
                currentJobEventID,
                null,
                null,
                null,
                null,
                null,
                null,
                functionName,
                seriesTypeName,
                referenceRegulatory,
                null,
                null);

    }

    public static MdxDocumentEvent ofIMdxDocument(String sourceID, long currentJobEventID, IMdxDocument iMdxDocument,
            long documentReceivedTimestamp, long epochMdxDataStoreWriteTime, int version, String identifier,
            ProcessingType processingType, String loadDate,
            XmartSession xmartSession) {

        return new MdxDocumentEvent(documentReceivedTimestamp,
            epochMdxDataStoreWriteTime,
            MdxEventType.SERIES_VIEW,
            identifier,
            version,
            processingType,
            sourceID,
            currentJobEventID,
            null,
            null,
            null,
            iMdxDocument,
            new XmlDocumentTraverser(iMdxDocument.getContent().asString()),
            null,
            MdxSeriesTypeName.get(iMdxDocument.getHeader().getIdentifier().getTypeName()).getRootName(),
            iMdxDocument.getHeader().getIdentifier().getTypeName(),
            null,
                loadDate, xmartSession);

    }

    public long getDocumentReceivedTimestamp() {
        return documentReceivedTimestamp;
    }

    public long getEpochMdxDataStoreWriteTime() {
        return epochMdxDataStoreWriteTime;
    }

    public LocalDateTime getMdxDataStoreWriteTime() {
        return Instant.ofEpochMilli(epochMdxDataStoreWriteTime).atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    public MdxEventType getMdxEventType() {
        return mdxEventType;
    }

    public String getIdentifier() {
        return identifier;
    }

    public int getVersion() {
        return version;
    }

    public ProcessingType getProcessingType() {
        return processingType;
    }

    public String getSourceID() {
        return sourceID;
    }

    public long getCurrentJobEventID() {
        return currentJobEventID;
    }

    public RefRegInstrument getRefRegInstrument() {
        return refRegInstrument;
    }

    public TimeSeriesEsma getTimeSeriesEsma() {
        return timeSeriesEsma;
    }

    public List<RefRegInstrumentUnderlying> getRefRegInstrumentUnderlyings() {
        return refRegInstrumentUnderlyings;
    }

    public IMdxDocument getiMdxDocument() {
        return iMdxDocument;
    }

    public XmlDocumentTraverser getMdxDocumentTraverser() {
        return mdxDocumentTraverser;
    }

    public MdxTimePointContent getMdxTimePointContent() {
        return mdxTimePointContent;
    }

    public String getFunctionName() {
        return functionName;
    }

    public String getSeriesTypeName() {
        return seriesTypeName;
    }

    public ReferenceRegulatory getReferenceRegulatory() {
        return referenceRegulatory;
    }

    public String getLoadDate() {
        return loadDate;
    }

    public XmartSession getXmartSession() {
        return xmartSession;
    }
}
