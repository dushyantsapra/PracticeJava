package com.nwm.xmart.streaming.example;

import com.nwm.xmart.streaming.common.job.StreamJob;
import com.nwm.xmart.streaming.source.kdb.KDBSource;
import com.nwm.xmart.streaming.source.kdb.event.KDBSourceEvent;
import com.nwm.xmart.streaming.source.kdb.parameters.BdxKdbFunctionDetails;
import com.nwm.xmart.streaming.source.kdb.sorting.KDBFunctionType;
import com.nwm.xmart.streaming.source.mdx.session.MDXSessionType;
import com.nwm.xmart.streaming.source.tdx.TDXSource;
import com.nwm.xmart.streaming.source.tdx.event.TDXSourceEvent;
import com.rbs.datafabric.client.DataFabricClient;
import com.rbs.datafabric.client.DataFabricClientFactory;
import com.rbs.datafabric.domain.ClientConfiguration;
import com.rbs.datafabric.domain.Credentials;
import com.rbs.datafabric.domain.Document;
import com.rbs.datafabric.domain.DocumentFormat;
import com.rbs.datafabric.domain.client.builder.InsertRequestBuilder;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.PrintSinkFunction;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Created by gardlex on 18/10/2017.
 */
public class CheckpointedTDXAPISourceTest {

    private static Logger logger = LoggerFactory.getLogger(CheckpointedMDXSourceTest.class);

    public static void main(String[] args) throws Exception {

        // Populate cache with 10 stream events
        CheckpointedTDXAPISourceTest t = new CheckpointedTDXAPISourceTest();
        t.buildStream(args);

    }

    public void buildStream(String[] args) throws Exception {
        // StreamJob implementation can override any abstract methid as long as it calls super() first
        TDXAPIStreamJob streamJob = new TDXAPIStreamJob();
        streamJob.run(args);
    }

    class TDXAPIStreamJob extends StreamJob {

        @Override
        protected void configureAndExecuteStream(StreamExecutionEnvironment env) {

            try {
            // Type info reqd for the FlinkDeserializer
            final TypeInformation<TDXSourceEvent> tdxSourceEventType = TypeInformation.of(new TypeHint<TDXSourceEvent>(){});
            Class<TDXSourceEvent> tdxSourceClassRef = tdxSourceEventType.getTypeClass();
//            DataStream<KDBSourceEvent> stream1 = configureSrc1(env, parameters, mdxSourceClassRef, mdxSourceEventType);
//            DataStream<KDBSourceEvent> stream2 = configureSrc2(env, parameters, mdxSourceClassRef, mdxSourceEventType);
//            DataStream<KDBSourceEvent> stream3 = configureSrc3(env, parameters, mdxSourceClassRef, mdxSourceEventType);
//            DataStream<KDBSourceEvent> stream4 = configureSrc4(env, parameters, mdxSourceClassRef, mdxSourceEventType);
//            DataStream<KDBSourceEvent> stream5 = configureSrc5(env, parameters, mdxSourceClassRef, mdxSourceEventType);
//            DataStream<KDBSourceEvent> stream6 = configureSrc6(env, parameters, mdxSourceClassRef, mdxSourceEventType);
//            DataStream<KDBSourceEvent> stream7 = configureSrc7(env, parameters, mdxSourceClassRef, mdxSourceEventType);
            DataStream<TDXSourceEvent> streamTDX = configureTDXAPISource(env, parameters, tdxSourceClassRef, tdxSourceEventType);

//            DataStream<KDBSourceEvent> joinedMdxStream = stream1.union(stream2, stream3, stream7);

//                streamTDX.addSink(new PrintSinkFunction()  {
//                    @Override
//                    public void invoke(Object record) {
//                        super.invoke(record);
//                    }
//                });


                streamTDX.addSink(new TestSink())
                    .uid("TDXAPI-TestSink")
                    .name("TDXAPI-TestSink")
                    .setParallelism(1);

            env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);


                String execPlan = env.getExecutionPlan();
                logger.info("TDXAPI EXECUTION PLAN = " + execPlan);
                env.execute(configuration.getString("flink.job.name",""));
            } catch (Exception e) {
                logger.error("Exception running the Checkpointed TDXAPI SourceTest",e);
                throw new RuntimeException(e);
            }
        }
    }

    private DataStream<TDXSourceEvent> configureTDXAPISource(StreamExecutionEnvironment env, ParameterTool parameters, Class<TDXSourceEvent> tdxSourceClassRef, TypeInformation<TDXSourceEvent> tdxSourceEventType) {
        SourceFunction<TDXSourceEvent> src1 =  new TDXSource("TDX-Source-TEST-Name");
        DataStream<TDXSourceEvent> dateStream = env.addSource(src1, tdxSourceEventType)
                .uid("TDXAPI-SOURCE_UID")
                .name("TDXAPI-SOURCE_NAME")
                .setParallelism(1);

        return dateStream;
    }

    private DataStream<KDBSourceEvent> configureFISource(StreamExecutionEnvironment env, ParameterTool parameters, Class<KDBSourceEvent> mdxSourceClassRef, TypeInformation<KDBSourceEvent> kdbSourceEventType) {

        ConcurrentMap<String,String> functionParameters = new ConcurrentHashMap<>();
        functionParameters.put(parameters.get("kdb.src1.parameter.startDate.key"),parameters.get("kdb.src1.parameter.startDate.value"));
        functionParameters.put(parameters.get("kdb.src1.parameter.endDate.key"),parameters.get("kdb.src1.parameter.endDate.value"));

        ConcurrentMap<String,String> functionParameters2 = new ConcurrentHashMap<>();
        functionParameters2.put(parameters.get("kdb.src2.parameter.startDate.key"),parameters.get("kdb.src2.parameter.startDate.value"));
        functionParameters2.put(parameters.get("kdb.src2.parameter.endDate.key"),parameters.get("kdb.src2.parameter.endDate.value"));

        BdxKdbFunctionDetails fiMifidRfqDetails = new BdxKdbFunctionDetails(
                parameters.get("kdb.src1.sourceID"),
                parameters.get("kdb.src1.kdbFunctionName"),
                parameters.get("kdb.src1.sourceName"),
                KDBFunctionType.FI_MIFID_RFQ,
                MDXSessionType.SSO,
                functionParameters,
                parameters.get("kdb.src1.mdxEnvironmentName"),
                parameters.get("kdb.src1.kdbEnvironmentName"),
                parameters.get("kdb.src1.tableName.value"));

        BdxKdbFunctionDetails fiMifidQecDetails = new BdxKdbFunctionDetails(
                parameters.get("kdb.src2.sourceID"),
                parameters.get("kdb.src2.kdbFunctionName"),
                parameters.get("kdb.src2.sourceName"),
                KDBFunctionType.FI_MIFID_QEC,
                MDXSessionType.SSO,
                functionParameters2,
                parameters.get("kdb.src2.mdxEnvironmentName"),
                parameters.get("kdb.src2.kdbEnvironmentName"),
                parameters.get("kdb.src2.tableName.value"));


        List<BdxKdbFunctionDetails> list = new ArrayList<BdxKdbFunctionDetails>();
        list.add(fiMifidRfqDetails);
        list.add(fiMifidQecDetails);

        SourceFunction<KDBSourceEvent> src1 =  new KDBSource(parameters, list);
        DataStream<KDBSourceEvent> dateStream = env.addSource(src1, kdbSourceEventType)
                .uid("FI_RFQ_QECSRC_UID")
                .name("FI_RFQ_QEC_SRC_NAME")
                .setParallelism(1);

        return dateStream;
    }

    class TestSink extends RichSinkFunction<TDXSourceEvent> implements CheckpointListener {

        private Logger logger = LoggerFactory.getLogger(TestSink.class);
        private DataFabricClient dataFabricClient;

        private int ctr;

        public TestSink() throws IOException {
        }

        @Override
        public void notifyCheckpointComplete(long checkpointId) throws Exception {
            logger.info("TestSINK Checkpoint RECD = " + checkpointId);
        }

        @Override
        public void invoke(TDXSourceEvent event) throws Exception {
            Document document = dataFabricClient.getDataFabricSerializer().serialize(event);
            dataFabricClient.insert(InsertRequestBuilder.create("bdx-db", "tdx-api-source-test-1").withDocument(document));
        }

        @Override
        public void open(Configuration parameters) throws Exception {
            dataFabricClient = getDFC();
        }

        private DataFabricClient getDFC() throws Exception {
            // TST
            ClientConfiguration clientConfiguration = new ClientConfiguration().withCredentials(new Credentials().withUsername("svc-XMartAppUat")
                    .withPassword("As03!#rV12"))
                    .withHost("DATAFABRIC-TST")
                    .withAccessToken("631d6bb8-feb9-4504-b725-fd069c3ebedf");
            // DEV
//        ClientConfiguration clientConfiguration = new ClientConfiguration().withCredentials(new Credentials().withUsername("svc-XMartAppDev")
//                .withPassword("$zt[o3XM"))
//                .withHost("datafabric-dev")
//                .withAccessToken("631d6bb8-feb9-4504-b725-fd069c3ebedf");

            DataFabricClient dataFabricClient = DataFabricClientFactory.createDataFabricClient(clientConfiguration);
            return dataFabricClient;
        }
    }

}
