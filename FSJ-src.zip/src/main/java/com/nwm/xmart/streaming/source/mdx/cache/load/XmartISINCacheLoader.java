package com.nwm.xmart.streaming.source.mdx.cache.load;

import com.microsoft.sqlserver.jdbc.SQLServerConnection;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import com.nwm.xmart.streaming.database.SqlServerConnectionDetails;
import com.nwm.xmart.streaming.database.SqlServerConnector;
import com.nwm.xmart.streaming.source.mdx.cache.IsinCache;
import com.nwm.xmart.streaming.source.mdx.cache.exception.ISINCacheException;
import com.nwm.xmart.streaming.database.exceptions.SqlServerConnectorException;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.java.utils.ParameterTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Created by gardlex on 15/05/2018.
 */
public class XmartISINCacheLoader implements ISINCacheLoader {
    private static Logger logger = LoggerFactory.getLogger(IsinCache.class);
    private final SqlServerConnector sqlServerConnector;
    private final ParameterTool paramaterTool;
    private AtomicReference<SQLServerConnection> sqlConnRef = new AtomicReference<>();
    private final String isinSqlQuery;

    public static void main(String[] args) throws IOException {

        Map<String, String> map = new HashMap<>();
        map.put("operator.sink.sqlserver.timeout.sec", "10");
        map.put("operator.sink.sqlserver.retry.limit", "3");
        map.put("operator.sink.sqlserver.retry.period", "5000");
        map.put("operator.sink.sqlserver.server","lonms08691.fm.rbsgrp.net\\DMGBSMT01");
        map.put("operator.sink.sqlserver.database","XMart");
        map.put("operator.sink.sqlserver.username","TDXDEV");
        map.put("operator.sink.sqlserver.password", "Ksive+RhnDQU/83neYVsZw==");
        map.put("mdx.sql.isin.query", "select instrumentid from api.V_ExportRDXISINList");   // V_ExportMDXISINList V_ExportRDXISINList


        ParameterTool pt = ParameterTool.fromMap(map);
        try {
            XmartISINCacheLoader l = new XmartISINCacheLoader("select instrumentid from api.V_TotalISINList", pt);
            Set<String> latestIsins = l.getLatestISINs();
        } catch (SqlServerConnectorException e) {
            e.printStackTrace();
        }
    }



    public XmartISINCacheLoader(String isinQuery, ParameterTool paramaterTool) throws SqlServerConnectorException {
        this.paramaterTool = paramaterTool;
        this.sqlServerConnector = new SqlServerConnector(new SqlServerConnectionDetails(paramaterTool));
        sqlConnRef.set(sqlServerConnector.getConnection());
        this.isinSqlQuery = isinQuery;
    }

    @Override
    public Set<String> getLatestISINs() throws SqlServerConnectorException {
        Set<String> latestIsins = new HashSet<>();

        if (!sqlServerConnector.checkConnection(sqlConnRef.get())) {
            sqlConnRef.set(sqlServerConnector.getConnection());
        }

        try {
            PreparedStatement preparedStatement = sqlConnRef.get().prepareStatement(isinSqlQuery);
            ResultSet rs = preparedStatement.executeQuery();

            String isin = null;
            while (rs.next()) {
                isin = rs.getString(1);
                if (StringUtils.isEmpty(isin)) {
                    throw new ISINCacheException("Found an empty or null ISIN String when fetching the ISINs from the database view, invalid value is [ " + isin + " ]");
                }
                latestIsins.add(isin);
            }

        } catch (Exception e) {
            throw new SqlServerConnectorException("", e);
        }

        return latestIsins;
    }

    @Override
    public void close() {
        try {
            sqlConnRef.get().close();
        } catch (SQLServerException e) {
            // ignore;
        }
    }
}
