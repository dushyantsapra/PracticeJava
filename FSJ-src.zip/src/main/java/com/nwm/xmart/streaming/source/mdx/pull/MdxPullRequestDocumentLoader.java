package com.nwm.xmart.streaming.source.mdx.pull;

import com.nwm.xmart.streaming.source.mdx.cache.IsinCache;
import com.nwm.xmart.streaming.source.mdx.cache.listener.ISINCacheListener;
import com.nwm.xmart.streaming.source.mdx.subscription.MdxSubscription;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import rbs.gbm.mdx.webService.interfaces.MdxException;

/**
 * Created by gardlex on 11/04/2018.
 */
public interface MdxPullRequestDocumentLoader<MdxSourceEvent> extends ISINCacheListener {
    MdxPullRequestDocumentLoader withInitialCapacity(int capacity);
    MdxPullRequestDocumentLoader withReadBatchSize(int readBatchSize);
    MdxPullRequestDocumentLoader withMdxIdentifier(String identifier);
    MdxPullRequestDocumentLoader withISINCache(IsinCache isinCache);
    void setSourceContext(SourceFunction.SourceContext srcCtx);
//    MdxPullRequestDocumentLoader withMdxSessionContext(MdxSessionContext mdxSessionContext);
    MdxPullRequestDocumentLoader withMdxDocumentStoreFetcher(MdxReader documentStoreFetcher);
    void loadDocuments() throws MdxException;
    MdxPullRequestDocumentLoader withCounter(IntCounter counter);
    MdxPullRequestDocumentLoader withSubscription(MdxSubscription subscription);
    void setInitialLoad(boolean isInitialLoad);
    MdxPullRequestDocumentLoader withSourceFunction(SourceFunction<MdxSourceEvent> sourceFunction);
}
