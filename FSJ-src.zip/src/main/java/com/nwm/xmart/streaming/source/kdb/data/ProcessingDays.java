package com.nwm.xmart.streaming.source.kdb.data;

import java.util.List;

/**
 * Created by gardlex on 21/06/2018.
 */
public class ProcessingDays {

    private final List<String> daysToLoad;
    private final KDBProcessingMode kdbProcessingMode;

    public ProcessingDays(List<String> daysToLoad, KDBProcessingMode kdbProcessingMode) {
        this.daysToLoad = daysToLoad;
        this.kdbProcessingMode = kdbProcessingMode;
    }

    public List<String> getDaysToLoad() {
        return daysToLoad;
    }

    public KDBProcessingMode getKdbProcessingMode() {
        return kdbProcessingMode;
    }
}
