package com.nwm.xmart.streaming.source.mdx;

import com.nwm.xmart.streaming.database.SqlServerConnectionDetails;
import com.nwm.xmart.streaming.database.exceptions.XmartSqlServerException;
import com.nwm.xmart.streaming.database.session.XmartSession;
import com.nwm.xmart.streaming.manager.SourceManager;
import com.nwm.xmart.streaming.manager.results.ProcessingResults;
import com.nwm.xmart.streaming.manager.settings.FunctionSettings;
import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.streaming.source.mdx.event.MdxEventType;
import com.nwm.xmart.streaming.source.mdx.event.ProcessingType;
import com.nwm.xmart.streaming.source.mdx.exception.MdxLoadFailureException;
import com.nwm.xmart.streaming.source.mdx.exception.MdxLoadRuntimeException;
import com.nwm.xmart.streaming.source.mdx.session.MDXSessionType;
import com.nwm.xmart.streaming.source.mdx.session.MdxSessionContext;
import com.nwm.xmart.streaming.source.mdx.util.MDXUtil;
import com.nwm.xmart.util.MDCUtil;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.mdx.webService.interfaces.*;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

import static java.util.Objects.isNull;

public class MdxDailySource extends RichParallelSourceFunction<MdxDocumentEvent> {

    private static final long serialVersionUID = -6340863697830856202L;
    private static final Logger logger = LoggerFactory.getLogger(MdxDailySource.class);

    private AtomicLong eventCounter = new AtomicLong();

    private final IntCounter numValidDocuments = new IntCounter();
    private final IntCounter numFaliedDocuments = new IntCounter();
    private final IntCounter numMissingDocuments = new IntCounter();

    private final String documentLocation;
    private final int sourceId;
    private final String xmartSessionHandler;

    private transient ParameterTool params;
    private transient MdxSessionContext mdxSession;

    public MdxDailySource(int sourceId, String documentLocation, String xmartSessionHandler) {
        this.documentLocation = documentLocation;
        this.sourceId = sourceId;
        this.xmartSessionHandler = xmartSessionHandler;
    }

    @Override
    public void open(Configuration configuration) throws Exception {

        params = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        MDCUtil.putJobNameInMDC(params);

        mdxSession = MDXUtil.getMdxSessionContextFor(params,
                MdxEventType.SERIES_VIEW,
                ProcessingType.LOAD,
                MDXSessionType.SSO);

        initialiseAccumulators();

    }

    private void initialiseAccumulators() {
        getRuntimeContext().addAccumulator("numValidDocuments", this.numValidDocuments);
        getRuntimeContext().addAccumulator("numInvalidDocuments", this.numFaliedDocuments);
        getRuntimeContext().addAccumulator("numMissingDocuments", this.numMissingDocuments);
    }

    @Override
    public void run(SourceContext<MdxDocumentEvent> ctx) {

        // create source manager
        // include extra parameters with source context which will be needed below
        SourceManager<MdxDocumentEvent> sourceManager = new SourceManager<MdxDocumentEvent>(params)
                .withExtraParameters(new HashMap<String, Object>() {
                    {
                        put("sourceContext", ctx);
                    }
                });


        // run method which requires the function selector
        sourceManager.run(this::runForDate);

    }

    private ProcessingResults runForDate(FunctionSettings functionSettings) {
        ProcessingResults processingResults = new ProcessingResults(false,false,false);
        String functionDocumentLocation = getDocumentLocation(functionSettings);
        String functionDate = functionSettings.getDay();

        List<IMdxBatchDocument> populatedDocuments = getPopulatedMdxDocuments(functionDocumentLocation, functionDate);

        processingResults.setConnectionSuccessful(true);

        if(populatedDocuments.size() > 0){
            XmartSession xmartSession = getXmartSession(functionDocumentLocation, functionDate, populatedDocuments.size());
            SourceContext<MdxDocumentEvent> ctx = (SourceContext<MdxDocumentEvent>)functionSettings.getExtraParameter("sourceContext");

            for (IMdxBatchDocument document : populatedDocuments) {
               collectDocumentToStream(ctx, document, functionDate, xmartSession);
            }

            processingResults.setDataAvailable(true);
        } else {
            processingResults.setDataAvailable(false);
            logger.warn("No valid documents found during load of MDX for location {} and date {}", functionDocumentLocation, functionSettings.getDay());
        }

        processingResults.setDataProcessedSuccessfully(true);

        return processingResults;
    }

    private XmartSession getXmartSession(String functionDocumentLocation,
            String functionDate,
            int populatedDocumentCount) {
        XmartSession xmartSession = new XmartSession(functionDocumentLocation + ":" + functionDate,
                xmartSessionHandler);

        try {
            xmartSession = xmartSession.openSession(new SqlServerConnectionDetails(params));
        } catch (XmartSqlServerException e) {
            logger.error("Exception getting Xmart session for location {} and date {}", functionDocumentLocation, functionDate);
            throw new MdxLoadRuntimeException("Exception getting Xmart session for location " + functionDocumentLocation + " and date " + functionDate);
        }

        xmartSession = xmartSession.setRowCount(populatedDocumentCount);

        return xmartSession;
    }

    private String getDocumentLocation(FunctionSettings functionSettings) {
        return documentLocation.replace("[function]", functionSettings.getFunctionName());
    }

    private List<IMdxBatchDocument> getPopulatedMdxDocuments(String functionDocumentLocation,
            String functionDate) {

        IMdxDocumentCollection mdxBatchDocuments = getMdxBatchDocuments(functionDocumentLocation, functionDate);

        List<IMdxBatchDocument> populatedDocuments = new ArrayList<>();
        for (IMdxBatchDocument document : mdxBatchDocuments) {
            try {
                if(checkDocument(document)) populatedDocuments.add(document);
            } catch (MdxLoadFailureException e) {
                logger.error("Exception checking MDX document for location {} and date {}", functionDocumentLocation, functionDate);
                throw new MdxLoadRuntimeException("Exception checking MDX document for location " + functionDocumentLocation + " and date " + functionDate);
            }
        }
        return populatedDocuments;
    }

    private IMdxDocumentCollection getMdxBatchDocuments(String functionDocumentLocation,
            String functionDate) {
        try {
            return readMdxDocuments(mdxSession.getMdxSeriesViewSession(), functionDocumentLocation, functionDate);
        } catch (MdxLoadFailureException e) {
            logger.error("Exception reading MDX documents for location {} and date {}", functionDocumentLocation, functionDate);
            throw new MdxLoadRuntimeException("Exception reading MDX documents for location " + functionDocumentLocation + " and date " + functionDate);
        }
    }

    private IMdxDocumentCollection readMdxDocuments(IMdxSession service, String documentLocation, String date)
            throws MdxLoadFailureException {

        IMdxDocumentCollection mdxBatchDocuments;

        try {
            String[] identifiers = readMdxIdentifiers(documentLocation, service);

            List<String> identifierDateList =
                    Arrays.stream(identifiers)
                          .map(i -> i + "@" + date)
                          .collect(Collectors.toList());

            mdxBatchDocuments = service.readBatch(identifierDateList.iterator());
        } catch (MdxException e) {
            logger.error("MdxException occurred during load of MDX data for location {} and date {}", documentLocation, date);
            throw new MdxLoadFailureException("MdxException occurred during load of MDX data for location " + documentLocation + " and date " + date, e);
        }

        return mdxBatchDocuments;
    }

    private String[] readMdxIdentifiers(String documentLocation, IMdxSession service)
            throws MdxException, MdxLoadFailureException {

        int MAX_NUM_IDENTIFIERS = 1_000_000;

        String[] identifiers = service.dir(documentLocation, true, MAX_NUM_IDENTIFIERS);

        if(identifiers.length == MAX_NUM_IDENTIFIERS){
            logger.error("Maximum number of identifiers reached during load of MDX for location {} - records may be missing", documentLocation);
            throw new MdxLoadFailureException("Maximum number of identifiers reached during load of MDX for location " + documentLocation);
        } else if(identifiers.length > MAX_NUM_IDENTIFIERS * 0.9){
            logger.warn("Number of identifiers approaching maximum during load of MDX for location {} - records may be missed in future", documentLocation);
        }

        return identifiers;

    }

    private boolean checkDocument(IMdxBatchDocument document) throws MdxLoadFailureException {

        if(checkDocumentReadFailure(document)){
            numFaliedDocuments.add(1);
            logger.error("Failure during read of MDX identifier {}", document.getException().getExceptionIdentifier(), document.getException());
            throw new MdxLoadFailureException("Failure during read of MDX identifier " + document.getException().getExceptionIdentifier(), document.getException());
        }

        if(checkDocumentNotFound(document)){
            numMissingDocuments.add(1);
            logger.debug("Missing document during read of MDX identifier {}", document.getException().getExceptionIdentifier(), document.getException());
            return false;
        } else{
            return true;
        }

    }

    private boolean checkDocumentNotFound(IMdxBatchDocument document) {
        return !isNull(document.getException()) && document.getException() instanceof DocumentNotFoundException;
    }

    private boolean checkDocumentReadFailure(IMdxBatchDocument document) {
        return !isNull(document.getException()) && !(document.getException() instanceof DocumentNotFoundException);
    }

    private void collectDocumentToStream(SourceContext<MdxDocumentEvent> ctx,
            IMdxBatchDocument document,
            String loadDate,
            XmartSession xmartSession){

        long epochXmlWriteTime = getEpochXmlWriteTime(document);
        String identifier = document.getHeader().getIdentifier().getPath();
        int version = document.getHeader().getVersion();

        MdxDocumentEvent mdxDocumentEvent = MdxDocumentEvent.ofIMdxDocument(Integer.toString(sourceId),
                eventCounter.incrementAndGet(),
                document,
                new Date().getTime(),
                epochXmlWriteTime,
                version,
                identifier,
                ProcessingType.LOAD,
                loadDate, xmartSession);

        synchronized (ctx.getCheckpointLock()) {
            ctx.collect(mdxDocumentEvent);
        }

        numValidDocuments.add(1);

    }

    private long getEpochXmlWriteTime(IMdxDocument mdxDocument) {
        return Instant.parse(mdxDocument.getHeader().getXmlWriteTime()).toEpochMilli();
    }

    @Override
    public void close() {
        mdxSession.close();
    }

    @Override
    public void cancel() {

    }

}
