package com.nwm.xmart.streaming.source.rdx.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class RdxLoadException extends RuntimeException {

    public RdxLoadException() {
        super();
    }

    public RdxLoadException(String msg) {
        super(msg);
    }

    public RdxLoadException(String msg, Throwable t) {
        super(msg, t);
    }
}
