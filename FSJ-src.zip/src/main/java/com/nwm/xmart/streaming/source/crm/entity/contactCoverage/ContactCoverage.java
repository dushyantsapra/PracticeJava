package com.nwm.xmart.streaming.source.crm.entity.contactCoverage;

import com.nwm.xmart.streaming.source.crm.entity.common.Employee;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Id", "IsDeleted", "LastReferencedDate", "LastViewedDate", "SystemModstamp", "Name", "CreatedById",
                     "CreatedDate", "LastModifiedById", "LastModifiedDate", "Backup_Rank", "Call_Order",
                     "Call_Order_Number", "Contact", "Desk", "Employee", "Employee_Away_Date", "End_Date", "Inactive",
                     "Inactive_MisMatch", "Is_Backup", "Is_My_Coverage", "Is_Priority", "Is_Temporary",
                     "Last_Inactive_Value", "Notes", "Original_Parent_Contact_Coverage", "Parent_Contact_Coverage",
                     "Priority_Approval_Date", "Priority_Approver_Notes", "Priority_Status", "Product", "Rank", "Role",
                     "Start_Date", "Status", "To_Be_Processed", "Unique_Id" })

public class ContactCoverage implements Serializable {
    private static final long serialVersionUID = 106567475070613098L;

    @JsonProperty("Id")
    private String id;
    @JsonProperty("IsDeleted")
    private Boolean isDeleted;
    @JsonProperty("LastReferencedDate")
    private Object lastReferencedDate;
    @JsonProperty("LastViewedDate")
    private Object lastViewedDate;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("Backup_Rank")
    private Object backupRank;
    @JsonProperty("Call_Order")
    private Object callOrder;
    @JsonProperty("Call_Order_Number")
    private Integer callOrderNumber;
    @JsonProperty("Contact")
    private String contact;
    @JsonProperty("Desk")
    private String desk;
    @JsonProperty("Employee")
    private Employee employee;
    @JsonProperty("Employee_Away_Date")
    private Object employeeAwayDate;
    @JsonProperty("End_Date")
    private String endDate;
    @JsonProperty("Inactive")
    private Boolean inactive;
    @JsonProperty("Inactive_MisMatch")
    private Boolean inactiveMisMatch;
    @JsonProperty("Is_Backup")
    private Boolean isBackup;
    @JsonProperty("Is_My_Coverage")
    private Boolean isMyCoverage;
    @JsonProperty("Is_Priority")
    private Boolean isPriority;
    @JsonProperty("Is_Temporary")
    private Boolean isTemporary;
    @JsonProperty("Last_Inactive_Value")
    private Object lastInactiveValue;
    @JsonProperty("Notes")
    private Object notes;
    @JsonProperty("Original_Parent_Contact_Coverage")
    private String originalParentContactCoverage;
    @JsonProperty("Parent_Contact_Coverage")
    private String parentContactCoverage;
    @JsonProperty("Priority_Approval_Date")
    private Object priorityApprovalDate;
    @JsonProperty("Priority_Approver_Notes")
    private Object priorityApproverNotes;
    @JsonProperty("Priority_Status")
    private String priorityStatus;
    @JsonProperty("Product")
    private Product product;
    @JsonProperty("Rank")
    private String rank;
    @JsonProperty("Role")
    private String role;
    @JsonProperty("Start_Date")
    private String startDate;
    @JsonProperty("Status")
    private String status;
    @JsonProperty("To_Be_Processed")
    private Boolean toBeProcessed;
    @JsonProperty("Unique_Id")
    private String uniqueId;

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("IsDeleted")
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    @JsonProperty("IsDeleted")
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    @JsonProperty("LastReferencedDate")
    public Object getLastReferencedDate() {
        return lastReferencedDate;
    }

    @JsonProperty("LastReferencedDate")
    public void setLastReferencedDate(Object lastReferencedDate) {
        this.lastReferencedDate = lastReferencedDate;
    }

    @JsonProperty("LastViewedDate")
    public Object getLastViewedDate() {
        return lastViewedDate;
    }

    @JsonProperty("LastViewedDate")
    public void setLastViewedDate(Object lastViewedDate) {
        this.lastViewedDate = lastViewedDate;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("Backup_Rank")
    public Object getBackupRank() {
        return backupRank;
    }

    @JsonProperty("Backup_Rank")
    public void setBackupRank(Object backupRank) {
        this.backupRank = backupRank;
    }

    @JsonProperty("Call_Order")
    public Object getCallOrder() {
        return callOrder;
    }

    @JsonProperty("Call_Order")
    public void setCallOrder(Object callOrder) {
        this.callOrder = callOrder;
    }

    @JsonProperty("Call_Order_Number")
    public Integer getCallOrderNumber() {
        return callOrderNumber;
    }

    @JsonProperty("Call_Order_Number")
    public void setCallOrderNumber(Integer callOrderNumber) {
        this.callOrderNumber = callOrderNumber;
    }

    @JsonProperty("Contact")
    public String getContact() {
        return contact;
    }

    @JsonProperty("Contact")
    public void setContact(String contact) {
        this.contact = contact;
    }

    @JsonProperty("Desk")
    public String getDesk() {
        return desk;
    }

    @JsonProperty("Desk")
    public void setDesk(String desk) {
        this.desk = desk;
    }

    @JsonProperty("Employee")
    public Employee getEmployee() {
        return employee;
    }

    @JsonProperty("Employee")
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    @JsonProperty("Employee_Away_Date")
    public Object getEmployeeAwayDate() {
        return employeeAwayDate;
    }

    @JsonProperty("Employee_Away_Date")
    public void setEmployeeAwayDate(Object employeeAwayDate) {
        this.employeeAwayDate = employeeAwayDate;
    }

    @JsonProperty("End_Date")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("End_Date")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    @JsonProperty("Inactive")
    public Boolean getInactive() {
        return inactive;
    }

    @JsonProperty("Inactive")
    public void setInactive(Boolean inactive) {
        this.inactive = inactive;
    }

    @JsonProperty("Inactive_MisMatch")
    public Boolean getInactiveMisMatch() {
        return inactiveMisMatch;
    }

    @JsonProperty("Inactive_MisMatch")
    public void setInactiveMisMatch(Boolean inactiveMisMatch) {
        this.inactiveMisMatch = inactiveMisMatch;
    }

    @JsonProperty("Is_Backup")
    public Boolean getIsBackup() {
        return isBackup;
    }

    @JsonProperty("Is_Backup")
    public void setIsBackup(Boolean isBackup) {
        this.isBackup = isBackup;
    }

    @JsonProperty("Is_My_Coverage")
    public Boolean getIsMyCoverage() {
        return isMyCoverage;
    }

    @JsonProperty("Is_My_Coverage")
    public void setIsMyCoverage(Boolean isMyCoverage) {
        this.isMyCoverage = isMyCoverage;
    }

    @JsonProperty("Is_Priority")
    public Boolean getIsPriority() {
        return isPriority;
    }

    @JsonProperty("Is_Priority")
    public void setIsPriority(Boolean isPriority) {
        this.isPriority = isPriority;
    }

    @JsonProperty("Is_Temporary")
    public Boolean getIsTemporary() {
        return isTemporary;
    }

    @JsonProperty("Is_Temporary")
    public void setIsTemporary(Boolean isTemporary) {
        this.isTemporary = isTemporary;
    }

    @JsonProperty("Last_Inactive_Value")
    public Object getLastInactiveValue() {
        return lastInactiveValue;
    }

    @JsonProperty("Last_Inactive_Value")
    public void setLastInactiveValue(Object lastInactiveValue) {
        this.lastInactiveValue = lastInactiveValue;
    }

    @JsonProperty("Notes")
    public Object getNotes() {
        return notes;
    }

    @JsonProperty("Notes")
    public void setNotes(Object notes) {
        this.notes = notes;
    }

    @JsonProperty("Original_Parent_Contact_Coverage")
    public String getOriginalParentContactCoverage() {
        return originalParentContactCoverage;
    }

    @JsonProperty("Original_Parent_Contact_Coverage")
    public void setOriginalParentContactCoverage(String originalParentContactCoverage) {
        this.originalParentContactCoverage = originalParentContactCoverage;
    }

    @JsonProperty("Parent_Contact_Coverage")
    public String getParentContactCoverage() {
        return parentContactCoverage;
    }

    @JsonProperty("Parent_Contact_Coverage")
    public void setParentContactCoverage(String parentContactCoverage) {
        this.parentContactCoverage = parentContactCoverage;
    }

    @JsonProperty("Priority_Approval_Date")
    public Object getPriorityApprovalDate() {
        return priorityApprovalDate;
    }

    @JsonProperty("Priority_Approval_Date")
    public void setPriorityApprovalDate(Object priorityApprovalDate) {
        this.priorityApprovalDate = priorityApprovalDate;
    }

    @JsonProperty("Priority_Approver_Notes")
    public Object getPriorityApproverNotes() {
        return priorityApproverNotes;
    }

    @JsonProperty("Priority_Approver_Notes")
    public void setPriorityApproverNotes(Object priorityApproverNotes) {
        this.priorityApproverNotes = priorityApproverNotes;
    }

    @JsonProperty("Priority_Status")
    public String getPriorityStatus() {
        return priorityStatus;
    }

    @JsonProperty("Priority_Status")
    public void setPriorityStatus(String priorityStatus) {
        this.priorityStatus = priorityStatus;
    }

    @JsonProperty("Product")
    public Product getProduct() {
        return product;
    }

    @JsonProperty("Product")
    public void setProduct(Product product) {
        this.product = product;
    }

    @JsonProperty("Rank")
    public String getRank() {
        return rank;
    }

    @JsonProperty("Rank")
    public void setRank(String rank) {
        this.rank = rank;
    }

    @JsonProperty("Role")
    public String getRole() {
        return role;
    }

    @JsonProperty("Role")
    public void setRole(String role) {
        this.role = role;
    }

    @JsonProperty("Start_Date")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("Start_Date")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    @JsonProperty("Status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("To_Be_Processed")
    public Boolean getToBeProcessed() {
        return toBeProcessed;
    }

    @JsonProperty("To_Be_Processed")
    public void setToBeProcessed(Boolean toBeProcessed) {
        this.toBeProcessed = toBeProcessed;
    }

    @JsonProperty("Unique_Id")
    public String getUniqueId() {
        return uniqueId;
    }

    @JsonProperty("Unique_Id")
    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ContactCoverage{");
        sb.append("id='").append(id).append('\'');
        sb.append(", isDeleted=").append(isDeleted);
        sb.append(", lastReferencedDate=").append(lastReferencedDate);
        sb.append(", lastViewedDate=").append(lastViewedDate);
        sb.append(", systemModstamp='").append(systemModstamp).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", createdById='").append(createdById).append('\'');
        sb.append(", createdDate='").append(createdDate).append('\'');
        sb.append(", lastModifiedById='").append(lastModifiedById).append('\'');
        sb.append(", lastModifiedDate='").append(lastModifiedDate).append('\'');
        sb.append(", backupRank=").append(backupRank);
        sb.append(", callOrder=").append(callOrder);
        sb.append(", callOrderNumber=").append(callOrderNumber);
        sb.append(", contact='").append(contact).append('\'');
        sb.append(", desk=").append(desk);
        sb.append(", employee=").append(employee);
        sb.append(", employeeAwayDate=").append(employeeAwayDate);
        sb.append(", endDate=").append(endDate);
        sb.append(", inactive='").append(inactive).append('\'');
        sb.append(", inactiveMisMatch=").append(inactiveMisMatch);
        sb.append(", isBackup=").append(isBackup);
        sb.append(", isMyCoverage='").append(isMyCoverage).append('\'');
        sb.append(", isPriority=").append(isPriority);
        sb.append(", isTemporary='").append(isTemporary).append('\'');
        sb.append(", lastInactiveValue=").append(lastInactiveValue);
        sb.append(", notes=").append(notes);
        sb.append(", originalParentContactCoverage=").append(originalParentContactCoverage);
        sb.append(", parentContactCoverage=").append(parentContactCoverage);
        sb.append(", priorityApprovalDate=").append(priorityApprovalDate);
        sb.append(", priorityApproverNotes=").append(priorityApproverNotes);
        sb.append(", priorityStatus=").append(priorityStatus);
        sb.append(", product=").append(product);
        sb.append(", rank=").append(rank);
        sb.append(", role='").append(role).append('\'');
        sb.append(", startDate=").append(startDate);
        sb.append(", status=").append(status);
        sb.append(", toBeProcessed=").append(toBeProcessed);
        sb.append(", uniqueId='").append(uniqueId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
