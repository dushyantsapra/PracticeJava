package com.nwm.xmart.streaming.source.mdx.identifier;

/**
 * Created by gardlex on 11/05/2018.
 */
public interface IdentifierGenerator {
    String getIdentifierForISIN(String isin);
    String extractISINFromIdentifier(String identifier);
}
