package com.nwm.xmart.streaming.source.df.event;

import com.nwm.xmart.streaming.source.json.JSONDocumentTraverser;
import com.rbs.datafabric.domain.BsonDocument;
import com.rbs.datafabric.domain.Document;
import com.rbs.datafabric.domain.JsonDocument;
import com.rbs.datafabric.domain.Record;
import com.rbs.datafabric.domain.event.*;
import com.rbs.datafabric.shaded.com.google.gson.Gson;
import com.rbs.datafabric.shaded.org.bson.BSON;
import com.rbs.datafabric.shaded.org.bson.BSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;
import java.util.Objects;

import static java.util.Objects.isNull;

public class DataFabricWatchEvent {

    private static final Logger logger = LoggerFactory.getLogger(DataFabricWatchEvent.class);

    final private JSONDocumentTraverser jsonPayload;
    final private long timestamp;
    final private String getDatabaseName;
    final private String getCollectionName;
    final private long offset;
    final private String dfKey;
    final private long dfVersion;

    public DataFabricWatchEvent(ContinuousQueryEvent continuousQueryEvent) {
        Record record = getDfRecord(continuousQueryEvent);
        this.jsonPayload = getDfJsonTraverser(record);
        this.timestamp = System.currentTimeMillis();
        this.getDatabaseName = continuousQueryEvent.getDatabaseName();
        this.getCollectionName = continuousQueryEvent.getCollectionName();
        this.offset = continuousQueryEvent.getOffset();
        this.dfKey = record.getId().getKey();
        this.dfVersion = record.getId().getVersion();
    }

    private JSONDocumentTraverser getDfJsonTraverser(Record record){

       Document document = record.getDocument();

        if(isNull(document)){
            return null;
        }

       return createJsonDocumentTraverser(document);

    }

    private Record getDfRecord(ContinuousQueryEvent continuousQueryEvent){

        if(isNull(continuousQueryEvent)){
            throw new IllegalArgumentException("Null ContinuousQueryEvent object passed as argument.");
        }

        Record record;

        if (continuousQueryEvent instanceof ContinuousQuerySnapshotStreamEvent) {
            record = ((ContinuousQuerySnapshotStreamEvent) continuousQueryEvent).getRecord();
        } else if (continuousQueryEvent instanceof ContinuousQueryInsertEvent) {
            record = ((ContinuousQueryInsertEvent) continuousQueryEvent).getRecord();
        } else if (continuousQueryEvent instanceof ContinuousQueryUpdateEvent) {
            record = ((ContinuousQueryUpdateEvent) continuousQueryEvent).getRecord();
        } else {
            logger.info("ContinuousQueryEvent of type {} passed for offset {}. This type is not processed.", continuousQueryEvent.getClass().getCanonicalName(), continuousQueryEvent.getOffset());
            return null;
        }

        if(isNull(record)){
            throw new IllegalArgumentException("ContinuousQueryEvent object passed as argument does not contain a valid record.");
        }

        return record;

    }

    private JSONDocumentTraverser createJsonDocumentTraverser(Document document) {
        String jsonString = null;
        if(document instanceof BsonDocument){
            BsonDocument bsonDocument = (BsonDocument) document;
            BSONObject bsonObject = BSON.decode(bsonDocument.getContents());
            Map bsonMap = bsonObject.toMap();
            jsonString = new Gson().toJson(bsonMap, Map.class);
        }else if (document instanceof JsonDocument) {
            JsonDocument jsonDocument = (JsonDocument) document;
            jsonString = jsonDocument.getContents();
        }
        else{
            throw new IllegalArgumentException("Document object passed as argument is not a recognised document type.");
        }

        JSONDocumentTraverser traverser;
        try {
            traverser = new JSONDocumentTraverser(jsonString);
        } catch (IOException e) {
            throw new IllegalStateException("Invalid document from DF Stream Event provided that cannot be converted to JSON Document Traverser");
        }

        return traverser;
    }

    public static boolean isValidDFWatchEvent(String sourceName, ContinuousQueryEvent continuousQueryEvent){

        if (continuousQueryEvent instanceof ContinuousQuerySnapshotStreamFailedEvent) {
            ContinuousQuerySnapshotStreamFailedEvent snapshotStreamFailedEvent = (ContinuousQuerySnapshotStreamFailedEvent) continuousQueryEvent;
            throw new IllegalStateException("Durable watch scan initial snapshot load failed, source=" + sourceName + " cause=" + snapshotStreamFailedEvent.getCause());
        }

        if (continuousQueryEvent instanceof ContinuousQuerySnapshotStreamEvent) {
            return true;
        } else if (continuousQueryEvent instanceof ContinuousQueryInsertEvent) {
            return true;
        } else if (continuousQueryEvent instanceof ContinuousQueryUpdateEvent) {
            return true;
        } else {
            logger.info("ContinuousQueryEvent of type {} passed for offset {}. This type is not processed.", continuousQueryEvent.getClass().getCanonicalName(), continuousQueryEvent.getOffset());
            return false;
        }

    }

    public JSONDocumentTraverser getJsonPayload() {
        return jsonPayload;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getGetDatabaseName() {
        return getDatabaseName;
    }

    public String getGetCollectionName() {
        return getCollectionName;
    }

    public long getOffset() {
        return offset;
    }

    public String getDfKey() {
        return dfKey;
    }

    public long getDfVersion() {
        return dfVersion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        DataFabricWatchEvent that = (DataFabricWatchEvent) o;
        return timestamp == that.timestamp && offset == that.offset && dfVersion == that.dfVersion && Objects
                .equals(jsonPayload, that.jsonPayload) && Objects.equals(getDatabaseName, that.getDatabaseName)
                && Objects.equals(getCollectionName, that.getCollectionName) && Objects.equals(dfKey, that.dfKey);
    }

    @Override
    public int hashCode() {
        return Objects.hash(jsonPayload, timestamp, getDatabaseName, getCollectionName, offset, dfKey, dfVersion);
    }

}
