package com.nwm.xmart.streaming.util;

import com.nwm.xmart.streaming.source.df.serialisation.DFSourceDeserializer;
import com.nwm.xmart.streaming.source.df.serialisation.ODCSourceDeserializer;
import com.nwm.xmart.streaming.source.df.serialisation.SourceDeserializer;
import com.nwm.xmart.streaming.source.df.serialisation.SourceDeserializerType;
import com.nwm.xmart.sso.EncryptDecryptAES;
import com.rbs.datafabric.agile.commons.lang.StartableException;
import com.rbs.datafabric.client.DataFabricClient;
import com.rbs.datafabric.client.DataFabricClientFactory;
import com.rbs.datafabric.common.serialization.DataFabricSerializer;
import com.rbs.datafabric.domain.ClientConfiguration;
import com.rbs.datafabric.domain.Credentials;
import com.rbs.datafabric.protocol.ProtocolMessageDecoder;
import com.rbs.datafabric.protocol.ProtocolMessageDecoderFactory;
import com.rbs.odc.datafabric.OdcDataFabricRecordSerialiser;
import com.rbs.odc.datafabric.wrapper.DataFabricDocumentSerialiser;
import com.rbs.odc.datafabric.wrapper.DefaultDataFabricRecordSerialiser;
import org.apache.commons.lang.StringUtils;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by gardlex on 18/10/2017.
 */
public class DataFabricUtil implements Serializable {
    private final SourceDeserializerType deserialiserType;
    private SourceDeserializer sourceDeserializer;
    private static final Logger logger = LoggerFactory.getLogger(DataFabricUtil.class);
    private final Configuration configuration;
    private final String username;
    private final String password;
    private final String host;
    private final String accesstoken;
    private final Set<DataFabricClient> dataFabricClients = new HashSet<>();

    // Set up the data fabric serializers & protocol decoders needed by the Flink job (
    public DataFabricUtil(Configuration configuration) {
        this.configuration = configuration;
        deserialiserType = SourceDeserializerType.getType(configuration.getString("flink.datafabric.deserialiser.type", ""));
        username = configuration.getString("datafabric.credentials.username", "");
        password = EncryptDecryptAES.decrypt(configuration.getString("datafabric.credentials.password", ""));
        host = configuration.getString("datafabric.credentials.host", "");
        accesstoken = EncryptDecryptAES.decrypt(configuration.getString("datafabric.credentials.accesstoken", ""));
        validateSystemRequiredParameters(username, password, host, accesstoken); //, dfSerializersList, protocolDecodersList);
    }

    private void validateSystemRequiredParameters(String username, String password, String host, String accesstoken) { //} String serializersList, String protocolDecodersList) {
        if (StringUtils.isEmpty(username)
                || StringUtils.isEmpty(password)
                || StringUtils.isEmpty(host)
                || StringUtils.isEmpty(accesstoken)) {
            String msg = "DataFabricUtil singleton usage: requires the following properties in System: " + System.lineSeparator()
                    + "datafabric.credentials.username" +  System.lineSeparator()
                    + "datafabric.credentials.password" +  System.lineSeparator()
                    + "datafabric.credentials.host" +  System.lineSeparator()
                    + "datafabric.credentials.accesstoken" +  System.lineSeparator();
            logger.error(msg);
            throw new RuntimeException(msg);
        }
    }

    public DataFabricClient getDataFabricClient(){
        return createDataFabricClient(username, password, host, accesstoken);
    }

     public DataFabricClient createDataFabricClient(String username, String password, String host, String accesstoken) {
        ClientConfiguration clientConfiguration = new ClientConfiguration().withCredentials(
                new Credentials().withUsername(username)
                        .withPassword(password))
                .withHost(host)
                .withAccessToken(accesstoken);
        DataFabricClient dataFabricClient = null;
        try {
            dataFabricClient = DataFabricClientFactory.createDataFabricClient(clientConfiguration);
        } catch (StartableException e) {
            String msg = "Could not instantiate DataFabricClient";
            logger.error(msg,e);
            throw new RuntimeException(msg, e);
        }

        dataFabricClients.add(dataFabricClient);

        return dataFabricClient;
    }

    public DataFabricSerializer getDataFabricDeserializerInstance() {
        DataFabricClient dataFabricClient = createDataFabricClient(username, password, host, accesstoken);
        logger.info("Created DataFabricSerializer for usaername [ " + username + " ]," + " password [ " + password + " ], "
        + " host [ " + host + " ], accesstoken [ " + accesstoken + " ]");
        DataFabricSerializer dataFabricSerializer = dataFabricClient.getDataFabricSerializer();

        return dataFabricSerializer;
    }

    public OdcDataFabricRecordSerialiser getODCDeserializerInstance() {
        DataFabricClient dataFabricClient = createDataFabricClient(username, password, host, accesstoken);
        logger.info("Created DataFabricSerializer for usaername [ " + username + " ]," + " password [ " + password + " ], "
                + " host [ " + host + " ], accesstoken [ " + accesstoken + " ]");
        dataFabricClients.add(dataFabricClient);

        DataFabricDocumentSerialiser dataFabricDocumentSerialiser = new DataFabricDocumentSerialiser(dataFabricClient.getDataFabricSerializer());
        OdcDataFabricRecordSerialiser odcDataFabricRecordSerialiser = new OdcDataFabricRecordSerialiser(new DefaultDataFabricRecordSerialiser(dataFabricDocumentSerialiser));
        logger.info("Created ODC odcDataFabricRecordSerialiser based on DataFabricSerializer");
        return odcDataFabricRecordSerialiser;
    }

    public ProtocolMessageDecoder getProtocolDecoderDeserializerInstance() {
        logger.info("Created ProtocolMessageDecoder");
        ProtocolMessageDecoder protocolMessageDecoder = ProtocolMessageDecoderFactory.create();

        return protocolMessageDecoder;
    }

    public SourceDeserializer getSourceDeserializerInstance() {
        switch (deserialiserType) {
            case DATAFABRIC :
                sourceDeserializer = new DFSourceDeserializer(this);
                break;
            case ODC :
                sourceDeserializer = new ODCSourceDeserializer(this, configuration);
                break;
            default:
                throw new RuntimeException("Invalid deserializerType encountered");
        }

        return sourceDeserializer;
    }

    public void close() {
        // Close all the resources
        for (DataFabricClient dataFabricClient : dataFabricClients) {
            try {
                dataFabricClient.close();
            } catch (Exception e) {
                logger.error("Error Closing DF client", e);
            }
        }
    }
}
