package com.nwm.xmart.streaming.source.mdx.pull;

import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.streaming.source.mdx.event.ProcessingType;
import com.nwm.xmart.streaming.source.mdx.exception.MdxLoadFailureException;
import com.nwm.xmart.streaming.source.mdx.session.MdxSessionContext;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.mdx.webService.impl.MdxTimePointContent;
import rbs.gbm.mdx.webService.impl.MdxTimeSeriesContent;
import rbs.gbm.mdx.webService.interfaces.IMdxTimeSeriesReader;
import rbs.gbm.mdx.webService.interfaces.IMdxTimeSeriesSession;
import rbs.gbm.mdx.webService.interfaces.MdxException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public class TimeSeriesMdxReader implements MdxReader {

    private final static Logger logger = LoggerFactory.getLogger(TimeSeriesMdxReader.class);

    private final MdxSessionContext mdxSessionContext;
    private final IntCounter invalidMdxDocumentCtr;
    private final String mdxIdentifier;
    private final AtomicLong currentJobEventIDCounter;
    private final String sourceID;
    private final int mdxReadBatchSize;

    private TimeSeriesMdxReader(MdxSessionContext mdxSessionContext,
            IntCounter invalidMdxDocumentCtr,
            String mdxIdentifier,
            AtomicLong currentJobEventIDCounter,
            String sourceID,
            int mdxReadBatchSize) {
        this.mdxSessionContext = mdxSessionContext;
        this.invalidMdxDocumentCtr = invalidMdxDocumentCtr;
        this.mdxIdentifier = mdxIdentifier;
        this.currentJobEventIDCounter = currentJobEventIDCounter;
        this.sourceID = sourceID;
        this.mdxReadBatchSize = mdxReadBatchSize;
    }

    public static class Builder {

        private MdxSessionContext mdxSessionContext;
        private volatile int mdxReadBatchSize;
        private IntCounter invalidMdxDocumentCtr;
        private volatile String mdxIdentifier;
        private final String sourceID;
        private AtomicLong currentJobEventIDCounter;

        public Builder(String sourceID){
            this.sourceID = sourceID;
        }

        public Builder withCurrentJobEventIDCounter(AtomicLong currentJobEventIDCounter) {
            this.currentJobEventIDCounter = currentJobEventIDCounter;
            return this;
        }

        public Builder withMdxSessionContext(MdxSessionContext mdxSessionContext) {
            this.mdxSessionContext = mdxSessionContext;
            return this;
        }

        public Builder withReadBatchSize(int readBatchSize) {
            this.mdxReadBatchSize = readBatchSize;
            return this;
        }

        public Builder withInvalidDocumentCounter(IntCounter counter) {
            this.invalidMdxDocumentCtr = counter;
            return this;
        }

        public Builder withMdxIdentifier(String identifier) {
            this.mdxIdentifier = identifier;
            return this;
        }

        public TimeSeriesMdxReader build() {
            return new TimeSeriesMdxReader(mdxSessionContext,
                    invalidMdxDocumentCtr,
                    mdxIdentifier,
                    currentJobEventIDCounter,
                    sourceID,
                    mdxReadBatchSize);
        }

    }

    @Override
    public void close() throws MdxException {
        mdxSessionContext.close();
    }

    @Override
    public List<MdxDocumentEvent> getMdxDocuments(List<String> fullIdentifiersList)
            throws MdxException {

        List<MdxDocumentEvent> mdxDocuments = new ArrayList<>();
        int batchSize = 0;
        List<String> batchList = new ArrayList<>();

        final IMdxTimeSeriesSession timeSeriesSession = mdxSessionContext.getMdxTimeSeriesSession();
        String[] fullIdentifiersArrayBatch = null;

        for (String fullIdentifier : fullIdentifiersList) {
            batchList.add(fullIdentifier);
            if (++batchSize == mdxReadBatchSize) {
                fullIdentifiersArrayBatch = new String[batchList.size()];
                batchList.toArray(fullIdentifiersArrayBatch);
                IMdxTimeSeriesReader seriesReader = timeSeriesSession.readBatch(fullIdentifiersArrayBatch, null);
                mdxDocuments.addAll(processTimeSeriesReader(seriesReader));
                batchList = new ArrayList<>();
                batchSize = 0;
            }
        }

        if (batchSize > 0) {
            fullIdentifiersArrayBatch = new String[batchList.size()];
            batchList.toArray(fullIdentifiersArrayBatch);
            IMdxTimeSeriesReader seriesReader = timeSeriesSession.readBatch(fullIdentifiersArrayBatch, null);
            mdxDocuments.addAll(processTimeSeriesReader(seriesReader));
        }

        return mdxDocuments;
    }




    private List<MdxDocumentEvent> processTimeSeriesReader(IMdxTimeSeriesReader seriesReader)
            throws MdxException {

        List<MdxDocumentEvent> events = new ArrayList<>();

        try {
            while (seriesReader.next()) {
                MdxTimeSeriesContent timeSeriesContent = seriesReader.getTimeSeriesContent();
                timeSeriesContent.getMetadata();
                MdxTimePointContent[] timeConts = timeSeriesContent.getTimePoints();
                MdxTimePointContent mdxTimePointContent = timeConts[0];
                Long timePointContentEpochWriteTime = getWriteTimeEpoch(mdxTimePointContent);
                String identifier = timeSeriesContent.getIdentifier();
                int version = mdxTimePointContent.getVersion();

                // bad data check
                if (timePointContentEpochWriteTime == 0) {
                    // filter invalid recs
                    logger.warn("Filtered INVALID mdxTimePointContent due to zero epochWriteTime for identifier [ " + identifier
                            + " ], metaData [ " + mdxTimePointContent.getMetadata() + " ]");
                    continue;
                }

                try {
                    events.add(MdxDocumentEvent.ofMdxTimePointContent(sourceID, currentJobEventIDCounter.incrementAndGet(), mdxTimePointContent, System.currentTimeMillis(), timePointContentEpochWriteTime, version, identifier, ProcessingType.LOAD));
                } catch (Exception e) {
                    logger.error("Could not create MdxDocumentEvent constructor", e);
                    throw new MdxException("Could not create MdxDocumentEvent constructor", e);
                }
            }
        } catch (SQLException s) {
            logger.error("Could not create MdxDocumentEvent SQLException raised when querying seriesReader", s);
            throw new MdxException("Could not create MdxDocumentEvent  SQLException raised when querying seriesReader", s);
        } catch (MdxException m) {
            logger.error("Could not create MdxDocumentEvent MDXException raised when querying seriesReader", m);
            throw new MdxException("Could not create MdxDocumentEvent MDXException raised when querying seriesReader:", m);
        }

        return events;
    }

    private Long getWriteTimeEpoch(MdxTimePointContent mdxTimePointContent) {
        if (mdxTimePointContent.getWriteTime() != null) {
            return mdxTimePointContent.getWriteTime().getTime();
        }
        logger.warn("Rejecting this MdxTimePointContent as the xmlWriteTime is NULL: " + mdxTimePointContent.getStatus() + " " + mdxTimePointContent.getMetadata());
        return Long.valueOf(0);
    }

}
