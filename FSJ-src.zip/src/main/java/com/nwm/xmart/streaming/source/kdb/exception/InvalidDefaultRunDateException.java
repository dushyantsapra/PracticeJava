package com.nwm.xmart.streaming.source.kdb.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class InvalidDefaultRunDateException extends RuntimeException {

    public InvalidDefaultRunDateException() {
        super();
    }

    public InvalidDefaultRunDateException(String msg) {
        super(msg);
    }

    public InvalidDefaultRunDateException(String msg, Throwable t) {
        super(msg, t);
    }
}
