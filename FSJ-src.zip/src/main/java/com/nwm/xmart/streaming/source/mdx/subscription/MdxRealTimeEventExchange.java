package com.nwm.xmart.streaming.source.mdx.subscription;

/**
 * Created by gardlex on 13/04/2018.
 */
public interface MdxRealTimeEventExchange<MdxSourceEvent> {
    public MdxSourceEvent getNextMdxDocumentEvent() throws MdxSubscriptionFailureException;
    public void putMdxDocumentEvent(MdxSourceEvent event);
    public MdxRealTimeEventExchange withInitialCapacity(int capacity);
    public MdxRealTimeEventExchange startWithXmlWriteTimeEpoch(long xmlWriteTimeEpoch);
    public void build();
}
