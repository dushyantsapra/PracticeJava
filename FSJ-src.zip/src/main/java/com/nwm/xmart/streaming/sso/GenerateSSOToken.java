package com.nwm.xmart.streaming.sso;

import com.nwm.xmart.sso.SSOSession;
import com.nwm.xmart.sso.exception.SSOSessionException;
import com.nwm.xmart.sso.EncryptDecryptAES;
import org.apache.flink.api.java.utils.ParameterTool;

import java.util.HashMap;
import java.util.Map;

public class GenerateSSOToken {
    public static String getSsoToken(Map<String, String> params) {
        return createSsoToken(getSsoParameterMap(params));
    }

    public static String getSsoToken(ParameterTool params) {
        return createSsoToken(getSsoParameterMap(params.toMap()));
    }

    private static String createSsoToken(Map<String, String> params){
        try {
            if (Boolean.valueOf((params.get("sso.token.autogenerate") != null) ? params.get("sso.token.autogenerate") : "false")) {
                SSOSession ssoSession = new SSOSession(params);
                try {
                    return ssoSession.getSSOToken();
                } catch (Exception e) {
                    throw new SSOSessionException("Source Function could not obtain the SSOToken", e);
                }
            } else {
                return params.get("sso.ssoToken");
            }
        }
        catch (Exception e) {
            throw new SSOSessionException("Source Function could not obtain the SSOToken", e);
        }
    }

    private static Map<String, String> getSsoParameterMap(Map<String, String> params) {
        Map<String, String> parameterMap = new HashMap<>();

        parameterMap.put("sso.token.autogenerate", params.get("sso.token.autogenerate"));
        parameterMap.put("sso.wsdl.address", params.get("sso.wsdl.address"));
        parameterMap.put("sso.username", params.get("sso.username"));
        parameterMap.put("sso.decrypted.password", EncryptDecryptAES.decrypt(params.get("sso.encrypted.password")));
        parameterMap.put("sso.truststore.location", params.get("sso.truststore.location"));
        parameterMap.put("sso.truststore.decrypted.password", EncryptDecryptAES.decrypt(params.get("sso.truststore.encrypted.password")));
        parameterMap.put("sso.profileName", params.get("sso.profileName"));

        return parameterMap;
    }
}



