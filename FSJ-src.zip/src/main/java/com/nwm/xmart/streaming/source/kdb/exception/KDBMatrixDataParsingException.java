package com.nwm.xmart.streaming.source.kdb.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class KDBMatrixDataParsingException extends RuntimeException {

    public KDBMatrixDataParsingException() {
        super();
    }

    public KDBMatrixDataParsingException(String msg) {
        super(msg);
    }

    public KDBMatrixDataParsingException(String msg, Throwable t) {
        super(msg, t);
    }
}
