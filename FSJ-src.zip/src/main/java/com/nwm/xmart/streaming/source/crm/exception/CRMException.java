package com.nwm.xmart.streaming.source.crm.exception;

public class CRMException extends RuntimeException {
    public CRMException() {
        super();
    }

    public CRMException(String msg) {
        super(msg);
    }

    public CRMException(String msg, Throwable t) {
        super(msg, t);
    }

}
