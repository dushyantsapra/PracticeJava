package com.nwm.xmart.streaming.source.kdb;

import com.nwm.xmart.streaming.database.SqlServerConnectionDetails;
import com.nwm.xmart.streaming.database.dao.SqlServerDao;
import com.nwm.xmart.streaming.database.exceptions.XmartSqlServerException;
import com.nwm.xmart.streaming.database.statements.StatementParameters;
import com.nwm.xmart.streaming.database.statements.kdb.KdbLastRunInsertStatement;
import com.nwm.xmart.streaming.source.kdb.data.KDBDataTransformer;
import com.nwm.xmart.streaming.source.kdb.data.KDBProcessingMode;
import com.nwm.xmart.streaming.source.kdb.data.ProcessingResult;
import com.nwm.xmart.streaming.source.kdb.data.ResultValidator;
import com.nwm.xmart.streaming.source.kdb.event.KDBSourceEvent;
import com.nwm.xmart.streaming.source.kdb.exception.CheckpointDateRangeException;import com.nwm.xmart.streaming.source.kdb.exception.KDBProcessingDatesException;
import com.nwm.xmart.streaming.source.kdb.exception.KDBResultException;
import com.nwm.xmart.streaming.source.kdb.parameters.BdxKdbFunctionDetails;
import com.nwm.xmart.streaming.source.kdb.parameters.DateParameterUtil;
import com.nwm.xmart.streaming.source.kdb.session.BdxKdbFunctionContext;
import com.nwm.xmart.streaming.source.kdb.session.KDBSession;
import com.nwm.xmart.streaming.source.kdb.sorting.DateTimeComparator;
import com.nwm.xmart.streaming.source.kdb.sorting.KDBSortKeyBuilder;
import com.nwm.xmart.streaming.database.exceptions.SqlServerConnectorException;
import com.nwm.xmart.streaming.source.mdx.session.MDXSessionType;
import com.nwm.xmart.streaming.source.mdx.session.MdxSessionBuilderException;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.state.OperatorStateStore;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.typeutils.TupleTypeInfo;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import rbs.gbm.mdx.utils.analytics.IAnalyticResult;
import rbs.gbm.mdx.utils.analytics.KdbRequestBuilder;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import static com.nwm.xmart.streaming.sso.GenerateSSOToken.getSsoToken;
import static java.util.Objects.isNull;

public class KDBSource extends RichParallelSourceFunction<KDBSourceEvent> implements CheckpointedFunction, CheckpointListener {
    private static Logger logger = LoggerFactory.getLogger(KDBSource.class);
    private final ConcurrentMap<String, ConcurrentMap<String, IntCounter>> functionAccumulatorMap = new ConcurrentHashMap<>();
    private transient ListState<Tuple3<String, String, Long>> functionLoadState;
    private ConcurrentMap<String, RestoredProcessingDayTime> restoredProcessingDayTimes = new ConcurrentHashMap<>();
    private ConcurrentMap<String, ProcessingDayTime> lastProcessingDayTimes = new ConcurrentHashMap<>();
    private volatile boolean isRestored;
    private volatile boolean isRunning = true;
    private final AtomicLong currentJobEventIDCounter = new AtomicLong();
    private final List<BdxKdbFunctionDetails> functionsList = new ArrayList<>();
    private final ConcurrentMap<String, BdxKdbFunctionContext> functionContextMap = new ConcurrentHashMap<>();
    private final ParameterTool params;
    private Map<String, KDBProcessingResultTracker> functionProcessingResultsMap = new HashMap<>();
    private SqlServerDao kdbLastRunInsertDao;

    public KDBSource(ParameterTool params, List<BdxKdbFunctionDetails> functionDetailsList) {
        this.params = params;
        this.functionsList.addAll(functionDetailsList);
    }

    @Override
    public void run(SourceContext<KDBSourceEvent> ctx) throws Exception {
        // Build the function context per function we're processing
        buildKdbFunctionContexts();

        // Create a results tracker
        createResultsTracker();

        // log how many processing days per function we're expecting to process
        for (BdxKdbFunctionDetails functionDetails : functionsList) {
            BdxKdbFunctionContext kdbFunctionContext = functionContextMap.get(functionDetails.getKdbSourceName());
            logger.info("Processing FunctionName [ " + functionDetails.getKdbSourceName()

                    + " ], Running job in processing mode [ " + kdbFunctionContext.getProcessingDays().getKdbProcessingMode() + " ], no of days to load [ " + kdbFunctionContext.getProcessingDays().getDaysToLoad().size() + " ]");
        }

        // Use the selector to rotate the functions, so each function takes turns to process a day's worth of events
        // So it follows the order of: FncA-Day1, FncB-Day-1, FncA-Day2, FncB-Day2, FncA-Day3, FncB-Day3 etc etc
        KDBFunctionSelector kdbFunctionSelector = new KDBFunctionSelector(functionsList, functionContextMap);

        // Validate the processing days restored from the checkpoint
        validateRestoredFunctionProcessingDays();

        String nextFunction;
        String day;
        KDBSession currentKDBSession;
        LocalDate localRestoredProcessingDay;
        boolean functionException = false;


        // loop until the there are no more processing days for any function
        while ( kdbFunctionSelector.isFunctionProcessingDayAvailable()) {
            nextFunction = kdbFunctionSelector.getNextFunctionToProcess();
            day = kdbFunctionSelector.getNextProcessingDayForFunction(nextFunction);
            currentKDBSession = functionContextMap.get(nextFunction).getKdbSession();
            localRestoredProcessingDay = getRestoredProcessingDay(nextFunction);

            // skip days that have already been processed - more applicable for historic or multi day load
            // same day means use the datetime value for skipping events already sent.
            if (isRestored && (localRestoredProcessingDay != null && DateParameterUtil.getLocalDateFor(day).isBefore(localRestoredProcessingDay))) {
                continue;
            }

            // the KDBSession parameters may not just be start and end date - but these must be overridden for each day we're processing
            currentKDBSession.withParameter("startDate", day)
                             .withParameter("endDate", day)
                             .withIAnalyticRequestIdentifierBuilder(new KdbRequestBuilder());

            ProcessingResult processingResult;
            try {
                if (currentKDBSession.build()) {
                    processingResult = processKdbDataForSingleDay(functionContextMap.get(nextFunction), ctx, day);
                    if (!processingResult.isValidKDResponseStatus()) {
                        functionAccumulatorMap.get(nextFunction).get("numDaysFailedProcessing").add(1);
                        functionProcessingResultsMap.get(nextFunction).addDayFailedProcessing(day);
                    } else if (!processingResult.isKdbDataAvailable()) {
                        functionAccumulatorMap.get(nextFunction).get("numDaysNoKDBDataAvailable").add(1);
                        functionProcessingResultsMap.get(nextFunction).addDayNoDataAvailable(day);
                    } else if (processingResult.isDataProcessedSuccessfully()) {
                        functionAccumulatorMap.get(nextFunction).get("numDaysSuccessfullyProcessing").add(1);
                        functionProcessingResultsMap.get(nextFunction).addDaySuccessfullyProcessed(day);
                    } else {
                        functionAccumulatorMap.get(nextFunction).get("numDaysFailedProcessing").add(1);
                        functionProcessingResultsMap.get(nextFunction).addDayFailedProcessing(day);
                    }
                } else {
                    functionAccumulatorMap.get(nextFunction).get("numDaysFailedToBuildAnalyticSession").add(1);
                    functionProcessingResultsMap.get(nextFunction).addDayNoAnalyticSession(day);
                    processingResult = null;
                }
            } catch (InterruptedException e) {
                functionException = true;
                logger.error("KDB Source interrupted during load of function " + functionContextMap.get(nextFunction).getFunctionName());
                break;
            }

            // If we are in daily processing mode we need to add success/fail entry into sql db
            KDBProcessingMode processingMode = functionContextMap.get(nextFunction).getProcessingDays().getKdbProcessingMode();
            if (processingMode.equals(KDBProcessingMode.OPERATIONAL_DEFAULT_DAILY)) {
                if (processingResult != null && processingResult.isDataProcessedSuccessfully()) {
                    // insert success row into db
                    insertLastSuccessfulDateForKdbFunction(nextFunction, day);
                } else {
                    functionException = true;
                    logger.error("error while processing function: " + functionContextMap.get(nextFunction).getFunctionName());
                    logger.error("removing function from list: " + functionContextMap.get(nextFunction).getFunctionName());
                    // removes this function from selector so it will no longer process records from this function.
                    kdbFunctionSelector.removeFunction(nextFunction);
                }
            }
        }

        // log results
        printProcessingResults();

        // clean up resources
        closeKdbSessions();
        int sleepDuration = params.getInt("kdb.sleep.duration.minutes", 15);
        try {
            logger.info("KDB, SLEEPING FOR " + sleepDuration + " MINUTES, until manually cancelled or interrupted");
            TimeUnit.MINUTES.sleep(sleepDuration);
        } catch (InterruptedException e) {
            logger.warn("KDB Source interrupted from sleeping for " + sleepDuration + " minutes", e);
        }

        if(functionException){
            throw new KDBResultException("A failure occurred processing one or more of the functions included in this source. Review log file for more details.");
        }

    }

    // this is a temp function and will be updated in the future once the two projects are merged
    private void insertLastSuccessfulDateForKdbFunction(String functionName, String date)
            throws SqlServerConnectorException {
        try {

            StatementParameters statementParams = new StatementParameters();
            statementParams.add("functionName", functionName);
            statementParams.add("date", date);

            kdbLastRunInsertDao.write("usp_ProcessStateSet", statementParams);
        }
        catch (Exception ex){
            throw new SqlServerConnectorException("Could not execute stored procedure: " + ex);
        }
    }

    private void printProcessingResults() {
        for (KDBProcessingResultTracker resultTracker : functionProcessingResultsMap.values()) {
            resultTracker.print();
        }
    }

    private void createResultsTracker() {
        for (BdxKdbFunctionDetails functionDetails : functionsList) {
            functionProcessingResultsMap.put(functionDetails.getKdbSourceName(), new KDBProcessingResultTracker(functionDetails.getKdbSourceName()));
        }
    }

    private void validateRestoredFunctionProcessingDays() {
        for (BdxKdbFunctionDetails functionDetails : functionsList) {
            BdxKdbFunctionContext kdbFunctionContext = functionContextMap.get(functionDetails.getKdbSourceName());

            if (isRestored) {
                validateCheckpointDayAgainstParameters(kdbFunctionContext.getSourceName(), kdbFunctionContext.getProcessingDays().getDaysToLoad());
            }
        }
    }

    private void buildKdbFunctionContexts() {
        // Create a KDBFunctionContext per function we need to process
        for (BdxKdbFunctionDetails functionDetails : functionsList) {

            // Create a sort key builder that can be used for all functions
            KDBSortKeyBuilder sortKeyBuilder = new KDBSortKeyBuilder(params.getRequired("kdb.sort.key.columns"));

            BdxKdbFunctionContext kdbFunctionContext = new BdxKdbFunctionContext();
            try {
                kdbFunctionContext.setProcessingDays(DateParameterUtil.getProcessingDays(params, functionDetails.getFunctionParameters(), functionDetails.getKdbSourceName()));
            } catch (XmartSqlServerException e) {
                throw new KDBProcessingDatesException("Exception getting processing dates for KDB function " + functionDetails.getKdbSourceName());
            }
            kdbFunctionContext.setKdbDataTransformer(new KDBDataTransformer(functionDetails.getKdbFunctionType(), sortKeyBuilder));
            kdbFunctionContext.setSourceID(functionDetails.getSourceID());
            kdbFunctionContext.setSourceName(functionDetails.getKdbSourceName());
            kdbFunctionContext.setFunctionName(functionDetails.getFunctionName());
            kdbFunctionContext.setTableName(functionDetails.getKdbTableName());

            KDBSession kdbSession = new KDBSession()
                    .withFlinkParameters(params)
                    .withApplicationName(params.get("kdb.applicationName"))
                    .withApplicationVersion(params.get("kdb.applicationVersion"))
                    .withMdxEnvironmentName(functionDetails.getMdxEnvironment())
                    .withKdbEnvironmentName(functionDetails.getKdbEnvironment())
                    .withKdbFunctionName(functionDetails.getFunctionName());

            // Apply any function parameters
            for (Map.Entry<String,String> entry : functionDetails.getFunctionParameters().entrySet()) {
                kdbSession.withParameter(entry.getKey(), entry.getValue());
            }

            switch (functionDetails.getKdbSessionType()) {
            case MDX_ACCESS:
                kdbSession.withKDBSessionType(MDXSessionType.MDX_ACCESS);
                break;
            case SSO:
                kdbSession.withSSOToken(getSsoToken(params));
                kdbSession.withKDBSessionType(MDXSessionType.SSO);
                break;
            default:
                throw new MdxSessionBuilderException("Unsupported type: " + functionDetails.getKdbSessionType());
            }

            kdbFunctionContext.setKdbSession(kdbSession);

            // Add function context to function context to map for processing usage later
            functionContextMap.put(functionDetails.getKdbSourceName(),kdbFunctionContext);
        }
    }

    private void validateCheckpointDayAgainstParameters(String functionName, List<String> daysToLoad) {
        if (!daysToLoad.isEmpty()) {
            LocalDate lastPocessingDay = DateParameterUtil.getLocalDateFor(daysToLoad.get(daysToLoad.size() - 1));
            LocalDate restoredFunctionProcessingDay = getRestoredProcessingDay(functionName);
            if (lastPocessingDay.isBefore(restoredFunctionProcessingDay)) {
                throw new CheckpointDateRangeException("Function [ " + functionName + " ], Last Processing Day specified or derived for this Flink job, " +
                        "is LESS THAN restored checkpoint processing Day. When resuming from a checkpoint use the ORIGINAL date range for this job to complete." +
                        " LastProcessingDay Specified [ " + lastPocessingDay.toString() + " ], Restored Checkpoint Processing Day [ " + restoredFunctionProcessingDay + " ]");
            }
        }
    }

    private ProcessingResult processKdbDataForSingleDay(BdxKdbFunctionContext kdbFunctionContext, SourceContext<KDBSourceEvent> ctx, String day) throws InterruptedException {
        ProcessingResult processingResult = null;

        int waitDuration = params.getInt("kdb.retry.wait.milliseconds", 60000);
        int attemptsRemaining = params.getInt("kdb.retry.attempts", 3);

        while(attemptsRemaining > 0){
            // reduce number of remaining attempts by 1
            attemptsRemaining = attemptsRemaining - 1;

            IAnalyticResult result;

            try {
                result = kdbFunctionContext.getKdbSession().getMDXAccessKDBData();
            } catch (ExecutionException e) {
                logger.error("Error occurred for Source [ " + kdbFunctionContext.getSourceName() + " ], whilst retrieving data for Day [ " + day + " ] ", e);
                result = null;
            } catch (InterruptedException i) {
                logger.error("KDB Load was interrupted for Source [ " + kdbFunctionContext.getSourceName() + " ], during processing Day [ " + day + " ] ", i);
                kdbFunctionContext.getKdbSession().close();
                Thread.currentThread().interrupt();
                throw i;
            }

            processingResult = ResultValidator.validateResult(result, kdbFunctionContext.getSourceName(), day);

            if (!processingResult.isValidKDResponseStatus()) {
                processingResult.setDataProcessedSuccessfully(false);
            }
            else if (!processingResult.isKdbDataAvailable()) {
                processingResult.setDataProcessedSuccessfully(true);
            }
            else {
                processKdbResults(kdbFunctionContext, ctx, day, result);
                processingResult.setDataProcessedSuccessfully(true);
            }

            if (processingResult.isDataProcessedSuccessfully()){
                break;
            }else if(attemptsRemaining == 0) {
                logger.error("KDB did not run successfully for Source [ " + kdbFunctionContext.getSourceName() + " ], during processing Day [ " + day + " ], no attempts remaining");
            }else{
                //wait
                logger.warn("KDB did not run successfully for Source [ " + kdbFunctionContext.getSourceName() + " ], during processing Day [ " + day + " ], attempts remaining = " + attemptsRemaining + ". Waiting " + waitDuration + " milliseconds for next retry");
                try{
                    Thread.sleep(waitDuration);
                } catch (InterruptedException i) {
                    logger.error("Wait before retry was interrupted for Source [ " + kdbFunctionContext.getSourceName() + " ], during processing Day [ " + day + " ] ", i);
                }
            }
        }

        return processingResult;
    }

    private void processKdbResults(BdxKdbFunctionContext kdbFunctionContext,
                                    SourceContext<KDBSourceEvent> ctx,
                                    String day,
                                    IAnalyticResult result) {

        List<KDBSourceEvent> sourceEvents = kdbFunctionContext.getKdbDataTransformer().convertTo2DArraySourceEvents(
                kdbFunctionContext.getSourceID(),
                kdbFunctionContext.getFunctionName(),
                kdbFunctionContext.getTableName(),
                day, result
                                                                                                                   );
        sourceEvents.sort(new DateTimeComparator());

        final Object checkpointLock = ctx.getCheckpointLock();
        ProcessingDayTime processingDayTime;
        long sourceEventEpochDateTime;
        long restoredEventEpochDateTime;

        for (KDBSourceEvent sourceEvent : sourceEvents) {
            if (!isRunning) {
                break;
            }

            sourceEventEpochDateTime = (long) sourceEvent.getKDBSortKey().getSortKeyValue();
            restoredEventEpochDateTime = getRestoredEpochTime(kdbFunctionContext);
            if (isRestored && (restoredEventEpochDateTime > 0) && (sourceEventEpochDateTime < restoredEventEpochDateTime)) {
                // skip events processed before last checkpoint, note events >= restored time will be processed, some events may have the same time
                continue;
            }

            // Update the KDB event with time sent into stream and event ID
            sourceEvent.setCurrentJobEventID(currentJobEventIDCounter.incrementAndGet());
            sourceEvent.setDocumentReceivedTimestamp(System.currentTimeMillis());

            synchronized (checkpointLock) {
                ctx.collect(sourceEvent);
                processingDayTime = getLastProcessingDayTime(kdbFunctionContext);

                processingDayTime.setProcessingDay(day);
                processingDayTime.setEpochTime(sourceEventEpochDateTime);
                functionAccumulatorMap.get(kdbFunctionContext.getSourceName()).get("numEventsProcessed").add(1);
            }
        }
    }

    private ProcessingDayTime getLastProcessingDayTime(BdxKdbFunctionContext kdbFunctionContext) {
        ProcessingDayTime processingDayTime = lastProcessingDayTimes.get(kdbFunctionContext.getSourceName());
        if (processingDayTime == null) {
            processingDayTime = new ProcessingDayTime(kdbFunctionContext.getSourceName(), null, 0);
            lastProcessingDayTimes.put(kdbFunctionContext.getSourceName(), processingDayTime);
        }

        return processingDayTime;
    }

    private long getRestoredEpochTime(BdxKdbFunctionContext kdbFunctionContext) {
        RestoredProcessingDayTime restoredProcessingDayTime = restoredProcessingDayTimes.get(kdbFunctionContext.getSourceName());
        if (restoredProcessingDayTime != null) {
            if (restoredProcessingDayTime.getEpochTime() != 0) {
                return restoredProcessingDayTime.getEpochTime();
            }
        }

        return 0;
    }

    private LocalDate getRestoredProcessingDay(String nextFunction) {
        RestoredProcessingDayTime restoredProcessingDayTime = restoredProcessingDayTimes.get(nextFunction);
        if (restoredProcessingDayTime != null) {
            if (restoredProcessingDayTime.getProcessingDay() != null) {
                return DateParameterUtil.getLocalDateFor(restoredProcessingDayTime.getProcessingDay());
            }
        }

        return null;
    }

    @Override
    public void notifyCheckpointComplete(long checkpointId) {
        logger.info("Checkpoint Complete ID [ " + checkpointId + " ]");
    }

    @Override
    public void snapshotState(FunctionSnapshotContext context) throws Exception {
        // MDC logging
        ParameterTool params = (ParameterTool)getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        String mdcJobNameKey =  params.get("nwm.job.param","jobName");
        String jobName = params.get("flink.job.name", "No Job Name Specific");
        MDC.put(mdcJobNameKey,jobName);

        // If the lastEpochSourceEventDateTime is still -1 there's a race condition where the KDB result hasn't been returned and we
        // haven't published anything so don't persist any state to the checkpoint
        // todo - if nothing in the map then just out an empty snahspot
        if (lastProcessingDayTimes.keySet().size() == 0) {
            logger.info("snapshotState called with empty  = -1, no checkpoint data persisted");
            return;
        }

        // write the source event datetime to the list of operator states
        this.functionLoadState.clear();

        for (String key : lastProcessingDayTimes.keySet()) {
            ProcessingDayTime processingDayTime = lastProcessingDayTimes.get(key);
            this.functionLoadState.add(Tuple3.of(processingDayTime.getFunctionName(), processingDayTime.getProcessingDay(), processingDayTime.getEpochTime()));
            logger.info("Checkpoint taken for Function [ " + processingDayTime.getFunctionName() + " ], LastProcessingDay { " + processingDayTime.getProcessingDay() +
                    " ], LastSourceEventEpochDateTime [ " + processingDayTime.getEpochTime() + " ] for checkpointID [ " + context.getCheckpointId() + " ]");
        }
    }

    @Override
    public void initializeState(FunctionInitializationContext context) throws Exception {
        // MDC logging
        ParameterTool params = (ParameterTool)getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        String mdcJobNameKey =  params.get("nwm.job.param","jobName");
        String jobName = params.get("flink.job.name", "No Job Name Specific");
        MDC.put(mdcJobNameKey,jobName);

        // register the state with the backend
        OperatorStateStore stateStore = context.getOperatorStateStore();
        String listStateDescriptorName = "kdb-" + jobName + "-lastEpochSourceEventDateTime";
        logger.info("Registering state for [ " + listStateDescriptorName + " ]");

        TupleTypeInfo<Tuple3<String, String, Long>> typeInfo = TupleTypeInfo.getBasicAndBasicValueTupleTypeInfo(new Class[] {String.class, String.class, Long.class});
        this.functionLoadState = stateStore.getListState(new ListStateDescriptor<>(
                listStateDescriptorName, typeInfo));

        // if the job was restarted, we set the restored lastEpochDateTimeSourceState
        if (context.isRestored()) {
            String functionName;
            String processingDay;
            Long epochDateTime;

            for (Tuple3<String, String, Long> restoredFunctionDayTime : this.functionLoadState.get()) {
                functionName = restoredFunctionDayTime.f0;
                processingDay = restoredFunctionDayTime.f1;
                epochDateTime = restoredFunctionDayTime.f2;

                restoredProcessingDayTimes.put(functionName, new RestoredProcessingDayTime(functionName, processingDay, epochDateTime));
            }

            isRestored = true;
            for (String key : restoredProcessingDayTimes.keySet()) {
                RestoredProcessingDayTime restoredProcessingDayTime = restoredProcessingDayTimes.get(key);
                logger.info("RESTORED Function [ " + restoredProcessingDayTime.getFunctionName() + " ], Processing Day [ " + restoredProcessingDayTime.getProcessingDay() +
                        " ], Epoch Time [ " + restoredProcessingDayTime.getEpochTime() + " ]");
            }
        }
    }

    @Override
    public void cancel() {
        isRunning = false;
        closeKdbLastRunInsertDao();
        closeKdbSessions();
    }

    private void closeKdbSessions() {
        for (String functionName : functionContextMap.keySet()) {
            BdxKdbFunctionContext context = functionContextMap.get(functionName);
            context.getKdbSession().close();
        }
    }

    @Override
    public void open(Configuration configuration) throws Exception {

        ParameterTool params = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        String mdcJobNameKey =  params.get("nwm.job.param","jobName");
        String jobName = params.get("flink.job.name", "No Job Name Specific");
        MDC.put(mdcJobNameKey,jobName);

        openAccumulators();

        openKdbLastRunInsertDao(params);
    }

    private void openKdbLastRunInsertDao(ParameterTool parameterTool) throws XmartSqlServerException {

        KdbLastRunInsertStatement xmartStatement = new KdbLastRunInsertStatement();

        kdbLastRunInsertDao = new SqlServerDao(xmartStatement, new SqlServerConnectionDetails(parameterTool));

        kdbLastRunInsertDao.open();

    }

    private void closeKdbLastRunInsertDao() {
        if(!isNull(kdbLastRunInsertDao)){
            kdbLastRunInsertDao.close();
        }
    }

    private void openAccumulators() {
        // Flink accumlators / counters
        for (BdxKdbFunctionDetails details : functionsList) {
            IntCounter numDaysFailedProcessing = new IntCounter();
            IntCounter numDaysSuccessfullyProcessing = new IntCounter();
            IntCounter numEventsProcessed = new IntCounter();
            IntCounter numDaysNoKDBDataAvailable = new IntCounter();
            IntCounter numDaysFailedToBuildAnalyticSession = new IntCounter();
            ConcurrentMap<String, IntCounter> accumulatorsMap = new ConcurrentHashMap<>();

            getRuntimeContext().addAccumulator(details.getKdbSourceName()+"-numDaysFailedProcessing", numDaysFailedProcessing);
            accumulatorsMap.put("numDaysFailedProcessing", numDaysFailedProcessing);

            getRuntimeContext().addAccumulator(details.getKdbSourceName()+"-numDaysSuccessfullyProcessing", numDaysSuccessfullyProcessing);
            accumulatorsMap.put("numDaysSuccessfullyProcessing", numDaysSuccessfullyProcessing);

            getRuntimeContext().addAccumulator(details.getKdbSourceName()+"-numEventsProcessed", numEventsProcessed);
            accumulatorsMap.put("numEventsProcessed", numEventsProcessed);

            getRuntimeContext().addAccumulator(details.getKdbSourceName()+"-numDaysNoKDBDataAvailable", numDaysNoKDBDataAvailable);
            accumulatorsMap.put("numDaysNoKDBDataAvailable", numDaysNoKDBDataAvailable);

            getRuntimeContext().addAccumulator(details.getKdbSourceName()+"-numDaysFailedToBuildAnalyticSession", numDaysFailedToBuildAnalyticSession);
            accumulatorsMap.put("numDaysFailedToBuildAnalyticSession", numDaysFailedToBuildAnalyticSession);

            functionAccumulatorMap.put(details.getKdbSourceName(), accumulatorsMap);
        }
    }
}
