package com.nwm.xmart.streaming.database.dao;

import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerConnection;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import com.nwm.xmart.streaming.database.SqlServerConnectionDetails;
import com.nwm.xmart.streaming.database.SqlServerConnector;
import com.nwm.xmart.streaming.database.exceptions.SqlServerConnectorException;
import com.nwm.xmart.streaming.database.exceptions.XmartSqlServerException;
import com.nwm.xmart.streaming.database.session.XmartSession;
import com.nwm.xmart.streaming.database.statements.XmartStatement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import static java.util.Objects.isNull;

public class SqlServerDao {

    @SuppressWarnings("unused")
    private static final long serialVersionUID = 7671680707369330182L;

    private static final Logger logger = LoggerFactory.getLogger(SqlServerDao.class);

    private final SqlServerConnector connector;
    private final SqlServerConnectionDetails connectionDetails;

    private transient SQLServerConnection connection;

    private final Map<String, XmartStatement> xmartStatementMap = new HashMap<>();

    public SqlServerDao(XmartStatement xmartStatement, SqlServerConnectionDetails connectionDetails){
        this.connectionDetails = connectionDetails;
        this.connector = new SqlServerConnector(connectionDetails);
        this.xmartStatementMap.put(xmartStatement.getName(), xmartStatement);
    }

    public void open() throws XmartSqlServerException {

        try {
            connection = connector.getConnection();
        } catch (SqlServerConnectorException e) {
            throw new XmartSqlServerException("Failed to connect to SQL Server when opening DAO object.", e);
        }

        for(Map.Entry<String, XmartStatement> xmartStatementEntry : xmartStatementMap.entrySet()) {
            try {
                xmartStatementEntry.getValue().open(connection);
            } catch (SQLServerException e) {
                throw new XmartSqlServerException("Failed to open xmart prepared statement " + xmartStatementEntry.getKey() + " when opening DAO object.", e);
            }
        }
    }

    public void close() {

        for(Map.Entry<String, XmartStatement> xmartStatementEntry : xmartStatementMap.entrySet()) {
            xmartStatementEntry.getValue().close();
        }

        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            logger.warn("Close of connectionfailed: {}", e.getMessage());
        }
    }

    public Long write(String statementName, Object obj) throws XmartSqlServerException {

        Long executeTime = 0L;

        if (!connector.checkConnection(connection)) {
            try {
                connection = connector.getConnection();
            } catch (SqlServerConnectorException e) {
                throw new XmartSqlServerException("Failed to connect to SQL Server when writing using DAO object.");
            }
        }

        int retryCounter = 0;
        boolean isComplete = false;

        while (!isComplete && retryCounter < connectionDetails.getRetryLimit()) {

            if (logger.isDebugEnabled()) {
                logger.debug("Sql Server attempt {} to write {}", retryCounter + 1, obj.toString());
            }

            try {

                SQLServerCallableStatement ps = getCallableStatement(statementName, obj);

                ps.setEscapeProcessing(true);
                ps.setQueryTimeout(connectionDetails.getTimeoutSec());

                executeTime = System.nanoTime();

                ps.executeBatch();
                ps.clearBatch();

                if (logger.isDebugEnabled()) {
                    logger.debug("Sql statement executed for XML : {}", obj.toString());
                }

                isComplete = true;
            } catch (SQLException e) {
                logger.error("Error executing statement", e);
            }

            if (!isComplete) {

                retryCounter++;

                try {

                    Thread.sleep(connectionDetails.getRetryPeriod());
                } catch (InterruptedException ie) {

                    logger.error("Interrupt before retrying SQL Server connection:", ie);
                    Thread.currentThread().interrupt();

                    isComplete = true;
                }
            }
        }

        if (!isComplete) {
            logger.error("SQL Server {} attempts to execute statement exceeded retry limit.", retryCounter);
            throw new XmartSqlServerException("SQL Server attempts to execute statement exceeded retry limit.");
        }

        return executeTime;
    }

    public ResultSet read(String statementName, Object obj) throws XmartSqlServerException {
        ResultSet queryResults = null;

        if (!connector.checkConnection(connection)) {
            try {
                connection = connector.getConnection();
            } catch (SqlServerConnectorException e) {
                throw new XmartSqlServerException("Failed to connect to SQL Server when reading using DAO object.");
            }
        }

        int retryCounter = 0;
        boolean isComplete = false;

        while (!isComplete && retryCounter < connectionDetails.getRetryLimit()) {

            if (logger.isDebugEnabled()) {
                logger.debug("Sql Server attempt {} to write {}", retryCounter + 1, obj.toString());
            }

            try {

                SQLServerCallableStatement ps = getCallableStatement(statementName, obj);

                ps.setEscapeProcessing(true);
                ps.setQueryTimeout(connectionDetails.getTimeoutSec());

                queryResults = ps.executeQuery();
                ps.clearBatch();

                if (logger.isDebugEnabled()) {
                    logger.debug("Sql statement executed for XML : {}", obj.toString());
                }

                isComplete = true;
            } catch (SQLException e) {
                logger.error("Error executing statement", e);
            }

            if (!isComplete) {

                retryCounter++;

                try {

                    Thread.sleep(connectionDetails.getRetryPeriod());
                } catch (InterruptedException ie) {

                    logger.error("Interrupt before retrying SQL Server connection:", ie);
                    Thread.currentThread().interrupt();

                    isComplete = true;
                }
            }
        }

        if (!isComplete) {
            logger.error("SQL Server {} attempts to execute statement exceeded retry limit.", retryCounter);
            throw new XmartSqlServerException("SQL Server attempts to execute statement exceeded retry limit.");
        }

        return queryResults;
    }

    public XmartSession readSession(XmartSession sessionRequested) throws XmartSqlServerException {

        int sessionAuditId = 0;

        if (!connector.checkConnection(connection)) {
            try {
                connection = connector.getConnection();
            } catch (SqlServerConnectorException e) {
                throw new XmartSqlServerException("Failed to connect to SQL Server when getting XmartSession using DAO object.");
            }
        }

        int retryCounter = 0;
        boolean isComplete = false;

        while (!isComplete && retryCounter < connectionDetails.getRetryLimit()) {

            if (logger.isDebugEnabled()) {
                logger.debug("Sql Server attempt {} to read session {}", retryCounter + 1, sessionRequested.toString());
            }

            try {

                SQLServerCallableStatement ps = getCallableStatement("usp_ExtractSessionStart",
                        sessionRequested);

                ps.setEscapeProcessing(true);
                ps.setQueryTimeout(connectionDetails.getTimeoutSec());

                ps.executeQuery();

                sessionAuditId = ps.getInt("pExtractSessionID");

                ps.clearBatch();

                if (logger.isDebugEnabled()) {
                    logger.debug("Sql statement executed for XML : {}", sessionRequested.toString());
                }

                isComplete = true;
            } catch (SQLException e) {
                logger.error("Error executing statement", e);
            }

            if (!isComplete) {

                retryCounter++;

                try {

                    Thread.sleep(connectionDetails.getRetryPeriod());
                } catch (InterruptedException ie) {

                    logger.error("Interrupt before retrying SQL Server connection:", ie);
                    Thread.currentThread().interrupt();

                    isComplete = true;
                }
            }
        }

        if (!isComplete) {
            logger.error("SQL Server {} attempts to execute statement exceeded retry limit.", retryCounter);
            throw new XmartSqlServerException("SQL Server attempts to execute statement exceeded retry limit.");
        }

        return sessionRequested.setSessionId(sessionAuditId);
    }

    private SQLServerCallableStatement getCallableStatement(String statementName, Object obj)
            throws SQLException, XmartSqlServerException {

        XmartStatement xmartStatement = xmartStatementMap.get(statementName);

        if(isNull(xmartStatement)){
            throw new XmartSqlServerException("Prepared statement " + statementName + " not found.");
        }

        return xmartStatement.getPreparedStatement(obj);
    }

}
