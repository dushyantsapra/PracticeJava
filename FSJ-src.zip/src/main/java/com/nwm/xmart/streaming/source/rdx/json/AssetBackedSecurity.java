
package com.nwm.xmart.streaming.source.rdx.json;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AssetPoolGroup",
    "AssetPoolSeries",
    "OriginalCreditSupportPercentage",
    "PoolCPR3Months",
    "CRD122AEligible",
    "CurrentCreditSupportPercentage",
    "DelinqAbove60DaysPercentage",
    "GranularPool",
    "IsMortgageBacked",
    "MortgageDealName",
    "MortgageCMOClass",
    "IsMortgagePaidOff",
    "MortgageOriginalDealBalance",
    "ConditionalDefaultRate3M",
    "LossSeverityHistorical3M",
    "MortgagePoolNumber",
    "RetentionMethod122A",
    "TrancheTypeDescription",
    "PercentageLoansLimitedDocument",
    "USAgencyIssuedIndicator",
    "WeightedAverageCoupon",
    "CreditScoreWeightedAvg",
    "WeightedAverageLoanAge",
    "WeightedAverageOriginalLoantoValue",
    "PoolOriginalMaturity"
})
public class AssetBackedSecurity {

    @JsonProperty("AssetPoolGroup")
    private String assetPoolGroup;
    @JsonProperty("AssetPoolSeries")
    private String assetPoolSeries;
    @JsonProperty("OriginalCreditSupportPercentage")
    private Object originalCreditSupportPercentage;
    @JsonProperty("PoolCPR3Months")
    private Object poolCPR3Months;
    @JsonProperty("CRD122AEligible")
    private Object cRD122AEligible;
    @JsonProperty("CurrentCreditSupportPercentage")
    private Object currentCreditSupportPercentage;
    @JsonProperty("DelinqAbove60DaysPercentage")
    private Object delinqAbove60DaysPercentage;
    @JsonProperty("GranularPool")
    private Object granularPool;
    @JsonProperty("IsMortgageBacked")
    private Boolean isMortgageBacked;
    @JsonProperty("MortgageDealName")
    private String mortgageDealName;
    @JsonProperty("MortgageCMOClass")
    private Object mortgageCMOClass;
    @JsonProperty("IsMortgagePaidOff")
    private Object isMortgagePaidOff;
    @JsonProperty("MortgageOriginalDealBalance")
    private Object mortgageOriginalDealBalance;
    @JsonProperty("ConditionalDefaultRate3M")
    private Object conditionalDefaultRate3M;
    @JsonProperty("LossSeverityHistorical3M")
    private Object lossSeverityHistorical3M;
    @JsonProperty("MortgagePoolNumber")
    private Object mortgagePoolNumber;
    @JsonProperty("RetentionMethod122A")
    private Object retentionMethod122A;
    @JsonProperty("TrancheTypeDescription")
    private String trancheTypeDescription;
    @JsonProperty("PercentageLoansLimitedDocument")
    private Object percentageLoansLimitedDocument;
    @JsonProperty("USAgencyIssuedIndicator")
    private Object uSAgencyIssuedIndicator;
    @JsonProperty("WeightedAverageCoupon")
    private Double weightedAverageCoupon;
    @JsonProperty("CreditScoreWeightedAvg")
    private Object creditScoreWeightedAvg;
    @JsonProperty("WeightedAverageLoanAge")
    private Object weightedAverageLoanAge;
    @JsonProperty("WeightedAverageOriginalLoantoValue")
    private Object weightedAverageOriginalLoantoValue;
    @JsonProperty("PoolOriginalMaturity")
    private Object poolOriginalMaturity;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("AssetPoolGroup")
    public String getAssetPoolGroup() {
        return assetPoolGroup;
    }

    @JsonProperty("AssetPoolGroup")
    public void setAssetPoolGroup(String assetPoolGroup) {
        this.assetPoolGroup = assetPoolGroup;
    }

    @JsonProperty("AssetPoolSeries")
    public String getAssetPoolSeries() {
        return assetPoolSeries;
    }

    @JsonProperty("AssetPoolSeries")
    public void setAssetPoolSeries(String assetPoolSeries) {
        this.assetPoolSeries = assetPoolSeries;
    }

    @JsonProperty("OriginalCreditSupportPercentage")
    public Object getOriginalCreditSupportPercentage() {
        return originalCreditSupportPercentage;
    }

    @JsonProperty("OriginalCreditSupportPercentage")
    public void setOriginalCreditSupportPercentage(Object originalCreditSupportPercentage) {
        this.originalCreditSupportPercentage = originalCreditSupportPercentage;
    }

    @JsonProperty("PoolCPR3Months")
    public Object getPoolCPR3Months() {
        return poolCPR3Months;
    }

    @JsonProperty("PoolCPR3Months")
    public void setPoolCPR3Months(Object poolCPR3Months) {
        this.poolCPR3Months = poolCPR3Months;
    }

    @JsonProperty("CRD122AEligible")
    public Object getCRD122AEligible() {
        return cRD122AEligible;
    }

    @JsonProperty("CRD122AEligible")
    public void setCRD122AEligible(Object cRD122AEligible) {
        this.cRD122AEligible = cRD122AEligible;
    }

    @JsonProperty("CurrentCreditSupportPercentage")
    public Object getCurrentCreditSupportPercentage() {
        return currentCreditSupportPercentage;
    }

    @JsonProperty("CurrentCreditSupportPercentage")
    public void setCurrentCreditSupportPercentage(Object currentCreditSupportPercentage) {
        this.currentCreditSupportPercentage = currentCreditSupportPercentage;
    }

    @JsonProperty("DelinqAbove60DaysPercentage")
    public Object getDelinqAbove60DaysPercentage() {
        return delinqAbove60DaysPercentage;
    }

    @JsonProperty("DelinqAbove60DaysPercentage")
    public void setDelinqAbove60DaysPercentage(Object delinqAbove60DaysPercentage) {
        this.delinqAbove60DaysPercentage = delinqAbove60DaysPercentage;
    }

    @JsonProperty("GranularPool")
    public Object getGranularPool() {
        return granularPool;
    }

    @JsonProperty("GranularPool")
    public void setGranularPool(Object granularPool) {
        this.granularPool = granularPool;
    }

    @JsonProperty("IsMortgageBacked")
    public Boolean getIsMortgageBacked() {
        return isMortgageBacked;
    }

    @JsonProperty("IsMortgageBacked")
    public void setIsMortgageBacked(Boolean isMortgageBacked) {
        this.isMortgageBacked = isMortgageBacked;
    }

    @JsonProperty("MortgageDealName")
    public String getMortgageDealName() {
        return mortgageDealName;
    }

    @JsonProperty("MortgageDealName")
    public void setMortgageDealName(String mortgageDealName) {
        this.mortgageDealName = mortgageDealName;
    }

    @JsonProperty("MortgageCMOClass")
    public Object getMortgageCMOClass() {
        return mortgageCMOClass;
    }

    @JsonProperty("MortgageCMOClass")
    public void setMortgageCMOClass(Object mortgageCMOClass) {
        this.mortgageCMOClass = mortgageCMOClass;
    }

    @JsonProperty("IsMortgagePaidOff")
    public Object getIsMortgagePaidOff() {
        return isMortgagePaidOff;
    }

    @JsonProperty("IsMortgagePaidOff")
    public void setIsMortgagePaidOff(Object isMortgagePaidOff) {
        this.isMortgagePaidOff = isMortgagePaidOff;
    }

    @JsonProperty("MortgageOriginalDealBalance")
    public Object getMortgageOriginalDealBalance() {
        return mortgageOriginalDealBalance;
    }

    @JsonProperty("MortgageOriginalDealBalance")
    public void setMortgageOriginalDealBalance(Object mortgageOriginalDealBalance) {
        this.mortgageOriginalDealBalance = mortgageOriginalDealBalance;
    }

    @JsonProperty("ConditionalDefaultRate3M")
    public Object getConditionalDefaultRate3M() {
        return conditionalDefaultRate3M;
    }

    @JsonProperty("ConditionalDefaultRate3M")
    public void setConditionalDefaultRate3M(Object conditionalDefaultRate3M) {
        this.conditionalDefaultRate3M = conditionalDefaultRate3M;
    }

    @JsonProperty("LossSeverityHistorical3M")
    public Object getLossSeverityHistorical3M() {
        return lossSeverityHistorical3M;
    }

    @JsonProperty("LossSeverityHistorical3M")
    public void setLossSeverityHistorical3M(Object lossSeverityHistorical3M) {
        this.lossSeverityHistorical3M = lossSeverityHistorical3M;
    }

    @JsonProperty("MortgagePoolNumber")
    public Object getMortgagePoolNumber() {
        return mortgagePoolNumber;
    }

    @JsonProperty("MortgagePoolNumber")
    public void setMortgagePoolNumber(Object mortgagePoolNumber) {
        this.mortgagePoolNumber = mortgagePoolNumber;
    }

    @JsonProperty("RetentionMethod122A")
    public Object getRetentionMethod122A() {
        return retentionMethod122A;
    }

    @JsonProperty("RetentionMethod122A")
    public void setRetentionMethod122A(Object retentionMethod122A) {
        this.retentionMethod122A = retentionMethod122A;
    }

    @JsonProperty("TrancheTypeDescription")
    public String getTrancheTypeDescription() {
        return trancheTypeDescription;
    }

    @JsonProperty("TrancheTypeDescription")
    public void setTrancheTypeDescription(String trancheTypeDescription) {
        this.trancheTypeDescription = trancheTypeDescription;
    }

    @JsonProperty("PercentageLoansLimitedDocument")
    public Object getPercentageLoansLimitedDocument() {
        return percentageLoansLimitedDocument;
    }

    @JsonProperty("PercentageLoansLimitedDocument")
    public void setPercentageLoansLimitedDocument(Object percentageLoansLimitedDocument) {
        this.percentageLoansLimitedDocument = percentageLoansLimitedDocument;
    }

    @JsonProperty("USAgencyIssuedIndicator")
    public Object getUSAgencyIssuedIndicator() {
        return uSAgencyIssuedIndicator;
    }

    @JsonProperty("USAgencyIssuedIndicator")
    public void setUSAgencyIssuedIndicator(Object uSAgencyIssuedIndicator) {
        this.uSAgencyIssuedIndicator = uSAgencyIssuedIndicator;
    }

    @JsonProperty("WeightedAverageCoupon")
    public Double getWeightedAverageCoupon() {
        return weightedAverageCoupon;
    }

    @JsonProperty("WeightedAverageCoupon")
    public void setWeightedAverageCoupon(Double weightedAverageCoupon) {
        this.weightedAverageCoupon = weightedAverageCoupon;
    }

    @JsonProperty("CreditScoreWeightedAvg")
    public Object getCreditScoreWeightedAvg() {
        return creditScoreWeightedAvg;
    }

    @JsonProperty("CreditScoreWeightedAvg")
    public void setCreditScoreWeightedAvg(Object creditScoreWeightedAvg) {
        this.creditScoreWeightedAvg = creditScoreWeightedAvg;
    }

    @JsonProperty("WeightedAverageLoanAge")
    public Object getWeightedAverageLoanAge() {
        return weightedAverageLoanAge;
    }

    @JsonProperty("WeightedAverageLoanAge")
    public void setWeightedAverageLoanAge(Object weightedAverageLoanAge) {
        this.weightedAverageLoanAge = weightedAverageLoanAge;
    }

    @JsonProperty("WeightedAverageOriginalLoantoValue")
    public Object getWeightedAverageOriginalLoantoValue() {
        return weightedAverageOriginalLoantoValue;
    }

    @JsonProperty("WeightedAverageOriginalLoantoValue")
    public void setWeightedAverageOriginalLoantoValue(Object weightedAverageOriginalLoantoValue) {
        this.weightedAverageOriginalLoantoValue = weightedAverageOriginalLoantoValue;
    }

    @JsonProperty("PoolOriginalMaturity")
    public Object getPoolOriginalMaturity() {
        return poolOriginalMaturity;
    }

    @JsonProperty("PoolOriginalMaturity")
    public void setPoolOriginalMaturity(Object poolOriginalMaturity) {
        this.poolOriginalMaturity = poolOriginalMaturity;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("assetPoolGroup", assetPoolGroup).append("assetPoolSeries", assetPoolSeries).append("originalCreditSupportPercentage", originalCreditSupportPercentage).append("poolCPR3Months", poolCPR3Months).append("cRD122AEligible", cRD122AEligible).append("currentCreditSupportPercentage", currentCreditSupportPercentage).append("delinqAbove60DaysPercentage", delinqAbove60DaysPercentage).append("granularPool", granularPool).append("isMortgageBacked", isMortgageBacked).append("mortgageDealName", mortgageDealName).append("mortgageCMOClass", mortgageCMOClass).append("isMortgagePaidOff", isMortgagePaidOff).append("mortgageOriginalDealBalance", mortgageOriginalDealBalance).append("conditionalDefaultRate3M", conditionalDefaultRate3M).append("lossSeverityHistorical3M", lossSeverityHistorical3M).append("mortgagePoolNumber", mortgagePoolNumber).append("retentionMethod122A", retentionMethod122A).append("trancheTypeDescription", trancheTypeDescription).append("percentageLoansLimitedDocument", percentageLoansLimitedDocument).append("uSAgencyIssuedIndicator", uSAgencyIssuedIndicator).append("weightedAverageCoupon", weightedAverageCoupon).append("creditScoreWeightedAvg", creditScoreWeightedAvg).append("weightedAverageLoanAge", weightedAverageLoanAge).append("weightedAverageOriginalLoantoValue", weightedAverageOriginalLoantoValue).append("poolOriginalMaturity", poolOriginalMaturity).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(mortgageCMOClass).append(mortgageDealName).append(assetPoolGroup).append(cRD122AEligible).append(poolCPR3Months).append(granularPool).append(mortgagePoolNumber).append(weightedAverageLoanAge).append(poolOriginalMaturity).append(trancheTypeDescription).append(assetPoolSeries).append(retentionMethod122A).append(isMortgagePaidOff).append(lossSeverityHistorical3M).append(currentCreditSupportPercentage).append(percentageLoansLimitedDocument).append(mortgageOriginalDealBalance).append(weightedAverageOriginalLoantoValue).append(originalCreditSupportPercentage).append(uSAgencyIssuedIndicator).append(isMortgageBacked).append(conditionalDefaultRate3M).append(delinqAbove60DaysPercentage).append(additionalProperties).append(weightedAverageCoupon).append(creditScoreWeightedAvg).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AssetBackedSecurity) == false) {
            return false;
        }
        AssetBackedSecurity rhs = ((AssetBackedSecurity) other);
        return new EqualsBuilder().append(mortgageCMOClass, rhs.mortgageCMOClass).append(mortgageDealName, rhs.mortgageDealName).append(assetPoolGroup, rhs.assetPoolGroup).append(cRD122AEligible, rhs.cRD122AEligible).append(poolCPR3Months, rhs.poolCPR3Months).append(granularPool, rhs.granularPool).append(mortgagePoolNumber, rhs.mortgagePoolNumber).append(weightedAverageLoanAge, rhs.weightedAverageLoanAge).append(poolOriginalMaturity, rhs.poolOriginalMaturity).append(trancheTypeDescription, rhs.trancheTypeDescription).append(assetPoolSeries, rhs.assetPoolSeries).append(retentionMethod122A, rhs.retentionMethod122A).append(isMortgagePaidOff, rhs.isMortgagePaidOff).append(lossSeverityHistorical3M, rhs.lossSeverityHistorical3M).append(currentCreditSupportPercentage, rhs.currentCreditSupportPercentage).append(percentageLoansLimitedDocument, rhs.percentageLoansLimitedDocument).append(mortgageOriginalDealBalance, rhs.mortgageOriginalDealBalance).append(weightedAverageOriginalLoantoValue, rhs.weightedAverageOriginalLoantoValue).append(originalCreditSupportPercentage, rhs.originalCreditSupportPercentage).append(uSAgencyIssuedIndicator, rhs.uSAgencyIssuedIndicator).append(isMortgageBacked, rhs.isMortgageBacked).append(conditionalDefaultRate3M, rhs.conditionalDefaultRate3M).append(delinqAbove60DaysPercentage, rhs.delinqAbove60DaysPercentage).append(additionalProperties, rhs.additionalProperties).append(weightedAverageCoupon, rhs.weightedAverageCoupon).append(creditScoreWeightedAvg, rhs.creditScoreWeightedAvg).isEquals();
    }

}
