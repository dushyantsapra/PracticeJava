package com.nwm.xmart.streaming.source.mdx.cache.listener;

import java.util.Set;

/**
 * Created by gardlex on 13/05/2018.
 */
public interface ISINCacheListener {
    void setLatestISINs(Set<String> latestIsinList, Set<String> newIsinList);
}
