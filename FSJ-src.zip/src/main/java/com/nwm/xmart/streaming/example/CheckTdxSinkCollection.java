package com.nwm.xmart.streaming.example;

import com.nwm.xmart.streaming.source.rdx.event.RDXSourceEvent;
import com.rbs.datafabric.client.DataFabricClient;
import com.rbs.datafabric.client.DataFabricClientFactory;
import com.rbs.datafabric.common.DataFabricSerializerException;
import com.rbs.datafabric.common.serialization.DataFabricSerializer;
import com.rbs.datafabric.domain.*;
import com.rbs.datafabric.domain.client.builder.DropCollectionRequestBuilder;
import com.rbs.datafabric.domain.client.builder.ScanRequestBuilder;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by gardlex on 29/03/2018.
 */
public class CheckTdxSinkCollection {

    private org.slf4j.Logger logger = LoggerFactory.getLogger(CheckTdxSinkCollection.class);

    public static void main(String[] args) throws Exception {
        CheckTdxSinkCollection checkRdxSinkCollection = new CheckTdxSinkCollection();
//        checkRdxSinkCollection.validateState();
        checkRdxSinkCollection.deleteColl();
    }

    private void deleteColl() throws Exception {
        final DataFabricClient dataFabricClient = getDFC();
        final DataFabricSerializer dataFabricSerializer = dataFabricClient.getDataFabricSerializer();
        dataFabricClient.dropCollection(DropCollectionRequestBuilder.create("session-db", "tdx-api-Bdx-ldn-prod-4"));
//        Thread.sleep(3000);

        dataFabricClient.close();
    }


    public void validateState() throws Exception {
        final DataFabricClient dataFabricClient = getDFC();
        final DataFabricSerializer dataFabricSerializer = dataFabricClient.getDataFabricSerializer();


//        "session-db", "session-rdx-test"

        ScanExpression scanExpression = new ScanExpression()
                .withDatabaseName("session-db")
                .withCollectionName("session-rdx-test3")
                .withPageLimit(5)
                .withWhereExpression(
                        new WhereExpression()
//                                .withExpression("integerValue = 2 and doubleValue > 1.2 and stringValue = 'Hello, world!'")
                );

        // here are the records we wanted
        Iterable<Record> foundRecords = dataFabricClient.scan(
                ScanRequestBuilder.create(scanExpression) //.withComment("Hello World Scan"));
        );

        List<Long> list = new ArrayList<>();

        for (Record foundRecord : foundRecords) {
            list.add(getChangeId(dataFabricSerializer, foundRecord));
        }

        logger.info("list size " + list.size());
        checkContiguous(list);



        Thread.sleep(3000);

        dataFabricClient.close();
    }

    private void checkContiguous(List<Long> list) {
        Collections.sort(list);
        logger.info("firstValue = " + list.get(0) + ", lastValue = " + list.get(list.size()-1));

        HashMap<Long,Integer> dupes = new HashMap<>();

        Long lastValue = null;

        for (Long l : list) {
            if (lastValue == null) {
                lastValue = l;
                logger.info("first value = " + lastValue);
            } else {
                if (l.longValue() - lastValue.longValue() > 1) {
                    logger.info("missing value: current = " + l + ",  last = " + lastValue);
                }
                if (l.longValue() - lastValue.longValue() == 0) {
                    logger.info("duplicate value: current = " + l + ",  last = " + lastValue);
                    Integer cachedCount = dupes.get(l);
                    if ( cachedCount == null) {
                        dupes.put(l,2);
                    } else {
                        dupes.put(l,cachedCount.intValue() +1);
                    }
                }
                lastValue = l;
            }
        }

        printDupes(dupes);
    }

    private void printDupes(HashMap<Long, Integer> map) {
        for (Map.Entry<Long,Integer> value : map.entrySet()) {
            logger.info("dupe: " + value.getKey() + ", " + value.getValue());
        }
    }

    private void checkForDuplicates(List<Long> list) {

    }


    private DataFabricClient getDFC() throws Exception {
        // TST
        ClientConfiguration clientConfiguration = new ClientConfiguration().withCredentials(new Credentials().withUsername("svc-XMartAppUat")
                .withPassword("As03!#rV12"))
                .withHost("DATAFABRIC-TST")
                .withAccessToken("631d6bb8-feb9-4504-b725-fd069c3ebedf");
        // DEV
//        ClientConfiguration clientConfiguration = new ClientConfiguration().withCredentials(new Credentials().withUsername("svc-XMartAppDev")
//                .withPassword("$zt[o3XM"))
//                .withHost("datafabric-dev")
//                .withAccessToken("631d6bb8-feb9-4504-b725-fd069c3ebedf");

        DataFabricClient dataFabricClient = DataFabricClientFactory.createDataFabricClient(clientConfiguration);
        return dataFabricClient;
    }

    private long getChangeId(DataFabricSerializer dataFabricSerializer, Record record) throws Exception {
//        logger.info("Found a record!");
        RDXSourceEvent event = null;
        try {
             event = dataFabricSerializer.deserialize(record.getDocument(), RDXSourceEvent.class);
        } catch (DataFabricSerializerException e) {
            logger.info(e.getMessage());
        }

        if (event == null) {
            throw new Exception("event was NULL");
        }

        return event.getChangeID();
    }
}
