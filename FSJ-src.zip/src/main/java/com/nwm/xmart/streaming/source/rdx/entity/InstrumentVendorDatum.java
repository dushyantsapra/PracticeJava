
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "FieldName",
    "FieldValue",
    "FieldValueText"
})
public class InstrumentVendorDatum {

    @JsonProperty("FieldName")
    private Object fieldName;
    @JsonProperty("FieldValue")
    private Object fieldValue;
    @JsonProperty("FieldValueText")
    private Object fieldValueText;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("FieldName")
    public Object getFieldName() {
        return fieldName;
    }

    @JsonProperty("FieldName")
    public void setFieldName(Object fieldName) {
        this.fieldName = fieldName;
    }

    @JsonProperty("FieldValue")
    public Object getFieldValue() {
        return fieldValue;
    }

    @JsonProperty("FieldValue")
    public void setFieldValue(Object fieldValue) {
        this.fieldValue = fieldValue;
    }

    @JsonProperty("FieldValueText")
    public Object getFieldValueText() {
        return fieldValueText;
    }

    @JsonProperty("FieldValueText")
    public void setFieldValueText(Object fieldValueText) {
        this.fieldValueText = fieldValueText;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("fieldName", fieldName).append("fieldValue", fieldValue).append("fieldValueText", fieldValueText).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(fieldValueText).append(fieldName).append(additionalProperties).append(fieldValue).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InstrumentVendorDatum) == false) {
            return false;
        }
        InstrumentVendorDatum rhs = ((InstrumentVendorDatum) other);
        return new EqualsBuilder().append(fieldValueText, rhs.fieldValueText).append(fieldName, rhs.fieldName).append(additionalProperties, rhs.additionalProperties).append(fieldValue, rhs.fieldValue).isEquals();
    }

}
