package com.nwm.xmart.streaming.source.kdb.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class FunctionParameterParsingException extends RuntimeException {

    public FunctionParameterParsingException() {
        super();
    }

    public FunctionParameterParsingException(String msg) {
        super(msg);
    }

    public FunctionParameterParsingException(String msg, Throwable t) {
        super(msg, t);
    }
}
