package com.nwm.xmart.streaming.source.rdx.query;



import com.nwm.xmart.streaming.source.rdx.exception.RdxSubscriptionException;
import org.apache.flink.util.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.dx.webService.impl.DxDateTime;
import rbs.gbm.dx.webService.impl.rdx.CriteriaBuilder;

import rbs.gbm.dx.webService.interfaces.rdx.ICriteria;
import rbs.gbm.dx.webService.interfaces.rdx.IRdxType;

import java.util.*;

/**
 * Created by gardlex on 22/05/2018.
 */
public class RdxLoaderCriteriaBuilder {
    private static Logger logger = LoggerFactory.getLogger(RdxLoaderCriteriaBuilder.class);
    private volatile IRdxType rdxType;
    private volatile int year;
    private volatile int month;
    private volatile int day;
    private volatile int hour;
    private volatile int min;
    private volatile int sec;
    private volatile String assetClassKey;
    private volatile String assetClassValue;
    private volatile String requestedFacets;
    private volatile Set<String> isinSet;

    public RdxLoaderCriteriaBuilder withRdxType(IRdxType rdxType) {
        this.rdxType = rdxType;
        return this;
    }

    public RdxLoaderCriteriaBuilder withLatestValudationDate(int year, int month, int day, int hour, int min, int sec) {
        this.year = year;
        this.month = month;
        this.day = day;
        this.hour = hour;
        this.min = min;
        this.sec = sec;

        return this;
    }

    public RdxLoaderCriteriaBuilder withInstrumentAssetClass(String assetClassKey, String assetClassValue) {
        this.assetClassKey = assetClassKey;
        this.assetClassValue = assetClassValue;
        return this;
    }

    public RdxLoaderCriteriaBuilder withRequestedFacets(String requestedFacets) {
        this.requestedFacets = requestedFacets;
        return this;
    }

    public RdxLoaderCriteriaBuilder withIsins(Set<String> isinSet) {
        this.isinSet = isinSet;
        return this;
    }


    public ICriteria build() {
        try {
            CriteriaBuilder builder = new CriteriaBuilder(rdxType)
                    .setValuationDateCriteriaLatest( new DxDateTime(year,month,day, hour, min, sec, 0))
                    .addFieldCriteria(assetClassKey, assetClassValue)
                    .addAliasCriteria("ISIN", getAliasCriteria(isinSet));

            // specify the requested facets
            for(RequestedFacet requestedFacet : RequestedFacetPropertyParser.getRequestedFacetsFromString(requestedFacets)) {
                builder.addRequestedFacet(requestedFacet.getFacetName(), requestedFacet.getFacetAttributes());
            }

            // Now build the criteria
            return builder.buildCriteria();
        } catch (Exception e) {
            logger.error("Could not build the ICriteria: ", e);
            throw new RdxSubscriptionException("Could not build the ICriteria", e);
        }
    }

    private String[] getAliasCriteria(Set<String> isinSet) {

        String[] isinArray = new String[isinSet.size()];
        isinSet.toArray(isinArray);

        return isinArray;
    }
}
