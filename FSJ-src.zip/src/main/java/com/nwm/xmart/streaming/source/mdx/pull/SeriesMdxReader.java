package com.nwm.xmart.streaming.source.mdx.pull;

import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.streaming.source.mdx.event.ProcessingType;
import com.nwm.xmart.streaming.source.mdx.exception.MdxLoadFailureException;
import com.nwm.xmart.streaming.source.mdx.exception.MdxLoadRuntimeException;
import com.nwm.xmart.streaming.source.mdx.session.MdxSessionContext;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.mdx.webService.impl.MdxBatchDocument;
import rbs.gbm.mdx.webService.interfaces.IMdxBatchDocument;
import rbs.gbm.mdx.webService.interfaces.IMdxDocument;
import rbs.gbm.mdx.webService.interfaces.IMdxDocumentCollection;
import rbs.gbm.mdx.webService.interfaces.MdxException;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public class SeriesMdxReader implements MdxReader {

    private final static Logger logger = LoggerFactory.getLogger(SeriesMdxReader.class);

    private final MdxSessionContext mdxSessionContext;
    private final IntCounter invalidMdxDocumentCtr;
    private final String mdxIdentifier;
    private final AtomicLong jobWideEventIdCounter;
    private final String sourceID;
    private final int maxBatchSize;

    private SeriesMdxReader(MdxSessionContext mdxSessionContext,
            IntCounter invalidMdxDocumentCtr,
            String mdxIdentifier,
            AtomicLong currentJobEventIDCounter,
            String sourceID,
            int mdxReadBatchSize) {
        this.mdxSessionContext = mdxSessionContext;
        this.invalidMdxDocumentCtr = invalidMdxDocumentCtr;
        this.mdxIdentifier = mdxIdentifier;
        this.jobWideEventIdCounter = currentJobEventIDCounter;
        this.sourceID = sourceID;
        this.maxBatchSize = mdxReadBatchSize;
    }

    public static class Builder {

        private MdxSessionContext mdxSessionContext;
        private volatile int mdxReadBatchSize;
        private IntCounter invalidMdxDocumentCtr;
        private volatile String mdxIdentifier;
        private final String sourceID;
        private AtomicLong currentJobEventIDCounter;

        public Builder(String sourceID){
            this.sourceID = sourceID;
        }

        public Builder withCurrentJobEventIDCounter(AtomicLong currentJobEventIDCounter) {
            this.currentJobEventIDCounter = currentJobEventIDCounter;
            return this;
        }

        public Builder withMdxSessionContext(MdxSessionContext mdxSessionContext) {
            this.mdxSessionContext = mdxSessionContext;
            return this;
        }

        public Builder withReadBatchSize(int readBatchSize) {
            this.mdxReadBatchSize = readBatchSize;
            return this;
        }

        public Builder withInvalidDocumentCounter(IntCounter counter) {
            this.invalidMdxDocumentCtr = counter;
            return this;
        }

        public Builder withMdxIdentifier(String identifier) {
            this.mdxIdentifier = identifier;
            return this;
        }

        public SeriesMdxReader build() {
            return new SeriesMdxReader(mdxSessionContext,
                    invalidMdxDocumentCtr,
                    mdxIdentifier,
                    currentJobEventIDCounter,
                    sourceID,
                    mdxReadBatchSize);
        }

    }

    @Override
    public void close() throws MdxException {
        mdxSessionContext.close();
    }

    @Override
    public List<MdxDocumentEvent> getMdxDocuments(List<String> fullIdentifiersList) throws MdxException {

        List<MdxDocumentEvent> mdxDocuments = new ArrayList<>();
        IMdxDocumentCollection mdxBatchDocuments = null;

        int size = fullIdentifiersList.size();

        for(int start = 0; start < size; start = start + maxBatchSize){
            int end = start + maxBatchSize < size ? start + maxBatchSize : size;

            List<String> batchList = fullIdentifiersList.subList(start, end);

            mdxBatchDocuments = mdxSessionContext.getMdxSeriesViewSession().readBatch(batchList.iterator());
            try {
                mdxDocuments.addAll(processDocumentCollection(mdxBatchDocuments));
            } catch (MdxLoadFailureException e) {
                throw new MdxLoadRuntimeException("Failure processing the MDX documents", e);
            }
        }

        logger.info("For last ISIN Load of Series View (Instruments) Only: " + mdxIdentifier + ": No of invalid documents found = " + invalidMdxDocumentCtr.getLocalValuePrimitive());
        invalidMdxDocumentCtr.resetLocal();

        return mdxDocuments;
    }

    private List<MdxDocumentEvent> processDocumentCollection(IMdxDocumentCollection mdxBatchDocuments)
            throws MdxLoadFailureException {
        if (mdxBatchDocuments == null ) {
            logger.warn("CONTACT MDX SUPPORT: IMdxDocumentCollection mdxBatchDocuments IS NULL");
            return new ArrayList<MdxDocumentEvent>();
        }

        final Iterator<IMdxBatchDocument> docIterator = mdxBatchDocuments.iterator();
        List<MdxDocumentEvent> events = new ArrayList<>();
        MdxBatchDocument mdxBatchDocument = null;
        IMdxDocument mdxDocument = null;

        while (docIterator.hasNext()) {
            mdxBatchDocument = (MdxBatchDocument)docIterator.next();   // Cast so that we can identify whether an exception occurred with this document
            if (mdxBatchDocument.getException() != null) {
                invalidMdxDocumentCtr.add(1);
                continue;
            }

            // Cast back to get the MdxDocument
            mdxDocument = (IMdxDocument)mdxBatchDocument;
            long epochXmlWriteTime = getEpochXmlWriteTime(mdxDocument);
            String identifier = mdxDocument.getHeader().getIdentifier().getPath();
            int version = mdxDocument.getHeader().getVersion();

            try {
                events.add(MdxDocumentEvent.ofIMdxDocumentWithRegInstrument(sourceID, jobWideEventIdCounter
                        .incrementAndGet(), mdxDocument, System.currentTimeMillis(), epochXmlWriteTime, version, identifier, ProcessingType.LOAD));
            } catch (Exception e) {
                logger.error("Could not create MdxDocumentEvent constructor", e);
                throw new MdxLoadFailureException("Could not create MdxDocumentEvent constructor", e);
            }
        }

        return events;
    }

    private long getEpochXmlWriteTime(IMdxDocument mdxDocument) {
        return Instant.parse(mdxDocument.getHeader().getXmlWriteTime()).toEpochMilli();
    }
}
