package com.nwm.xmart.streaming.source.rdx.subscription;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nwm.xmart.streaming.source.rdx.query.RdxDataReader;
import com.nwm.xmart.streaming.source.mdx.event.ProcessingType;
import com.nwm.xmart.streaming.source.rdx.exception.RdxSubscriptionException;
import com.nwm.xmart.streaming.source.rdx.json.RdxFixedIncome;
import com.nwm.xmart.streaming.source.rdx.query.RdxSubscriptionCriteriaBuilder;
import com.nwm.xmart.streaming.source.rdx.session.RDXSessionContext;
import org.apache.commons.lang3.reflect.ConstructorUtils;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.util.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.dx.webService.interfaces.IRdxSession;
import rbs.gbm.dx.webService.interfaces.rdx.*;
import rbs.gbm.mdx.webService.interfaces.MdxException;
import rbs.gbm.mdx.webService.interfaces.ReferenceDataOperationType;

import java.io.IOException;
import java.util.Date;
import java.util.Set;
import java.util.concurrent.*;
import java.util.concurrent.locks.ReentrantLock;


/**
 * Encapsulates the logic required for RDX connectivity. Creates an IRdxSession  subscription that
 *
 * Created by gardlex on 23/03/2018.
 */
public class ReferenceDataRdxSubscription<RdxSourceEvent> implements RdxSubscription<RdxSourceEvent> {

    private static Logger logger = LoggerFactory.getLogger(ReferenceDataRdxSubscription.class);
    private final ObjectMapper objectMapper = new ObjectMapper();
    private volatile Object subscribeToken;
    private final Class<RdxSourceEvent> sourceEventClass;
    private volatile SourceFunction<RdxSourceEvent> sourceFunction;
    private volatile LinkedBlockingQueue<RdxSourceEvent> subscriptionQueue;
    private volatile RDXSessionContext rdxSession;
    private volatile RdxSubscriptionCriteriaBuilder rdxSubscriptionCriteriaBuilder;
    private volatile int initialCapacity;
    private final ReentrantLock subscriptionLock = new ReentrantLock();
    private final ConcurrentMap<String, String> isinMap = new ConcurrentHashMap<>();
    private volatile String applicationSubscriptionName;

    public ReferenceDataRdxSubscription(Class<RdxSourceEvent> sourceEventClass) {
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        this.sourceEventClass = sourceEventClass;
    }

    @Override
    public RdxSubscription withSourceFunction(SourceFunction<RdxSourceEvent> sourceFunction) {
        this.sourceFunction = sourceFunction;
        return this;
    }

    @Override
    public ReentrantLock getSubscriptionLock() {
        return subscriptionLock;
    }

    @Override
    public RdxSubscription withInitialCapacity(int capacity) {
        this.initialCapacity = capacity;
        this.subscriptionQueue = new LinkedBlockingQueue<RdxSourceEvent>(initialCapacity);
        return this;
    }

    @Override
    public RdxSubscription withApplicationSubscriptionName(String applicationSubscriptionName) {
        this.applicationSubscriptionName = applicationSubscriptionName;
        return this;
    }

    @Override
    public RdxSubscription withRDXSession(RDXSessionContext rdxSession) {
        this.rdxSession = rdxSession;
        return this;
    }

    @Override
    public RdxSubscription withRdxSubscriptionCriteriaBuilder(RdxSubscriptionCriteriaBuilder builder) {
        this.rdxSubscriptionCriteriaBuilder = builder;
        return this;
    }

    @Override
    public void setStartChangeID(long changeID) {
        rdxSubscriptionCriteriaBuilder.withStartChangeID(changeID);
    }

    @Override
    public void startCachingSubscriptionEvents() {
        try {
            subscribeToken = rdxSession.getRdxSession().subscribe(rdxSubscriptionCriteriaBuilder.build(), this, applicationSubscriptionName);
//            Thread.sleep(10000);
//            Assert.isTrue(!subscribeToken.equals(null), "token must be not null");
        }
        catch (Exception e) {
            logger.error("Could not start the ReferenceDataRdxSubscription", e);
            close();
            throw new RdxSubscriptionException("Interrupted whilst consuming single rdx event", e);
        }
    }

    @Override
    public void close() {
        // unsubscribe
        try {
            if (subscribeToken != null) {
                rdxSession.getRdxSession().unsubscribe(subscribeToken);
            }
        } catch (Exception e) {
            logger.warn("Close(): Could not unsubscribe the token", e);
        }

        // close session
        try {
            rdxSession.getRdxSession().close();
        } catch (MdxException e) {
            logger.warn("Close(): Could not close the ReferenceDataRdxSubscription session", e);
        }
    }

    @Override
    public void onRdxDocChange(final IRdxSession source,
                               final Object handlerRef, final Object clientRefObject,
                               final IReferenceData referenceData, ReferenceDataOperationType operationType)
    {

        logger.info("RDX SUBSCRIPTION - RDX published subscription event {}, {}, {}, {}, {}"
                ,referenceData.getRdxChangeId()
                ,referenceData.getRdxId()
                ,referenceData.getRdxSeriesId()
                ,referenceData.getValuationDate()
                ,referenceData.getVersion());

        // Convert to JSON
        RdxFixedIncome rdxFixedIncome = null;
        RdxSourceEvent rdxSourceEvent = null;

        switch (referenceData.getRdxType().GetEntitySubtype()) {
            case "FixedIncome":
                // CReate the JSON
                try {
                    rdxFixedIncome = objectMapper.readValue(referenceData.getContent(), RdxFixedIncome.class);
                } catch (IOException e) {
                    logger.error("Subscription event: Could not create JSON for FixedIncome for content: " + referenceData.getContent(), e);
                    close();
                    sourceFunction.cancel();
                }

                // Reject if no facets
                if (rdxFixedIncome.getFacets() == null) {
                    logger.warn("RdxFixedIncome instance found without any facets, rejecting this subscription event");
                    return;
                }

                // filter out any events that aren't in the ISIN list
                String isin = RdxDataReader.getIsinFromAliasFor(rdxFixedIncome);
                if (isin == null) {
                    return;
                }

                if (isinMap.get(isin) == null) {
                    return;
                }

                // Construct the rdx source event
                try {
                    rdxSourceEvent = ConstructorUtils.invokeConstructor(
                            sourceEventClass,
                            rdxFixedIncome,
                            referenceData.getRdxChangeId(),
                            referenceData.getRdxId(),
                            referenceData.getRdxSeriesId(),
                            referenceData.getValuationDate(),
                            referenceData.getVersion(),
                            ProcessingType.SUBSCRIPTION,
                            System.currentTimeMillis());
                } catch (Exception e) {
                    logger.error("Subscription event: Could not create RdxSourceEvent for FixedIncome for content: " + referenceData.getContent(), e);
                    close();
                    sourceFunction.cancel();
                }
                break;
            default:
                logger.error("SUPPORTING RDX Subscription for FixedIncome Only, a non-FixedIncome event has been received, CONTENT IS: " + referenceData.getContent());
                close();
                sourceFunction.cancel();
        }

        // Push event for consumption by the RDXSource
        putRdxEvent(rdxSourceEvent);

//        // TODO - used for slowing down rate of rdx events
//        try {
//            Thread.sleep(5000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
    }

    @Override
    public void onRdxStatusChange(final IRdxSession source, final Object handlerRef,
                                  final Object clientRefObject, final IReferenceDataStatus status) {
        Date d = new Date();

        IAlias[] aliases = status.getAliases();
        String aliasInfo = "<no alias>";
        if (aliases.length >= 1) {
            IAlias firstAlias = aliases[0];
            aliasInfo = String.format("[%s:%s]", firstAlias.getAliasType(), firstAlias.getAliasValue());
        }
    }

    @Override
    public void onSubscriptionRevoked(final IRdxSession source,
                                      final Object handlerRef, final Object clientRefObject) {
        // TODO - handle failure here to stop source operator
        logger.error("Receive subscription revocation: handlerRef="+handlerRef+", and clientRef: "+ clientRefObject);
        logger.error("If this function gets called, it means that your subscription has been revoked. Please contact DX Support.");
        close();
        sourceFunction.cancel();
    }

    @Override
    public RdxSourceEvent getNextRdxEvent() throws RdxSubscriptionException {
        try {
            return subscriptionQueue.take();
        } catch (InterruptedException e) {
            logger.error("Interrupted whilst removing single rdx event",e);
            Thread.currentThread().interrupt();
            close();
            sourceFunction.cancel();
            throw new RdxSubscriptionException("Interrupted whilst consuming single rdx event", e);
        }
    }

    private void putRdxEvent(RdxSourceEvent rdxSourceEvent) {
        try {
            subscriptionQueue.put(rdxSourceEvent);
        } catch (InterruptedException e) {
            logger.error("Interrupted putting into queuesingle rdx event", e);
            Thread.currentThread().interrupt();
            close();
            sourceFunction.cancel();
            throw new RdxSubscriptionException("Interrupted putting single rdx event into queue", e);
        }
    }

    @Override
    public RdxSubscription setISINList(Set<String> isinList) {
        subscriptionLock.lock();
        try {
            isinMap.clear();
            for (String isin : isinList) {
                isinMap.put(isin, "");
            }
        } finally {
            subscriptionLock.unlock();
        }

        return this;
    }
}
