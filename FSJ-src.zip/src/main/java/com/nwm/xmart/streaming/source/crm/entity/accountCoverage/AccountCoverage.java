package com.nwm.xmart.streaming.source.crm.entity.accountCoverage;

import com.nwm.xmart.streaming.source.crm.entity.common.Account;
import com.nwm.xmart.streaming.source.crm.entity.common.Employee;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(
        { "Id", "Name", "CreatedById", "CreatedDate", "LastModifiedById", "LastModifiedDate", "SystemModstamp",
          "Account", "Call_Order", "Call_Order_Number", "Coverage_Region", "Desk", "Division", "Employee",
          "Employee_Email", "End_Date", "Inactive", "Inactive_MisMatch", "Is_Backup", "Is_My_Coverage",
          "Last_Inactive_Value", "Notes", "Product_Lookup", "Product", "Products", "Rank", "Role", "Start_Date",
          "Status", "To_Be_Processed", "Unique_Id" })

public class AccountCoverage implements Serializable {
    private static final long serialVersionUID = 6478474175388304053L;

    @JsonProperty("Id")
    private String id;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("Account")
    private Account account;
    @JsonProperty("Call_Order")
    private Object callOrder;
    @JsonProperty("Call_Order_Number")
    private Integer callOrderNumber;
    @JsonProperty("Coverage_Region")
    private CoverageRegion coverageRegion;
    @JsonProperty("Desk")
    private String desk;
    @JsonProperty("Division")
    private String division;
    @JsonProperty("Employee")
    private Employee employee;
    @JsonProperty("Employee_Email")
    private String employeeEmail;
    @JsonProperty("End_Date")
    private String endDate;
    @JsonProperty("Inactive")
    private Boolean inactive;
    @JsonProperty("Inactive_MisMatch")
    private Boolean inactiveMisMatch;
    @JsonProperty("Is_Backup")
    private Boolean isBackup;
    @JsonProperty("Is_My_Coverage")
    private Boolean isMyCoverage;
    @JsonProperty("Last_Inactive_Value")
    private Boolean lastInactiveValue;
    @JsonProperty("Notes")
    private Object notes;
    @JsonProperty("Product_Lookup")
    private Object productLookup;
    @JsonProperty("Product")
    private Object product;
    @JsonProperty("Products")
    private Object products;
    @JsonProperty("Rank")
    private String rank;
    @JsonProperty("Role")
    private String role;
    @JsonProperty("Start_Date")
    private String startDate;
    @JsonProperty("Status")
    private String status;
    @JsonProperty("To_Be_Processed")
    private Boolean toBeProcessed;
    @JsonProperty("Unique_Id")
    private String uniqueId;

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("Account")
    public Account getAccount() {
        return account;
    }

    @JsonProperty("Account")
    public void setAccount(Account account) {
        this.account = account;
    }

    @JsonProperty("Call_Order")
    public Object getCallOrder() {
        return callOrder;
    }

    @JsonProperty("Call_Order")
    public void setCallOrder(Object callOrder) {
        this.callOrder = callOrder;
    }

    @JsonProperty("Call_Order_Number")
    public Integer getCallOrderNumber() {
        return callOrderNumber;
    }

    @JsonProperty("Call_Order_Number")
    public void setCallOrderNumber(Integer callOrderNumber) {
        this.callOrderNumber = callOrderNumber;
    }

    @JsonProperty("Coverage_Region")
    public CoverageRegion getCoverageRegion() {
        return coverageRegion;
    }

    @JsonProperty("Coverage_Region")
    public void setCoverageRegion(CoverageRegion coverageRegion) {
        this.coverageRegion = coverageRegion;
    }

    @JsonProperty("Desk")
    public String getDesk() {
        return desk;
    }

    @JsonProperty("Desk")
    public void setDesk(String desk) {
        this.desk = desk;
    }

    @JsonProperty("Division")
    public String getDivision() {
        return division;
    }

    @JsonProperty("Division")
    public void setDivision(String division) {
        this.division = division;
    }

    @JsonProperty("Employee")
    public Employee getEmployee() {
        return employee;
    }

    @JsonProperty("Employee")
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    @JsonProperty("Employee_Email")
    public String getEmployeeEmail() {
        return employeeEmail;
    }

    @JsonProperty("Employee_Email")
    public void setEmployeeEmail(String employeeEmail) {
        this.employeeEmail = employeeEmail;
    }

    @JsonProperty("End_Date")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("End_Date")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    @JsonProperty("Inactive")
    public Boolean getInactive() {
        return inactive;
    }

    @JsonProperty("Inactive")
    public void setInactive(Boolean inactive) {
        this.inactive = inactive;
    }

    @JsonProperty("Inactive_MisMatch")
    public Boolean getInactiveMisMatch() {
        return inactiveMisMatch;
    }

    @JsonProperty("Inactive_MisMatch")
    public void setInactiveMisMatch(Boolean inactiveMisMatch) {
        this.inactiveMisMatch = inactiveMisMatch;
    }

    @JsonProperty("Is_Backup")
    public Boolean getIsBackup() {
        return isBackup;
    }

    @JsonProperty("Is_Backup")
    public void setIsBackup(Boolean isBackup) {
        this.isBackup = isBackup;
    }

    @JsonProperty("Is_My_Coverage")
    public Boolean getIsMyCoverage() {
        return isMyCoverage;
    }

    @JsonProperty("Is_My_Coverage")
    public void setIsMyCoverage(Boolean isMyCoverage) {
        this.isMyCoverage = isMyCoverage;
    }

    @JsonProperty("Last_Inactive_Value")
    public Boolean getLastInactiveValue() {
        return lastInactiveValue;
    }

    @JsonProperty("Last_Inactive_Value")
    public void setLastInactiveValue(Boolean lastInactiveValue) {
        this.lastInactiveValue = lastInactiveValue;
    }

    @JsonProperty("Notes")
    public Object getNotes() {
        return notes;
    }

    @JsonProperty("Notes")
    public void setNotes(Object notes) {
        this.notes = notes;
    }

    @JsonProperty("Product_Lookup")
    public Object getProductLookup() {
        return productLookup;
    }

    @JsonProperty("Product_Lookup")
    public void setProductLookup(Object productLookup) {
        this.productLookup = productLookup;
    }

    @JsonProperty("Product")
    public Object getProduct() {
        return product;
    }

    @JsonProperty("Product")
    public void setProduct(Object product) {
        this.product = product;
    }

    @JsonProperty("Products")
    public Object getProducts() {
        return products;
    }

    @JsonProperty("Products")
    public void setProducts(Object products) {
        this.products = products;
    }

    @JsonProperty("Rank")
    public String getRank() {
        return rank;
    }

    @JsonProperty("Rank")
    public void setRank(String rank) {
        this.rank = rank;
    }

    @JsonProperty("Role")
    public String getRole() {
        return role;
    }

    @JsonProperty("Role")
    public void setRole(String role) {
        this.role = role;
    }

    @JsonProperty("Start_Date")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("Start_Date")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    @JsonProperty("Status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("To_Be_Processed")
    public Boolean getToBeProcessed() {
        return toBeProcessed;
    }

    @JsonProperty("To_Be_Processed")
    public void setToBeProcessed(Boolean toBeProcessed) {
        this.toBeProcessed = toBeProcessed;
    }

    @JsonProperty("Unique_Id")
    public String getUniqueId() {
        return uniqueId;
    }

    @JsonProperty("Unique_Id")
    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("AccountCoverage{");
        sb.append("id='").append(id).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", createdById='").append(createdById).append('\'');
        sb.append(", createdDate='").append(createdDate).append('\'');
        sb.append(", lastModifiedById='").append(lastModifiedById).append('\'');
        sb.append(", lastModifiedDate='").append(lastModifiedDate).append('\'');
        sb.append(", systemModstamp='").append(systemModstamp).append('\'');
        sb.append(", account=").append(account);
        sb.append(", callOrder=").append(callOrder);
        sb.append(", callOrderNumber=").append(callOrderNumber);
        sb.append(", coverageRegion=").append(coverageRegion);
        sb.append(", desk='").append(desk).append('\'');
        sb.append(", division='").append(division).append('\'');
        sb.append(", employee=").append(employee);
        sb.append(", employeeEmail='").append(employeeEmail).append('\'');
        sb.append(", endDate='").append(endDate).append('\'');
        sb.append(", inactive=").append(inactive);
        sb.append(", inactiveMisMatch=").append(inactiveMisMatch);
        sb.append(", isBackup=").append(isBackup);
        sb.append(", isMyCoverage=").append(isMyCoverage);
        sb.append(", lastInactiveValue=").append(lastInactiveValue);
        sb.append(", notes=").append(notes);
        sb.append(", productLookup=").append(productLookup);
        sb.append(", product=").append(product);
        sb.append(", products=").append(products);
        sb.append(", rank='").append(rank).append('\'');
        sb.append(", role='").append(role).append('\'');
        sb.append(", startDate='").append(startDate).append('\'');
        sb.append(", status='").append(status).append('\'');
        sb.append(", toBeProcessed=").append(toBeProcessed);
        sb.append(", uniqueId='").append(uniqueId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
