package com.nwm.xmart.streaming.source.mdx.pull;

import com.nwm.xmart.streaming.database.exceptions.SqlServerConnectorException;
import com.nwm.xmart.streaming.source.mdx.cache.IsinCache;
import com.nwm.xmart.streaming.source.mdx.cache.load.MDXIsinCacheItem;
import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.streaming.source.mdx.identifier.IdentifierGenerator;
import com.nwm.xmart.streaming.source.mdx.subscription.MdxSubscription;
import com.nwm.xmart.streaming.source.mdx.identifier.SeriesViewIdentifierGenerator;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.mdx.webService.impl.MdxBatchDocument;
import rbs.gbm.mdx.webService.interfaces.*;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created by gardlex on 11/04/2018.
 */
public class SeriesViewMdxLoader implements MdxPullRequestDocumentLoader<MdxDocumentEvent> {

    private static Logger logger = LoggerFactory.getLogger(SeriesViewMdxLoader.class);
    private volatile int initialCapacity;
    private volatile int mdxReadBatchSize;
    private volatile String mdxIdentifier;
    private volatile IsinCache isinCache;
    private final AtomicReference<SourceFunction.SourceContext> sourceCtx = new AtomicReference<>();
    private final AtomicReference<IdentifierGenerator> identifierGeneratorRef = new AtomicReference<>();
    private MdxReader mdxReader;
    private final AtomicReference<IntCounter> srcEventCounter = new AtomicReference<>();
    private volatile boolean isInitialLoad;
    private final AtomicReference<MdxSubscription> mdxSubscriptionRef = new AtomicReference<>();
    private final AtomicReference<SourceFunction<MdxDocumentEvent>> sourceFunctionRef = new AtomicReference<>();
    private final ConcurrentMap<String, String> refreshFullIsinMap = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, String> refreshNewIsinMap = new ConcurrentHashMap<>();

    public SeriesViewMdxLoader() {
    }

    @Override
    public void setSourceContext(SourceFunction.SourceContext srcCtx) {
        this.sourceCtx.set(srcCtx);
    }

    @Override
    public MdxPullRequestDocumentLoader withMdxDocumentStoreFetcher(MdxReader documentStoreFetcher) {
        this.mdxReader = documentStoreFetcher;
        return this;
    }

    @Override
    public MdxPullRequestDocumentLoader withISINCache(IsinCache isinCache) {
        this.isinCache = isinCache;
        return this;
    }

    @Override
    public MdxPullRequestDocumentLoader withInitialCapacity(int capacity) {
        this.initialCapacity = capacity;
        return this;
    }

    @Override
    public MdxPullRequestDocumentLoader withReadBatchSize(int readBatchSize) {
        this.mdxReadBatchSize = readBatchSize;
        return this;
    }

    @Override
    public MdxPullRequestDocumentLoader withCounter(IntCounter counter) {
        this.srcEventCounter.set(counter);
        return this;
    }

    @Override
    public MdxPullRequestDocumentLoader withSubscription(MdxSubscription subscription) {
        this.mdxSubscriptionRef.set(subscription);
        return this;
    }

    @Override
    public MdxPullRequestDocumentLoader withSourceFunction(SourceFunction<MdxDocumentEvent> sourceFunction) {
        this.sourceFunctionRef.set(sourceFunction);

        return this;
    }

    @Override
    public MdxPullRequestDocumentLoader withMdxIdentifier(String identifier) {
        this.mdxIdentifier = identifier;
        this.identifierGeneratorRef.set(new SeriesViewIdentifierGenerator(identifier));

        return this;
    }

    @Override
    public void setInitialLoad(boolean isInitialLoad) {
        this.isInitialLoad = isInitialLoad;
    }

    @Override
    public void loadDocuments() throws MdxException {
        AtomicInteger noOfPublishedToStream;

        final ReentrantLock subscriptionLock = mdxSubscriptionRef.get().getSubscriptionLock();
        subscriptionLock.lock();
        try {
            // perform data load by fetching all events from MDX data store
            Set<String> isinSet = null;
            if (isInitialLoad) {
                isinSet = isinCache.getISINsToLoad();
            } else {
                isinSet = new HashSet<>();
                isinSet.addAll(refreshNewIsinMap.keySet());
            }

            // Construct the full identifiers
            final IdentifierGenerator identifierGenerator = identifierGeneratorRef.get();
            List<String> fullIdentifiersList = new ArrayList<>();
            for (String isin : isinSet) {
                fullIdentifiersList.add(identifierGenerator.getIdentifierForISIN(isin));
            }

            // Get the mdxDocuments
            List<MdxDocumentEvent> mdxDocumentsList = mdxReader.getMdxDocuments(fullIdentifiersList);

            // Now push each document into the stream updating the MDXIsinCacheItem cache's document, version (the latest version to be published)
            SourceFunction.SourceContext srcCtx = sourceCtx.get();
            final Object checkpointLock = srcCtx.getCheckpointLock();
            IntCounter intCounter = srcEventCounter.get();
            noOfPublishedToStream = new AtomicInteger();

            logger.info("For Identifier [ " + mdxIdentifier + " ], no of MDX documents retrieved is [ " + mdxDocumentsList.size() + " ]");

            for (MdxDocumentEvent event : mdxDocumentsList) {
                publishEventToStream(srcCtx, checkpointLock, intCounter, noOfPublishedToStream, event);
            }

            // Update the subscription's ISIN list
            if (isInitialLoad) {
                mdxSubscriptionRef.get().setISINList(isinSet);
            } else {
                mdxSubscriptionRef.get().setISINList(refreshFullIsinMap.keySet());
            }

        } catch (SqlServerConnectorException e) {
            throw new MdxException("Failed to retrieve list of ISINs for SeriesView MDX load");
        } finally {
            subscriptionLock.unlock();
        }

        logger.info("For Identifier [ " + mdxIdentifier + " ], no of MDX documents published to stream is [ " + noOfPublishedToStream + " ]");
    }

    private void publishEventToStream(SourceFunction.SourceContext srcCtx, Object checkpointLock, IntCounter intCounter, AtomicInteger noOfPublishedToStream, MdxDocumentEvent event) {
        MDXIsinCacheItem mdxIsinCacheItem;
        synchronized (checkpointLock) {
            mdxIsinCacheItem = new MDXIsinCacheItem(
                    event.getIdentifier(),
                    event.getVersion(),
                    event.getEpochMdxDataStoreWriteTime());
            if (isinCache.putISINCacheItem(mdxIsinCacheItem)) {
                srcCtx.collect(event);
                intCounter.add(1);
                noOfPublishedToStream.getAndIncrement();
            }
        }
    }

    @Override
    public void setLatestISINs(Set<String> fullIsinList, Set<String> newIsinList) {
        // Ensure that only the new isins are now loaded
        setInitialLoad(false);
        refreshFullIsinMap.clear();
        refreshNewIsinMap.clear();

        for (String fullIsin : fullIsinList) {
            refreshFullIsinMap.put(fullIsin, "");
        }

        for (String newIsin : fullIsinList) {
            refreshNewIsinMap.put(newIsin, "");
        }

        try {
            loadDocuments();
        } catch (MdxException e) {
            logger.error("Could not load refreshed ISIN list items ", e);
            sourceFunctionRef.get().cancel();
        }
    }

    private long getEpochXmlWriteTime(IMdxDocument mdxDocument) {
        if (mdxDocument.getHeader() != null && mdxDocument.getHeader().getXmlWriteTime() != null) {
            return Instant.parse(mdxDocument.getHeader().getXmlWriteTime()).toEpochMilli();
        }
        logger.error("Rejecting this MdxDocument as the xmlWriteTime is NULL. Showing Exception stack: ", ((MdxBatchDocument)mdxDocument).getException());
        return 0;
    }
}
