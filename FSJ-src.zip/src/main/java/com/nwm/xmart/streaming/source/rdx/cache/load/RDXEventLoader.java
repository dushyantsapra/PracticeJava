package com.nwm.xmart.streaming.source.rdx.cache.load;


import com.nwm.xmart.streaming.source.mdx.cache.IsinCache;
import com.nwm.xmart.streaming.source.mdx.cache.listener.ISINCacheListener;
import com.nwm.xmart.streaming.source.rdx.exception.RdxLoadException;
import com.nwm.xmart.streaming.source.rdx.session.RDXSessionContextType;
import com.nwm.xmart.streaming.source.rdx.subscription.RdxSubscription;
import com.nwm.xmart.streaming.source.rdx.query.RdxLoaderCriteriaBuilder;
import com.nwm.xmart.streaming.source.rdx.session.RDXSessionContext;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.functions.source.SourceFunction;

/**
 * Created by gardlex on 21/05/2018.
 */
public interface RDXEventLoader<RdxSourceEvent> extends ISINCacheListener {
    RDXEventLoader withISINCache(IsinCache isinCache);
    RDXEventLoader withCounter(IntCounter counter);
    RDXEventLoader withRdxSubscription(RdxSubscription subscription);
    RDXEventLoader withSourceFunction(SourceFunction<RdxSourceEvent> sourceFunction);
    void setInitialLoad(boolean isInitialLoad);
    long loadRdxEvents() throws RdxLoadException;
    RDXEventLoader withRDXSession(RDXSessionContext rdxSession);
    RDXEventLoader withRdxLoaderCriteriaBuilder(RdxLoaderCriteriaBuilder builder);
    void close();
    void setSourceContext(SourceFunction.SourceContext srcCtx);
    public RDXEventLoader withFlinkParameters(ParameterTool flinkParameters);
}
