package com.nwm.xmart.streaming.source.mdx.identifier;

import java.util.StringTokenizer;

/**
 * Created by gardlex on 14/05/2018.
 */
public class TimeSeriesIdentifierGenerator implements IdentifierGenerator {

    private final String seriesIdentifier;

    public TimeSeriesIdentifierGenerator(String seriesIdentifier) {
        this.seriesIdentifier = seriesIdentifier;
    }

    /**
     * Create an MDX full identifier used for MDX document retrieval
     *
     * @param isin
     * @return the full MDX identifier
     */
    @Override
    public String getIdentifierForISIN(String isin) {
        return seriesIdentifier + isin + "/totv";
    }

    @Override
    public String extractISINFromIdentifier(String fullIdentifier) {
        // identifier in the form 'timeseries/esma/shared/mdx/EZ11QVQMZ900/totv'
        StringTokenizer st = new StringTokenizer(fullIdentifier, "/");
        st.nextToken();st.nextToken();st.nextToken();st.nextToken();

        return st.nextToken();
    }
}
