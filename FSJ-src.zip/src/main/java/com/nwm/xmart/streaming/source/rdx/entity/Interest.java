
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AccrualDaysBetweenCouponDate",
    "MortgageStartAccrualDateperSettle",
    "AccruedCouponBasis",
    "EventCouponCap",
    "AdjustedDate",
    "CouponCCYFXRate",
    "CouponFrequency",
    "CurrentAccrualRate",
    "EndAccrualDate",
    "ExDivDaysMultiplier",
    "ExDivDaysPeriod",
    "FirstCouponDate",
    "MtgeIndexusedFor1stInterestPaymentPerSettl",
    "FirstSettleDate",
    "CouponRate",
    "CouponFloor",
    "PayDay",
    "InterestAccrued",
    "CalculationType",
    "CalculationTypeDescription",
    "InterestCurrency",
    "InterestSpread",
    "IssueSpreadToBenchmark",
    "LastResetDate",
    "MortgageRecordDate",
    "MortgageFirstPayDate",
    "MortgageNextPayDateperSettle",
    "MtgeNextPayDatePerSettle",
    "NextAccrualRate",
    "NextCouponDate",
    "NextResetDate",
    "PenultimateCouponDate",
    "PriceMethodology",
    "RedemptionCCYFXRate",
    "ResetIndex",
    "SpreadtoMidSwapsatIssue",
    "MarginAddPlusDelta",
    "PreviousCouponSettleDate",
    "RedemptionAmount",
    "RedemptionCurrency",
    "InterestAccrualDate",
    "DayCount",
    "NextAccrualDate"
})
public class Interest {

    @JsonProperty("AccrualDaysBetweenCouponDate")
    private Object accrualDaysBetweenCouponDate;
    @JsonProperty("MortgageStartAccrualDateperSettle")
    private Object mortgageStartAccrualDateperSettle;
    @JsonProperty("AccruedCouponBasis")
    private Object accruedCouponBasis;
    @JsonProperty("EventCouponCap")
    private Object eventCouponCap;
    @JsonProperty("AdjustedDate")
    private Object adjustedDate;
    @JsonProperty("CouponCCYFXRate")
    private Object couponCCYFXRate;
    @JsonProperty("CouponFrequency")
    private Object couponFrequency;
    @JsonProperty("CurrentAccrualRate")
    private Object currentAccrualRate;
    @JsonProperty("EndAccrualDate")
    private Object endAccrualDate;
    @JsonProperty("ExDivDaysMultiplier")
    private Object exDivDaysMultiplier;
    @JsonProperty("ExDivDaysPeriod")
    private String exDivDaysPeriod;
    @JsonProperty("FirstCouponDate")
    private Object firstCouponDate;
    @JsonProperty("MtgeIndexusedFor1stInterestPaymentPerSettl")
    private Object mtgeIndexusedFor1stInterestPaymentPerSettl;
    @JsonProperty("FirstSettleDate")
    private String firstSettleDate;
    @JsonProperty("CouponRate")
    private Object couponRate;
    @JsonProperty("CouponFloor")
    private Object couponFloor;
    @JsonProperty("PayDay")
    private Object payDay;
    @JsonProperty("InterestAccrued")
    private Object interestAccrued;
    @JsonProperty("CalculationType")
    private String calculationType;
    @JsonProperty("CalculationTypeDescription")
    private String calculationTypeDescription;
    @JsonProperty("InterestCurrency")
    private Object interestCurrency;
    @JsonProperty("InterestSpread")
    private Object interestSpread;
    @JsonProperty("IssueSpreadToBenchmark")
    private Object issueSpreadToBenchmark;
    @JsonProperty("LastResetDate")
    private Object lastResetDate;
    @JsonProperty("MortgageRecordDate")
    private Object mortgageRecordDate;
    @JsonProperty("MortgageFirstPayDate")
    private Object mortgageFirstPayDate;
    @JsonProperty("MortgageNextPayDateperSettle")
    private Object mortgageNextPayDateperSettle;
    @JsonProperty("MtgeNextPayDatePerSettle")
    private Object mtgeNextPayDatePerSettle;
    @JsonProperty("NextAccrualRate")
    private Object nextAccrualRate;
    @JsonProperty("NextCouponDate")
    private Object nextCouponDate;
    @JsonProperty("NextResetDate")
    private Object nextResetDate;
    @JsonProperty("PenultimateCouponDate")
    private Object penultimateCouponDate;
    @JsonProperty("PriceMethodology")
    private Object priceMethodology;
    @JsonProperty("RedemptionCCYFXRate")
    private Object redemptionCCYFXRate;
    @JsonProperty("ResetIndex")
    private Object resetIndex;
    @JsonProperty("SpreadtoMidSwapsatIssue")
    private Object spreadtoMidSwapsatIssue;
    @JsonProperty("MarginAddPlusDelta")
    private Object marginAddPlusDelta;
    @JsonProperty("PreviousCouponSettleDate")
    private Object previousCouponSettleDate;
    @JsonProperty("RedemptionAmount")
    private Object redemptionAmount;
    @JsonProperty("RedemptionCurrency")
    private Object redemptionCurrency;
    @JsonProperty("InterestAccrualDate")
    private Object interestAccrualDate;
    @JsonProperty("DayCount")
    private String dayCount;
    @JsonProperty("NextAccrualDate")
    private Object nextAccrualDate;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("AccrualDaysBetweenCouponDate")
    public Object getAccrualDaysBetweenCouponDate() {
        return accrualDaysBetweenCouponDate;
    }

    @JsonProperty("AccrualDaysBetweenCouponDate")
    public void setAccrualDaysBetweenCouponDate(Object accrualDaysBetweenCouponDate) {
        this.accrualDaysBetweenCouponDate = accrualDaysBetweenCouponDate;
    }

    @JsonProperty("MortgageStartAccrualDateperSettle")
    public Object getMortgageStartAccrualDateperSettle() {
        return mortgageStartAccrualDateperSettle;
    }

    @JsonProperty("MortgageStartAccrualDateperSettle")
    public void setMortgageStartAccrualDateperSettle(Object mortgageStartAccrualDateperSettle) {
        this.mortgageStartAccrualDateperSettle = mortgageStartAccrualDateperSettle;
    }

    @JsonProperty("AccruedCouponBasis")
    public Object getAccruedCouponBasis() {
        return accruedCouponBasis;
    }

    @JsonProperty("AccruedCouponBasis")
    public void setAccruedCouponBasis(Object accruedCouponBasis) {
        this.accruedCouponBasis = accruedCouponBasis;
    }

    @JsonProperty("EventCouponCap")
    public Object getEventCouponCap() {
        return eventCouponCap;
    }

    @JsonProperty("EventCouponCap")
    public void setEventCouponCap(Object eventCouponCap) {
        this.eventCouponCap = eventCouponCap;
    }

    @JsonProperty("AdjustedDate")
    public Object getAdjustedDate() {
        return adjustedDate;
    }

    @JsonProperty("AdjustedDate")
    public void setAdjustedDate(Object adjustedDate) {
        this.adjustedDate = adjustedDate;
    }

    @JsonProperty("CouponCCYFXRate")
    public Object getCouponCCYFXRate() {
        return couponCCYFXRate;
    }

    @JsonProperty("CouponCCYFXRate")
    public void setCouponCCYFXRate(Object couponCCYFXRate) {
        this.couponCCYFXRate = couponCCYFXRate;
    }

    @JsonProperty("CouponFrequency")
    public Object getCouponFrequency() {
        return couponFrequency;
    }

    @JsonProperty("CouponFrequency")
    public void setCouponFrequency(Object couponFrequency) {
        this.couponFrequency = couponFrequency;
    }

    @JsonProperty("CurrentAccrualRate")
    public Object getCurrentAccrualRate() {
        return currentAccrualRate;
    }

    @JsonProperty("CurrentAccrualRate")
    public void setCurrentAccrualRate(Object currentAccrualRate) {
        this.currentAccrualRate = currentAccrualRate;
    }

    @JsonProperty("EndAccrualDate")
    public Object getEndAccrualDate() {
        return endAccrualDate;
    }

    @JsonProperty("EndAccrualDate")
    public void setEndAccrualDate(Object endAccrualDate) {
        this.endAccrualDate = endAccrualDate;
    }

    @JsonProperty("ExDivDaysMultiplier")
    public Object getExDivDaysMultiplier() {
        return exDivDaysMultiplier;
    }

    @JsonProperty("ExDivDaysMultiplier")
    public void setExDivDaysMultiplier(Object exDivDaysMultiplier) {
        this.exDivDaysMultiplier = exDivDaysMultiplier;
    }

    @JsonProperty("ExDivDaysPeriod")
    public String getExDivDaysPeriod() {
        return exDivDaysPeriod;
    }

    @JsonProperty("ExDivDaysPeriod")
    public void setExDivDaysPeriod(String exDivDaysPeriod) {
        this.exDivDaysPeriod = exDivDaysPeriod;
    }

    @JsonProperty("FirstCouponDate")
    public Object getFirstCouponDate() {
        return firstCouponDate;
    }

    @JsonProperty("FirstCouponDate")
    public void setFirstCouponDate(Object firstCouponDate) {
        this.firstCouponDate = firstCouponDate;
    }

    @JsonProperty("MtgeIndexusedFor1stInterestPaymentPerSettl")
    public Object getMtgeIndexusedFor1stInterestPaymentPerSettl() {
        return mtgeIndexusedFor1stInterestPaymentPerSettl;
    }

    @JsonProperty("MtgeIndexusedFor1stInterestPaymentPerSettl")
    public void setMtgeIndexusedFor1stInterestPaymentPerSettl(Object mtgeIndexusedFor1stInterestPaymentPerSettl) {
        this.mtgeIndexusedFor1stInterestPaymentPerSettl = mtgeIndexusedFor1stInterestPaymentPerSettl;
    }

    @JsonProperty("FirstSettleDate")
    public String getFirstSettleDate() {
        return firstSettleDate;
    }

    @JsonProperty("FirstSettleDate")
    public void setFirstSettleDate(String firstSettleDate) {
        this.firstSettleDate = firstSettleDate;
    }

    @JsonProperty("CouponRate")
    public Object getCouponRate() {
        return couponRate;
    }

    @JsonProperty("CouponRate")
    public void setCouponRate(Object couponRate) {
        this.couponRate = couponRate;
    }

    @JsonProperty("CouponFloor")
    public Object getCouponFloor() {
        return couponFloor;
    }

    @JsonProperty("CouponFloor")
    public void setCouponFloor(Object couponFloor) {
        this.couponFloor = couponFloor;
    }

    @JsonProperty("PayDay")
    public Object getPayDay() {
        return payDay;
    }

    @JsonProperty("PayDay")
    public void setPayDay(Object payDay) {
        this.payDay = payDay;
    }

    @JsonProperty("InterestAccrued")
    public Object getInterestAccrued() {
        return interestAccrued;
    }

    @JsonProperty("InterestAccrued")
    public void setInterestAccrued(Object interestAccrued) {
        this.interestAccrued = interestAccrued;
    }

    @JsonProperty("CalculationType")
    public String getCalculationType() {
        return calculationType;
    }

    @JsonProperty("CalculationType")
    public void setCalculationType(String calculationType) {
        this.calculationType = calculationType;
    }

    @JsonProperty("CalculationTypeDescription")
    public String getCalculationTypeDescription() {
        return calculationTypeDescription;
    }

    @JsonProperty("CalculationTypeDescription")
    public void setCalculationTypeDescription(String calculationTypeDescription) {
        this.calculationTypeDescription = calculationTypeDescription;
    }

    @JsonProperty("InterestCurrency")
    public Object getInterestCurrency() {
        return interestCurrency;
    }

    @JsonProperty("InterestCurrency")
    public void setInterestCurrency(Object interestCurrency) {
        this.interestCurrency = interestCurrency;
    }

    @JsonProperty("InterestSpread")
    public Object getInterestSpread() {
        return interestSpread;
    }

    @JsonProperty("InterestSpread")
    public void setInterestSpread(Object interestSpread) {
        this.interestSpread = interestSpread;
    }

    @JsonProperty("IssueSpreadToBenchmark")
    public Object getIssueSpreadToBenchmark() {
        return issueSpreadToBenchmark;
    }

    @JsonProperty("IssueSpreadToBenchmark")
    public void setIssueSpreadToBenchmark(Object issueSpreadToBenchmark) {
        this.issueSpreadToBenchmark = issueSpreadToBenchmark;
    }

    @JsonProperty("LastResetDate")
    public Object getLastResetDate() {
        return lastResetDate;
    }

    @JsonProperty("LastResetDate")
    public void setLastResetDate(Object lastResetDate) {
        this.lastResetDate = lastResetDate;
    }

    @JsonProperty("MortgageRecordDate")
    public Object getMortgageRecordDate() {
        return mortgageRecordDate;
    }

    @JsonProperty("MortgageRecordDate")
    public void setMortgageRecordDate(Object mortgageRecordDate) {
        this.mortgageRecordDate = mortgageRecordDate;
    }

    @JsonProperty("MortgageFirstPayDate")
    public Object getMortgageFirstPayDate() {
        return mortgageFirstPayDate;
    }

    @JsonProperty("MortgageFirstPayDate")
    public void setMortgageFirstPayDate(Object mortgageFirstPayDate) {
        this.mortgageFirstPayDate = mortgageFirstPayDate;
    }

    @JsonProperty("MortgageNextPayDateperSettle")
    public Object getMortgageNextPayDateperSettle() {
        return mortgageNextPayDateperSettle;
    }

    @JsonProperty("MortgageNextPayDateperSettle")
    public void setMortgageNextPayDateperSettle(Object mortgageNextPayDateperSettle) {
        this.mortgageNextPayDateperSettle = mortgageNextPayDateperSettle;
    }

    @JsonProperty("MtgeNextPayDatePerSettle")
    public Object getMtgeNextPayDatePerSettle() {
        return mtgeNextPayDatePerSettle;
    }

    @JsonProperty("MtgeNextPayDatePerSettle")
    public void setMtgeNextPayDatePerSettle(Object mtgeNextPayDatePerSettle) {
        this.mtgeNextPayDatePerSettle = mtgeNextPayDatePerSettle;
    }

    @JsonProperty("NextAccrualRate")
    public Object getNextAccrualRate() {
        return nextAccrualRate;
    }

    @JsonProperty("NextAccrualRate")
    public void setNextAccrualRate(Object nextAccrualRate) {
        this.nextAccrualRate = nextAccrualRate;
    }

    @JsonProperty("NextCouponDate")
    public Object getNextCouponDate() {
        return nextCouponDate;
    }

    @JsonProperty("NextCouponDate")
    public void setNextCouponDate(Object nextCouponDate) {
        this.nextCouponDate = nextCouponDate;
    }

    @JsonProperty("NextResetDate")
    public Object getNextResetDate() {
        return nextResetDate;
    }

    @JsonProperty("NextResetDate")
    public void setNextResetDate(Object nextResetDate) {
        this.nextResetDate = nextResetDate;
    }

    @JsonProperty("PenultimateCouponDate")
    public Object getPenultimateCouponDate() {
        return penultimateCouponDate;
    }

    @JsonProperty("PenultimateCouponDate")
    public void setPenultimateCouponDate(Object penultimateCouponDate) {
        this.penultimateCouponDate = penultimateCouponDate;
    }

    @JsonProperty("PriceMethodology")
    public Object getPriceMethodology() {
        return priceMethodology;
    }

    @JsonProperty("PriceMethodology")
    public void setPriceMethodology(Object priceMethodology) {
        this.priceMethodology = priceMethodology;
    }

    @JsonProperty("RedemptionCCYFXRate")
    public Object getRedemptionCCYFXRate() {
        return redemptionCCYFXRate;
    }

    @JsonProperty("RedemptionCCYFXRate")
    public void setRedemptionCCYFXRate(Object redemptionCCYFXRate) {
        this.redemptionCCYFXRate = redemptionCCYFXRate;
    }

    @JsonProperty("ResetIndex")
    public Object getResetIndex() {
        return resetIndex;
    }

    @JsonProperty("ResetIndex")
    public void setResetIndex(Object resetIndex) {
        this.resetIndex = resetIndex;
    }

    @JsonProperty("SpreadtoMidSwapsatIssue")
    public Object getSpreadtoMidSwapsatIssue() {
        return spreadtoMidSwapsatIssue;
    }

    @JsonProperty("SpreadtoMidSwapsatIssue")
    public void setSpreadtoMidSwapsatIssue(Object spreadtoMidSwapsatIssue) {
        this.spreadtoMidSwapsatIssue = spreadtoMidSwapsatIssue;
    }

    @JsonProperty("MarginAddPlusDelta")
    public Object getMarginAddPlusDelta() {
        return marginAddPlusDelta;
    }

    @JsonProperty("MarginAddPlusDelta")
    public void setMarginAddPlusDelta(Object marginAddPlusDelta) {
        this.marginAddPlusDelta = marginAddPlusDelta;
    }

    @JsonProperty("PreviousCouponSettleDate")
    public Object getPreviousCouponSettleDate() {
        return previousCouponSettleDate;
    }

    @JsonProperty("PreviousCouponSettleDate")
    public void setPreviousCouponSettleDate(Object previousCouponSettleDate) {
        this.previousCouponSettleDate = previousCouponSettleDate;
    }

    @JsonProperty("RedemptionAmount")
    public Object getRedemptionAmount() {
        return redemptionAmount;
    }

    @JsonProperty("RedemptionAmount")
    public void setRedemptionAmount(Object redemptionAmount) {
        this.redemptionAmount = redemptionAmount;
    }

    @JsonProperty("RedemptionCurrency")
    public Object getRedemptionCurrency() {
        return redemptionCurrency;
    }

    @JsonProperty("RedemptionCurrency")
    public void setRedemptionCurrency(Object redemptionCurrency) {
        this.redemptionCurrency = redemptionCurrency;
    }

    @JsonProperty("InterestAccrualDate")
    public Object getInterestAccrualDate() {
        return interestAccrualDate;
    }

    @JsonProperty("InterestAccrualDate")
    public void setInterestAccrualDate(Object interestAccrualDate) {
        this.interestAccrualDate = interestAccrualDate;
    }

    @JsonProperty("DayCount")
    public String getDayCount() {
        return dayCount;
    }

    @JsonProperty("DayCount")
    public void setDayCount(String dayCount) {
        this.dayCount = dayCount;
    }

    @JsonProperty("NextAccrualDate")
    public Object getNextAccrualDate() {
        return nextAccrualDate;
    }

    @JsonProperty("NextAccrualDate")
    public void setNextAccrualDate(Object nextAccrualDate) {
        this.nextAccrualDate = nextAccrualDate;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("accrualDaysBetweenCouponDate", accrualDaysBetweenCouponDate).append("mortgageStartAccrualDateperSettle", mortgageStartAccrualDateperSettle).append("accruedCouponBasis", accruedCouponBasis).append("eventCouponCap", eventCouponCap).append("adjustedDate", adjustedDate).append("couponCCYFXRate", couponCCYFXRate).append("couponFrequency", couponFrequency).append("currentAccrualRate", currentAccrualRate).append("endAccrualDate", endAccrualDate).append("exDivDaysMultiplier", exDivDaysMultiplier).append("exDivDaysPeriod", exDivDaysPeriod).append("firstCouponDate", firstCouponDate).append("mtgeIndexusedFor1stInterestPaymentPerSettl", mtgeIndexusedFor1stInterestPaymentPerSettl).append("firstSettleDate", firstSettleDate).append("couponRate", couponRate).append("couponFloor", couponFloor).append("payDay", payDay).append("interestAccrued", interestAccrued).append("calculationType", calculationType).append("calculationTypeDescription", calculationTypeDescription).append("interestCurrency", interestCurrency).append("interestSpread", interestSpread).append("issueSpreadToBenchmark", issueSpreadToBenchmark).append("lastResetDate", lastResetDate).append("mortgageRecordDate", mortgageRecordDate).append("mortgageFirstPayDate", mortgageFirstPayDate).append("mortgageNextPayDateperSettle", mortgageNextPayDateperSettle).append("mtgeNextPayDatePerSettle", mtgeNextPayDatePerSettle).append("nextAccrualRate", nextAccrualRate).append("nextCouponDate", nextCouponDate).append("nextResetDate", nextResetDate).append("penultimateCouponDate", penultimateCouponDate).append("priceMethodology", priceMethodology).append("redemptionCCYFXRate", redemptionCCYFXRate).append("resetIndex", resetIndex).append("spreadtoMidSwapsatIssue", spreadtoMidSwapsatIssue).append("marginAddPlusDelta", marginAddPlusDelta).append("previousCouponSettleDate", previousCouponSettleDate).append("redemptionAmount", redemptionAmount).append("redemptionCurrency", redemptionCurrency).append("interestAccrualDate", interestAccrualDate).append("dayCount", dayCount).append("nextAccrualDate", nextAccrualDate).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(calculationType).append(previousCouponSettleDate).append(accrualDaysBetweenCouponDate).append(lastResetDate).append(nextCouponDate).append(nextAccrualRate).append(nextResetDate).append(dayCount).append(mortgageRecordDate).append(mtgeIndexusedFor1stInterestPaymentPerSettl).append(marginAddPlusDelta).append(couponFrequency).append(accruedCouponBasis).append(mortgageStartAccrualDateperSettle).append(issueSpreadToBenchmark).append(couponCCYFXRate).append(firstCouponDate).append(interestSpread).append(redemptionCCYFXRate).append(interestCurrency).append(resetIndex).append(exDivDaysPeriod).append(endAccrualDate).append(exDivDaysMultiplier).append(priceMethodology).append(mortgageNextPayDateperSettle).append(interestAccrualDate).append(spreadtoMidSwapsatIssue).append(currentAccrualRate).append(redemptionCurrency).append(eventCouponCap).append(penultimateCouponDate).append(couponFloor).append(redemptionAmount).append(nextAccrualDate).append(couponRate).append(mtgeNextPayDatePerSettle).append(mortgageFirstPayDate).append(adjustedDate).append(calculationTypeDescription).append(firstSettleDate).append(payDay).append(additionalProperties).append(interestAccrued).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Interest) == false) {
            return false;
        }
        Interest rhs = ((Interest) other);
        return new EqualsBuilder().append(calculationType, rhs.calculationType).append(previousCouponSettleDate, rhs.previousCouponSettleDate).append(accrualDaysBetweenCouponDate, rhs.accrualDaysBetweenCouponDate).append(lastResetDate, rhs.lastResetDate).append(nextCouponDate, rhs.nextCouponDate).append(nextAccrualRate, rhs.nextAccrualRate).append(nextResetDate, rhs.nextResetDate).append(dayCount, rhs.dayCount).append(mortgageRecordDate, rhs.mortgageRecordDate).append(mtgeIndexusedFor1stInterestPaymentPerSettl, rhs.mtgeIndexusedFor1stInterestPaymentPerSettl).append(marginAddPlusDelta, rhs.marginAddPlusDelta).append(couponFrequency, rhs.couponFrequency).append(accruedCouponBasis, rhs.accruedCouponBasis).append(mortgageStartAccrualDateperSettle, rhs.mortgageStartAccrualDateperSettle).append(issueSpreadToBenchmark, rhs.issueSpreadToBenchmark).append(couponCCYFXRate, rhs.couponCCYFXRate).append(firstCouponDate, rhs.firstCouponDate).append(interestSpread, rhs.interestSpread).append(redemptionCCYFXRate, rhs.redemptionCCYFXRate).append(interestCurrency, rhs.interestCurrency).append(resetIndex, rhs.resetIndex).append(exDivDaysPeriod, rhs.exDivDaysPeriod).append(endAccrualDate, rhs.endAccrualDate).append(exDivDaysMultiplier, rhs.exDivDaysMultiplier).append(priceMethodology, rhs.priceMethodology).append(mortgageNextPayDateperSettle, rhs.mortgageNextPayDateperSettle).append(interestAccrualDate, rhs.interestAccrualDate).append(spreadtoMidSwapsatIssue, rhs.spreadtoMidSwapsatIssue).append(currentAccrualRate, rhs.currentAccrualRate).append(redemptionCurrency, rhs.redemptionCurrency).append(eventCouponCap, rhs.eventCouponCap).append(penultimateCouponDate, rhs.penultimateCouponDate).append(couponFloor, rhs.couponFloor).append(redemptionAmount, rhs.redemptionAmount).append(nextAccrualDate, rhs.nextAccrualDate).append(couponRate, rhs.couponRate).append(mtgeNextPayDatePerSettle, rhs.mtgeNextPayDatePerSettle).append(mortgageFirstPayDate, rhs.mortgageFirstPayDate).append(adjustedDate, rhs.adjustedDate).append(calculationTypeDescription, rhs.calculationTypeDescription).append(firstSettleDate, rhs.firstSettleDate).append(payDay, rhs.payDay).append(additionalProperties, rhs.additionalProperties).append(interestAccrued, rhs.interestAccrued).isEquals();
    }

}
