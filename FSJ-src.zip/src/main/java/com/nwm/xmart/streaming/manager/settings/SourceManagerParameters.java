package com.nwm.xmart.streaming.manager.settings;

import com.nwm.xmart.streaming.manager.enums.ProcessingMode;
import com.nwm.xmart.streaming.manager.exceptions.PropertyNotFoundException;
import org.apache.flink.api.java.utils.ParameterTool;

import java.time.format.DateTimeFormatter;

public class SourceManagerParameters {

    public static int getSleepDuration(ParameterTool params) {
        int sleepDuration = params.getInt("source.manager.sleep.duration.minutes", -1);
        if (sleepDuration <= 0) {
            throwPropertyNotFound("source.manager.sleep.duration.minutes", "or, source.manager.sleep.duration.minutes <= 0.");
        }
        return sleepDuration;
    }

    public static ProcessingMode getMode(ParameterTool params) {
        String processingModeString = params.get("source.manager.mode", null);
        if (processingModeString == null) {
            throwPropertyNotFound("source.manager.mode", null);
        }
        return ProcessingMode.valueOf(processingModeString.toUpperCase());
    }

    public static DateTimeFormatter getOutputFormat(ParameterTool params) {
        // output format
        String outputFormatString = params.get("source.manager.outputFormat", null);
        if (outputFormatString == null) {
            throwPropertyNotFound("source.manager.outputFormat", null);
        }
        return DateTimeFormatter.ofPattern(outputFormatString);
    }


    public static String[] getFunctionsList(ParameterTool params) {
        String functions = params.get("source.manager.functions", null);
        if (functions == null) {
            throwPropertyNotFound("source.manager.functions", null);
        }
        return functions.split(",");
    }

    public static String getDailyJobName(ParameterTool params) {
        String dailyJobNameString = params.get("source.manager.daily.jobName", null);
        if (dailyJobNameString == null) {
            throwPropertyNotFound("source.manager.daily.jobName", null);
        }
        return dailyJobNameString;
    }

    public static String getDailyInitialLastSuccessfulDay(ParameterTool params) {
        String dailyInitialLastSuccessfulDayString = params.get("source.manager.daily.initialLastSuccessfulDay", null);
        if (dailyInitialLastSuccessfulDayString == null) {
            throwPropertyNotFound("source.manager.daily.initialLastSuccessfulDay", null);
        }
        return dailyInitialLastSuccessfulDayString;
    }

    private static void throwPropertyNotFound(String propertyName, String extraMessage) {
        throw new PropertyNotFoundException(propertyName + " is not set in properties file " + extraMessage);
    }
}