package com.nwm.xmart.streaming.source.crm.entity.callReport;

import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "ECD_Id", "User" })
public class LoggedBy implements Serializable {
    private static final long serialVersionUID = 5053344250741347315L;

    @JsonProperty("ECD_Id")
    private String eCDId;
    @JsonProperty("User")
    private String user;

    @JsonProperty("ECD_Id")
    public String getECDId() {
        return eCDId;
    }

    @JsonProperty("ECD_Id")
    public void setECDId(String eCDId) {
        this.eCDId = eCDId;
    }

    @JsonProperty("User")
    public String getUser() {
        return user;
    }

    @JsonProperty("User")
    public void setUser(String user) {
        this.user = user;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("LoggedBy{");
        sb.append("eCDId='").append(eCDId).append('\'');
        sb.append(", user='").append(user).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
