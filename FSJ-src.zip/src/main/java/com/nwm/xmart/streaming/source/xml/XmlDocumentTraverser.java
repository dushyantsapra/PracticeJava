package com.nwm.xmart.streaming.source.xml;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import static java.util.Objects.isNull;

@SuppressWarnings({ "WeakerAccess", "SameParameterValue" })
public final class XmlDocumentTraverser {

    protected static final Logger logger = LoggerFactory.getLogger(XmlDocumentTraverser.class);
    private static final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final String name;
    private final String contents;
    private final Map<String, String> attributeMap;

    private final List<XmlDocumentTraverser> listOfChildNodes;

    public XmlDocumentTraverser(Node node) {
        checkElementNode(node);

        this.name = node.getNodeName();
        this.contents = node.getTextContent();
        this.attributeMap = getAttributes(node);
        this.listOfChildNodes = getListOfChildNodes(node);

    }

    public XmlDocumentTraverser(String xmlString) {

        if(isNull(xmlString) || xmlString.isEmpty()) throw new IllegalArgumentException("NULL or empty XML String passed to XML Document Traverser");

        String xmlFragment = "<root>" + xmlString + "</root>";

        DocumentBuilder docBuilder;
        try {
            docBuilder = factory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            logger.error("Could not create document builder due to configuration issue", e);
            throw new XmlTraverserRuntimeException("Could not create document builder due to configuration issue");
        }

        Document doc;
        try {
            doc = docBuilder.parse(new ByteArrayInputStream(xmlFragment.getBytes("UTF-8")));
        } catch (UnsupportedEncodingException e) {
            logger.error("Could not parse xml (unsupported encoding): {}", xmlString, e);
            throw new IllegalArgumentException("Could not parse xml (unsupported encoding): " + xmlString);
        } catch (IOException e) {
            logger.error("Could not parse xml (io exception): {}", xmlString, e);
            throw new IllegalArgumentException("Could not parse xml (io exception): " + xmlString);
        } catch (SAXException e) {
            logger.error("Could not parse xml (SAX Error): {}", xmlString, e);
            throw new IllegalArgumentException("Could not parse xml (SAX Error): " + xmlString);
        }

        Node node = doc.getDocumentElement();
        this.name = node.getNodeName();
        this.contents = node.getTextContent();
        this.attributeMap = getAttributes(node);
        this.listOfChildNodes = getListOfChildNodes(node);

    }

    private Map<String, String> getAttributes(Node node) {
        NamedNodeMap attributeNodeMap = node.getAttributes();
        int len = attributeNodeMap.getLength();

        Map<String, String> attributeMap = new HashMap<String, String>(len);
        for (int i = 0; i < len; i++) {
            attributeMap.put(attributeNodeMap.item(i).getNodeName(),
                    attributeNodeMap.item(i).getTextContent());
        }
        return attributeMap;
    }

    private List<XmlDocumentTraverser> getListOfChildNodes(Node node) {
        NodeList children = node.getChildNodes();

        int len = children.getLength();

        List<XmlDocumentTraverser> list = new ArrayList<>(len);

        for (int i = 0; i < len; i++) {
            if(isElementNode(children.item(i))){
                list.add(new XmlDocumentTraverser(children.item(i)));
            }
        }

        return list;
    }

    private void checkElementNode(Node node) {
        if(isNull(node)) throw new IllegalArgumentException("NULL Node passed to XML Document Traverser");
        if(isNull(node.getNodeName())) throw new IllegalArgumentException("Node with NULL name passed to XML Document Traverser");

        if(!isElementNode(node)){
            throw new IllegalArgumentException("The node " + node.getNodeName() + " is not an element node and cannot contain another node.");
        }
    }
    private boolean isElementNode(Node node) {
        return node.getNodeType() == Node.ELEMENT_NODE;
    }


    public String getNodeName(){
        return name;
    }

    public int getNumberOfChildren() {
        return listOfChildNodes.size();
    }

    public XmlDocumentTraverser getObjectNode(String childNodeName) throws XmlFormatException {

        List<XmlDocumentTraverser> list = listOfChildNodes.stream()
                                                          .filter(node -> childNodeName.equals(node.getNodeName()))
                                                          .collect(Collectors.toList());

        if(list.size() > 1){
            logger.error("Duplicate nodes existed for the single node requested: {}", childNodeName);
            throw new XmlFormatException("Duplicate nodes existed for the single node requested: " + childNodeName);
        }

        if(list.isEmpty()){
            return null;
        }

        return list.get(0);

    }

    public List<XmlDocumentTraverser> getListOfNodes(String childNodeName){
        return listOfChildNodes.stream()
                               .filter(node -> childNodeName.equals(node.getNodeName()))
                               .collect(Collectors.toList());
    }

    private String getTextValue(){
        return contents;
    }

    public String getAttributeValue(String attributeName) {
        return attributeMap.get(attributeName);
    }

    public Double getDoubleAttributeValue(String attributeName) throws XmlFormatException {
        return parseDouble(getAttributeValue(attributeName));
    }

    public Integer getIntegerAttributeValue(String attributeName) throws XmlFormatException {
        return parseInteger(getAttributeValue(attributeName));
    }

    public LocalDate getDateAttributeValue(String attributeName) throws XmlFormatException {
        return parseLocalDate(getAttributeValue(attributeName));
    }

    private Double getDoubleValue() throws XmlFormatException {
        return parseDouble(getTextValue());
    }

    private Integer getIntegerValue() throws XmlFormatException {
        return parseInteger(getTextValue());
    }

    private LocalDate getDateValue() throws XmlFormatException {
        return parseLocalDate(getTextValue());
    }

    public String getTextValueNode(String childNodeName) throws XmlFormatException {
        XmlDocumentTraverser xmlDocumentTraverser = getObjectNode(childNodeName);
        if(isNull(xmlDocumentTraverser)) return null;

        return xmlDocumentTraverser.getTextValue();
    }

    public Double getDoubleValueNode(String childNodeName) throws XmlFormatException {
        XmlDocumentTraverser xmlDocumentTraverser = getObjectNode(childNodeName);
        if(isNull(xmlDocumentTraverser)) return null;

        return xmlDocumentTraverser.getDoubleValue();
    }

    public Integer getIntegerValueNode(String childNodeName) throws XmlFormatException {
        XmlDocumentTraverser xmlDocumentTraverser = getObjectNode(childNodeName);
        if(isNull(xmlDocumentTraverser)) return null;

        return xmlDocumentTraverser.getIntegerValue();
    }

    public LocalDate getDateValueNode(String childNodeName) throws XmlFormatException {
        XmlDocumentTraverser xmlDocumentTraverser = getObjectNode(childNodeName);
        if(isNull(xmlDocumentTraverser)) return null;

        return xmlDocumentTraverser.getDateValue();
    }

    private Integer parseInteger(String integerString) throws XmlFormatException {
        if(isNull(integerString)) return null;
        try {
            return Integer.parseInt(integerString);
        } catch (NumberFormatException e) {
            throw new XmlFormatException("Invalid number format: " + integerString, e);
        }
    }

    private Double parseDouble(String doubleString) throws XmlFormatException {
        if(isNull(doubleString)) return null;
        try {
            return Double.parseDouble(doubleString);
        } catch (NumberFormatException e) {
            throw new XmlFormatException("Invalid number format: " + doubleString, e);
        }
    }

    private LocalDate parseLocalDate(String dateString) throws XmlFormatException {
        if(isNull(dateString)) return null;

        try {
            return LocalDate.parse(dateString, DATE_FORMATTER);
        } catch (DateTimeParseException e) {
            throw new XmlFormatException("Invalid date format: " + dateString, e);
        }
    }

    public String toString(){
        return getNodeName() + ":" + getTextValue();
    }

}
