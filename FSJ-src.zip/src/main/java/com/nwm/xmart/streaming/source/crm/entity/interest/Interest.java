package com.nwm.xmart.streaming.source.crm.entity.interest;

import com.nwm.xmart.streaming.source.crm.entity.common.Account;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Budget_rate", "CreatedById", "CreatedDate", "Data_Migration_Id", "Id", "LastModifiedById",
                     "LastModifiedDate", "Name", "OwnerId", "SystemModstamp", "Account_Mismatch", "Account",
                     "As_Of_Date", "Contact", "Expired_Modified_Date", "Expired", "Interest_Subject", "Is_Disinterest",
                     "Label", "Last_Discussed", "Note", "Reason", "Report_Type", "Source" })
public class Interest implements Serializable {
    private static final long serialVersionUID = -2658744313858356552L;

    @JsonProperty("Budget_rate")
    private Integer budgetRate;
    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("Data_Migration_Id")
    private Object dataMigrationId;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("OwnerId")
    private String ownerId;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("Account_Mismatch")
    private Boolean accountMismatch;
    @JsonProperty("Account")
    private Account account;
    @JsonProperty("As_Of_Date")
    private String asOfDate;
    @JsonProperty("Contact")
    private String contact;
    @JsonProperty("Expired_Modified_Date")
    private String expiredModifiedDate;
    @JsonProperty("Expired")
    private Boolean expired;
    @JsonProperty("Interest_Subject")
    private InterestSubject interestSubject;
    @JsonProperty("Is_Disinterest")
    private Boolean isDisinterest;
    @JsonProperty("Label")
    private String label;
    @JsonProperty("Last_Discussed")
    private String lastDiscussed;
    @JsonProperty("Note")
    private String note;
    @JsonProperty("Reason")
    private String reason;
    @JsonProperty("Report_Type")
    private Object reportType;
    @JsonProperty("Source")
    private String source;

    @JsonProperty("Budget_rate")
    public Integer getBudgetRate() {
        return budgetRate;
    }

    @JsonProperty("Budget_rate")
    public void setBudgetRate(Integer budgetRate) {
        this.budgetRate = budgetRate;
    }

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("Data_Migration_Id")
    public Object getDataMigrationId() {
        return dataMigrationId;
    }

    @JsonProperty("Data_Migration_Id")
    public void setDataMigrationId(Object dataMigrationId) {
        this.dataMigrationId = dataMigrationId;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("OwnerId")
    public String getOwnerId() {
        return ownerId;
    }

    @JsonProperty("OwnerId")
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("Account_Mismatch")
    public Boolean getAccountMismatch() {
        return accountMismatch;
    }

    @JsonProperty("Account_Mismatch")
    public void setAccountMismatch(Boolean accountMismatch) {
        this.accountMismatch = accountMismatch;
    }

    @JsonProperty("Account")
    public Account getAccount() {
        return account;
    }

    @JsonProperty("Account")
    public void setAccount(Account account) {
        this.account = account;
    }

    @JsonProperty("As_Of_Date")
    public String getAsOfDate() {
        return asOfDate;
    }

    @JsonProperty("As_Of_Date")
    public void setAsOfDate(String asOfDate) {
        this.asOfDate = asOfDate;
    }

    @JsonProperty("Contact")
    public String getContact() {
        return contact;
    }

    @JsonProperty("Contact")
    public void setContact(String contact) {
        this.contact = contact;
    }

    @JsonProperty("Expired_Modified_Date")
    public String getExpiredModifiedDate() {
        return expiredModifiedDate;
    }

    @JsonProperty("Expired_Modified_Date")
    public void setExpiredModifiedDate(String expiredModifiedDate) {
        this.expiredModifiedDate = expiredModifiedDate;
    }

    @JsonProperty("Expired")
    public Boolean getExpired() {
        return expired;
    }

    @JsonProperty("Expired")
    public void setExpired(Boolean expired) {
        this.expired = expired;
    }

    @JsonProperty("Interest_Subject")
    public InterestSubject getInterestSubject() {
        return interestSubject;
    }

    @JsonProperty("Interest_Subject")
    public void setInterestSubject(InterestSubject interestSubject) {
        this.interestSubject = interestSubject;
    }

    @JsonProperty("Is_Disinterest")
    public Boolean getIsDisinterest() {
        return isDisinterest;
    }

    @JsonProperty("Is_Disinterest")
    public void setIsDisinterest(Boolean isDisinterest) {
        this.isDisinterest = isDisinterest;
    }

    @JsonProperty("Label")
    public String getLabel() {
        return label;
    }

    @JsonProperty("Label")
    public void setLabel(String label) {
        this.label = label;
    }

    @JsonProperty("Last_Discussed")
    public String getLastDiscussed() {
        return lastDiscussed;
    }

    @JsonProperty("Last_Discussed")
    public void setLastDiscussed(String lastDiscussed) {
        this.lastDiscussed = lastDiscussed;
    }

    @JsonProperty("Note")
    public String getNote() {
        return note;
    }

    @JsonProperty("Note")
    public void setNote(String note) {
        this.note = note;
    }

    @JsonProperty("Reason")
    public String getReason() {
        return reason;
    }

    @JsonProperty("Reason")
    public void setReason(String reason) {
        this.reason = reason;
    }

    @JsonProperty("Report_Type")
    public Object getReportType() {
        return reportType;
    }

    @JsonProperty("Report_Type")
    public void setReportType(Object reportType) {
        this.reportType = reportType;
    }

    @JsonProperty("Source")
    public String getSource() {
        return source;
    }

    @JsonProperty("Source")
    public void setSource(String source) {
        this.source = source;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Interest{");
        sb.append("budgetRate=").append(budgetRate);
        sb.append(", createdById='").append(createdById).append('\'');
        sb.append(", createdDate='").append(createdDate).append('\'');
        sb.append(", dataMigrationId=").append(dataMigrationId);
        sb.append(", id='").append(id).append('\'');
        sb.append(", lastModifiedById='").append(lastModifiedById).append('\'');
        sb.append(", lastModifiedDate='").append(lastModifiedDate).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", ownerId='").append(ownerId).append('\'');
        sb.append(", systemModstamp='").append(systemModstamp).append('\'');
        sb.append(", accountMismatch=").append(accountMismatch);
        sb.append(", account=").append(account);
        sb.append(", asOfDate='").append(asOfDate).append('\'');
        sb.append(", contact=").append(contact);
        sb.append(", expiredModifiedDate=").append(expiredModifiedDate);
        sb.append(", expired=").append(expired);
        sb.append(", interestSubject=").append(interestSubject);
        sb.append(", isDisinterest=").append(isDisinterest);
        sb.append(", label=").append(label);
        sb.append(", lastDiscussed='").append(lastDiscussed).append('\'');
        sb.append(", note='").append(note).append('\'');
        sb.append(", reason='").append(reason).append('\'');
        sb.append(", reportType=").append(reportType);
        sb.append(", source='").append(source).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
