package com.nwm.xmart.streaming.example;

import com.nwm.xmart.streaming.monitor.GeneosPersistenceFile;
import com.nwm.xmart.streaming.monitor.InactiveKafkaMonitor;
import com.nwm.xmart.streaming.monitor.InactivityMonitor;
import com.nwm.xmart.streaming.source.df.DataFabricFlinkKafkaSource;
import com.nwm.xmart.streaming.source.df.KafkaProperties;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.nwm.xmart.streaming.source.df.serialisation.FlinkDeserializer;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import com.rbs.datafabric.domain.event.RecordModifiedEvent;
import com.nwm.xmart.streaming.common.job.StreamJob;
import com.rbs.odc.core.domain.ODCValue;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.util.serialization.KeyedDeserializationSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Created by gardlex on 18/10/2017.
 */
public class ExampleBDXReaderFlinkJob {

    private static Logger logger = LoggerFactory.getLogger(ExampleBDXReaderFlinkJob.class);

    public static void main(String[] args) throws Exception {

        // StreamJob implementation can override any abstract methid as long as it calls super() first
        StreamJob streamJob = new ExampleODCStream();
        streamJob.run(args);
    }



    private static DataFabricFlinkKafkaSource getSource(Configuration configuration, DataFabricUtil dataFabricUtil, Class<DataFabricStreamEvent<BDXSinkData>> sourceClassRef) {
        // For Flink Deserializer

        InactivityMonitor inactivityMonitor = new InactiveKafkaMonitor(configuration, new GeneosPersistenceFile(configuration));

        // The deserializer itself
        KeyedDeserializationSchema<DataFabricStreamEvent<BDXSinkData>> deserialiser =
                new FlinkDeserializer<DataFabricStreamEvent<BDXSinkData>, BDXSinkData, RecordModifiedEvent>(
                        dataFabricUtil,
                        sourceClassRef,
                        BDXSinkData.class,
                        inactivityMonitor,
                        configuration);
        DataFabricFlinkKafkaSource sourceFunction = new DataFabricFlinkKafkaSource<DataFabricStreamEvent<ODCValue>>(dataFabricUtil, configuration, new KafkaProperties(configuration), deserialiser);

        return sourceFunction;
    }

    static class ExampleODCStream extends StreamJob {
            @Override
            protected void configureAndExecuteStream(StreamExecutionEnvironment env) {

                DataFabricUtil dataFabricUtil = new DataFabricUtil(configuration);

                // Type info reqd for the FlinkDeserializer
                final TypeInformation<DataFabricStreamEvent<BDXSinkData>> info = TypeInformation.of(new TypeHint<DataFabricStreamEvent<BDXSinkData>>(){});
                Class<DataFabricStreamEvent<BDXSinkData>> sourceClassRef = info.getTypeClass();

                // Crate the DataFabricSource
                DataFabricFlinkKafkaSource flinkKafkaSource = getSource(configuration, dataFabricUtil, sourceClassRef);

                // Map trasnformer
                ExampleMapTransform mapTransform = getMapTransform(configuration, dataFabricUtil);

                // Configuration of the stream
                DataStream<DataFabricStreamEvent<BDXSinkData>> input = env
                        .addSource(flinkKafkaSource, info)
                        .uid(configuration.getString("operator.trade.source.name",""))
                        .name(configuration.getString("operator.trade.source.name", ""))
                        .setParallelism(configuration.getInteger("operator.trade.source.parallelism", 1))
                        .map(mapTransform)
                        .setParallelism(3); //configuration.getInteger("operator.trade.transformer.parallelism", 1));
                input.addSink(new OdcUIDCounterSink())
                        .uid(configuration.getString("operator.datafabric.sink.name",""))
                        .name(configuration.getString("operator.datafabric.sink.name",""))
                        .setParallelism(1); //configuration.getInteger("operator.datafabric.sink.parallelism",1));

                try {
                    logger.info("EXECUTION PLAN = " + env.getExecutionPlan());
                    env.execute("ExampleODCFlinkJob");
                } catch (Exception e) {
                    logger.error("Exception running the ExampleODCFlinkJob",e);
                    throw new RuntimeException(e);
                }
            }
    }

    private static ExampleMapTransform getMapTransform(Configuration configuration, DataFabricUtil dataFabricUtil) {

        return new ExampleMapTransform();

    }
}
