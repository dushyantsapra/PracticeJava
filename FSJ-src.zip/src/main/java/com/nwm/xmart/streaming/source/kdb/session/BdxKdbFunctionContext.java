package com.nwm.xmart.streaming.source.kdb.session;

import com.nwm.xmart.streaming.source.kdb.data.KDBDataTransformer;
import com.nwm.xmart.streaming.source.kdb.data.ProcessingDays;

/**
 * Created by gardlex on 06/08/2018.
 *
 * Not Threadsafe
 */
public class BdxKdbFunctionContext {
    private KDBSession kdbSession;
    private ProcessingDays processingDays;
    private KDBDataTransformer kdbDataTransformer;
    private String sourceID;
    private String sourceName;
    private String functionName;
    private String tableName;


    public KDBDataTransformer getKdbDataTransformer() {
        return kdbDataTransformer;
    }

    public void setKdbDataTransformer(KDBDataTransformer kdbDataTransformer) {
        this.kdbDataTransformer = kdbDataTransformer;
    }

    public KDBSession getKdbSession() {
        return kdbSession;
    }

    public void setKdbSession(KDBSession kdbSession) {
        this.kdbSession = kdbSession;
    }

    public ProcessingDays getProcessingDays() {
        return processingDays;
    }

    public void setProcessingDays(ProcessingDays processingDays) {
        this.processingDays = processingDays;
    }

    public void setSourceID(String sourceID) {
        this.sourceID = sourceID;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }

    public String getSourceID() {
        return sourceID;
    }

    public String getSourceName() {
        return sourceName;
    }

    public String getFunctionName() {
        return functionName;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

}
