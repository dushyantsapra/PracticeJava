package com.nwm.xmart.streaming.source.rdx.query;

import com.nwm.xmart.streaming.source.rdx.exception.RdxSubscriptionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.dx.webService.impl.rdx.SubscriptionCriteriaBuilder;
import rbs.gbm.dx.webService.interfaces.rdx.IRdxType;
import rbs.gbm.dx.webService.interfaces.rdx.ISubscriptionCriteria;

import java.io.InvalidObjectException;

/**
 * Created by gardlex on 21/05/2018.
 */
public class RdxSubscriptionCriteriaBuilder {
    private static Logger logger = LoggerFactory.getLogger(RdxSubscriptionCriteriaBuilder.class);
    private final SubscriptionCriteriaBuilder subscriptionCriteriaBuilder = new SubscriptionCriteriaBuilder();
    private volatile long changeID;
    private volatile IRdxType rdxType;

    public RdxSubscriptionCriteriaBuilder withStartChangeID(long changeId) {
        changeID = changeId;
        return this;
    }

    public RdxSubscriptionCriteriaBuilder withRdxType(IRdxType rdxType) {
        this.rdxType = rdxType;
        return this;
    }

    public ISubscriptionCriteria build() throws RdxSubscriptionException {
        try {
            subscriptionCriteriaBuilder
                    .setTypeCriteria(rdxType.GetEntityType(), rdxType.GetEntitySubtype())
                    .setStartChangeId(changeID);
            return subscriptionCriteriaBuilder.buildSubscriptionCriteria();
        } catch (InvalidObjectException e) {
            logger.error("Could not build the ISubscriptionCriteria: ", e);
            throw new RdxSubscriptionException("Could not build the ISubscriptionCriteria", e);
        }
    }
}
