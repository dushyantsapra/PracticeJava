package com.nwm.xmart.streaming.source.rdx.cache.load;

import com.nwm.xmart.streaming.source.mdx.cache.IsinCache;
import com.nwm.xmart.streaming.source.mdx.event.ProcessingType;
import com.nwm.xmart.streaming.source.rdx.event.RDXSourceEvent;
import com.nwm.xmart.streaming.source.rdx.query.RdxDataReader;
import com.nwm.xmart.streaming.source.mdx.cache.load.CacheItem;
import com.nwm.xmart.streaming.source.rdx.exception.RdxLoadException;
import com.nwm.xmart.streaming.source.rdx.json.RdxFixedIncome;
import com.nwm.xmart.streaming.source.rdx.query.RdxContentParser;
import com.nwm.xmart.streaming.source.rdx.session.RDXSessionContextType;
import com.nwm.xmart.streaming.source.rdx.subscription.RdxSubscription;
import com.nwm.xmart.streaming.source.rdx.query.RdxLoaderCriteriaBuilder;
import com.nwm.xmart.streaming.source.rdx.session.RDXSessionContext;
import com.nwm.xmart.util.MDCUtil;
import org.apache.commons.lang3.reflect.ConstructorUtils;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.util.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.dx.webService.impl.DxDateTime;
import rbs.gbm.dx.webService.interfaces.IRdxSession;
import rbs.gbm.dx.webService.interfaces.rdx.IReferenceData;
import rbs.gbm.mdx.webService.interfaces.MdxException;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created by gardlex on 21/05/2018.
 */
public class RDXReferenceDataLoader<RdxSourceEvent> implements RDXEventLoader<RdxSourceEvent> {

    private static Logger logger = LoggerFactory.getLogger(RDXReferenceDataLoader.class);
    private volatile IsinCache isinCache;
    private final Class<RdxSourceEvent> sourceEventClass;
    private volatile SourceFunction<RdxSourceEvent> sourceFunction;
    private volatile SourceFunction.SourceContext sourceCtx;
    private volatile IntCounter loadEventCounter;
    private volatile RdxSubscription rdxSubscription;
    private volatile boolean isInitialLoad;
    private volatile boolean isHistoricalLoad;
    private final ConcurrentMap<String, String> refreshFullIsinMap = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, String> refreshNewIsinMap = new ConcurrentHashMap<>();
    private volatile RDXSessionContext rdxSession;
    private volatile RdxLoaderCriteriaBuilder loaderCriteriaBuilder;
    private volatile int MAX_NO_ISINS_PER_QUERY;
    private final RdxContentParser rdxContentParser = new RdxContentParser();
    private long lastChangeId;
    private transient ExecutorService executorService;
    private volatile ParameterTool flinkParameters;

    public RDXReferenceDataLoader(Class<RdxSourceEvent> sourceEventClass, boolean isHistoricalLoad) {
        this.sourceEventClass = sourceEventClass;
        this.isHistoricalLoad = isHistoricalLoad;
        this.executorService = Executors.newSingleThreadExecutor(
                new ThreadFactory() {
                    @Override
                    public Thread newThread(Runnable r) {
                        Thread t = new Thread(r);

                        t.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                            @Override
                            public void uncaughtException(Thread t, Throwable e) {
                                LoggerFactory.getLogger(t.getName()).error("RDXReferenceDataLoader thread is no longer running", e.getMessage(), e);
                            }
                        });

                        return t;
                    }
                }
        );
    }

    @Override
    public void setSourceContext(SourceFunction.SourceContext srcCtx) {
        this.sourceCtx = srcCtx;
    }

    @Override
    public RDXEventLoader withISINCache(IsinCache isinCache) {
        this.isinCache = isinCache;
        return this;
    }

    @Override
    public RDXEventLoader withCounter(IntCounter counter) {
        this.loadEventCounter = counter;
        return this;
    }

    @Override
    public RDXEventLoader withRdxSubscription(RdxSubscription subscription) {
        this.rdxSubscription = subscription;
        return this;
    }

    @Override
    public RDXEventLoader withSourceFunction(SourceFunction<RdxSourceEvent> sourceFunction) {
        this.sourceFunction = sourceFunction;
        return this;
    }

    @Override
    public RDXEventLoader withRDXSession(RDXSessionContext rdxSession) {
        this.rdxSession = rdxSession;
        return this;
    }

    @Override
    public RDXEventLoader withRdxLoaderCriteriaBuilder(RdxLoaderCriteriaBuilder builder) {
        this.loaderCriteriaBuilder = builder;
        return this;
    }

    public RDXEventLoader withFlinkParameters(ParameterTool flinkParameters){
        this.flinkParameters = flinkParameters;
        MAX_NO_ISINS_PER_QUERY = flinkParameters.getInt("rdx.loader.fetch.max.isins", 300);
        return this;
    }

    @Override
    public void close() {
        try {
            rdxSession.close();
            executorService.shutdownNow();
        } catch (Exception e) {
            logger.warn("Error whilst closing RDX Loader", e);
        }
    }

    @Override
    public void setInitialLoad(boolean isInitialLoad) {
        this.isInitialLoad = isInitialLoad;
    }

    @Override
    public long loadRdxEvents() throws RdxLoadException {
        final ReentrantLock subscriptionLock = rdxSubscription.getSubscriptionLock();

        logger.info("RDX LOADER - Getting subscription lock");

        subscriptionLock.lock();

        logger.info("RDX LOADER - Got subscription lock");

        lastChangeId = 0;
        AtomicInteger noOfRdxEventsPublishedInLoad = new AtomicInteger();

        // Define the AS OF DATE for the RDX query
        if (!isHistoricalLoad) {
            DxDateTime nowDateTime = DxDateTime.getUtcNow();
            loaderCriteriaBuilder.withLatestValudationDate(
                    nowDateTime.getYear(),
                    nowDateTime.getMonth(),
                    nowDateTime.getDay(),
                    nowDateTime.getHour(),
                    nowDateTime.getMinute(),
                    nowDateTime.getSecond()
            );
        }

        try {
            // get set of ISINs to process
            Set<String> isinSet = null;
            if (isInitialLoad) {
                isinSet = isinCache.getISINsToLoad();
            } else {
                isinSet = new HashSet<>();
                isinSet.addAll(refreshNewIsinMap.keySet());
            }

            // Perform batching if necessary
            if (isinSet.size() > MAX_NO_ISINS_PER_QUERY) {
                int batchSize = 0;
                Set<String> batchSet = new HashSet<>();

                for (String isin : isinSet) {
                    batchSet.add(isin);
                    if (++batchSize == MAX_NO_ISINS_PER_QUERY) {
                        processIsins(batchSet, noOfRdxEventsPublishedInLoad);
                        batchSet = new HashSet<>();
                        batchSize = 0;
                    }
                }

                if (batchSize > 0) {
                    processIsins(batchSet, noOfRdxEventsPublishedInLoad);
                }
            } else {
                processIsins(isinSet, noOfRdxEventsPublishedInLoad);
            }

            // Update the subscription's ISIN list
            if (isInitialLoad) {
                rdxSubscription.setISINList(isinSet);
            } else {
                rdxSubscription.setISINList(refreshFullIsinMap.keySet());
            }
        } catch(Exception e) {
            logger.error("Error occurred during a loading of RDX events", e);
            throw new RdxLoadException("Error occurred during a loading of RDX events", e);
        } finally {
            subscriptionLock.unlock();
            logger.info("RDX LOADER - Unlocked subscription lock");
        }

        logger.info("No of RDX events published to stream for current load is [ " + noOfRdxEventsPublishedInLoad + " ]");

        return lastChangeId;
    }

    private void processIsins(Set<String> batchIsinSet, AtomicInteger noOfRdxEventsPublishedInLoad) throws Exception {
        // Set the loader's ISIN list
        loaderCriteriaBuilder.withIsins(batchIsinSet);

        // Get the rdxDocuments
        Iterator<IReferenceData> fetchIterator = null;
        int retryAttempts = flinkParameters.getInt("rdx.loader.fetch.retry.attempts", 3);
        for (int x=0; x < retryAttempts; x++) {
            try {
                Future<Iterator<IReferenceData>> fetchFuture = executorService.submit(new Callable<Iterator<IReferenceData>>() {
                    @Override
                    public Iterator<IReferenceData> call() throws Exception {
                        MDCUtil.putJobNameInMDC(flinkParameters);
                        return rdxSession.getRdxSession().query(loaderCriteriaBuilder.build()).iterator();
                    }
                });
                fetchIterator = fetchFuture.get(flinkParameters.getLong("rdx.loader.fetch.timeout.secs", 300), TimeUnit.SECONDS);
                break;
            } catch (InterruptedException i) {
                Thread.currentThread().interrupt();
                logger.error("Fetching of RDX instruments (ISINs) was interrupted on attempt: " + x, i);
                executorService.shutdownNow();
                throw i;
            } catch (Exception e) {
                logger.error("Fetching of RDX instruments (ISINs) failed on attempt: " + x, e);
                fetchIterator = null;
                try {
                    rdxSession.buildNewSession();
                } catch (Exception b) {
                    logger.error("processIsins: Could not build NEW RdxSession");
                    throw b;
                }
            }
        }

        // check whether we reached the max no of retries
        if (fetchIterator == null) {
            executorService.shutdownNow();
            throw new RdxLoadException("No ISINs retrieved after " + retryAttempts + " retry attempts");
        }

        // Now push each document into the stream updating the IsinCacheItem cache's document, version (the latest version to be published)
        final Object checkpointLock = sourceCtx.getCheckpointLock();

        RdxSourceEvent rdxSourceEvent;
        RdxFixedIncome rdxFixedIncome = null;
        IReferenceData referenceData = null;
        long currentChangeID ;

        while (fetchIterator.hasNext()) {
            referenceData = fetchIterator.next();
            rdxFixedIncome = rdxContentParser.getJSONPojoForContent(referenceData.getContent());

            // Reject if no facets
            if (rdxFixedIncome.getFacets() == null) {
                logger.info("RdxFixedIncome instance found without any facets, rejecting this load event");
                continue;
            }

            currentChangeID = referenceData.getRdxChangeId();
            if (currentChangeID > lastChangeId) {
                lastChangeId = currentChangeID;
            }
            // RdxFixedIncome rdxFixedIncome, long changeID, String rdxId, String rdxSeriesId, String valuationDate, int version, ProcessingType processingType, long timeReceivedFromSource
            rdxSourceEvent = ConstructorUtils.invokeConstructor(
                    sourceEventClass,
                    rdxFixedIncome,
                    currentChangeID,
                    referenceData.getRdxId(),
                    referenceData.getRdxSeriesId(),
                    referenceData.getValuationDate(),
                    referenceData.getVersion(),
                    ProcessingType.LOAD,
                    System.currentTimeMillis());

            publishEventToStream(sourceCtx, checkpointLock, loadEventCounter, rdxSourceEvent, rdxFixedIncome, noOfRdxEventsPublishedInLoad);
        }
    }

    private void publishEventToStream(SourceFunction.SourceContext srcCtx, Object checkpointLock, IntCounter intCounter, RdxSourceEvent rdxSourceEvent, RdxFixedIncome rdxFixedIncome, AtomicInteger noOfRdxEventsPublishedInLoad) {
        CacheItem rdxIsinCacheItem;
        RDXSourceEvent event = (RDXSourceEvent)rdxSourceEvent;

        logger.info("RDX LOADER - about to enter checkpointLock");

        synchronized (checkpointLock) {

            logger.info("RDX LOADER - in checkpointLock");

            String isin = RdxDataReader.getIsinFromAliasFor(rdxFixedIncome);
            // Don't publish if FixedIncome doesn't have ISIN
            if (isin == null) {
                return;
            }

            rdxIsinCacheItem = new RDXIsinCacheItem(
                    isin,
                    event.getValuationDate(),
                    event.getVersion());
            if (isinCache.putISINCacheItem(rdxIsinCacheItem)) {
                srcCtx.collect(rdxSourceEvent);
                intCounter.add(1);
                noOfRdxEventsPublishedInLoad.incrementAndGet();
            }
        }

        logger.info("RDX LOADER - left checkpointLock");

    }



    @Override
    public void setLatestISINs(Set<String> fullIsinList, Set<String> newIsinList) {
        logger.info("RDX LOADER - setLatestISINs: Full = " + fullIsinList.size() + ", new = " + newIsinList.size());
        // Ensure that only the new isins are now loaded
        setInitialLoad(false);
        refreshFullIsinMap.clear();
        refreshNewIsinMap.clear();

        for (String fullIsin : fullIsinList) {
            refreshFullIsinMap.put(fullIsin, "");
        }

        for (String newIsin : fullIsinList) {
            refreshNewIsinMap.put(newIsin, "");
        }

        try {
            loadRdxEvents();
        } catch (Exception e) {
            logger.error("Could not load refreshed ISIN list items ", e);
            sourceFunction.cancel();
            throw new RdxLoadException("Could not load refreshed ISIN list items", e);
        }
    }


}
