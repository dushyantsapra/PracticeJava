
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "MaterialModificationDate",
    "MaterialModificationReason",
    "TaxObligation",
    "GrandfatheredObligation",
    "FatcaShortTermIndicator",
    "TaxProvider",
    "IssuedBeforeFATCAGrandfatheringDate",
    "USFDAPIncome",
    "MaterialModification"
})
public class InstrumentTax {

    @JsonProperty("MaterialModificationDate")
    private Object materialModificationDate;
    @JsonProperty("MaterialModificationReason")
    private Object materialModificationReason;
    @JsonProperty("TaxObligation")
    private String taxObligation;
    @JsonProperty("GrandfatheredObligation")
    private String grandfatheredObligation;
    @JsonProperty("FatcaShortTermIndicator")
    private String fatcaShortTermIndicator;
    @JsonProperty("TaxProvider")
    private String taxProvider;
    @JsonProperty("IssuedBeforeFATCAGrandfatheringDate")
    private String issuedBeforeFATCAGrandfatheringDate;
    @JsonProperty("USFDAPIncome")
    private String uSFDAPIncome;
    @JsonProperty("MaterialModification")
    private String materialModification;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("MaterialModificationDate")
    public Object getMaterialModificationDate() {
        return materialModificationDate;
    }

    @JsonProperty("MaterialModificationDate")
    public void setMaterialModificationDate(Object materialModificationDate) {
        this.materialModificationDate = materialModificationDate;
    }

    @JsonProperty("MaterialModificationReason")
    public Object getMaterialModificationReason() {
        return materialModificationReason;
    }

    @JsonProperty("MaterialModificationReason")
    public void setMaterialModificationReason(Object materialModificationReason) {
        this.materialModificationReason = materialModificationReason;
    }

    @JsonProperty("TaxObligation")
    public String getTaxObligation() {
        return taxObligation;
    }

    @JsonProperty("TaxObligation")
    public void setTaxObligation(String taxObligation) {
        this.taxObligation = taxObligation;
    }

    @JsonProperty("GrandfatheredObligation")
    public String getGrandfatheredObligation() {
        return grandfatheredObligation;
    }

    @JsonProperty("GrandfatheredObligation")
    public void setGrandfatheredObligation(String grandfatheredObligation) {
        this.grandfatheredObligation = grandfatheredObligation;
    }

    @JsonProperty("FatcaShortTermIndicator")
    public String getFatcaShortTermIndicator() {
        return fatcaShortTermIndicator;
    }

    @JsonProperty("FatcaShortTermIndicator")
    public void setFatcaShortTermIndicator(String fatcaShortTermIndicator) {
        this.fatcaShortTermIndicator = fatcaShortTermIndicator;
    }

    @JsonProperty("TaxProvider")
    public String getTaxProvider() {
        return taxProvider;
    }

    @JsonProperty("TaxProvider")
    public void setTaxProvider(String taxProvider) {
        this.taxProvider = taxProvider;
    }

    @JsonProperty("IssuedBeforeFATCAGrandfatheringDate")
    public String getIssuedBeforeFATCAGrandfatheringDate() {
        return issuedBeforeFATCAGrandfatheringDate;
    }

    @JsonProperty("IssuedBeforeFATCAGrandfatheringDate")
    public void setIssuedBeforeFATCAGrandfatheringDate(String issuedBeforeFATCAGrandfatheringDate) {
        this.issuedBeforeFATCAGrandfatheringDate = issuedBeforeFATCAGrandfatheringDate;
    }

    @JsonProperty("USFDAPIncome")
    public String getUSFDAPIncome() {
        return uSFDAPIncome;
    }

    @JsonProperty("USFDAPIncome")
    public void setUSFDAPIncome(String uSFDAPIncome) {
        this.uSFDAPIncome = uSFDAPIncome;
    }

    @JsonProperty("MaterialModification")
    public String getMaterialModification() {
        return materialModification;
    }

    @JsonProperty("MaterialModification")
    public void setMaterialModification(String materialModification) {
        this.materialModification = materialModification;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("materialModificationDate", materialModificationDate).append("materialModificationReason", materialModificationReason).append("taxObligation", taxObligation).append("grandfatheredObligation", grandfatheredObligation).append("fatcaShortTermIndicator", fatcaShortTermIndicator).append("taxProvider", taxProvider).append("issuedBeforeFATCAGrandfatheringDate", issuedBeforeFATCAGrandfatheringDate).append("uSFDAPIncome", uSFDAPIncome).append("materialModification", materialModification).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(grandfatheredObligation).append(uSFDAPIncome).append(materialModificationReason).append(issuedBeforeFATCAGrandfatheringDate).append(materialModification).append(taxObligation).append(fatcaShortTermIndicator).append(materialModificationDate).append(taxProvider).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InstrumentTax) == false) {
            return false;
        }
        InstrumentTax rhs = ((InstrumentTax) other);
        return new EqualsBuilder().append(grandfatheredObligation, rhs.grandfatheredObligation).append(uSFDAPIncome, rhs.uSFDAPIncome).append(materialModificationReason, rhs.materialModificationReason).append(issuedBeforeFATCAGrandfatheringDate, rhs.issuedBeforeFATCAGrandfatheringDate).append(materialModification, rhs.materialModification).append(taxObligation, rhs.taxObligation).append(fatcaShortTermIndicator, rhs.fatcaShortTermIndicator).append(materialModificationDate, rhs.materialModificationDate).append(taxProvider, rhs.taxProvider).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
