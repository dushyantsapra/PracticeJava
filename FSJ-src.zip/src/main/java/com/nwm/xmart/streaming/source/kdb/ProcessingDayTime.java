package com.nwm.xmart.streaming.source.kdb;

/**
 * Created by gardlex on 08/08/2018.
 */
public class ProcessingDayTime {
    private volatile String functionName;
    private volatile String processingDay;
    private volatile long epochTime;

    public ProcessingDayTime(String functionName, String processingDay, long epochTime) {
        this.functionName = functionName;
        this.processingDay = processingDay;
        this.epochTime = epochTime;
    }

    public String getFunctionName() {
        return functionName;
    }

    public String getProcessingDay() {
        return processingDay;
    }

    public long getEpochTime() {
        return epochTime;
    }

    public void setProcessingDay(String processingDay) {
        this.processingDay = processingDay;
    }

    public void setEpochTime(long epochTime) {
        this.epochTime = epochTime;
    }
}
