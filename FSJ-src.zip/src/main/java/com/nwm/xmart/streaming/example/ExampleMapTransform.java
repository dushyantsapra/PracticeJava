package com.nwm.xmart.streaming.example;

import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.rbs.odc.core.domain.ODCValue;
import org.apache.flink.api.common.functions.RichMapFunction;

/**
 * Created by gardlex on 10/11/2017.
 */
public class ExampleMapTransform extends RichMapFunction<DataFabricStreamEvent<ODCValue>, DataFabricStreamEvent<ODCValue>> {

    @Override
    public DataFabricStreamEvent<ODCValue> map(DataFabricStreamEvent<ODCValue> value) throws Exception {
//        logger.info("map value = " + value);

        // This is how you throw any error...MUST ONLY USE THE RAW BYTES don't provide a class to store for ODC
//        try {
//            throw new RuntimeException("This is a test Exception inside a MapFunction");
//        } catch (Exception e) {
//            errorMonitor.captureRawErrorStreamEvent("TestJob", "testOperator", value.getTopic(), value.getStreamPosition(), value.getEventRawBytes(), ExceptionUtils.stringifyException(e));
//        }

        return value;
    }
}
