package com.nwm.xmart.streaming.source.tdx.event;

import com.nwm.xmart.streaming.source.json.JSONDocumentTraverser;

import java.time.LocalDateTime;

/**
 * Created by gardlex on 08/10/2018.
 */
public class TDXSourceEvent {
    private final JSONDocumentTraverser jsonDocumentTraverser;
    private final String eventSequenceId;
    private final String dataSetId;
    private final long timeReceivedFromSource;
    private final int version;
    private final LocalDateTime from;
    private final LocalDateTime to;

    public TDXSourceEvent(JSONDocumentTraverser jsonDocumentTraverser, String eventSequenceId, String dataSetId, long timeReceivedFromSource,
                          int version, LocalDateTime from, LocalDateTime to) {
        this.jsonDocumentTraverser = jsonDocumentTraverser;
        this.eventSequenceId = eventSequenceId;
        this.dataSetId = dataSetId;
        this.timeReceivedFromSource = timeReceivedFromSource;
        this.version = version;
        this.from = from;
        this.to = to;
    }

    public JSONDocumentTraverser getJsonDocumentTraverser() {
        return jsonDocumentTraverser;
    }

    public String getEventSequenceId() {
        return eventSequenceId;
    }

    public String getDataSetId() {
        return dataSetId;
    }

    public long getTimeReceivedFromSource() {
        return timeReceivedFromSource;
    }

    public int getVersion() {
        return version;
    }

    public LocalDateTime getFrom() {
        return from;
    }

    public LocalDateTime getTo() {
        return to;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("TDXSourceEvent{");
        sb.append("jsonDocumentTraverser=").append(jsonDocumentTraverser);
        sb.append(", eventSequenceId='").append(eventSequenceId).append('\'');
        sb.append(", dataSetId='").append(dataSetId).append('\'');
        sb.append(", timeReceivedFromSource=").append(timeReceivedFromSource);
        sb.append(", version=").append(version);
        sb.append(", from=").append(from);
        sb.append(", to=").append(to);
        sb.append('}');
        return sb.toString();
    }
}
