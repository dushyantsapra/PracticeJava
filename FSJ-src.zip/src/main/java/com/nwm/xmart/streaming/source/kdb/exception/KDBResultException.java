package com.nwm.xmart.streaming.source.kdb.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class KDBResultException extends RuntimeException {

    public KDBResultException() {
        super();
    }

    public KDBResultException(String msg) {
        super(msg);
    }

    public KDBResultException(String msg, Throwable t) {
        super(msg, t);
    }
}
