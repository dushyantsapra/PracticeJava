
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "LoanGeogCurrentFirst",
    "LoanGeogCurrentFirstEar",
    "LoanGeogCurrentSecond",
    "LoanGeogCurrentSecondEar",
    "LoanGeogCurrentThird",
    "LoanGeogCurrentThirdEar",
    "LoanGeogCurrentFourth",
    "LoanGeogCurrentFourthEar",
    "LoanGeogCurrentFifth",
    "LoanGeogCurrentFifthEar"
})
public class GeographicDistribution {

    @JsonProperty("LoanGeogCurrentFirst")
    private Object loanGeogCurrentFirst;
    @JsonProperty("LoanGeogCurrentFirstEar")
    private Object loanGeogCurrentFirstEar;
    @JsonProperty("LoanGeogCurrentSecond")
    private Object loanGeogCurrentSecond;
    @JsonProperty("LoanGeogCurrentSecondEar")
    private Object loanGeogCurrentSecondEar;
    @JsonProperty("LoanGeogCurrentThird")
    private Object loanGeogCurrentThird;
    @JsonProperty("LoanGeogCurrentThirdEar")
    private Object loanGeogCurrentThirdEar;
    @JsonProperty("LoanGeogCurrentFourth")
    private Object loanGeogCurrentFourth;
    @JsonProperty("LoanGeogCurrentFourthEar")
    private Object loanGeogCurrentFourthEar;
    @JsonProperty("LoanGeogCurrentFifth")
    private Object loanGeogCurrentFifth;
    @JsonProperty("LoanGeogCurrentFifthEar")
    private Object loanGeogCurrentFifthEar;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("LoanGeogCurrentFirst")
    public Object getLoanGeogCurrentFirst() {
        return loanGeogCurrentFirst;
    }

    @JsonProperty("LoanGeogCurrentFirst")
    public void setLoanGeogCurrentFirst(Object loanGeogCurrentFirst) {
        this.loanGeogCurrentFirst = loanGeogCurrentFirst;
    }

    @JsonProperty("LoanGeogCurrentFirstEar")
    public Object getLoanGeogCurrentFirstEar() {
        return loanGeogCurrentFirstEar;
    }

    @JsonProperty("LoanGeogCurrentFirstEar")
    public void setLoanGeogCurrentFirstEar(Object loanGeogCurrentFirstEar) {
        this.loanGeogCurrentFirstEar = loanGeogCurrentFirstEar;
    }

    @JsonProperty("LoanGeogCurrentSecond")
    public Object getLoanGeogCurrentSecond() {
        return loanGeogCurrentSecond;
    }

    @JsonProperty("LoanGeogCurrentSecond")
    public void setLoanGeogCurrentSecond(Object loanGeogCurrentSecond) {
        this.loanGeogCurrentSecond = loanGeogCurrentSecond;
    }

    @JsonProperty("LoanGeogCurrentSecondEar")
    public Object getLoanGeogCurrentSecondEar() {
        return loanGeogCurrentSecondEar;
    }

    @JsonProperty("LoanGeogCurrentSecondEar")
    public void setLoanGeogCurrentSecondEar(Object loanGeogCurrentSecondEar) {
        this.loanGeogCurrentSecondEar = loanGeogCurrentSecondEar;
    }

    @JsonProperty("LoanGeogCurrentThird")
    public Object getLoanGeogCurrentThird() {
        return loanGeogCurrentThird;
    }

    @JsonProperty("LoanGeogCurrentThird")
    public void setLoanGeogCurrentThird(Object loanGeogCurrentThird) {
        this.loanGeogCurrentThird = loanGeogCurrentThird;
    }

    @JsonProperty("LoanGeogCurrentThirdEar")
    public Object getLoanGeogCurrentThirdEar() {
        return loanGeogCurrentThirdEar;
    }

    @JsonProperty("LoanGeogCurrentThirdEar")
    public void setLoanGeogCurrentThirdEar(Object loanGeogCurrentThirdEar) {
        this.loanGeogCurrentThirdEar = loanGeogCurrentThirdEar;
    }

    @JsonProperty("LoanGeogCurrentFourth")
    public Object getLoanGeogCurrentFourth() {
        return loanGeogCurrentFourth;
    }

    @JsonProperty("LoanGeogCurrentFourth")
    public void setLoanGeogCurrentFourth(Object loanGeogCurrentFourth) {
        this.loanGeogCurrentFourth = loanGeogCurrentFourth;
    }

    @JsonProperty("LoanGeogCurrentFourthEar")
    public Object getLoanGeogCurrentFourthEar() {
        return loanGeogCurrentFourthEar;
    }

    @JsonProperty("LoanGeogCurrentFourthEar")
    public void setLoanGeogCurrentFourthEar(Object loanGeogCurrentFourthEar) {
        this.loanGeogCurrentFourthEar = loanGeogCurrentFourthEar;
    }

    @JsonProperty("LoanGeogCurrentFifth")
    public Object getLoanGeogCurrentFifth() {
        return loanGeogCurrentFifth;
    }

    @JsonProperty("LoanGeogCurrentFifth")
    public void setLoanGeogCurrentFifth(Object loanGeogCurrentFifth) {
        this.loanGeogCurrentFifth = loanGeogCurrentFifth;
    }

    @JsonProperty("LoanGeogCurrentFifthEar")
    public Object getLoanGeogCurrentFifthEar() {
        return loanGeogCurrentFifthEar;
    }

    @JsonProperty("LoanGeogCurrentFifthEar")
    public void setLoanGeogCurrentFifthEar(Object loanGeogCurrentFifthEar) {
        this.loanGeogCurrentFifthEar = loanGeogCurrentFifthEar;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("loanGeogCurrentFirst", loanGeogCurrentFirst).append("loanGeogCurrentFirstEar", loanGeogCurrentFirstEar).append("loanGeogCurrentSecond", loanGeogCurrentSecond).append("loanGeogCurrentSecondEar", loanGeogCurrentSecondEar).append("loanGeogCurrentThird", loanGeogCurrentThird).append("loanGeogCurrentThirdEar", loanGeogCurrentThirdEar).append("loanGeogCurrentFourth", loanGeogCurrentFourth).append("loanGeogCurrentFourthEar", loanGeogCurrentFourthEar).append("loanGeogCurrentFifth", loanGeogCurrentFifth).append("loanGeogCurrentFifthEar", loanGeogCurrentFifthEar).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(loanGeogCurrentFirstEar).append(loanGeogCurrentSecond).append(loanGeogCurrentSecondEar).append(loanGeogCurrentFifth).append(loanGeogCurrentFourth).append(loanGeogCurrentThirdEar).append(loanGeogCurrentFifthEar).append(loanGeogCurrentFirst).append(additionalProperties).append(loanGeogCurrentFourthEar).append(loanGeogCurrentThird).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof GeographicDistribution) == false) {
            return false;
        }
        GeographicDistribution rhs = ((GeographicDistribution) other);
        return new EqualsBuilder().append(loanGeogCurrentFirstEar, rhs.loanGeogCurrentFirstEar).append(loanGeogCurrentSecond, rhs.loanGeogCurrentSecond).append(loanGeogCurrentSecondEar, rhs.loanGeogCurrentSecondEar).append(loanGeogCurrentFifth, rhs.loanGeogCurrentFifth).append(loanGeogCurrentFourth, rhs.loanGeogCurrentFourth).append(loanGeogCurrentThirdEar, rhs.loanGeogCurrentThirdEar).append(loanGeogCurrentFifthEar, rhs.loanGeogCurrentFifthEar).append(loanGeogCurrentFirst, rhs.loanGeogCurrentFirst).append(additionalProperties, rhs.additionalProperties).append(loanGeogCurrentFourthEar, rhs.loanGeogCurrentFourthEar).append(loanGeogCurrentThird, rhs.loanGeogCurrentThird).isEquals();
    }

}
