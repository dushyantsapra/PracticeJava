package com.nwm.xmart.streaming.example;

import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by gardlex on 05/12/2017.
 */
public class OdcUIDCounterSink extends RichSinkFunction<DataFabricStreamEvent<BDXSinkData>> {

    private static Logger logger = LoggerFactory.getLogger(OdcUIDCounterSink.class);
    private boolean scheduledStats;
    private ScheduledExecutorService scheduledExecutorService;
    private final ConcurrentMap<String,Integer> odcUIDCount = new ConcurrentHashMap<>();


    @Override
    public void invoke(DataFabricStreamEvent<BDXSinkData> value) throws Exception {
        BDXSinkData bdxSinkData = value.getEventPayload();
        String uid = bdxSinkData.getSourceSystemId() + "-" + bdxSinkData.getSourceSystemTransactionId() + "-" + bdxSinkData.getVersion();
        Integer count = odcUIDCount.get(uid);
        if (count == null) {
            count = Integer.valueOf(1);
        } else {
            count = Integer.valueOf(count.intValue() + 1);
        }
        odcUIDCount.put(uid, count);
    }

    private void checkScheduledStats() {
        if (!scheduledStats) {
            try {
                // Create the thread
                logger.info("About to schedule  InactivityMonitor");
                scheduledExecutorService = Executors.newSingleThreadScheduledExecutor(
                        new ThreadFactory() {
                            @Override
                            public Thread newThread(Runnable r) {
                                Thread t = new Thread(r);

                                t.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                                    @Override
                                    public void uncaughtException(Thread t, Throwable e) {
                                        logger.info("Exception Occurred in Runnable");
                                    }
                                });

                                return t;

                            }
                        }
                );

                scheduledExecutorService.scheduleAtFixedRate(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            logger.info("SIZE = " + odcUIDCount.keySet().size());
                            final AtomicInteger duplicates = new AtomicInteger(0);
                            odcUIDCount.values()
                                    .stream()
                                    .forEach(i -> {
                                        if ( i > 1) {
                                            duplicates.incrementAndGet();
                                        }
                                    });
                            logger.info("DUPLICATES = " + duplicates.intValue());
                        } catch (Exception e) {
                            logger.error("Error occurred updating the inactivityMonitor", e);
                            throw new RuntimeException("Error occurred updating the inactivityMonitor");
                        }
                    }
                }, 0, 30, TimeUnit.SECONDS);

            } catch (Exception e) {
                logger.error("Could not start inactivity monitor thread", e);
                throw new RuntimeException("Could not start inactivity monitor thread");
            }
            scheduledStats = true;
        }
    }
}
