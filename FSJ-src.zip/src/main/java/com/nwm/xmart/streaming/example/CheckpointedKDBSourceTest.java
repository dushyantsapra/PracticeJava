package com.nwm.xmart.streaming.example;

import com.nwm.xmart.sso.EncryptDecryptAES;
import com.nwm.xmart.streaming.source.kdb.KDBSource;
import com.nwm.xmart.streaming.source.kdb.event.KDBSourceEvent;
import com.nwm.xmart.streaming.source.kdb.parameters.BdxKdbFunctionDetails;
import com.nwm.xmart.streaming.source.kdb.sorting.KDBFunctionType;
import com.nwm.xmart.streaming.source.mdx.session.MDXSessionType;
import com.rbs.datafabric.client.DataFabricClient;
import com.rbs.datafabric.client.DataFabricClientFactory;
import com.rbs.datafabric.domain.ClientConfiguration;
import com.rbs.datafabric.domain.Credentials;
import com.rbs.datafabric.domain.Document;
import com.rbs.datafabric.domain.DocumentFormat;
import com.rbs.datafabric.domain.client.builder.InsertRequestBuilder;
import com.nwm.xmart.streaming.common.job.StreamJob;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Created by gardlex on 18/10/2017.
 */
public class CheckpointedKDBSourceTest {

    private static Logger logger = LoggerFactory.getLogger(CheckpointedMDXSourceTest.class);

    public static void main(String[] args) throws Exception {

        // Populate cache with 10 stream events
        CheckpointedKDBSourceTest t = new CheckpointedKDBSourceTest();
        t.buildStream(args);

    }

    public void buildStream(String[] args) throws Exception {
        // StreamJob implementation can override any abstract methid as long as it calls super() first
        KDBStreamJob streamJob = new KDBStreamJob();
        streamJob.run(args);
    }

    class KDBStreamJob extends StreamJob {

        @Override
        protected void configureAndExecuteStream(StreamExecutionEnvironment env) {

            try {
            // Type info reqd for the FlinkDeserializer
            final TypeInformation<KDBSourceEvent> mdxSourceEventType = TypeInformation.of(new TypeHint<KDBSourceEvent>(){});
            Class<KDBSourceEvent> mdxSourceClassRef = mdxSourceEventType.getTypeClass();
//            DataStream<KDBSourceEvent> stream1 = configureSrc1(env, parameters, mdxSourceClassRef, mdxSourceEventType);
//            DataStream<KDBSourceEvent> stream2 = configureSrc2(env, parameters, mdxSourceClassRef, mdxSourceEventType);
//            DataStream<KDBSourceEvent> stream3 = configureSrc3(env, parameters, mdxSourceClassRef, mdxSourceEventType);
//            DataStream<KDBSourceEvent> stream4 = configureSrc4(env, parameters, mdxSourceClassRef, mdxSourceEventType);
//            DataStream<KDBSourceEvent> stream5 = configureSrc5(env, parameters, mdxSourceClassRef, mdxSourceEventType);
//            DataStream<KDBSourceEvent> stream6 = configureSrc6(env, parameters, mdxSourceClassRef, mdxSourceEventType);
//            DataStream<KDBSourceEvent> stream7 = configureSrc7(env, parameters, mdxSourceClassRef, mdxSourceEventType);
            DataStream<KDBSourceEvent> streamFI = configureFISource(env, parameters, mdxSourceClassRef, mdxSourceEventType);

//            DataStream<KDBSourceEvent> joinedMdxStream = stream1.union(stream2, stream3, stream7);
                streamFI.addSink(new TestSink())

//                InterruptSourceFunction interruptSrc = new InterruptSourceFunction();
//                DataStream<KDBSourceEvent> interruptStream = env.addSource(interruptSrc);
//            interruptStream.addSink(new TestSink())

//                stream1.addSink(new TestSink())
                    .uid("KDB-TestSink")
                    .name("KDB-TestSink")
                    .setParallelism(3);
            env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);


                String execPlan = env.getExecutionPlan();
                logger.info("EXECUTION PLAN = " + execPlan);
                env.execute(configuration.getString("flink.job.name",""));
            } catch (Exception e) {
                logger.error("Exception running the CheckpointedKDBSourceTest",e);
                throw new RuntimeException(e);
            }
        }
    }

    private DataStream<KDBSourceEvent> configureFISource(StreamExecutionEnvironment env, ParameterTool parameters, Class<KDBSourceEvent> mdxSourceClassRef, TypeInformation<KDBSourceEvent> kdbSourceEventType) {

        ConcurrentMap<String,String> functionParameters = new ConcurrentHashMap<>();
        functionParameters.put(parameters.get("kdb.src1.parameter.startDate.key"),parameters.get("kdb.src1.parameter.startDate.value"));
        functionParameters.put(parameters.get("kdb.src1.parameter.endDate.key"),parameters.get("kdb.src1.parameter.endDate.value"));

        ConcurrentMap<String,String> functionParameters2 = new ConcurrentHashMap<>();
        functionParameters2.put(parameters.get("kdb.src2.parameter.startDate.key"),parameters.get("kdb.src2.parameter.startDate.value"));
        functionParameters2.put(parameters.get("kdb.src2.parameter.endDate.key"),parameters.get("kdb.src2.parameter.endDate.value"));

        BdxKdbFunctionDetails fiMifidRfqDetails = new BdxKdbFunctionDetails(
                parameters.get("kdb.src1.sourceID"),
                parameters.get("kdb.src1.kdbFunctionName"),
                parameters.get("kdb.src1.sourceName"),
                KDBFunctionType.FI_MIFID_RFQ,
                MDXSessionType.SSO,
                functionParameters,
                parameters.get("kdb.src1.mdxEnvironmentName"),
                parameters.get("kdb.src1.kdbEnvironmentName"),
                parameters.get("kdb.src1.tableName.value"));

        BdxKdbFunctionDetails fiMifidQecDetails = new BdxKdbFunctionDetails(
                parameters.get("kdb.src2.sourceID"),
                parameters.get("kdb.src2.kdbFunctionName"),
                parameters.get("kdb.src2.sourceName"),
                KDBFunctionType.FI_MIFID_QEC,
                MDXSessionType.SSO,
                functionParameters2,
                parameters.get("kdb.src2.mdxEnvironmentName"),
                parameters.get("kdb.src2.kdbEnvironmentName"),
                parameters.get("kdb.src2.tableName.value"));


        List<BdxKdbFunctionDetails> list = new ArrayList<BdxKdbFunctionDetails>();
        list.add(fiMifidRfqDetails);
        list.add(fiMifidQecDetails);

        SourceFunction<KDBSourceEvent> src1 =  new KDBSource(parameters, list);
        DataStream<KDBSourceEvent> dateStream = env.addSource(src1, kdbSourceEventType)
                .uid("FI_RFQ_QECSRC_UID")
                .name("FI_RFQ_QEC_SRC_NAME")
                .setParallelism(1);

        return dateStream;
    }

//    private DataStream<KDBSourceEvent> configureSrc1(StreamExecutionEnvironment env, ParameterTool parameters, Class<KDBSourceEvent> mdxSourceClassRef, TypeInformation<KDBSourceEvent> kdbSourceEventType) {
//        Map<String,String> functionParameters = new HashMap<>();
//        functionParameters.put(parameters.get("kdb.src1.parameter.startDate.key"),parameters.get("kdb.src1.parameter.startDate.value"));
//        functionParameters.put(parameters.get("kdb.src1.parameter.endDate.key"),parameters.get("kdb.src1.parameter.endDate.value"));
//
//        SourceFunction<KDBSourceEvent> src1 =  new KDBSource(
//                parameters.get("kdb.src1.sourceID"),
//                parameters.get("kdb.src1.kdbFunctionName"),
//                parameters.get("kdb.src1.sourceName"),
//                KDBFunctionType.FI_MIFID_RFQ,
//                MDXSessionType.SSO,
//                functionParameters,
//                parameters.get("kdb.src1.mdxEnvironmentName"),
//                parameters.get("kdb.src1.kdbEnvironmentName"));
//        DataStream<KDBSourceEvent> dateStream = env.addSource(src1, kdbSourceEventType)
//                .uid("FImifidRFQ_SRC_UID")
//                .name("FImifidRFQ_SRC_NAME")
//                .setParallelism(1);
//
//        return dateStream;
//    }
//
//    private DataStream<KDBSourceEvent> configureSrc2(StreamExecutionEnvironment env, ParameterTool parameters, Class<KDBSourceEvent> mdxSourceClassRef, TypeInformation<KDBSourceEvent> kdbSourceEventType) {
//        Map<String,String> functionParameters = new HashMap<>();
//        functionParameters.put(parameters.get("kdb.src2.parameter.startDate.key"),parameters.get("kdb.src2.parameter.startDate.value"));
//        functionParameters.put(parameters.get("kdb.src2.parameter.endDate.key"),parameters.get("kdb.src2.parameter.endDate.value"));
//
//        SourceFunction<KDBSourceEvent> src2 =  new KDBSource(
//                parameters.get("kdb.src2.sourceID"),
//                parameters.get("kdb.src2.kdbFunctionName"),
//                parameters.get("kdb.src2.sourceName"),
//                KDBFunctionType.FI_MIFID_QEC,
//                MDXSessionType.SSO,
//                functionParameters,
//                parameters.get("kdb.src2.mdxEnvironmentName"),
//                parameters.get("kdb.src2.kdbEnvironmentName"));
//        DataStream<KDBSourceEvent> dateStream = env.addSource(src2, kdbSourceEventType)
//                .uid("FImifidQEC_SRC_UID")
//                .name("FImifidQEC_SRC_NAME")
//                .setParallelism(1);
//
//        return dateStream;
//    }
//
//    private DataStream<KDBSourceEvent> configureSrc3(StreamExecutionEnvironment env, ParameterTool parameters, Class<KDBSourceEvent> mdxSourceClassRef, TypeInformation<KDBSourceEvent> kdbSourceEventType) {
//        Map<String,String> functionParameters = new HashMap<>();
//        functionParameters.put(parameters.get("kdb.src3.parameter.startDate.key"),parameters.get("kdb.src3.parameter.startDate.value"));
//        functionParameters.put(parameters.get("kdb.src3.parameter.endDate.key"),parameters.get("kdb.src3.parameter.endDate.value"));
//
//        SourceFunction<KDBSourceEvent> src3 =  new KDBSource(
//                parameters.get("kdb.src3.sourceID"),
//                parameters.get("kdb.src3.kdbFunctionName"),
//                parameters.get("kdb.src3.sourceName"),
//                KDBFunctionType.FX_MIFID_OMS,
//                MDXSessionType.SSO,
//                functionParameters,
//                parameters.get("kdb.src3.mdxEnvironmentName"),
//                parameters.get("kdb.src3.kdbEnvironmentName"));
//        DataStream<KDBSourceEvent> dateStream = env.addSource(src3, kdbSourceEventType)
//                .uid("FXmifidOMS_SRC_UID")
//                .name("FXmifidOMS_SRC_NAME")
//                .setParallelism(1);
//
//        return dateStream;
//    }
//
//    private DataStream<KDBSourceEvent> configureSrc4(StreamExecutionEnvironment env, ParameterTool parameters, Class<KDBSourceEvent> mdxSourceClassRef, TypeInformation<KDBSourceEvent> kdbSourceEventType) {
//        Map<String,String> functionParameters = new HashMap<>();
//        functionParameters.put(parameters.get("kdb.src4.parameter.startDate.key"),parameters.get("kdb.src4.parameter.startDate.value"));
//        functionParameters.put(parameters.get("kdb.src4.parameter.endDate.key"),parameters.get("kdb.src4.parameter.endDate.value"));
//
//        SourceFunction<KDBSourceEvent> src4 =  new KDBSource(
//                parameters.get("kdb.src4.sourceID"),
//                parameters.get("kdb.src4.kdbFunctionName"),
//                parameters.get("kdb.src4.sourceName"),
//                KDBFunctionType.FX_MIFID_RFQ,
//                MDXSessionType.SSO,
//                functionParameters,
//                parameters.get("kdb.src4.mdxEnvironmentName"),
//                parameters.get("kdb.src4.kdbEnvironmentName"));
//        DataStream<KDBSourceEvent> dateStream = env.addSource(src4, kdbSourceEventType)
//                .uid("FXmifidRFQ_SRC_UID")
//                .name("FXmifidRFQ_SRC_UID")
//                .setParallelism(1);
//
//        return dateStream;
//    }
//
//    private DataStream<KDBSourceEvent> configureSrc5(StreamExecutionEnvironment env, ParameterTool parameters, Class<KDBSourceEvent> mdxSourceClassRef, TypeInformation<KDBSourceEvent> kdbSourceEventType) {
//        Map<String,String> functionParameters = new HashMap<>();
//        functionParameters.put(parameters.get("kdb.src5.parameter.startDate.key"),parameters.get("kdb.src5.parameter.startDate.value"));
//        functionParameters.put(parameters.get("kdb.src5.parameter.endDate.key"),parameters.get("kdb.src5.parameter.endDate.value"));
//
//        SourceFunction<KDBSourceEvent> src5 =  new KDBSource(
//                parameters.get("kdb.src5.sourceID"),
//                parameters.get("kdb.src5.kdbFunctionName"),
//                parameters.get("kdb.src5.sourceName"),
//                KDBFunctionType.FX_MIFID_TRADE,
//                MDXSessionType.SSO,
//                functionParameters,
//                parameters.get("kdb.src5.mdxEnvironmentName"),
//                parameters.get("kdb.src5.kdbEnvironmentName"));
//        DataStream<KDBSourceEvent> dateStream = env.addSource(src5, kdbSourceEventType)
//                .uid("FXmifidTrade_SRC_UID")
//                .name("FXmifidTrade_SRC_UID")
//                .setParallelism(1);
//
//        return dateStream;
//    }
//
//    private DataStream<KDBSourceEvent> configureSrc6(StreamExecutionEnvironment env, ParameterTool parameters, Class<KDBSourceEvent> mdxSourceClassRef, TypeInformation<KDBSourceEvent> kdbSourceEventType) {
//        Map<String,String> functionParameters = new HashMap<>();
//        functionParameters.put(parameters.get("kdb.src6.parameter.startDate.key"),parameters.get("kdb.src6.parameter.startDate.value"));
//        functionParameters.put(parameters.get("kdb.src6.parameter.endDate.key"),parameters.get("kdb.src6.parameter.endDate.value"));
//
//        SourceFunction<KDBSourceEvent> src6 =  new KDBSource(
//                parameters.get("kdb.src6.sourceID"),
//                parameters.get("kdb.src6.kdbFunctionName"),
//                parameters.get("kdb.src6.sourceName"),
//                KDBFunctionType.FX_MIFID_TRADE_ISIN,
//                MDXSessionType.SSO,
//                functionParameters,
//                parameters.get("kdb.src6.mdxEnvironmentName"),
//                parameters.get("kdb.src6.kdbEnvironmentName"));
//        DataStream<KDBSourceEvent> dateStream = env.addSource(src6, kdbSourceEventType)
//                .uid("FXmifidTradeIsin_SRC_UID")
//                .name("FXmifidTradeIsin_SRC_UID")
//                .setParallelism(1);
//
//        return dateStream;
//    }
//
//    private DataStream<KDBSourceEvent> configureSrc7(StreamExecutionEnvironment env, ParameterTool parameters, Class<KDBSourceEvent> mdxSourceClassRef, TypeInformation<KDBSourceEvent> kdbSourceEventType) {
//        Map<String,String> functionParameters = new HashMap<>();
//        functionParameters.put(parameters.get("kdb.src7.parameter.startDate.key"),parameters.get("kdb.src7.parameter.startDate.value"));
//        functionParameters.put(parameters.get("kdb.src7.parameter.endDate.key"),parameters.get("kdb.src7.parameter.endDate.value"));
//
//        SourceFunction<KDBSourceEvent> src7 =  new KDBSource(
//                parameters.get("kdb.src7.sourceID"),
//                parameters.get("kdb.src7.kdbFunctionName"),
//                parameters.get("kdb.src7.sourceName"),
//                KDBFunctionType.FX_MIFID_TRADE_ELIGIBILITY,
//                MDXSessionType.SSO,
//                functionParameters,
//                parameters.get("kdb.src7.mdxEnvironmentName"),
//                parameters.get("kdb.src7.kdbEnvironmentName"));
//        DataStream<KDBSourceEvent> dateStream = env.addSource(src7, kdbSourceEventType)
//                .uid("FXmifidTradeEligibility_SRC_UID")
//                .name("FXmifidTradeEligibility_SRC_UID")
//                .setParallelism(1);
//
//        return dateStream;
//    }

    class TestSink extends RichSinkFunction<KDBSourceEvent> implements CheckpointListener {

        private Logger logger = LoggerFactory.getLogger(TestSink.class);
        private DataFabricClient dataFabricClient;

        private int ctr;

        public TestSink() throws IOException {
        }

        @Override
        public void notifyCheckpointComplete(long checkpointId) throws Exception {
            logger.info("TestSINK Checkpoint RECD = " + checkpointId);
        }

        @Override
        public void invoke(KDBSourceEvent event) throws Exception {
//            Object[] data = event.getRecordData();
//            data[15] = null;
//            data[16] = null;
//            data[22] = null;
//            data[28] = null;
//            data[31] = null;
//            data[32] = null;
//            data[33] = null;
//            data[34] = null;
//            data[35] = null;
            Document document = dataFabricClient.getDataFabricSerializer()
                    .withDocumentFormat(DocumentFormat.BSON)
                    .serialize(event);
            dataFabricClient.insert(InsertRequestBuilder.create("session-db", "session-kdb-enquiry-2").withDocument(document));
        }

        @Override
        public void open(Configuration parameters) throws Exception {
            dataFabricClient = getDFC();
        }

        private DataFabricClient getDFC() throws Exception {
            // TST
            ClientConfiguration clientConfiguration = new ClientConfiguration().withCredentials(new Credentials().withUsername("svc-XMartAppUat")
                    .withPassword(EncryptDecryptAES.decrypt("Gl6c8x+8lGbkwF0HWPDRSg==")))
                    .withHost("DATAFABRIC-TST")
                    .withAccessToken(EncryptDecryptAES.decrypt("9k1IyB07YGjc1r5rQf1MgrdZH6XNdr1WT0UEWLz1XmVX7tupKZdtPA2t/iljneNe"));
            // DEV
//        ClientConfiguration clientConfiguration = new ClientConfiguration().withCredentials(new Credentials().withUsername("svc-XMartAppDev")
//                .withPassword(EncryptDecryptAES.decrypt("FH+VI380zghSFhzIcvbC9A=="))
//                .withHost("datafabric-dev")
//                .withAccessToken(EncryptDecryptAES.decrypt("9k1IyB07YGjc1r5rQf1MgrdZH6XNdr1WT0UEWLz1XmVX7tupKZdtPA2t/iljneNe"));

            DataFabricClient dataFabricClient = DataFabricClientFactory.createDataFabricClient(clientConfiguration);
            return dataFabricClient;
        }
    }

}
