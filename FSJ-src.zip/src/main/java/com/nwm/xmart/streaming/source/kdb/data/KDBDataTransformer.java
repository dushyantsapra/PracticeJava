package com.nwm.xmart.streaming.source.kdb.data;

import com.nwm.xmart.streaming.source.kdb.event.KDBSourceEvent;
import com.nwm.xmart.streaming.source.kdb.sorting.KDBFunctionType;
import com.nwm.xmart.streaming.source.kdb.sorting.KDBSortKeyBuilder;
import com.nwm.xmart.streaming.source.kdb.sorting.SortKeyI;
import com.nwm.xmart.streaming.source.kdb.event.KDBSourceEventBuilder;
import com.nwm.xmart.streaming.source.kdb.exception.KDBMatrixDataParsingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.mdx.utils.analytics.IAnalyticResult;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Converts a KDB result set that contains arrays of column names and result data into a sorted 2D array of records.
 *
 * Author: Alex Gardner
 */

public class KDBDataTransformer {

    private static Logger logger = LoggerFactory.getLogger(KDBDataTransformer.class);

    private final KDBFunctionType kdbFunctionType;
    private final KDBSortKeyBuilder kdbSortKeyBuilder;

    public KDBDataTransformer(KDBFunctionType kdbFunctionType,
                              KDBSortKeyBuilder kdbSortKeyBuilder) {
        this.kdbFunctionType = kdbFunctionType;
        this.kdbSortKeyBuilder = kdbSortKeyBuilder;
    }

    public List<KDBSourceEvent> convertTo2DArraySourceEvents(String sourceID, String functionName, String tableName, String day, IAnalyticResult resultData) {
        List<KDBSourceEvent> sourceEventList = new ArrayList<>();
        KDBSourceEventBuilder sourceEventBuilder
                = new KDBSourceEventBuilder(sourceID,
                                            functionName,
                                            tableName,
                                            resultData.getSuccess(),
                                            resultData.getMessage(),
                                            resultData.getTag(),
                                            resultData.getColumnNames(),
                                            kdbFunctionType);

        String[] columnNames = resultData.getColumnNames();
        int noOfCcolumns = getNoOfColumnsFromResult(resultData);
        int noOfRecords = getNoOfRecordsFromResult(resultData);
        Object[] matrixData = resultData.getData();
        KDBSourceEvent kdbSourceEvent;

        logger.info("Retrieved {} records from query {} / date {} / cols {}", noOfRecords, functionName, day, Arrays.toString(columnNames));

        for (int horizontalRowIndex = 0; horizontalRowIndex < noOfRecords; horizontalRowIndex++) {

            Object[] eventRecordData = new Object[noOfCcolumns];
            SortKeyI sortKey = kdbSortKeyBuilder.createSortKeyForType(kdbFunctionType, columnNames);

            for (int verticalRowIndex = 0; verticalRowIndex < noOfCcolumns; verticalRowIndex++) {
                Object verticalColumnRow = matrixData[verticalRowIndex];

                if(verticalColumnRow == null){
                    throw new KDBMatrixDataParsingException("Missing vertical column data for columnID [ " + verticalRowIndex + " ], ColumnName [ " + columnNames[verticalRowIndex] + " ]");
                }

                Object value = getValueForVerticalIndex(verticalColumnRow, horizontalRowIndex);
                if (sortKey.isSortKeyIndex(verticalRowIndex)) {
                    sortKey.setSortKeyColumnValue(value, verticalRowIndex);
                }

                eventRecordData[verticalRowIndex] = value;
            }
            kdbSourceEvent = sourceEventBuilder
                    .withRecordIndex(horizontalRowIndex)
                    .withSortKey(sortKey)
                    .withRecordData(eventRecordData)
                    .withDateTime(sortKey.toString())
                    .build();
            sourceEventList.add(kdbSourceEvent);
        }

        return sourceEventList;
    }

    private Object getValueForVerticalIndex(Object horizontalColumnRow, int horizontalRowIndex) {
        try {
            // if IS NOT a primitive array then just cast to Object
            if (!horizontalColumnRow.getClass().getComponentType().isPrimitive()) {
                Object value = ((Object[]) horizontalColumnRow)[horizontalRowIndex];
                if (value instanceof char[]) {
                    return new String((char[])value);
                }
                return value;
            }

            // If IT IS a primitive array then return as Wrapper based primitive
            Object primitiveWrapperValue = Array.get(horizontalColumnRow, horizontalRowIndex);
            if (primitiveWrapperValue instanceof Double && ((Double)primitiveWrapperValue).isNaN()) {
                return null;
            }
            if (primitiveWrapperValue instanceof Float && ((Float)primitiveWrapperValue).isNaN()) {
                return null;
            }

            return primitiveWrapperValue;
        } catch (IllegalArgumentException e) {
            throw new KDBMatrixDataParsingException("Illegal argument found whilst extracting a column value", e);
        } catch (ArrayIndexOutOfBoundsException a) {
            throw new KDBMatrixDataParsingException("Invalid index specified whilst extracting a column value", a);
        }
    }

    private int getNoOfColumnsFromResult(IAnalyticResult resultData) {
        return resultData.getColumnNames().length;
    }

    private int getNoOfRecordsFromResult(IAnalyticResult resultData) {
        return ((Object[])resultData.getData()[0]).length;
    }
}
