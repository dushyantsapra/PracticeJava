package com.nwm.xmart.streaming.database.statements.kdb;

import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;
import com.nwm.xmart.streaming.database.statements.StatementParameters;
import com.nwm.xmart.streaming.database.statements.XmartStatement;

import java.sql.SQLException;

public class KdbLastRunReadStatement extends XmartStatement {

    public KdbLastRunReadStatement() {
        super();

        statementName = "fn_GetProcessState";
        PROC_COMMAND = "SELECT Isnull(convert(varchar(max), fwk.fn_GetProcessState(?)), '') as results";
    }

    @Override
    public SQLServerCallableStatement getPreparedStatement(Object obj) throws SQLException {

        preparedStatement.clearParameters();
        SQLServerCallableStatement sqlServerCallableStatement = (SQLServerCallableStatement) preparedStatement;

        StatementParameters statementParameters = (StatementParameters) obj;

        int index = 1;

        sqlServerCallableStatement.setObject(index++, "kdb-function-" + statementParameters.get("functionName"));

        sqlServerCallableStatement.addBatch();
        return sqlServerCallableStatement;
    }
}
