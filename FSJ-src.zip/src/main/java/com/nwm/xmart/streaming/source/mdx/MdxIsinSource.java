package com.nwm.xmart.streaming.source.mdx;

import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.streaming.source.mdx.subscription.MdxSubscription;
import com.nwm.xmart.streaming.source.mdx.cache.MDXIsinCache;
import com.nwm.xmart.streaming.source.mdx.cache.load.CacheItem;
import com.nwm.xmart.streaming.source.mdx.cache.load.ISINCacheLoader;
import com.nwm.xmart.streaming.source.mdx.cache.load.MDXIsinCacheItem;
import com.nwm.xmart.streaming.source.mdx.cache.load.XmartISINCacheLoader;
import com.nwm.xmart.streaming.source.mdx.event.MdxEventType;
import com.nwm.xmart.streaming.source.mdx.event.ProcessingType;
import com.nwm.xmart.streaming.source.mdx.pull.MdxReader;
import com.nwm.xmart.streaming.source.mdx.pull.MdxPullRequestDocumentLoader;
import com.nwm.xmart.streaming.source.mdx.session.MDXSessionType;
import com.nwm.xmart.streaming.source.mdx.session.MdxSessionContext;
import com.nwm.xmart.streaming.source.mdx.util.MDXUtil;
import com.nwm.xmart.streaming.source.mdx.subscription.MdxRealTimeEventExchange;
import com.nwm.xmart.util.MDCUtil;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.state.OperatorStateStore;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.typeutils.TupleTypeInfo;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import rbs.gbm.mdx.webService.interfaces.MdxException;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Subscribes to the MDX API
 *
 * Created by gardlex on 22/03/2018.
 */

public class MdxIsinSource<MdxSourceEvent> extends RichParallelSourceFunction<MdxSourceEvent> implements CheckpointedFunction, CheckpointListener {

    private static Logger logger = LoggerFactory.getLogger(MdxIsinSource.class);
    private MdxSubscription<MdxSourceEvent> mdxSubscription;
    private volatile boolean isInitialLoadRunning;
    private volatile boolean isSubscriptionRunning;
    private volatile boolean isRestored;
    private final Class<MdxSourceEvent> sourceEventClass;
    private transient ListState<Tuple3<String, Integer, Long>> isinListState;
    private MdxReader mdxReader;
    private volatile long lastEpochDocumentWriteTime = -1;
    private final IntCounter numInitialLoadSourceMdxEvents = new IntCounter();
    private final IntCounter numSubscriptionSourceMdxEvents = new IntCounter();
    private final IntCounter numInvalidMdxDocumentsFound = new IntCounter();
    private final String mdxInitialLoadIdentifier;
    private final String mdxInitialLoadIdentifierWildcard;
    private final String mdxSubscriptionIdentifier;
    private final String mdxSubscriptionIdentifierWildcard;
    private final String mdxSourceName;
    private final MdxEventType mdxEventType;
    private final MDXUtil<MdxSourceEvent> mdxUtil;
    private volatile String listStateDescriptorName;
    private final AtomicReference<MdxSessionContext> initialLoadMdxSessionContext = new AtomicReference<>();
    private final AtomicReference<MdxSessionContext> subscriptionMdxSessionContext = new AtomicReference<>();
    private final MDXSessionType mdxSessionType;
    private final AtomicReference<MdxPullRequestDocumentLoader<MdxSourceEvent>> mdxDocumentLoader = new AtomicReference<>();
    private final AtomicReference<MDXIsinCache> isinCacheRef = new AtomicReference<>();
    private final ConcurrentMap<CacheItem, String> restoredCacheItems = new ConcurrentHashMap<>();
    private final String isinDatastoreQuery;
    private final String sourceID;
    private final AtomicLong currentJobEventIDCounter = new AtomicLong();
    private volatile ISINCacheLoader isinCacheLoader;
    private volatile MDXIsinCache isinCache;

    public MdxIsinSource(String sourceID,
                     Class<MdxSourceEvent> sourceEventClass,
                     String mdxInitialLoadIdentifier,
                     String mdxInitialLoadIdentifierWildcard,
                     String mdxSubscriptionIdentifier,
                     String mdxSubscriptionIdentifierWildcard,
                     String mdxSourceName,
                     MdxEventType mdxEventType,
                     MDXSessionType mdxSessionType,
                     String isinDatastoreQuery) {
        this.sourceID = sourceID;
        this.sourceEventClass = sourceEventClass;
        this.mdxInitialLoadIdentifier = mdxInitialLoadIdentifier;
        this.mdxInitialLoadIdentifierWildcard = mdxInitialLoadIdentifierWildcard;
        this.mdxSubscriptionIdentifier = mdxSubscriptionIdentifier;
        this.mdxSubscriptionIdentifierWildcard = mdxSubscriptionIdentifierWildcard;
        this.mdxSourceName = mdxSourceName;
        this.mdxEventType = mdxEventType;
        this.mdxUtil = new MDXUtil<>(sourceEventClass);
        this.mdxSessionType = mdxSessionType;
        this.isinDatastoreQuery = isinDatastoreQuery;

    }

    @Override
    public void run(SourceContext<MdxSourceEvent> ctx) throws Exception {
        //MDC for logging
        ParameterTool parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        MDCUtil.putJobNameInMDC(parameters);

        // Load the documents first
        MdxPullRequestDocumentLoader<MdxSourceEvent> loader =  mdxDocumentLoader.get();
        loader.setSourceContext(ctx);
        loader.loadDocuments();

        // now process any cached subscription based events first and then continually process the events in real time
        isSubscriptionRunning = true;
        MdxSourceEvent mdxSourceEvent = null;
        MdxDocumentEvent mdxDocumentEvent = null;
        MDXIsinCacheItem mdxIsinCacheItem;
        ReentrantLock subscriptionLock = mdxSubscription.getSubscriptionLock();
        final Object checkpointLock = ctx.getCheckpointLock();
        final MDXIsinCache isinCache = isinCacheRef.get();

        // Start the ISIN cache refresh cycle
        isinCache.startPeriodicRefreshLoad();

        // Start consuming the subscription events
        while (isSubscriptionRunning) {
            mdxSourceEvent = mdxSubscription.getMdxNextEvent();

            subscriptionLock.lock();
            try {
                synchronized (checkpointLock) {
                    mdxDocumentEvent = (MdxDocumentEvent) mdxSourceEvent;
                    mdxIsinCacheItem = new MDXIsinCacheItem(
                            mdxDocumentEvent.getIdentifier(),
                            mdxDocumentEvent.getVersion(),
                            mdxDocumentEvent.getEpochMdxDataStoreWriteTime());
                    if (isinCache.putISINCacheItem(mdxIsinCacheItem)) {
                        ctx.collect(mdxSourceEvent);
                        this.numSubscriptionSourceMdxEvents.add(1);
                    }
                }

            } finally {
                subscriptionLock.unlock();
            }
        }
    }

    @Override
    public void cancel() {
        isInitialLoadRunning = false;
        isSubscriptionRunning = false;
        mdxSubscription.close();
        try {
            mdxReader.close();
        } catch (MdxException e) {
            logger.warn("Error when closing mdxReader", e);
        }
        isinCacheLoader.close();
        isinCacheRef.get().close();
    }

    @Override
    @SuppressWarnings("unchecked")
    public void open(Configuration configuration) throws Exception {

        ParameterTool params = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        // MDC logging
        String mdcJobNameKey =  params.get("nwm.job.param","jobName");
        String jobName = params.get("flink.job.name", "No Job Name Specific");
        MDC.put(mdcJobNameKey,jobName);

        // For testing purposes initialLoad can be switched off
        isInitialLoadRunning = params.getBoolean("mdx.enable.initialLoad");

        initialLoadMdxSessionContext.set(mdxUtil.getMdxSessionContextFor(params, mdxEventType, ProcessingType.LOAD, mdxSessionType));
        subscriptionMdxSessionContext.set(mdxUtil.getMdxSessionContextFor(params, mdxEventType, ProcessingType.SUBSCRIPTION, mdxSessionType));

        // Create the subscription service
        MdxRealTimeEventExchange<MdxSourceEvent>
                mdxSubscriptionEventExchange = mdxUtil.getMdxRealTimeEventExchange(params);
        mdxSubscriptionEventExchange.build();

        // Create a loader to manage the loading of mdx documents from the mdx store
        mdxDocumentLoader.set(mdxUtil.getMdxPullRequestEventExchange(mdxEventType, mdxInitialLoadIdentifier));
        mdxDocumentLoader.get().withCounter(numInitialLoadSourceMdxEvents);
        mdxDocumentLoader.get().withSourceFunction(this);
//        MDXIsinCache isinCache = new MDXIsinCache(new TestMdxISINCacheLoader(mdxInitialLoadIdentifier), mdxSourceName, params.getInt("mdx.isin.cache.refresh.interval.seconds",3600), mdxInitialLoadIdentifier);
        isinCacheLoader = new XmartISINCacheLoader(isinDatastoreQuery, params);
        isinCache = new MDXIsinCache(isinCacheLoader, mdxSourceName, params, mdxInitialLoadIdentifier);



        isinCache.registerCacheListener(mdxDocumentLoader.get());
        this.isinCacheRef.set(isinCache);
        mdxDocumentLoader.get().withISINCache(isinCacheRef.get());

        // Create a fetcher to fetch MdxDocuments from the MDX data store
        this.mdxReader = mdxUtil.createMdxDocumentStoreFetcher(mdxEventType, params, initialLoadMdxSessionContext.get(), mdxInitialLoadIdentifier, numInvalidMdxDocumentsFound, sourceID, currentJobEventIDCounter);
        mdxDocumentLoader.get().setInitialLoad(true);
        mdxDocumentLoader.get().withMdxDocumentStoreFetcher(mdxReader);

        // Check if we're resuming from a checkpoint, if so then set the MDXIsinCache to the restored state
        if (isRestored) {
            isinCache.setRestoredISINS(restoredCacheItems.keySet());
        }

        // MDX Subscription
        this.mdxSubscription = mdxUtil.createMdxSubscription(mdxEventType, params, mdxSubscriptionEventExchange, mdxSubscriptionIdentifier, mdxSubscriptionIdentifierWildcard, sourceID, currentJobEventIDCounter);
        mdxSubscription.withMdxSessionContext(subscriptionMdxSessionContext.get());
        mdxSubscription.withSourceFunction(this);

        // Assign the subscription to the loader
        mdxDocumentLoader.get().withSubscription(mdxSubscription);

        // Start receiving the MDX Subscription events BEFORE you start the initial load.
        this.mdxSubscription.startConsumingEvents();

        // Flink accumlators / counters
        getRuntimeContext().addAccumulator("numInitialLoadSourceMdxEvents", this.numInitialLoadSourceMdxEvents);
        getRuntimeContext().addAccumulator("numSubscriptionSourceMdxEvents", this.numSubscriptionSourceMdxEvents);
        getRuntimeContext().addAccumulator("numInvalidMdxDocumentsFound", this.numInvalidMdxDocumentsFound);
    }

    @Override
    public void notifyCheckpointComplete(long checkpointId) throws Exception {
        logger.info("Checkpoint Complete ID [ " + checkpointId + " ]");
    }

    @Override
    public void snapshotState(FunctionSnapshotContext context) throws Exception {
        ParameterTool params = (ParameterTool)getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        // MDC logging
        String mdcJobNameKey =  params.get("nwm.job.param","jobName");
        String jobName = params.get("flink.job.name", "No Job Name Specific");
        MDC.put(mdcJobNameKey,jobName);

        // The checkpoint lock is held when this method is called by Flink
        Collection<CacheItem> cacheItems = isinCacheRef.get().getValues();

        // write the changeID ro the list of operator states
        this.isinListState.clear();
        for (CacheItem cacheItem : cacheItems) {
            MDXIsinCacheItem mdxIsinCacheItem = (MDXIsinCacheItem) cacheItem;
            this.isinListState.add(Tuple3.of(mdxIsinCacheItem.getIdentifier(), mdxIsinCacheItem.getVersion(), mdxIsinCacheItem.getEpochXmlWriteTime()));
        }

        logger.info("Checkpoint taken with isinList size [ " + cacheItems.size() + " ] for checkpointID [ " + context.getCheckpointId() + " ]");
    }

    @Override
    public void initializeState(FunctionInitializationContext context) throws Exception {
        // MDC logging
        ParameterTool params = (ParameterTool)getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        String mdcJobNameKey =  params.get("nwm.job.param","jobName");
        String jobName = params.get("flink.job.name", "No Job Name Specific");
        MDC.put(mdcJobNameKey,jobName);

        // register the state with the backend
        OperatorStateStore stateStore = context.getOperatorStateStore();
        this.listStateDescriptorName = "mdx-" + mdxSourceName + "-ISIN-list";
        logger.info("Registering state for [ " + listStateDescriptorName + " ]");
        TupleTypeInfo<Tuple3<String, Integer, Long>> typeInfo = TupleTypeInfo.getBasicAndBasicValueTupleTypeInfo(new Class[] {String.class, Integer.class, Long.class});

        this.isinListState = stateStore.getListState(new ListStateDescriptor<Tuple3<String, Integer, Long>>(listStateDescriptorName, typeInfo));

        // if the job was restarted, we set the restored isinCache values
        if (context.isRestored()) {
            for (Tuple3<String, Integer, Long> restoredCacheItem : this.isinListState.get()) {
                restoredCacheItems.put(new MDXIsinCacheItem(restoredCacheItem.f0, restoredCacheItem.f1, restoredCacheItem.f2), "");
            }
            logger.info("initializeState: restored [ " + restoredCacheItems.size() + " ] ISIN cache items from checkpoint");

            isRestored = true;
        }
    }
}
