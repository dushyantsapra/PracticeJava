package com.nwm.xmart.streaming.source.crm.entity.organization;

import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Name" })
public class RecordType implements Serializable {
    private static final long serialVersionUID = -854688261024390908L;

    @JsonProperty("Name")
    private String recordTypeName;

    @JsonProperty("Name")
    public String getRecordTypeName() {
        return recordTypeName;
    }

    @JsonProperty("Name")
    public void setRecordTypeName(String recordTypeName) {
        this.recordTypeName = recordTypeName;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("RecordType{");
        sb.append("recordTypeName='").append(recordTypeName).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
