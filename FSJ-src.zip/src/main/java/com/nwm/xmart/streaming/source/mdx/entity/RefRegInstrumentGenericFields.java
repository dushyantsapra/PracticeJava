package com.nwm.xmart.streaming.source.mdx.entity;

import java.math.BigDecimal;

public class RefRegInstrumentGenericFields {
    private String notionalCurrency;
    private String expiryDate;
    private String referenceRate;
    private BigDecimal referenceRateTermValue;
    private String referenceRateTermUnit;
    private String notionalSchedule;
    private String deliveryType;
    private BigDecimal priceMultiplier;
    private String optionType;
    private String otherNotionalCurrency;
    private String optionExerciseStyle;
    private String valuationMethodorTrigger;
    private String settlementCurrency;
    private String returnorPayoutTrigger;
    private String debtSeniority;
    private String strikePrice;
    private String baseProduct;
    private String subProduct;
    private String additionalSubProduct;
    private String transactionType;
    private String finalPriceType;
    private String otherBaseProduct;
    private String otherSubProduct;
    private String otherAdditionalSubProduct;
    private String otherReferenceRate;
    private String instrumentISINNearLeg;
    private String instrumentISINFarLeg;
    private String placeofSettlement;
    private String underlyingAssetType;

    public String getNotionalCurrency() {
        return notionalCurrency;
    }

    public void setNotionalCurrency(String notionalCurrency) {
        this.notionalCurrency = notionalCurrency;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getReferenceRate() {
        return referenceRate;
    }

    public void setReferenceRate(String referenceRate) {
        this.referenceRate = referenceRate;
    }

    public BigDecimal getReferenceRateTermValue() {
        return referenceRateTermValue;
    }

    public void setReferenceRateTermValue(BigDecimal referenceRateTermValue) {
        this.referenceRateTermValue = referenceRateTermValue;
    }

    public String getReferenceRateTermUnit() {
        return referenceRateTermUnit;
    }

    public void setReferenceRateTermUnit(String referenceRateTermUnit) {
        this.referenceRateTermUnit = referenceRateTermUnit;
    }

    public String getNotionalSchedule() {
        return notionalSchedule;
    }

    public void setNotionalSchedule(String notionalSchedule) {
        this.notionalSchedule = notionalSchedule;
    }

    public String getDeliveryType() {
        return deliveryType;
    }

    public void setDeliveryType(String deliveryType) {
        this.deliveryType = deliveryType;
    }

    public BigDecimal getPriceMultiplier() {
        return priceMultiplier;
    }

    public void setPriceMultiplier(BigDecimal priceMultiplier) {
        this.priceMultiplier = priceMultiplier;
    }

    public String getOptionType() {
        return optionType;
    }

    public void setOptionType(String optionType) {
        this.optionType = optionType;
    }

    public String getOtherNotionalCurrency() {
        return otherNotionalCurrency;
    }

    public void setOtherNotionalCurrency(String otherNotionalCurrency) {
        this.otherNotionalCurrency = otherNotionalCurrency;
    }

    public String getOptionExerciseStyle() {
        return optionExerciseStyle;
    }

    public void setOptionExerciseStyle(String optionExerciseStyle) {
        this.optionExerciseStyle = optionExerciseStyle;
    }

    public String getValuationMethodorTrigger() {
        return valuationMethodorTrigger;
    }

    public void setValuationMethodorTrigger(String valuationMethodorTrigger) {
        this.valuationMethodorTrigger = valuationMethodorTrigger;
    }

    public String getSettlementCurrency() {
        return settlementCurrency;
    }

    public void setSettlementCurrency(String settlementCurrency) {
        this.settlementCurrency = settlementCurrency;
    }

    public String getReturnorPayoutTrigger() {
        return returnorPayoutTrigger;
    }

    public void setReturnorPayoutTrigger(String returnorPayoutTrigger) {
        this.returnorPayoutTrigger = returnorPayoutTrigger;
    }

    public String getDebtSeniority() {
        return debtSeniority;
    }

    public void setDebtSeniority(String debtSeniority) {
        this.debtSeniority = debtSeniority;
    }

    public String getStrikePrice() {
        return strikePrice;
    }

    public void setStrikePrice(String strikePrice) {
        this.strikePrice = strikePrice;
    }

    public String getBaseProduct() {
        return baseProduct;
    }

    public void setBaseProduct(String baseProduct) {
        this.baseProduct = baseProduct;
    }

    public String getSubProduct() {
        return subProduct;
    }

    public void setSubProduct(String subProduct) {
        this.subProduct = subProduct;
    }

    public String getAdditionalSubProduct() {
        return additionalSubProduct;
    }

    public void setAdditionalSubProduct(String additionalSubProduct) {
        this.additionalSubProduct = additionalSubProduct;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getFinalPriceType() {
        return finalPriceType;
    }

    public void setFinalPriceType(String finalPriceType) {
        this.finalPriceType = finalPriceType;
    }

    public String getOtherBaseProduct() {
        return otherBaseProduct;
    }

    public void setOtherBaseProduct(String otherBaseProduct) {
        this.otherBaseProduct = otherBaseProduct;
    }

    public String getOtherSubProduct() {
        return otherSubProduct;
    }

    public void setOtherSubProduct(String otherSubProduct) {
        this.otherSubProduct = otherSubProduct;
    }

    public String getOtherAdditionalSubProduct() {
        return otherAdditionalSubProduct;
    }

    public void setOtherAdditionalSubProduct(String otherAdditionalSubProduct) {
        this.otherAdditionalSubProduct = otherAdditionalSubProduct;
    }

    public String getOtherReferenceRate() {
        return otherReferenceRate;
    }

    public void setOtherReferenceRate(String otherReferenceRate) {
        this.otherReferenceRate = otherReferenceRate;
    }

    public String getInstrumentISINNearLeg() {
        return instrumentISINNearLeg;
    }

    public void setInstrumentISINNearLeg(String instrumentISINNearLeg) {
        this.instrumentISINNearLeg = instrumentISINNearLeg;
    }

    public String getInstrumentISINFarLeg() {
        return instrumentISINFarLeg;
    }

    public void setInstrumentISINFarLeg(String instrumentISINFarLeg) {
        this.instrumentISINFarLeg = instrumentISINFarLeg;
    }

    public String getPlaceofSettlement() {
        return placeofSettlement;
    }

    public void setPlaceofSettlement(String placeofSettlement) {
        this.placeofSettlement = placeofSettlement;
    }

    public String getUnderlyingAssetType() {
        return underlyingAssetType;
    }

    public void setUnderlyingAssetType(String underlyingAssetType) {
        this.underlyingAssetType = underlyingAssetType;
    }
}
