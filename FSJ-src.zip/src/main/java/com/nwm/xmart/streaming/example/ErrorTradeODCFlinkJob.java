package com.nwm.xmart.streaming.example;

import com.nwm.xmart.streaming.monitor.GeneosPersistenceFile;
import com.nwm.xmart.streaming.monitor.InactiveKafkaMonitor;
import com.nwm.xmart.streaming.monitor.InactivityMonitor;
import com.nwm.xmart.streaming.source.df.DataFabricFlinkKafkaSource;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import com.rbs.datafabric.domain.event.RecordModifiedEvent;
import com.nwm.xmart.streaming.common.job.StreamJob;
import com.nwm.xmart.streaming.source.df.KafkaProperties;
import com.nwm.xmart.streaming.source.df.serialisation.FlinkDeserializer;
import com.rbs.odc.core.domain.ODCValue;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.flink.streaming.util.serialization.KeyedDeserializationSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Created by gardlex on 18/10/2017.
 */
public class ErrorTradeODCFlinkJob {

    private static Logger logger = LoggerFactory.getLogger(ErrorTradeODCFlinkJob.class);

    public static void main(String[] args) throws Exception {

        // StreamJob implementation can override any abstract methid as long as it calls super() first
        StreamJob streamJob = new ExampleODCStream();
        streamJob.run(args);
    }



    private static DataFabricFlinkKafkaSource getSource(Configuration configuration, DataFabricUtil dataFabricUtil, Class<DataFabricStreamEvent<ODCValue>> sourceClassRef) {
        // For Flink Deserializer
        InactivityMonitor inactivityMonitor = new InactiveKafkaMonitor(configuration, new GeneosPersistenceFile(configuration));

        // The deserializer itself
        KeyedDeserializationSchema<DataFabricStreamEvent<ODCValue>> deserialiser =
                new FlinkDeserializer<DataFabricStreamEvent<ODCValue>, ODCValue, RecordModifiedEvent>(
                        dataFabricUtil,
                        sourceClassRef,
                        ODCValue.class,
                        inactivityMonitor,
                        configuration);
        DataFabricFlinkKafkaSource sourceFunction = new DataFabricFlinkKafkaSource<DataFabricStreamEvent<ODCValue>>(dataFabricUtil, configuration, new KafkaProperties(configuration), deserialiser);

        return sourceFunction;
    }

    static class ExampleODCStream extends StreamJob {
            @Override
            protected void configureAndExecuteStream(StreamExecutionEnvironment env) {

                DataFabricUtil dataFabricUtil = new DataFabricUtil(configuration);

                // Type info reqd for the FlinkDeserializer
                final TypeInformation<DataFabricStreamEvent<ODCValue>> info = TypeInformation.of(new TypeHint<DataFabricStreamEvent<ODCValue>>(){});
                Class<DataFabricStreamEvent<ODCValue>> sourceClassRef = info.getTypeClass();

                // Crate the DataFabricSource
                DataFabricFlinkKafkaSource flinkKafkaSource = getSource(configuration, dataFabricUtil, sourceClassRef);

                // Configuration of the stream
                DataStream<DataFabricStreamEvent<ODCValue>> input = env
                        .addSource(flinkKafkaSource, info)
                        .uid(configuration.getString("operator.trade.source.name",""))
                        .name(configuration.getString("operator.trade.source.name", ""))
                        .setParallelism(1); //configuration.getInteger("operator.trade.source.parallelism", 1));

                input.addSink(

                        new RichSinkFunction<DataFabricStreamEvent<ODCValue>>() {
                    @Override
                    public void invoke(DataFabricStreamEvent<ODCValue> value) throws Exception {
                        logger.info("value = " + value);
                    }
                })
                        .uid(configuration.getString("operator.datafabric.sink.name",""))
                        .name(configuration.getString("operator.datafabric.sink.name",""))
                        .setParallelism(1); //configuration.getInteger("operator.datafabric.sink.parallelism",1));

                try {
                    logger.info("EXECUTION PLAN = " + env.getExecutionPlan());
                    env.execute("ErrorTradeODCFlinkJob");
                } catch (Exception e) {
                    logger.error("Exception running the ErrorTradeODCFlinkJob",e);
                    throw new RuntimeException(e);
                }
            }
    }

}
