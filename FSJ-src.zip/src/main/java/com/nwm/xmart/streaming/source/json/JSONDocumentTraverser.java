package com.nwm.xmart.streaming.source.json;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.collect.Iterables;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;

import java.io.IOException;
import java.util.*;

/**
 * Created by gardlex on 10/10/2018.
 */
public class JSONDocumentTraverser {

    private static final Configuration JACKSON_JSON_NODE_CONFIGURATION = Configuration
                .builder()
                .mappingProvider(new JacksonMappingProvider())
                .jsonProvider(new JacksonJsonNodeJsonProvider())
                .build();

    private JsonNode jsonNode;
    private int id;

    public JSONDocumentTraverser(JsonNode jsonNode) {
        this.jsonNode = jsonNode;
        this.id = 0;
    }

    public JSONDocumentTraverser(ObjectNode objectNode) {
        this.jsonNode = (JsonNode) objectNode;
        this.id = 0;
    }

    public JSONDocumentTraverser(String jsonString) throws IOException {
        this.jsonNode = (JsonNode) new ObjectMapper().readTree(jsonString);
        this.id = 0;
    }

    public JSONDocumentTraverser getNodeAt(String path) {
        return new JSONDocumentTraverser(jsonNode.at(path));
    }

    private void setNodeId(int i) {
        this.id = i;
    }

    public Integer getNodeId() {
        return Integer.valueOf(id);
    }

    public Collection<JSONDocumentTraverser> duplicate() {
        List<JSONDocumentTraverser> duplicates = new ArrayList<>();
        JSONDocumentTraverser node0 = new JSONDocumentTraverser(jsonNode);
        node0.setNodeId(0);

        JSONDocumentTraverser node1 = new JSONDocumentTraverser(jsonNode);
        node0.setNodeId(1);

        duplicates.add(node0);
        duplicates.add(node1);

        return duplicates;
    }

    public Collection<JSONDocumentTraverser> getNodesAt(String path) {
        JsonNode multiNodes = jsonNode.at(path);
        List<JSONDocumentTraverser> nodeCollection = new ArrayList<>();

        Iterator<JsonNode> elementsIt = multiNodes.elements();
        while (elementsIt.hasNext()) {
            nodeCollection.add(new JSONDocumentTraverser(elementsIt.next()));
        }

        return nodeCollection;
    }



    public JSONDocumentTraverser getNodeUsingQuery(String searchExpression) {
        JsonNode queryResult = JsonPath.using(JSONDocumentTraverser.JACKSON_JSON_NODE_CONFIGURATION).parse(jsonNode.toString()).read(searchExpression);

        return new JSONDocumentTraverser(queryResult);
    }

    /**
     * This handles scenario where selecting an array entry from an ArrayNode and then extracting an attribute.
     *
     * e.g. the Json must be in the form:
     *
     * [{field : "value"}, {field : "value"}]
     */
    public String getStringAttributeFromArrayNode(String nodeIndexValue, String attributePath) {
        int index = Integer.valueOf(nodeIndexValue);

        if (jsonNode.isArray() && getArraySize(jsonNode) >= 1) {
                JsonNode selectedNode = jsonNode.get(index);
                JsonNode attributeNode = selectedNode.at(attributePath);
                return getTextNodeValue(attributeNode);
        }

        if (jsonNode.isMissingNode()) {
            return null;
        }

        throw new JSONTraverserException("Current JsonNode at path {} is not a ArrayNode");
    }

    public Double getDoubleAttributeFromArrayNode(String nodeIndexValue, String attributePath) {
        int index = Integer.valueOf(nodeIndexValue);

        if (jsonNode.isArray() && getArraySize(jsonNode) >= 1) {
            JsonNode selectedNode = jsonNode.get(index);
            JsonNode attributeNode = selectedNode.at(attributePath);
            return getDoubleNodeValue(attributeNode);
        }

        return null;
    }

    private int getArraySize(JsonNode arrayNode) {
        int ctr=0;
        for (JsonNode node : arrayNode) {
            ctr++;
        }

        return ctr;
    }

    public String getTextNodeValue(JsonNode jsonNode) {
        if (jsonNode.isTextual()) {
            return jsonNode.textValue();
        }

       return null;
    }

    public Double getDoubleNodeValue(JsonNode jsonNode) {
        if (jsonNode.isDouble()) {
            return jsonNode.doubleValue();
        }

        return null;
    }


    public String getNodeStringValueAt(String path) {
        JsonNode jsonNodeValue = jsonNode.at(path);
        if (jsonNodeValue.isTextual()) {
            return jsonNodeValue.textValue();
        }

        if (jsonNodeValue.isMissingNode()) {
            return null;
        }

        throw new JSONTraverserException("JsonNode at path {} is not a TextualNode");
    }

    public String getNodeStringValueAtWithDefault(String path, String defaultValue) {
        JsonNode jsonNodeValue = jsonNode.at(path);
        if (jsonNodeValue.isTextual()) {
            return jsonNodeValue.textValue();
        }
        if (jsonNodeValue.isMissingNode()) {
            return defaultValue;
        }
        throw new JSONTraverserException("JsonNode at path {} is not a TextualNode");
    }

    public Long getNodeLongValueAt(String path) {
        JsonNode jsonNodeValue = jsonNode.at(path);
        if (jsonNodeValue.isLong()) {
            return jsonNodeValue.longValue();
        }
        if (jsonNodeValue.isMissingNode()) {
            return null;
        }
        throw new JSONTraverserException("JsonNode at path {} is not a LongNode");
    }

    public Float getNodeFloatValueAt(String path) {
        JsonNode jsonNodeValue = jsonNode.at(path);
        if (jsonNodeValue.isFloat()) {
            return jsonNodeValue.floatValue();
        }
        if (jsonNodeValue.isMissingNode()) {
            return null;
        }
        throw new JSONTraverserException("JsonNode at path {} is not a FloatNode");
    }

    public Double getNodeDoubleValueAt(String path) {
        JsonNode jsonNodeValue = jsonNode.at(path);
        if (jsonNodeValue.isDouble()) {
            return jsonNodeValue.doubleValue();
        }
        if (jsonNodeValue.isMissingNode()) {
            return null;
        }
        throw new JSONTraverserException("JsonNode at path {} is not a DoubleNode");
    }

    public Short getNodeShortValueAt(String path) {
        JsonNode jsonNodeValue = jsonNode.at(path);
        if (jsonNodeValue.isShort()) {
            return jsonNodeValue.shortValue();
        }
        if (jsonNodeValue.isMissingNode()) {
            return null;
        }
        throw new JSONTraverserException("JsonNode at path {} is not a ShortNode");
    }

    public Integer getNodeIntegerValueAt(String path) {
        JsonNode jsonNodeValue = jsonNode.at(path);
        if (jsonNodeValue.isInt()) {
            return jsonNodeValue.intValue();
        }
        if (jsonNodeValue.isMissingNode()) {
            return null;
        }
        throw new JSONTraverserException("JsonNode at path {} is not a IntNode");
    }

    public Boolean getNodeBooleanValueAt(String path) {
        JsonNode jsonNodeValue = jsonNode.at(path);
        if (jsonNodeValue.isBoolean()) {
            return jsonNodeValue.booleanValue();
        }
        if (jsonNodeValue.isMissingNode()) {
            return null;
        }
        throw new JSONTraverserException("JsonNode at path {} is not a IntNode");
    }

    public String getDefaultStringValue(String defaultString) {
        return defaultString;
    }

    public JsonNode getJsonNode() {
        return jsonNode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        JSONDocumentTraverser traverser = (JSONDocumentTraverser) o;
        return id == traverser.id && Objects.equals(jsonNode, traverser.jsonNode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(jsonNode, id);
    }
}
