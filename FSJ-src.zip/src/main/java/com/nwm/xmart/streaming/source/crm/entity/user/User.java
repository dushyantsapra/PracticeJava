package com.nwm.xmart.streaming.source.crm.entity.user;

import com.nwm.xmart.streaming.source.crm.entity.common.Account;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(
        { "AboutMe", "Account", "Address", "Alias", "Analyst", "BadgeText", "BannerPhotoUrl", "CallCenterId", "City",
          "CommunityNickname", "CompanyName", "ContactId", "Country", "CreatedById", "CreatedDate",
          "Create_Data_Against_Coverage", "DefaultGroupNotificationFrequency", "DelegatedApproverId", "Department",
          "DigestFrequency", "Division", "ECD_Id", "ECD_URL", "Email", "EmailEncodingKey", "EmailPreferencesAutoBcc",
          "EmailPreferencesAutoBccStayInTouch", "EmailPreferencesStayInTouchReminder", "EmployeeNumber", "Extension",
          "Id", "Fax", "FederationIdentifier", "FirstName", "ForecastEnabled", "FullPhotoUrl", "GeocodeAccuracy",
          "Id_18", "IsActive", "IsProfilePhotoActive", "LanguageLocaleKey", "LastLoginDate", "LastModifiedById",
          "LastModifiedDate", "LastName", "LastPasswordChangeDate", "Latitude", "LocaleSidKey", "Longitude",
          "ManagerId", "MiddleName", "MobilePhone", "Name", "OfflinePdaTrialExpirationDate",
          "OfflineTrialExpirationDate", "Phone", "PostalCode", "Profile", "ReceivesAdminInfoEmails",
          "ReceivesInfoEmails", "SenderEmail", "SenderName", "Signature", "State", "StayInTouchNote",
          "StayInTouchSignature", "StayInTouchSubject", "Street", "SystemModstamp", "AEM__Aem_User_Type",
          "Create_New_Employee", "Delegated_Employee", "Delegated_User_Id", "Delegated_User", "Employee_Id",
          "Other_Phone_Numbers", "Session_Id", "Telephony_Password", "Telephony_Username",
          "User_Empl_Active_Status_Mismatch", "FR__Feature_Administrator", "TimeZoneSidKey", "Title", "Username",
          "UserRoleId", "UserType" })
public class User implements Serializable {
    private static final long serialVersionUID = -8498123601945520669L;

    @JsonProperty("AboutMe")
    private Object aboutMe;
    @JsonProperty("Account")
    private Account account;
    @JsonProperty("Address")
    private Address address;
    @JsonProperty("Alias")
    private String alias;
    @JsonProperty("Analyst")
    private Boolean analyst;
    @JsonProperty("BadgeText")
    private String badgeText;
    @JsonProperty("BannerPhotoUrl")
    private String bannerPhotoUrl;
    @JsonProperty("CallCenterId")
    private String callCenterId;
    @JsonProperty("City")
    private String city;
    @JsonProperty("CommunityNickname")
    private String communityNickname;
    @JsonProperty("CompanyName")
    private String companyName;
    @JsonProperty("ContactId")
    private String contactId;
    @JsonProperty("Country")
    private String country;
    @JsonProperty("CreatedById")
    private String createdById;
    @JsonProperty("CreatedDate")
    private String createdDate;
    @JsonProperty("Create_Data_Against_Coverage")
    private Boolean createDataAgainstCoverage;
    @JsonProperty("DefaultGroupNotificationFrequency")
    private String defaultGroupNotificationFrequency;
    @JsonProperty("DelegatedApproverId")
    private Object delegatedApproverId;
    @JsonProperty("Department")
    private String department;
    @JsonProperty("DigestFrequency")
    private String digestFrequency;
    @JsonProperty("Division")
    private String division;
    @JsonProperty("ECD_Id")
    private String eCDId;
    @JsonProperty("ECD_URL")
    private String eCDURL;
    @JsonProperty("Email")
    private String email;
    @JsonProperty("EmailEncodingKey")
    private String emailEncodingKey;
    @JsonProperty("EmailPreferencesAutoBcc")
    private Boolean emailPreferencesAutoBcc;
    @JsonProperty("EmailPreferencesAutoBccStayInTouch")
    private Boolean emailPreferencesAutoBccStayInTouch;
    @JsonProperty("EmailPreferencesStayInTouchReminder")
    private Boolean emailPreferencesStayInTouchReminder;
    @JsonProperty("EmployeeNumber")
    private String employeeNumber;
    @JsonProperty("Extension")
    private String extension;
    @JsonProperty("Id")
    private String id;
    @JsonProperty("Fax")
    private String fax;
    @JsonProperty("FederationIdentifier")
    private Object federationIdentifier;
    @JsonProperty("FirstName")
    private String firstName;
    @JsonProperty("ForecastEnabled")
    private Boolean forecastEnabled;
    @JsonProperty("FullPhotoUrl")
    private String fullPhotoUrl;
    @JsonProperty("GeocodeAccuracy")
    private Object geocodeAccuracy;
    @JsonProperty("Id_18")
    private String id18;
    @JsonProperty("IsActive")
    private Boolean isActive;
    @JsonProperty("IsProfilePhotoActive")
    private Boolean isProfilePhotoActive;
    @JsonProperty("LanguageLocaleKey")
    private String languageLocaleKey;
    @JsonProperty("LastLoginDate")
    private String lastLoginDate;
    @JsonProperty("LastModifiedById")
    private String lastModifiedById;
    @JsonProperty("LastModifiedDate")
    private String lastModifiedDate;
    @JsonProperty("LastName")
    private String lastName;
    @JsonProperty("LastPasswordChangeDate")
    private String lastPasswordChangeDate;
    @JsonProperty("Latitude")
    private Object latitude;
    @JsonProperty("LocaleSidKey")
    private String localeSidKey;
    @JsonProperty("Longitude")
    private Object longitude;
    @JsonProperty("ManagerId")
    private String managerId;
    @JsonProperty("MiddleName")
    private String middleName;
    @JsonProperty("MobilePhone")
    private String mobilePhone;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("OfflinePdaTrialExpirationDate")
    private Object offlinePdaTrialExpirationDate;
    @JsonProperty("OfflineTrialExpirationDate")
    private Object offlineTrialExpirationDate;
    @JsonProperty("Phone")
    private String phone;
    @JsonProperty("PostalCode")
    private String postalCode;
    @JsonProperty("Profile")
    private Profile profile;
    @JsonProperty("ReceivesAdminInfoEmails")
    private Boolean receivesAdminInfoEmails;
    @JsonProperty("ReceivesInfoEmails")
    private Boolean receivesInfoEmails;
    @JsonProperty("SenderEmail")
    private String senderEmail;
    @JsonProperty("SenderName")
    private String senderName;
    @JsonProperty("Signature")
    private Object signature;
    @JsonProperty("State")
    private String state;
    @JsonProperty("StayInTouchNote")
    private Object stayInTouchNote;
    @JsonProperty("StayInTouchSignature")
    private Object stayInTouchSignature;
    @JsonProperty("StayInTouchSubject")
    private Object stayInTouchSubject;
    @JsonProperty("Street")
    private String street;
    @JsonProperty("SystemModstamp")
    private String systemModstamp;
    @JsonProperty("AEM__Aem_User_Type")
    private Object aEMAemUserType;
    @JsonProperty("Create_New_Employee")
    private Boolean createNewEmployee;
    @JsonProperty("Delegated_Employee")
    private Object delegatedEmployee;
    @JsonProperty("Delegated_User_Id")
    private Object delegatedUserId;
    @JsonProperty("Delegated_User")
    private Object delegatedUser;
    @JsonProperty("Employee_Id")
    private String employeeId;
    @JsonProperty("Other_Phone_Numbers")
    private Object otherPhoneNumbers;
    @JsonProperty("Session_Id")
    private Object sessionId;
    @JsonProperty("Telephony_Password")
    private Object telephonyPassword;
    @JsonProperty("Telephony_Username")
    private Object telephonyUsername;
    @JsonProperty("User_Empl_Active_Status_Mismatch")
    private Boolean userEmplActiveStatusMismatch;
    @JsonProperty("FR__Feature_Administrator")
    private Object fRFeatureAdministrator;
    @JsonProperty("TimeZoneSidKey")
    private String timeZoneSidKey;
    @JsonProperty("Title")
    private String title;
    @JsonProperty("Username")
    private String username;
    @JsonProperty("UserRoleId")
    private String userRoleId;
    @JsonProperty("UserType")
    private String userType;

    @JsonProperty("AboutMe")
    public Object getAboutMe() {
        return aboutMe;
    }

    @JsonProperty("AboutMe")
    public void setAboutMe(Object aboutMe) {
        this.aboutMe = aboutMe;
    }

    @JsonProperty("Account")
    public Account getAccount() {
        return account;
    }

    @JsonProperty("Account")
    public void setAccount(Account account) {
        this.account = account;
    }

    @JsonProperty("Address")
    public Address getAddress() {
        return address;
    }

    @JsonProperty("Address")
    public void setAddress(Address address) {
        this.address = address;
    }

    @JsonProperty("Alias")
    public String getAlias() {
        return alias;
    }

    @JsonProperty("Alias")
    public void setAlias(String alias) {
        this.alias = alias;
    }

    @JsonProperty("Analyst")
    public Boolean getAnalyst() {
        return analyst;
    }

    @JsonProperty("Analyst")
    public void setAnalyst(Boolean analyst) {
        this.analyst = analyst;
    }

    @JsonProperty("BadgeText")
    public String getBadgeText() {
        return badgeText;
    }

    @JsonProperty("BadgeText")
    public void setBadgeText(String badgeText) {
        this.badgeText = badgeText;
    }

    @JsonProperty("BannerPhotoUrl")
    public String getBannerPhotoUrl() {
        return bannerPhotoUrl;
    }

    @JsonProperty("BannerPhotoUrl")
    public void setBannerPhotoUrl(String bannerPhotoUrl) {
        this.bannerPhotoUrl = bannerPhotoUrl;
    }

    @JsonProperty("CallCenterId")
    public String getCallCenterId() {
        return callCenterId;
    }

    @JsonProperty("CallCenterId")
    public void setCallCenterId(String callCenterId) {
        this.callCenterId = callCenterId;
    }

    @JsonProperty("City")
    public String getCity() {
        return city;
    }

    @JsonProperty("City")
    public void setCity(String city) {
        this.city = city;
    }

    @JsonProperty("CommunityNickname")
    public String getCommunityNickname() {
        return communityNickname;
    }

    @JsonProperty("CommunityNickname")
    public void setCommunityNickname(String communityNickname) {
        this.communityNickname = communityNickname;
    }

    @JsonProperty("CompanyName")
    public String getCompanyName() {
        return companyName;
    }

    @JsonProperty("CompanyName")
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    @JsonProperty("ContactId")
    public String getContactId() {
        return contactId;
    }

    @JsonProperty("ContactId")
    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    @JsonProperty("Country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("Country")
    public void setCountry(String country) {
        this.country = country;
    }

    @JsonProperty("CreatedById")
    public String getCreatedById() {
        return createdById;
    }

    @JsonProperty("CreatedById")
    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    @JsonProperty("CreatedDate")
    public String getCreatedDate() {
        return createdDate;
    }

    @JsonProperty("CreatedDate")
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    @JsonProperty("Create_Data_Against_Coverage")
    public Boolean getCreateDataAgainstCoverage() {
        return createDataAgainstCoverage;
    }

    @JsonProperty("Create_Data_Against_Coverage")
    public void setCreateDataAgainstCoverage(Boolean createDataAgainstCoverage) {
        this.createDataAgainstCoverage = createDataAgainstCoverage;
    }

    @JsonProperty("DefaultGroupNotificationFrequency")
    public String getDefaultGroupNotificationFrequency() {
        return defaultGroupNotificationFrequency;
    }

    @JsonProperty("DefaultGroupNotificationFrequency")
    public void setDefaultGroupNotificationFrequency(String defaultGroupNotificationFrequency) {
        this.defaultGroupNotificationFrequency = defaultGroupNotificationFrequency;
    }

    @JsonProperty("DelegatedApproverId")
    public Object getDelegatedApproverId() {
        return delegatedApproverId;
    }

    @JsonProperty("DelegatedApproverId")
    public void setDelegatedApproverId(Object delegatedApproverId) {
        this.delegatedApproverId = delegatedApproverId;
    }

    @JsonProperty("Department")
    public String getDepartment() {
        return department;
    }

    @JsonProperty("Department")
    public void setDepartment(String department) {
        this.department = department;
    }

    @JsonProperty("DigestFrequency")
    public String getDigestFrequency() {
        return digestFrequency;
    }

    @JsonProperty("DigestFrequency")
    public void setDigestFrequency(String digestFrequency) {
        this.digestFrequency = digestFrequency;
    }

    @JsonProperty("Division")
    public String getDivision() {
        return division;
    }

    @JsonProperty("Division")
    public void setDivision(String division) {
        this.division = division;
    }

    @JsonProperty("ECD_Id")
    public String getECDId() {
        return eCDId;
    }

    @JsonProperty("ECD_Id")
    public void setECDId(String eCDId) {
        this.eCDId = eCDId;
    }

    @JsonProperty("ECD_URL")
    public String getECDURL() {
        return eCDURL;
    }

    @JsonProperty("ECD_URL")
    public void setECDURL(String eCDURL) {
        this.eCDURL = eCDURL;
    }

    @JsonProperty("Email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("Email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("EmailEncodingKey")
    public String getEmailEncodingKey() {
        return emailEncodingKey;
    }

    @JsonProperty("EmailEncodingKey")
    public void setEmailEncodingKey(String emailEncodingKey) {
        this.emailEncodingKey = emailEncodingKey;
    }

    @JsonProperty("EmailPreferencesAutoBcc")
    public Boolean getEmailPreferencesAutoBcc() {
        return emailPreferencesAutoBcc;
    }

    @JsonProperty("EmailPreferencesAutoBcc")
    public void setEmailPreferencesAutoBcc(Boolean emailPreferencesAutoBcc) {
        this.emailPreferencesAutoBcc = emailPreferencesAutoBcc;
    }

    @JsonProperty("EmailPreferencesAutoBccStayInTouch")
    public Boolean getEmailPreferencesAutoBccStayInTouch() {
        return emailPreferencesAutoBccStayInTouch;
    }

    @JsonProperty("EmailPreferencesAutoBccStayInTouch")
    public void setEmailPreferencesAutoBccStayInTouch(Boolean emailPreferencesAutoBccStayInTouch) {
        this.emailPreferencesAutoBccStayInTouch = emailPreferencesAutoBccStayInTouch;
    }

    @JsonProperty("EmailPreferencesStayInTouchReminder")
    public Boolean getEmailPreferencesStayInTouchReminder() {
        return emailPreferencesStayInTouchReminder;
    }

    @JsonProperty("EmailPreferencesStayInTouchReminder")
    public void setEmailPreferencesStayInTouchReminder(Boolean emailPreferencesStayInTouchReminder) {
        this.emailPreferencesStayInTouchReminder = emailPreferencesStayInTouchReminder;
    }

    @JsonProperty("EmployeeNumber")
    public String getEmployeeNumber() {
        return employeeNumber;
    }

    @JsonProperty("EmployeeNumber")
    public void setEmployeeNumber(String employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    @JsonProperty("Extension")
    public String getExtension() {
        return extension;
    }

    @JsonProperty("Extension")
    public void setExtension(String extension) {
        this.extension = extension;
    }

    @JsonProperty("Id")
    public String getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("Fax")
    public String getFax() {
        return fax;
    }

    @JsonProperty("Fax")
    public void setFax(String fax) {
        this.fax = fax;
    }

    @JsonProperty("FederationIdentifier")
    public Object getFederationIdentifier() {
        return federationIdentifier;
    }

    @JsonProperty("FederationIdentifier")
    public void setFederationIdentifier(Object federationIdentifier) {
        this.federationIdentifier = federationIdentifier;
    }

    @JsonProperty("FirstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("FirstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("ForecastEnabled")
    public Boolean getForecastEnabled() {
        return forecastEnabled;
    }

    @JsonProperty("ForecastEnabled")
    public void setForecastEnabled(Boolean forecastEnabled) {
        this.forecastEnabled = forecastEnabled;
    }

    @JsonProperty("FullPhotoUrl")
    public String getFullPhotoUrl() {
        return fullPhotoUrl;
    }

    @JsonProperty("FullPhotoUrl")
    public void setFullPhotoUrl(String fullPhotoUrl) {
        this.fullPhotoUrl = fullPhotoUrl;
    }

    @JsonProperty("GeocodeAccuracy")
    public Object getGeocodeAccuracy() {
        return geocodeAccuracy;
    }

    @JsonProperty("GeocodeAccuracy")
    public void setGeocodeAccuracy(Object geocodeAccuracy) {
        this.geocodeAccuracy = geocodeAccuracy;
    }

    @JsonProperty("Id_18")
    public String getId18() {
        return id18;
    }

    @JsonProperty("Id_18")
    public void setId18(String id18) {
        this.id18 = id18;
    }

    @JsonProperty("IsActive")
    public Boolean getIsActive() {
        return isActive;
    }

    @JsonProperty("IsActive")
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    @JsonProperty("IsProfilePhotoActive")
    public Boolean getIsProfilePhotoActive() {
        return isProfilePhotoActive;
    }

    @JsonProperty("IsProfilePhotoActive")
    public void setIsProfilePhotoActive(Boolean isProfilePhotoActive) {
        this.isProfilePhotoActive = isProfilePhotoActive;
    }

    @JsonProperty("LanguageLocaleKey")
    public String getLanguageLocaleKey() {
        return languageLocaleKey;
    }

    @JsonProperty("LanguageLocaleKey")
    public void setLanguageLocaleKey(String languageLocaleKey) {
        this.languageLocaleKey = languageLocaleKey;
    }

    @JsonProperty("LastLoginDate")
    public String getLastLoginDate() {
        return lastLoginDate;
    }

    @JsonProperty("LastLoginDate")
    public void setLastLoginDate(String lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }

    @JsonProperty("LastModifiedById")
    public String getLastModifiedById() {
        return lastModifiedById;
    }

    @JsonProperty("LastModifiedById")
    public void setLastModifiedById(String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }

    @JsonProperty("LastModifiedDate")
    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    @JsonProperty("LastModifiedDate")
    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @JsonProperty("LastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("LastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("LastPasswordChangeDate")
    public String getLastPasswordChangeDate() {
        return lastPasswordChangeDate;
    }

    @JsonProperty("LastPasswordChangeDate")
    public void setLastPasswordChangeDate(String lastPasswordChangeDate) {
        this.lastPasswordChangeDate = lastPasswordChangeDate;
    }

    @JsonProperty("Latitude")
    public Object getLatitude() {
        return latitude;
    }

    @JsonProperty("Latitude")
    public void setLatitude(Object latitude) {
        this.latitude = latitude;
    }

    @JsonProperty("LocaleSidKey")
    public String getLocaleSidKey() {
        return localeSidKey;
    }

    @JsonProperty("LocaleSidKey")
    public void setLocaleSidKey(String localeSidKey) {
        this.localeSidKey = localeSidKey;
    }

    @JsonProperty("Longitude")
    public Object getLongitude() {
        return longitude;
    }

    @JsonProperty("Longitude")
    public void setLongitude(Object longitude) {
        this.longitude = longitude;
    }

    @JsonProperty("ManagerId")
    public String getManagerId() {
        return managerId;
    }

    @JsonProperty("ManagerId")
    public void setManagerId(String managerId) {
        this.managerId = managerId;
    }

    @JsonProperty("MiddleName")
    public String getMiddleName() {
        return middleName;
    }

    @JsonProperty("MiddleName")
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    @JsonProperty("MobilePhone")
    public String getMobilePhone() {
        return mobilePhone;
    }

    @JsonProperty("MobilePhone")
    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("OfflinePdaTrialExpirationDate")
    public Object getOfflinePdaTrialExpirationDate() {
        return offlinePdaTrialExpirationDate;
    }

    @JsonProperty("OfflinePdaTrialExpirationDate")
    public void setOfflinePdaTrialExpirationDate(Object offlinePdaTrialExpirationDate) {
        this.offlinePdaTrialExpirationDate = offlinePdaTrialExpirationDate;
    }

    @JsonProperty("OfflineTrialExpirationDate")
    public Object getOfflineTrialExpirationDate() {
        return offlineTrialExpirationDate;
    }

    @JsonProperty("OfflineTrialExpirationDate")
    public void setOfflineTrialExpirationDate(Object offlineTrialExpirationDate) {
        this.offlineTrialExpirationDate = offlineTrialExpirationDate;
    }

    @JsonProperty("Phone")
    public String getPhone() {
        return phone;
    }

    @JsonProperty("Phone")
    public void setPhone(String phone) {
        this.phone = phone;
    }

    @JsonProperty("PostalCode")
    public String getPostalCode() {
        return postalCode;
    }

    @JsonProperty("PostalCode")
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    @JsonProperty("Profile")
    public Profile getProfile() {
        return profile;
    }

    @JsonProperty("Profile")
    public void setProfile(Profile profile) {
        this.profile = profile;
    }

    @JsonProperty("ReceivesAdminInfoEmails")
    public Boolean getReceivesAdminInfoEmails() {
        return receivesAdminInfoEmails;
    }

    @JsonProperty("ReceivesAdminInfoEmails")
    public void setReceivesAdminInfoEmails(Boolean receivesAdminInfoEmails) {
        this.receivesAdminInfoEmails = receivesAdminInfoEmails;
    }

    @JsonProperty("ReceivesInfoEmails")
    public Boolean getReceivesInfoEmails() {
        return receivesInfoEmails;
    }

    @JsonProperty("ReceivesInfoEmails")
    public void setReceivesInfoEmails(Boolean receivesInfoEmails) {
        this.receivesInfoEmails = receivesInfoEmails;
    }

    @JsonProperty("SenderEmail")
    public String getSenderEmail() {
        return senderEmail;
    }

    @JsonProperty("SenderEmail")
    public void setSenderEmail(String senderEmail) {
        this.senderEmail = senderEmail;
    }

    @JsonProperty("SenderName")
    public String getSenderName() {
        return senderName;
    }

    @JsonProperty("SenderName")
    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    @JsonProperty("Signature")
    public Object getSignature() {
        return signature;
    }

    @JsonProperty("Signature")
    public void setSignature(Object signature) {
        this.signature = signature;
    }

    @JsonProperty("State")
    public String getState() {
        return state;
    }

    @JsonProperty("State")
    public void setState(String state) {
        this.state = state;
    }

    @JsonProperty("StayInTouchNote")
    public Object getStayInTouchNote() {
        return stayInTouchNote;
    }

    @JsonProperty("StayInTouchNote")
    public void setStayInTouchNote(Object stayInTouchNote) {
        this.stayInTouchNote = stayInTouchNote;
    }

    @JsonProperty("StayInTouchSignature")
    public Object getStayInTouchSignature() {
        return stayInTouchSignature;
    }

    @JsonProperty("StayInTouchSignature")
    public void setStayInTouchSignature(Object stayInTouchSignature) {
        this.stayInTouchSignature = stayInTouchSignature;
    }

    @JsonProperty("StayInTouchSubject")
    public Object getStayInTouchSubject() {
        return stayInTouchSubject;
    }

    @JsonProperty("StayInTouchSubject")
    public void setStayInTouchSubject(Object stayInTouchSubject) {
        this.stayInTouchSubject = stayInTouchSubject;
    }

    @JsonProperty("Street")
    public String getStreet() {
        return street;
    }

    @JsonProperty("Street")
    public void setStreet(String street) {
        this.street = street;
    }

    @JsonProperty("SystemModstamp")
    public String getSystemModstamp() {
        return systemModstamp;
    }

    @JsonProperty("SystemModstamp")
    public void setSystemModstamp(String systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    @JsonProperty("AEM__Aem_User_Type")
    public Object getAEMAemUserType() {
        return aEMAemUserType;
    }

    @JsonProperty("AEM__Aem_User_Type")
    public void setAEMAemUserType(Object aEMAemUserType) {
        this.aEMAemUserType = aEMAemUserType;
    }

    @JsonProperty("Create_New_Employee")
    public Boolean getCreateNewEmployee() {
        return createNewEmployee;
    }

    @JsonProperty("Create_New_Employee")
    public void setCreateNewEmployee(Boolean createNewEmployee) {
        this.createNewEmployee = createNewEmployee;
    }

    @JsonProperty("Delegated_Employee")
    public Object getDelegatedEmployee() {
        return delegatedEmployee;
    }

    @JsonProperty("Delegated_Employee")
    public void setDelegatedEmployee(Object delegatedEmployee) {
        this.delegatedEmployee = delegatedEmployee;
    }

    @JsonProperty("Delegated_User_Id")
    public Object getDelegatedUserId() {
        return delegatedUserId;
    }

    @JsonProperty("Delegated_User_Id")
    public void setDelegatedUserId(Object delegatedUserId) {
        this.delegatedUserId = delegatedUserId;
    }

    @JsonProperty("Delegated_User")
    public Object getDelegatedUser() {
        return delegatedUser;
    }

    @JsonProperty("Delegated_User")
    public void setDelegatedUser(Object delegatedUser) {
        this.delegatedUser = delegatedUser;
    }

    @JsonProperty("Employee_Id")
    public String getEmployeeId() {
        return employeeId;
    }

    @JsonProperty("Employee_Id")
    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    @JsonProperty("Other_Phone_Numbers")
    public Object getOtherPhoneNumbers() {
        return otherPhoneNumbers;
    }

    @JsonProperty("Other_Phone_Numbers")
    public void setOtherPhoneNumbers(Object otherPhoneNumbers) {
        this.otherPhoneNumbers = otherPhoneNumbers;
    }

    @JsonProperty("Session_Id")
    public Object getSessionId() {
        return sessionId;
    }

    @JsonProperty("Session_Id")
    public void setSessionId(Object sessionId) {
        this.sessionId = sessionId;
    }

    @JsonProperty("Telephony_Password")
    public Object getTelephonyPassword() {
        return telephonyPassword;
    }

    @JsonProperty("Telephony_Password")
    public void setTelephonyPassword(Object telephonyPassword) {
        this.telephonyPassword = telephonyPassword;
    }

    @JsonProperty("Telephony_Username")
    public Object getTelephonyUsername() {
        return telephonyUsername;
    }

    @JsonProperty("Telephony_Username")
    public void setTelephonyUsername(Object telephonyUsername) {
        this.telephonyUsername = telephonyUsername;
    }

    @JsonProperty("User_Empl_Active_Status_Mismatch")
    public Boolean getUserEmplActiveStatusMismatch() {
        return userEmplActiveStatusMismatch;
    }

    @JsonProperty("User_Empl_Active_Status_Mismatch")
    public void setUserEmplActiveStatusMismatch(Boolean userEmplActiveStatusMismatch) {
        this.userEmplActiveStatusMismatch = userEmplActiveStatusMismatch;
    }

    @JsonProperty("FR__Feature_Administrator")
    public Object getFRFeatureAdministrator() {
        return fRFeatureAdministrator;
    }

    @JsonProperty("FR__Feature_Administrator")
    public void setFRFeatureAdministrator(Object fRFeatureAdministrator) {
        this.fRFeatureAdministrator = fRFeatureAdministrator;
    }

    @JsonProperty("TimeZoneSidKey")
    public String getTimeZoneSidKey() {
        return timeZoneSidKey;
    }

    @JsonProperty("TimeZoneSidKey")
    public void setTimeZoneSidKey(String timeZoneSidKey) {
        this.timeZoneSidKey = timeZoneSidKey;
    }

    @JsonProperty("Title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("Title")
    public void setTitle(String title) {
        this.title = title;
    }

    @JsonProperty("Username")
    public String getUsername() {
        return username;
    }

    @JsonProperty("Username")
    public void setUsername(String username) {
        this.username = username;
    }

    @JsonProperty("UserRoleId")
    public String getUserRoleId() {
        return userRoleId;
    }

    @JsonProperty("UserRoleId")
    public void setUserRoleId(String userRoleId) {
        this.userRoleId = userRoleId;
    }

    @JsonProperty("UserType")
    public String getUserType() {
        return userType;
    }

    @JsonProperty("UserType")
    public void setUserType(String userType) {
        this.userType = userType;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("User{");
        sb.append("aboutMe=").append(aboutMe);
        sb.append(", account=").append(account);
        sb.append(", address=").append(address);
        sb.append(", alias='").append(alias).append('\'');
        sb.append(", analyst=").append(analyst);
        sb.append(", badgeText='").append(badgeText).append('\'');
        sb.append(", bannerPhotoUrl='").append(bannerPhotoUrl).append('\'');
        sb.append(", callCenterId='").append(callCenterId).append('\'');
        sb.append(", city='").append(city).append('\'');
        sb.append(", communityNickname='").append(communityNickname).append('\'');
        sb.append(", companyName='").append(companyName).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", country='").append(country).append('\'');
        sb.append(", createdById='").append(createdById).append('\'');
        sb.append(", createdDate='").append(createdDate).append('\'');
        sb.append(", createDataAgainstCoverage=").append(createDataAgainstCoverage);
        sb.append(", defaultGroupNotificationFrequency='").append(defaultGroupNotificationFrequency).append('\'');
        sb.append(", delegatedApproverId=").append(delegatedApproverId);
        sb.append(", department='").append(department).append('\'');
        sb.append(", digestFrequency='").append(digestFrequency).append('\'');
        sb.append(", division='").append(division).append('\'');
        sb.append(", eCDId='").append(eCDId).append('\'');
        sb.append(", eCDURL='").append(eCDURL).append('\'');
        sb.append(", email='").append(email).append('\'');
        sb.append(", emailEncodingKey='").append(emailEncodingKey).append('\'');
        sb.append(", emailPreferencesAutoBcc=").append(emailPreferencesAutoBcc);
        sb.append(", emailPreferencesAutoBccStayInTouch=").append(emailPreferencesAutoBccStayInTouch);
        sb.append(", emailPreferencesStayInTouchReminder=").append(emailPreferencesStayInTouchReminder);
        sb.append(", employeeNumber='").append(employeeNumber).append('\'');
        sb.append(", extension='").append(extension).append('\'');
        sb.append(", id='").append(id).append('\'');
        sb.append(", fax='").append(fax).append('\'');
        sb.append(", federationIdentifier=").append(federationIdentifier);
        sb.append(", firstName='").append(firstName).append('\'');
        sb.append(", forecastEnabled=").append(forecastEnabled);
        sb.append(", fullPhotoUrl='").append(fullPhotoUrl).append('\'');
        sb.append(", geocodeAccuracy=").append(geocodeAccuracy);
        sb.append(", id18='").append(id18).append('\'');
        sb.append(", isActive=").append(isActive);
        sb.append(", isProfilePhotoActive=").append(isProfilePhotoActive);
        sb.append(", languageLocaleKey='").append(languageLocaleKey).append('\'');
        sb.append(", lastLoginDate='").append(lastLoginDate).append('\'');
        sb.append(", lastModifiedById='").append(lastModifiedById).append('\'');
        sb.append(", lastModifiedDate='").append(lastModifiedDate).append('\'');
        sb.append(", lastName='").append(lastName).append('\'');
        sb.append(", lastPasswordChangeDate='").append(lastPasswordChangeDate).append('\'');
        sb.append(", latitude=").append(latitude);
        sb.append(", localeSidKey='").append(localeSidKey).append('\'');
        sb.append(", longitude=").append(longitude);
        sb.append(", managerId='").append(managerId).append('\'');
        sb.append(", middleName='").append(middleName).append('\'');
        sb.append(", mobilePhone='").append(mobilePhone).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", offlinePdaTrialExpirationDate=").append(offlinePdaTrialExpirationDate);
        sb.append(", offlineTrialExpirationDate=").append(offlineTrialExpirationDate);
        sb.append(", phone='").append(phone).append('\'');
        sb.append(", postalCode='").append(postalCode).append('\'');
        sb.append(", profile=").append(profile);
        sb.append(", receivesAdminInfoEmails=").append(receivesAdminInfoEmails);
        sb.append(", receivesInfoEmails=").append(receivesInfoEmails);
        sb.append(", senderEmail='").append(senderEmail).append('\'');
        sb.append(", senderName='").append(senderName).append('\'');
        sb.append(", signature=").append(signature);
        sb.append(", state='").append(state).append('\'');
        sb.append(", stayInTouchNote=").append(stayInTouchNote);
        sb.append(", stayInTouchSignature=").append(stayInTouchSignature);
        sb.append(", stayInTouchSubject=").append(stayInTouchSubject);
        sb.append(", street='").append(street).append('\'');
        sb.append(", systemModstamp='").append(systemModstamp).append('\'');
        sb.append(", aEMAemUserType=").append(aEMAemUserType);
        sb.append(", createNewEmployee=").append(createNewEmployee);
        sb.append(", delegatedEmployee=").append(delegatedEmployee);
        sb.append(", delegatedUserId=").append(delegatedUserId);
        sb.append(", delegatedUser=").append(delegatedUser);
        sb.append(", employeeId='").append(employeeId).append('\'');
        sb.append(", otherPhoneNumbers=").append(otherPhoneNumbers);
        sb.append(", sessionId=").append(sessionId);
        sb.append(", telephonyPassword=").append(telephonyPassword);
        sb.append(", telephonyUsername=").append(telephonyUsername);
        sb.append(", userEmplActiveStatusMismatch=").append(userEmplActiveStatusMismatch);
        sb.append(", fRFeatureAdministrator=").append(fRFeatureAdministrator);
        sb.append(", timeZoneSidKey='").append(timeZoneSidKey).append('\'');
        sb.append(", title='").append(title).append('\'');
        sb.append(", username='").append(username).append('\'');
        sb.append(", userRoleId='").append(userRoleId).append('\'');
        sb.append(", userType='").append(userType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
