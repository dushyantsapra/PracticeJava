package com.nwm.xmart.streaming.source.kdb.data;



import com.nwm.xmart.streaming.source.kdb.parameters.DateParameterUtil;

import java.time.LocalDate;
import java.util.*;

/**
 * Created by gardlex on 05/06/2018.
 */
public class RepairDatesPropertyParser {

    public static List<String> getRepairDatesFrom(String repairDates) {
        StringTokenizer repairDatesTokenizer = new StringTokenizer(repairDates, ",");
        List<LocalDate> sortedRepairDates = new ArrayList<>();

        while (repairDatesTokenizer.hasMoreTokens()) {
            LocalDate repairDate = DateParameterUtil.getLocalDateFor(repairDatesTokenizer.nextToken());
            sortedRepairDates.add(repairDate);
        }

        Collections.sort(sortedRepairDates);
        List<String> repairDatesStrList = new ArrayList<>();
        for (LocalDate date : sortedRepairDates) {
            repairDatesStrList.add(date.toString().replaceAll("-", "."));
        }

        return repairDatesStrList;
    }

}
