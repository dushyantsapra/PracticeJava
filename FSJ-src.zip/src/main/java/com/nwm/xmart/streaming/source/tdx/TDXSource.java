package com.nwm.xmart.streaming.source.tdx;

/**
 * Created by gardlex on 08/10/2018.
 */

import com.nwm.xmart.streaming.source.tdx.consumer.TDXConsumer;
import com.nwm.xmart.streaming.source.tdx.exception.TDXSourceException;
import com.tdx.client.api.exception.TDXDatasetEventConsumptionException;
import com.tdx.client.api.streams.TDXDatasetStreamEvent;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.slf4j.Logger;
import com.tdx.client.api.*;
import com.tdx.client.api.streams.TDXDatasetEventStream;
import com.tdx.client.api.streams.TDXDatasetEventStreamSubscription;
import com.tdx.client.core.TDXClientFactories;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.slf4j.LoggerFactory;

import java.util.Iterator;

import static com.nwm.xmart.streaming.sso.GenerateSSOToken.getSsoToken;
import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

/**
 * Created by gardlex on 04/10/2018.
 */
public class TDXSource<TDXSourceEvent>
        extends RichParallelSourceFunction<TDXSourceEvent> implements CheckpointedFunction, CheckpointListener {

    private static Logger logger = LoggerFactory.getLogger(TDXSource.class);
    private transient ListState<String> tdxState;
    private volatile String restoredEventSequenceId;
    private volatile TDXDatasetStreamEvent lastEventEmittedToStream;
    private final String tdxSourceName;
    private volatile Exception checkpointException;
    private String consumerGroupID;
    private String tag;
    private volatile String startingEventSequenceIdOverride;

    private volatile String dataSetId;
    private volatile String stateName;
    private transient SsoTokenSupplier ssoTokenSupplier;
    private transient TDXClientFactory clientFactory;
    private transient TDXClientConfiguration clientConfiguration;
    private volatile transient TDXConsumer tdxConsumer;
    private volatile TDXDatasetEventStreamSubscription datasetStreamSubscription;

    public TDXSource(String tdxSourceName) {
        this.tdxSourceName = tdxSourceName;
    }

    @Override
    public void run(SourceContext<TDXSourceEvent> ctx) throws Exception {
        // Get Flink job params
        ParameterTool parameter = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        //MDC
        putJobNameInMDC(parameter);

        // TDX Consumer
        tdxConsumer = new TDXConsumer(ctx, dataSetId);

        // TDX subscription
        TDXDatasetEventStream datasetStream = null;
        datasetStreamSubscription = null;

        TDXClient tdxClient = clientFactory.create(clientConfiguration, ssoTokenSupplier);

        Iterable<TDXDatasetEventStream> streams = tdxClient.findDatasetEventStreams(TDXDatasetEventStreamDescriptor.newBuilder()
                .setDatasetId(dataSetId)
                .setTag(tag)
                .build());

        Iterator<TDXDatasetEventStream> streamsIterator = streams.iterator();

        if (streamsIterator.hasNext()) {
            datasetStream = streamsIterator.next();
        }

        validateDatasetStream(datasetStream, streamsIterator);

        // Start the stream at the correct offset / eventSequenceId
        TDXDatasetEventStream.From fromStreamPosition = null;
        fromStreamPosition = defineStreamStartingPoint();

        // start the stream
        datasetStreamSubscription = datasetStream.start(
                fromStreamPosition,
                tdxConsumer,
                TDXDatasetEventStreamAdvancedConfiguration.newBuilder()
                        .setGroupId(consumerGroupID)
                        .build());


        // wait indefinitely until the stream terminates
        logger.info("About to enter wait state in run()");
        tdxConsumer.waitForStreamTermination();
        logger.info("TDXConsumer has stopped in TDXSource.run()");

        if (tdxConsumer.getError() != null) {
            throw new TDXSourceException("TDXConsumer failed", tdxConsumer.getError());
        }

        if (checkpointException != null) {
            throw checkpointException;
        }
    }

    /**
     *
     *
     * @return the position to start the stream From
     */
    private TDXDatasetEventStream.From defineStreamStartingPoint() {
        TDXDatasetEventStream.From fromStreamPosition;
        if (restoredEventSequenceId != null) {
            fromStreamPosition = TDXDatasetEventStream.From.eventSequenceId(restoredEventSequenceId);
            logger.info("Starting the fromStreamPosition from RESTORED eventSequenceId [ " + restoredEventSequenceId + " ]");
        } else {
            if (StringUtils.isNotEmpty(startingEventSequenceIdOverride)) {
                fromStreamPosition = TDXDatasetEventStream.From.eventSequenceId(startingEventSequenceIdOverride);
                logger.info("Starting the fromStreamPosition from OVERRIDDEN eventSequenceId  [ " + startingEventSequenceIdOverride + " ]");
            } else {
                throw new TDXSourceException("Not starting from a checkpoint OR an offset override can cause loss of data. Must resume job from a checkpoint or specify an offset to start from using the property: tdx.event.sequence.id.override");
            }
        }
        return fromStreamPosition;
    }

    private void validateDatasetStream(TDXDatasetEventStream datasetStream, Iterator<TDXDatasetEventStream> streamsIterator) {
        if (datasetStream == null) {
            throw new TDXSourceException("DataSetStream not found");
        }

        if (streamsIterator.hasNext()) {
            throw new TDXSourceException("Too many streams found");
        }
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        ParameterTool params = (ParameterTool)getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        //MDC
        putJobNameInMDC(params);
        clientFactory = TDXClientFactories.forProtocol(TDXProtocol.TCP);
        clientConfiguration = TDXClientConfiguration.newBuilder()
                .setConnectionString(params.get("tdx.env",""))
                .build();
        logger.info("TDXClientConfiguration built with connectionString = " + clientConfiguration.getConnectionString());

        // Use lambada function to set supply function to return getSSoToken
        ssoTokenSupplier = () -> getSsoToken(params);

        // stream properties
        dataSetId = params.get("tdx.datasetid","");
        consumerGroupID = params.get("tdx.consumer.group.id","");
        tag = params.get("tdx.dataset.tag","");
        startingEventSequenceIdOverride = params.get("tdx.event.sequence.id.override","");
    }

    @Override
    public void close() {
        datasetStreamSubscription.unsubscribe();
    }

    @Override
    public void cancel() {
        tdxConsumer.stopConsumingEvents();
    }

    @Override
    public void snapshotState(FunctionSnapshotContext context) throws Exception {
        ParameterTool params = (ParameterTool)getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        // MDC logging
        putJobNameInMDC(params);

        // Fetch the last event emitted into the stream prior to snapshot barrier
        // NOTE, this method holds the checkpoint lock when it is called.
        lastEventEmittedToStream = tdxConsumer.getCurrentEventForSnapshot();

        if (lastEventEmittedToStream != null) {
            tdxState.clear();
            tdxState.add(lastEventEmittedToStream.getEventSequenceId());
            logger.info("Checkpoint requested, currentStreamEventSequenceId=" + lastEventEmittedToStream.getEventSequenceId());
        } else {
            logger.info("Checkpoint requested, but no update to state");
        }
    }

    @Override
    public void initializeState(FunctionInitializationContext context) throws Exception {
        // Flink Params
        ParameterTool params = (ParameterTool)getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        //MDC
        putJobNameInMDC(params);

        // retrieve state
        stateName = "TDX-" + tdxSourceName + "-" + dataSetId;
        tdxState = context
                .getOperatorStateStore()
                .getListState(new ListStateDescriptor<String>(stateName, String.class));

        if (context.isRestored()) {
            for (String eventSequenceId : tdxState.get()) {
                this.restoredEventSequenceId = eventSequenceId;
            }

            if (restoredEventSequenceId != null) {
                logger.info("State restored, stateName = " + stateName + ", restoredEventSequenceId = " + restoredEventSequenceId);
            }
        } else {
            logger.info("State initialized, stateName = " + stateName);
        }
    }

    @Override
    public void notifyCheckpointComplete(long checkpointId) {
        try {
            // Commit the offset for the last event recorded in the snapshot
            lastEventEmittedToStream.markAsConsumed();
            logger.info("Committed Offset for checkpointID = " + checkpointId + ", eventSequenceId = " + lastEventEmittedToStream.getEventSequenceId());
        } catch (TDXDatasetEventConsumptionException e) {
            logger.error("TDXConsumer failed when marking event as consumed.", e);
            checkpointException = e;
            tdxConsumer.stopConsumingEvents();
        }
    }
}
