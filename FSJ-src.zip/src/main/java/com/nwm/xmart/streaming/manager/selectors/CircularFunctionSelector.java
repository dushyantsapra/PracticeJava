package com.nwm.xmart.streaming.manager.selectors;

import com.nwm.xmart.streaming.manager.settings.FunctionSettings;

import java.util.LinkedList;
import java.util.Map;


public class CircularFunctionSelector implements FunctionSelector {
    private final LinkedList<String> circularFunctionList = new LinkedList();
    private final Map<String, LinkedList<String>> functionProcessingDays;
    private Map<String, Object> extraParameters;

    public CircularFunctionSelector(Map<String, LinkedList<String>> functionProcessingDays, Map<String, Object> extraParameters) {
        this.extraParameters = extraParameters;
        this.functionProcessingDays = functionProcessingDays;
        for (Map.Entry<String, LinkedList<String>> entry : functionProcessingDays.entrySet()) {
            String key = entry.getKey();
            LinkedList<String> value = entry.getValue();
            if (value != null && value.size() > 0) {
                circularFunctionList.add(key);
            }
        }
    }

    public FunctionSettings getNext() {
        FunctionSettings results = null;

        if (isFunctionProcessingDayAvailable()) {
            String functionName = getNextFunctionToProcess();
            String day = getNextProcessingDayForFunction(functionName);

            results = new FunctionSettings(functionName, day)
                    .withExtraParameters(extraParameters);
        }

        return results;
    }

    public void remove(String functionName) {
        circularFunctionList.remove(functionName);
        functionProcessingDays.remove(functionName);
    }

    private boolean isFunctionProcessingDayAvailable() {
        return circularFunctionList.size() > 0;

    }

    private String getNextFunctionToProcess() {
        String nextFunction = circularFunctionList.getFirst();
        circularFunctionList.addLast(nextFunction);
        circularFunctionList.removeFirst();
        return nextFunction;
    }

    private String getNextProcessingDayForFunction(String functionName) {
        LinkedList<String> processingDays = functionProcessingDays.get(functionName);
        String nextProcessingDay = processingDays.removeFirst();
        if (processingDays.size() == 0) {
            functionProcessingDays.remove(functionName);
            circularFunctionList.removeLast();
        }

        return nextProcessingDay;
    }
}

