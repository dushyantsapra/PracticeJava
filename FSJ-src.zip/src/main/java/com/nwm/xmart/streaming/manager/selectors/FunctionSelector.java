package com.nwm.xmart.streaming.manager.selectors;

import com.nwm.xmart.streaming.manager.settings.FunctionSettings;

public interface FunctionSelector {
    FunctionSettings getNext();

    void remove(String functionName);
}
