package com.nwm.xmart.streaming.source.crm.entity.accountCoverage;

import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Name", "Default_City" })
public class CoverageRegion implements Serializable {
    private static final long serialVersionUID = 337971527272167337L;

    @JsonProperty("Name")
    private String name;
    @JsonProperty("Default_City")
    private DefaultCity defaultCity;

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("Default_City")
    public DefaultCity getDefaultCity() {
        return defaultCity;
    }

    @JsonProperty("Default_City")
    public void setDefaultCity(DefaultCity defaultCity) {
        this.defaultCity = defaultCity;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CoverageRegion{");
        sb.append("name='").append(name).append('\'');
        sb.append(", defaultCity=").append(defaultCity);
        sb.append('}');
        return sb.toString();
    }
}
