package com.nwm.xmart.streaming.source.mdx.sorting;

import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;

import java.util.Comparator;

/**
 * Compares the xml write time of two {@link MdxDocumentEvent}'s. The xml write time is converted
 * to a long timestamp (EpochMilli) and ordered in ascending order.
 *
 * Created by gardlex on 09/04/2018.
 */
public class WriteTimeComparator<MdxSourceEvent> implements Comparator<MdxSourceEvent> {
    @Override
    public int compare(MdxSourceEvent o1, MdxSourceEvent o2) {
        return Long.compare(((MdxDocumentEvent)o1).getEpochMdxDataStoreWriteTime(), ((MdxDocumentEvent)o2).getEpochMdxDataStoreWriteTime());
    }
}
