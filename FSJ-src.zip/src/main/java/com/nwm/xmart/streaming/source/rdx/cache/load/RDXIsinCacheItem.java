package com.nwm.xmart.streaming.source.rdx.cache.load;

import com.nwm.xmart.streaming.source.mdx.cache.load.CacheItem;
import rbs.gbm.dx.webService.impl.DxValuationDate;

/**
 * Created by gardlex on 13/05/2018.
 */
public class RDXIsinCacheItem implements CacheItem {
    private final String identifier;
    private final DxValuationDate dxValuationDate;
    private final Integer version;

    public RDXIsinCacheItem(String identifier, DxValuationDate dxValuationDate, Integer version) {
        this.identifier = identifier;
        this.dxValuationDate = dxValuationDate;
        this.version = version;
    }

    @Override
    public String getIdentifier() {
        return identifier;
    }

    public DxValuationDate getDxValuationDate() {
        return dxValuationDate;
    }

    public Integer getVersion() {
        return version;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("RDXIsinCacheItem{");
        sb.append("identifier='").append(identifier).append('\'');
        sb.append(", dxValuationDate=").append(dxValuationDate);
        sb.append(", version=").append(version);
        sb.append('}');
        return sb.toString();
    }
}
