package com.nwm.xmart.streaming.source.mdx.cache.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class ISINCacheException extends RuntimeException {

    public ISINCacheException() {
        super();
    }

    public ISINCacheException(String msg) {
        super(msg);
    }

    public ISINCacheException(String msg, Throwable t) {
        super(msg, t);
    }
}
