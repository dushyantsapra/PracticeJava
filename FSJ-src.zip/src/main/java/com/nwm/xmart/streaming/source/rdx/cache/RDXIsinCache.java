package com.nwm.xmart.streaming.source.rdx.cache;

import com.nwm.xmart.streaming.source.mdx.cache.IsinCache;
import com.nwm.xmart.streaming.source.mdx.cache.load.CacheItem;
import com.nwm.xmart.streaming.source.mdx.cache.load.ISINCacheLoader;
import com.nwm.xmart.streaming.source.rdx.cache.load.RDXIsinCacheItem;
import org.apache.flink.api.java.utils.ParameterTool;

/**
 * @NotThreadSafe
 *
 *
 * Created by gardlex on 11/05/2018.
 */
public class RDXIsinCache extends IsinCache {

    public RDXIsinCache(ISINCacheLoader isinCacheLoader, String sourceName, ParameterTool flinkParams) {
        super(sourceName, flinkParams, isinCacheLoader);
    }

    @Override
    public Integer getCachedVersionForISIN(String isin) {
        return ((RDXIsinCacheItem)isinMap.get(isin)).getVersion();
    }

    @Override
    public boolean putISINCacheItem(CacheItem newCacheItem) {

        CacheItem cachedItem = isinMap.get(newCacheItem.getIdentifier());
        RDXIsinCacheItem rdxCurrentIsinCacheItem = (cachedItem == null) ? null : (RDXIsinCacheItem) cachedItem;
        RDXIsinCacheItem newRdxIsinCacheItem = (RDXIsinCacheItem) newCacheItem;

        // if new version of mdxDocment has been received, then insert into ISIN map.
        if (rdxCurrentIsinCacheItem == null || rdxCurrentIsinCacheItem.getDxValuationDate().isBefore(newRdxIsinCacheItem.getDxValuationDate())) {
            isinMap.put(newRdxIsinCacheItem.getIdentifier(), newRdxIsinCacheItem);
            return true;
        }

        // if it's an earlier version then reject
        if (rdxCurrentIsinCacheItem.getDxValuationDate().isAfter(newRdxIsinCacheItem.getDxValuationDate())) {
            return false;
        }

        // existing item but version is the same so compare xmlWriteTime
        if (rdxCurrentIsinCacheItem.getDxValuationDate().compareTo(newRdxIsinCacheItem.getDxValuationDate()) == 0) {
            if (rdxCurrentIsinCacheItem.getVersion() < newRdxIsinCacheItem.getVersion()) {
                isinMap.put(newRdxIsinCacheItem.getIdentifier(), newRdxIsinCacheItem);
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}
