package com.nwm.xmart.streaming.database.statements.xmartsession;

import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.nwm.xmart.streaming.database.session.XmartSession;
import com.nwm.xmart.streaming.database.statements.XmartStatement;

import java.sql.*;

public class GetXmartSessionStatement extends XmartStatement {

    public GetXmartSessionStatement() {
        super();

        statementName = "usp_ExtractSessionStart";
        PROC_COMMAND = "EXEC [fwk].[usp_ExtractSessionStart] ?,?,?,?";
    }

    @Override
    public SQLServerCallableStatement getPreparedStatement(Object obj) throws SQLException {

        clearPreparedStatement();

        XmartSession session = (XmartSession) obj;

        preparedStatement.setString(1, session.getPayloadHandlerName());
        preparedStatement.setString(2, session.getSessionName());
        preparedStatement.setDateTime(3, Timestamp.valueOf(session.getInitialDateTime()));
        preparedStatement.registerOutParameter(4, Types.INTEGER);

        return preparedStatement;
    }
}
