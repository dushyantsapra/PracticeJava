package com.nwm.xmart.streaming.source.df.serialisation;

import com.nwm.xmart.streaming.error.exception.DeserialisationException;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import com.rbs.datafabric.common.serialization.DataFabricSerializer;
import com.rbs.datafabric.domain.Record;
import com.rbs.datafabric.domain.event.RecordModifiedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by gardlex on 30/10/2017.
 */
public class DFSourceDeserializer implements SourceDeserializer {

    private static Logger logger = LoggerFactory.getLogger(DFSourceDeserializer.class);
    private DataFabricSerializer dataFabricSerializer;
    private final DataFabricUtil dataFabricUtil;

    public DFSourceDeserializer(DataFabricUtil dataFabricUtil) {
        this.dataFabricUtil = dataFabricUtil;
    }

    @Override
    public <Target> Target deserialize(RecordModifiedEvent recordModifiedEvent, Class<Target> targetClass) {
        Target target = null;

        try {
            checkDataFabricInstanceExists();
            target = dataFabricSerializer.deserialize(recordModifiedEvent.getRecord().getDocument(), targetClass);
        } catch (Exception e) {
            logger.error("DFSourceDeserializer error", e);
            throw new DeserialisationException("DFSourceDeserializer: could not deserialise DF Record", e);
        }

        return target;
    }

    @Override
    public <Target> Target deserialize(Record record, Class<Target> targetClass) {
        Target target = null;

        try {
            checkDataFabricInstanceExists();
            target = dataFabricSerializer.deserialize(record.getDocument(), targetClass);
        } catch (Exception e) {
            logger.error("DFSourceDeserializer error", e);
            throw new DeserialisationException("DFSourceDeserializer: could not deserialise DF Record", e);
        }

        return target;
    }

    private void checkDataFabricInstanceExists() {
        if (dataFabricSerializer == null) {
            this.dataFabricSerializer = dataFabricUtil.getDataFabricDeserializerInstance();
        }
    }
}
