package com.nwm.xmart.streaming.example;

import com.nwm.xmart.sso.EncryptDecryptAES;
import com.nwm.xmart.streaming.common.job.StreamJob;
import com.nwm.xmart.streaming.source.rdx.RdxSource;
import com.nwm.xmart.streaming.source.rdx.event.RDXSourceEvent;
import com.rbs.datafabric.client.DataFabricClient;
import com.rbs.datafabric.client.DataFabricClientFactory;
import com.rbs.datafabric.domain.ClientConfiguration;
import com.rbs.datafabric.domain.Credentials;
import com.rbs.datafabric.domain.Document;
import com.rbs.datafabric.domain.client.builder.InsertRequestBuilder;

import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * Created by gardlex on 18/10/2017.
 */
public class CheckpointedRDXSourceTest {

    private static Logger logger = LoggerFactory.getLogger(CheckpointedRDXSourceTest.class);

    public static void main(String[] args) throws Exception {

        // Populate cache with 10 stream events
        CheckpointedRDXSourceTest t = new CheckpointedRDXSourceTest();
        t.buildStream(args);

    }

    public void buildStream(String[] args) throws Exception {
        // StreamJob implementation can override any abstract methid as long as it calls super() first
        RdxStreamJob streamJob = new RdxStreamJob();
        streamJob.run(args);
    }

    class RdxStreamJob extends StreamJob {

        @Override
        protected void configureAndExecuteStream(StreamExecutionEnvironment env) {

            try {
            // Type info reqd for the FlinkDeserializer
            final TypeInformation<RDXSourceEvent> rdxSourceEventType = TypeInformation.of(new TypeHint<RDXSourceEvent>(){});
            Class<RDXSourceEvent> rdxSourceClassRef = rdxSourceEventType.getTypeClass();

//            String pathLocation = "C:\\DEV\\flink-sources-investigation\\Files";
//            Path path = new Path(pathLocation);
//
//            TextInputFormat format = new TextInputFormat(path);

            // Configuration of the stream
            DataStream<RDXSourceEvent> input = env
                    .addSource(new RdxSource<RDXSourceEvent>(rdxSourceClassRef, parameters.get("rdx.src.sourceName")), rdxSourceEventType)
                    .uid("RDX_FIXED_INCOME")
                    .name("RDX_FIXED_INCOME")
                    .setParallelism(1);
            input.addSink(new TestSink())
                    .uid("RDX-TestSink")
                    .name("RDX-TestSink")
                    .setParallelism(1);
            env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);


                String execPlan = env.getExecutionPlan();
                logger.info("EXECUTION PLAN = " + execPlan);
                env.execute(configuration.getString("flink.job.name",""));
            } catch (Exception e) {
                logger.error("Exception running the ExampleODCFlinkJob",e);
                throw new RuntimeException(e);
            }
        }
    }

    class TestSink extends RichSinkFunction<RDXSourceEvent> implements CheckpointListener {

        private Logger logger = LoggerFactory.getLogger(TestSink.class);
        private DataFabricClient dataFabricClient;

        private int ctr;

        public TestSink() throws IOException {
        }

        @Override
        public void notifyCheckpointComplete(long checkpointId) throws Exception {
            logger.info("Checkpoint RECD = " + checkpointId);
        }

        @Override
        public void invoke(RDXSourceEvent event) throws Exception {
            Document document = dataFabricClient.getDataFabricSerializer().serialize(event);
            dataFabricClient.insert(InsertRequestBuilder.create("session-db", "session-rdx-isin").withDocument(document));
        }

        @Override
        public void open(Configuration parameters) throws Exception {
            dataFabricClient = getDFC();
        }

        private DataFabricClient getDFC() throws Exception {
            // TST
            ClientConfiguration clientConfiguration = new ClientConfiguration().withCredentials(new Credentials().withUsername("svc-XMartAppUat")
                    .withPassword(EncryptDecryptAES.decrypt("Gl6c8x+8lGbkwF0HWPDRSg==")))
                    .withHost("DATAFABRIC-TST")
                    .withAccessToken(EncryptDecryptAES.decrypt("9k1IyB07YGjc1r5rQf1MgrdZH6XNdr1WT0UEWLz1XmVX7tupKZdtPA2t/iljneNe"));

            DataFabricClient dataFabricClient = DataFabricClientFactory.createDataFabricClient(clientConfiguration);
            return dataFabricClient;
        }
    }

}
