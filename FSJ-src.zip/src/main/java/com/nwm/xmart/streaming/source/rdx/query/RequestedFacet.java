package com.nwm.xmart.streaming.source.rdx.query;

import java.util.Arrays;

/**
 * Created by gardlex on 21/05/2018.
 */
public class RequestedFacet {
    private final String facetName;
    private final String[] facetAttributes;

    public RequestedFacet(String facetName, String[] facetAttributes) {
        this.facetName = facetName;
        this.facetAttributes = facetAttributes;
    }

    public String getFacetName() {
        return facetName;
    }

    public String[] getFacetAttributes() {
        return facetAttributes;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("RequestedFacet{");
        sb.append("facetName='").append(facetName).append('\'');
        sb.append(", facetAttributes=").append(Arrays.toString(facetAttributes));
        sb.append('}');
        return sb.toString();
    }
}
