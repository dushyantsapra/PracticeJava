package com.nwm.xmart.streaming.manager;

import com.nwm.xmart.streaming.database.exceptions.XmartSqlServerException;
import com.nwm.xmart.streaming.manager.enums.ProcessingMode;
import com.nwm.xmart.streaming.manager.exceptions.SourceManagerException;
import com.nwm.xmart.streaming.manager.results.ProcessingResults;
import com.nwm.xmart.streaming.manager.results.ProcessingResultsTracker;
import com.nwm.xmart.streaming.manager.selectors.CircularFunctionSelector;
import com.nwm.xmart.streaming.manager.selectors.FunctionSelector;
import com.nwm.xmart.streaming.manager.settings.FunctionSettings;
import com.nwm.xmart.streaming.manager.settings.SourceManagerParameters;
import com.nwm.xmart.streaming.manager.utils.ProcessingDateUtil;
import com.nwm.xmart.streaming.manager.utils.SourceManagerSqlUtil;
import com.nwm.xmart.streaming.manager.utils.SourceManagerSqlUtilInterface;
import org.apache.flink.api.java.utils.ParameterTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

public class SourceManager<T> {
    private static Logger logger = LoggerFactory.getLogger(SourceManager.class);
    private final ParameterTool params;
    private SourceManagerSqlUtilInterface sourceManagerSqlUtil = new SourceManagerSqlUtil();
    private Map<String, Object> extraParameters = new HashMap<>();

    public SourceManager(ParameterTool params) {
        this.params = params;
    }

    public SourceManager<T> withSourceManagerSqlUtil(SourceManagerSqlUtilInterface sourceManagerSqlUtil) {
        this.sourceManagerSqlUtil = sourceManagerSqlUtil;
        return this;
    }

    public SourceManager<T> withExtraParameters(Map<String, Object> extraParameters) {
        this.extraParameters = extraParameters;
        return this;
    }

    public void run(Function<FunctionSettings, ProcessingResults> function) {

        Map<String, ProcessingResultsTracker> functionProcessingResultsMap = createProcessingResultsMap();

        FunctionSelector functionSelector = null;
        boolean functionException = false;

        try {
            functionSelector = createFunctionSelector();
        } catch (XmartSqlServerException e) {
            throw new SourceManagerException("Failure creating function selector.", e);
        }

        // Get the next or in this case first settings. Settings contain function name and date to run
        FunctionSettings functionSettings = functionSelector.getNext();
        while (functionSettings != null) {
            ProcessingResults processingResults = null;
            try {
                processingResults = function.apply(functionSettings);
                functionSelector = updateProcessState(processingResults, functionSettings, functionSelector);
            } catch (Exception ex) {
                functionException = true;
                logger.error("error while processing function: " + functionSettings.getFunctionName());
                logger.error(ex.toString());
                logger.error("removing function from list: " + functionSettings.getFunctionName());
                functionSelector.remove(functionSettings.getFunctionName());
                processingResults = null; // set to null in case error during update Process State
            }
            functionProcessingResultsMap = updateProcessingResults(processingResults, functionSettings, functionProcessingResultsMap);
            functionSettings = functionSelector.getNext();
        }

        printProcessingResults(functionProcessingResultsMap);
        waitBeforeShutdown();
        if(functionException){
            throw new SourceManagerException("A failure occurred processing one or more of the functions included in this source. Review log file for more details.");
        }
    }

    private FunctionSelector createFunctionSelector() throws XmartSqlServerException {
        // get processing days
        Map<String, LinkedList<String>> functionProcessingDays = ProcessingDateUtil.getProcessingDays(params, sourceManagerSqlUtil);

        // create function selector from processing days
        return new CircularFunctionSelector(functionProcessingDays, extraParameters);
    }

    private Map<String, ProcessingResultsTracker> createProcessingResultsMap() {
        Map<String, ProcessingResultsTracker> functionProcessingResultsMap = new HashMap<>();
        // Create function processing results map
        for (String functionName : SourceManagerParameters.getFunctionsList(this.params)) {
            functionProcessingResultsMap.put(functionName, new ProcessingResultsTracker(functionName));
        }
        return functionProcessingResultsMap;
    }


    private FunctionSelector updateProcessState(ProcessingResults processingResults, FunctionSettings functionSettings, FunctionSelector functionSelector)
            throws XmartSqlServerException {
        if (SourceManagerParameters.getMode(this.params).equals(ProcessingMode.DAILY)) {
            if (!processingResults.isConnectionSuccessful() || !processingResults.isDataProcessedSuccessfully()) {
                // Could not connect or did not run successfully - something went wrong so stop processing for this function
                functionSelector.remove(functionSettings.getFunctionName());
            } else if (processingResults.isDataAvailable()) {
                // Connected, processed successfully and found data - therefore insert new row into db
                sourceManagerSqlUtil.insertLastSuccessfulDateForFunction(this.params, functionSettings.getFunctionName(), functionSettings.getDay());
            }// else ran successfully but returned no data - do not insert row in db but do continue onto next day
        }
        return functionSelector;
    }

    private Map<String, ProcessingResultsTracker> updateProcessingResults(ProcessingResults processingResults, FunctionSettings functionSettings, Map<String, ProcessingResultsTracker> functionProcessingResultsMap) {
        if (processingResults == null) {
            functionProcessingResultsMap.get(functionSettings.getFunctionName()).addDayFailedProcessing(functionSettings.getDay());
        } else if (!processingResults.isConnectionSuccessful()) {
            functionProcessingResultsMap.get(functionSettings.getFunctionName()).addDayNoConnection(functionSettings.getDay());
        } else if (!processingResults.isDataAvailable()) {
            functionProcessingResultsMap.get(functionSettings.getFunctionName()).addDayNoDataAvailable(functionSettings.getDay());
        } else if (!processingResults.isDataProcessedSuccessfully()) {
            functionProcessingResultsMap.get(functionSettings.getFunctionName()).addDayFailedProcessing(functionSettings.getDay());
        } else {
            functionProcessingResultsMap.get(functionSettings.getFunctionName()).addDaySuccessfullyProcessed(functionSettings.getDay());
        }

        return functionProcessingResultsMap;
    }

    private void printProcessingResults(Map<String, ProcessingResultsTracker> functionProcessingResultsMap) {
        for (ProcessingResultsTracker resultTracker : functionProcessingResultsMap.values()) {
            resultTracker.print();
        }
    }

    private void waitBeforeShutdown() {
        int sleepDuration = SourceManagerParameters.getSleepDuration(this.params);
        try {
            logger.info("SLEEPING FOR " + sleepDuration + " MINUTES, until manually cancelled or interrupted");
            TimeUnit.MINUTES.sleep(sleepDuration);
        } catch (InterruptedException e) {
            logger.warn("Source interrupted from sleeping for " + sleepDuration + " minutes", e);
        }
    }
}
