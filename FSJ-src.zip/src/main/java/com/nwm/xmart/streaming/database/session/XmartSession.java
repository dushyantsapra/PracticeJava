package com.nwm.xmart.streaming.database.session;

import com.nwm.xmart.streaming.database.SqlServerConnectionDetails;
import com.nwm.xmart.streaming.database.dao.SqlServerDao;
import com.nwm.xmart.streaming.database.exceptions.XmartSqlServerException;
import com.nwm.xmart.streaming.database.statements.xmartsession.GetXmartSessionStatement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.time.LocalDateTime;

public class XmartSession {

    private static final Logger logger = LoggerFactory.getLogger(XmartSession.class);

    private final int sessionId;
    private final String sessionName;
    private final String payloadHandlerName;
    private final LocalDateTime initialDateTime;
    private final int rowCount;

    public XmartSession(String sessionName, String payloadHandlerName) {
        this.sessionId = 0;
        this.sessionName = sessionName;
        this.payloadHandlerName = payloadHandlerName;
        this.initialDateTime = LocalDateTime.now();
        this.rowCount = 0;
    }

    XmartSession(int sessionId, String sessionName, String payloadHandlerName, LocalDateTime initialDateTime, int rowCount) {
        this.sessionId = sessionId;
        this.sessionName = sessionName;
        this.payloadHandlerName = payloadHandlerName;
        this.initialDateTime = initialDateTime;
        this.rowCount = rowCount;
    }

    public XmartSession openSession(SqlServerConnectionDetails connectionDetails)
            throws XmartSqlServerException {
        return getXmartSession(this, connectionDetails);

    }

    public XmartSession setRowCount(int rowCount) {
        return new XmartSession(getSessionId(),
                getSessionName(),
                getPayloadHandlerName(),
                getInitialDateTime(),
                rowCount);
    }

    public XmartSession setSessionId(int sessionId) {
        return new XmartSession(sessionId,
                getSessionName(),
                getPayloadHandlerName(),
                getInitialDateTime(),
                0);
    }

    public int getSessionId() {
        return sessionId;
    }

    public String getSessionName() {
        return sessionName;
    }

    public String getPayloadHandlerName() {
        return payloadHandlerName;
    }

    public LocalDateTime getInitialDateTime() {
        return initialDateTime;
    }

    public int getRowCount() {
        return rowCount;
    }

    public boolean isOpenSession(){
        return sessionId > 0;
    }

    @Override
    public String toString() {
        return "XmartSession{" + "sessionId=" + sessionId + ", sessionName='" + sessionName + '\''
                + ", payloadHandlerName='" + payloadHandlerName + '\'' + ", initialDateTime=" + initialDateTime
                + ", rowCount=" + rowCount + '}';
    }

    private XmartSession getXmartSession(XmartSession requestedSession, SqlServerConnectionDetails connectionDetails)
            throws XmartSqlServerException {

        int retryCounter = 0;
        while (!requestedSession.isOpenSession() && retryCounter < connectionDetails.getSessionRetryLimit()) {
            if (logger.isDebugEnabled()) {
                logger.debug("Sql Server attempt {} to get BDX session for requested session {}", retryCounter, requestedSession);
            }

            requestedSession = openXmartSession(requestedSession, connectionDetails);
            if(requestedSession.isOpenSession()){
                logger.info("Sql Server got BDX session {}", requestedSession);
            }
            else {
                logger.warn("Sql Server requested BDX session, but did not receive an open session {}", requestedSession);
                retryCounter++;
                sleepThread(connectionDetails.getSessionRetryPeriod());
            }
        }

        if (!requestedSession.isOpenSession()) {
            logger.error("Sql Server attempt to get BDX session for handler {} exceeded retry limit.", requestedSession.getPayloadHandlerName());
            throw new XmartSqlServerException("Sql Server attempt to get BDX session for handler " + requestedSession.getPayloadHandlerName() + " exceeded retry limit.");
        }

        return requestedSession;
    }

    private void sleepThread(int periodMillisec) {
        try {
            Thread.sleep(periodMillisec);
        } catch (InterruptedException ie) {
            logger.error("Interrupt whilst attempting to get BDX session exceeded retry limit.");
            Thread.currentThread().interrupt();
        }
    }

    private XmartSession openXmartSession(XmartSession xmartSession, SqlServerConnectionDetails connectionDetails)
            throws XmartSqlServerException {

        SqlServerDao dao = new SqlServerDao(new GetXmartSessionStatement(), connectionDetails);
        dao.open();
        XmartSession openedSession = dao.readSession(xmartSession);
        dao.close();
        return openedSession;
    }

}
