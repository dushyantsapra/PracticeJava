package com.nwm.xmart.streaming.source.mdx;

import com.nwm.xmart.streaming.source.mdx.cache.load.ISINCacheLoader;
import com.nwm.xmart.streaming.source.mdx.cache.load.XmartISINCacheLoader;
import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.streaming.source.mdx.util.MDXUtil;
import com.nwm.xmart.util.MDCUtil;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import rbs.gbm.dx.webService.interfaces.regulatory.IEligibilityPayload;
import rbs.gbm.dx.webService.interfaces.regulatory.IRdxRegulationSession;
import rbs.gbm.mdx.webService.interfaces.MdxException;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;

import static java.lang.Thread.sleep;

public class MdxRegulatorySource<T> extends RichParallelSourceFunction<T>
        implements CheckpointedFunction, CheckpointListener, Serializable {
    private static final long serialVersionUID = -6340863697830856202L;
    private static final Logger logger = LoggerFactory.getLogger(MdxRegulatorySource.class);

    private IRdxRegulationSession iRdxRegulationSession;

    private String isinDataStoreQuery;
    private ISINCacheLoader isinCacheLoader;
    private Set<String> isins = new HashSet<>();
    private String sourceId;
    private AtomicLong eventCounter = new AtomicLong();

    public MdxRegulatorySource(String sourceId, String isinDataStoreQuery) {
        this.sourceId = sourceId;
        this.isinDataStoreQuery = isinDataStoreQuery;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void open(Configuration configuration) throws Exception {
        ParameterTool params = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        String mdcJobNameKey = params.get("nwm.job.param", "jobName");
        String jobName = params.get("flink.job.name", "No Job Name Specific");
        MDC.put(mdcJobNameKey, jobName);

        iRdxRegulationSession = MDXUtil.getRdxRegulationSession(params);

        isinCacheLoader = new XmartISINCacheLoader(isinDataStoreQuery, params);
        isins = isinCacheLoader.getLatestISINs();
    }

    @Override
    public void notifyCheckpointComplete(long checkpointId) throws Exception {

    }

    @Override
    public void snapshotState(FunctionSnapshotContext context) throws Exception {

    }

    @Override
    public void initializeState(FunctionInitializationContext context) throws Exception {

    }

    @Override
    public void run(SourceContext<T> ctx) {
        T mdxDocumentEvent = null;

        ParameterTool params = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        MDCUtil.putJobNameInMDC(params);

        try {
            for (String isin : isins) {
                try {
                    IEligibilityPayload payload = null;
                    payload = iRdxRegulationSession.getEligibilityPayload(isin);
                    if (payload == null) {
                        logger.info("No Data available for ISIN {}", isin);
                        continue;
                    }
                    mdxDocumentEvent = (T) MdxDocumentEvent
                            .ofIEligibilityPayload(payload, "mdxRefReg", "reference.regulatory", sourceId,
                                    eventCounter.incrementAndGet(), new Date().getTime());
                    synchronized (ctx.getCheckpointLock()) {
                        ctx.collect(mdxDocumentEvent);
                    }
                } catch (Exception e) {
                    logger.info("ISIN : {} Skipped as No Data avail. at MDX End, ", isin, e);
                }
            }

            //Sleeping so that we don't miss any record in the Window operator.
            try {
                logger.info("Data Consumed, Sleeping for 15 mins, to get the window operator to complete");
                sleep(900000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } finally {
            try {
                iRdxRegulationSession.Close();
            } catch (Exception e) {
                logger.info("Exception occurred while closing Reg Session", e);
            }
            isinCacheLoader.close();
        }
    }

    @Override
    public void cancel() {
        try {
            iRdxRegulationSession.Close();
            isinCacheLoader.close();
        } catch (MdxException e) {
            e.printStackTrace();
        }
    }
}
