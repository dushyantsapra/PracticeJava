package com.nwm.xmart.streaming.source.mdx.cache.load;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by gardlex on 15/05/2018.
 */
public class TestMdxISINCacheLoader implements ISINCacheLoader {

//    private ScheduledExecutorService scheduledExecutorService;
    private static final Logger logger = LoggerFactory.getLogger(TestMdxISINCacheLoader.class);
    private final AtomicInteger count = new AtomicInteger();
    private final String mdxIdentifier;


    public static void main(String[] args) throws IOException {
        TestMdxISINCacheLoader l = new TestMdxISINCacheLoader("");

    }

    final Set<String> fullISINList;

    public TestMdxISINCacheLoader(String mdxIdentifer) throws IOException {
        this.mdxIdentifier = mdxIdentifer;
        fullISINList = new TreeSet<>();

//        FileReader fr = new FileReader("C:/DEV/flink-sources-investigation/MDX/sql-database/ISIN-LIST-UNIX.txt");
//        FileReader fr = new FileReader("C:/DEV/flink-sources-investigation/RDX//DEV-DB-ISINS-3888.csv");
//        FileReader fr = new FileReader("C:/DEV/flink-sources-investigation/RDX//DEV-DB-ISINS-SMALL.txt");
        FileReader fr = new FileReader("C:/DEV/flink-sources-investigation/RDX//****.txt");
        BufferedReader br = new BufferedReader(fr);

        String line;
        while ((line = br.readLine()) != null) {
            fullISINList.add(line);
        }
        fr.close();

        logger.info(mdxIdentifer + ": Initial load = " + fullISINList.size());
    }

    @Override
    public Set<String> getLatestISINs() {
        Set<String> isins = new TreeSet<>();

//        int noOfIsinsToPublish = 5; //* count.incrementAndGet();
//
//        int ctr=0;
//        Iterator<String> it = fullISINList.iterator();
//        while (it.hasNext()) {
//            ctr++;
//            isins.add(it.next());
//            if (ctr == noOfIsinsToPublish) {
//                break;
//            }
//        }
//
//        // PLus add dummy values
//        isins.add("1");
//        isins.add("2");
//        isins.add("3");
//        isins.add("4");
//        isins.add("5");


        return fullISINList;
//        return isins;
    }

    @Override
    public void close() {

    }
}
