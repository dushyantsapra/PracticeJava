package com.nwm.xmart.streaming.source.mdx.parser;

import com.nwm.xmart.streaming.source.mdx.entity.RefRegInstrumentUnderlying;
import com.nwm.xmart.streaming.util.XmlXPathParser;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import rbs.gbm.mdx.webService.interfaces.IMdxDocument;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RefRegInstrumentUnderlyingParser {

    public static List<RefRegInstrumentUnderlying> buildRefRegInstrumentUnderlying(IMdxDocument iMdxDocument) {
        List<RefRegInstrumentUnderlying> refRegInstrumentUnderlyings = new ArrayList<>();

        addUnderlyingHierarchyAttributesMultiple(iMdxDocument, refRegInstrumentUnderlyings);
        addRootHierarchyAttributes(iMdxDocument, refRegInstrumentUnderlyings);
        addUnderlyingHierarchyAttributes(iMdxDocument, refRegInstrumentUnderlyings);
        addIndexAndPropHierarchyAttributes(iMdxDocument, refRegInstrumentUnderlyings);
        addDerivedISOUnderlyingInstrumentIndexAttributes(iMdxDocument, refRegInstrumentUnderlyings);

        return refRegInstrumentUnderlyings;
    }

    static RefRegInstrumentUnderlying create(IMdxDocument iMdxDocument) {
        String mdxTransport = iMdxDocument.getHeader().getTransport();
        String mdxTypeName = iMdxDocument.getHeader().getTypeName();
        String mdxPath = iMdxDocument.getHeader().getPath();
        int mdxDocumentVersion = iMdxDocument.getHeader().getVersion();
        String mdxValuationDate = null;
        if (iMdxDocument.getHeader().getValuationDate() != null) {
            mdxValuationDate = iMdxDocument.getHeader().getValuationDate().getYear() + "-" + iMdxDocument.getHeader()
                                                                                                         .getValuationDate()
                                                                                                         .getMonth()
                    + "-" + iMdxDocument.getHeader().getValuationDate().getDay();
        }

        Date mdxWrittenOnUTC = iMdxDocument.getHeader().getWriteTime();
        String xmlWriteTime = iMdxDocument.getHeader().getXmlWriteTime();

        RefRegInstrumentUnderlying refRegInstrumentUnderlying = new RefRegInstrumentUnderlying(mdxTransport,
                mdxTypeName, mdxPath, mdxDocumentVersion, mdxWrittenOnUTC, mdxValuationDate, xmlWriteTime);
        return refRegInstrumentUnderlying;
    }

    /*Case 1: Single Value
    <Attributes>
        <UnderlyingInstrumentISIN>XS1374865555</UnderlyingInstrumentISIN>
    </Attributes>

    Case 2: Repeated values
    <Attributes>
        <Underlying>
            <UnderlyingInstrumentISIN>INE713G08012</UnderlyingInstrumentISIN>
            <UnderlyingInstrumentISIN>XS0161774665</UnderlyingInstrumentISIN>
        </Underlying>
    </Attributes>

    Case 3: Repeated values
    <Attributes>
        <Underlying>
            <InstrumentISIN>JP343610ADB8</InstrumentISIN>
            <InstrumentISIN>ACA43810ADB8</InstrumentISIN>
        </Underlying>
    </Attributes>

    Case 8: Repeated values
    <Attributes>
        <Underlying>
            <ISOUnderlyingInstrumentIndex>CDX.NA.HY</ISOUnderlyingInstrumentIndex>
            <ISOUnderlyingInstrumentIndex>CDZ.NA.HK</ISOUnderlyingInstrumentIndex>
        </Underlying>
    </Attributes>*/
    static void addUnderlyingHierarchyAttributesMultiple(IMdxDocument iMdxDocument,
            List<RefRegInstrumentUnderlying> refRegInstrumentUnderlyings) {
        RefRegInstrumentUnderlying refRegInstrumentUnderlying = null;
        NodeList attributeNodeList = XmlXPathParser
                .getAttributeNodeList(iMdxDocument.getContent().asString(), "Instrument/Attributes");
        for (int attributeNodeLoop = 0; attributeNodeLoop < attributeNodeList.getLength(); attributeNodeLoop++) {
            Node attributeNode = attributeNodeList.item(attributeNodeLoop);
            NodeList attributeChildNodeList = attributeNode.getChildNodes();

            for (int attributeChildNodeLoop = 0; attributeChildNodeLoop < attributeChildNodeList.getLength();
                 attributeChildNodeLoop++) {
                Node attributeChildNode = attributeChildNodeList.item(attributeChildNodeLoop);
                switch (attributeChildNode.getNodeName()) {
                case "UnderlyingInstrumentISIN":
                    refRegInstrumentUnderlying = create(iMdxDocument);
                    refRegInstrumentUnderlying.setUnderlyingInstrumentISIN(attributeChildNode.getTextContent());
                    refRegInstrumentUnderlying.setType("root");
                    refRegInstrumentUnderlyings.add(refRegInstrumentUnderlying);
                    break;
                case "Underlying":
                    NodeList underlyingNodeList = attributeChildNode.getChildNodes();
                    for (int underlyingNodeLoop = 0; underlyingNodeLoop < underlyingNodeList.getLength();
                         underlyingNodeLoop++) {
                        Node underlyingNode = underlyingNodeList.item(underlyingNodeLoop);
                        switch (underlyingNode.getNodeName()) {
                        case "UnderlyingInstrumentISIN":
                            refRegInstrumentUnderlying = create(iMdxDocument);
                            refRegInstrumentUnderlying.setUnderlyingInstrumentISIN(underlyingNode.getTextContent());
                            refRegInstrumentUnderlying.setType("Underlying");
                            refRegInstrumentUnderlyings.add(refRegInstrumentUnderlying);
                            break;
                        case "InstrumentISIN":
                            refRegInstrumentUnderlying = create(iMdxDocument);
                            refRegInstrumentUnderlying.setInstrumentISIN(underlyingNode.getTextContent());
                            refRegInstrumentUnderlying.setType("Underlying");
                            refRegInstrumentUnderlyings.add(refRegInstrumentUnderlying);
                            break;
                        case "ISOUnderlyingInstrumentIndex":
                            refRegInstrumentUnderlying = create(iMdxDocument);
                            refRegInstrumentUnderlying.setiSOUnderlyingInstrumentIndex(underlyingNode.getTextContent());
                            refRegInstrumentUnderlying.setType("Underlying");
                            refRegInstrumentUnderlyings.add(refRegInstrumentUnderlying);
                            break;
                        }
                    }
                    break;
                }
            }
        }
    }

    //Case 4
    /*<Attributes>
	    <UnderlyingInstrumentIndexTermValue>1</UnderlyingInstrumentIndexTermValue>
	    <UnderlyingInstrumentIndexTermUnit>MNTH</UnderlyingInstrumentIndexTermUnit>
	    <UnderlyingInstrumentIndex>GBP-LIBOR-BBA</UnderlyingInstrumentIndex>
    </Attributes>*/
    static void addRootHierarchyAttributes(IMdxDocument iMdxDocument,
            List<RefRegInstrumentUnderlying> refRegInstrumentUnderlyings) {
        NodeList attributeNodeList = XmlXPathParser
                .getAttributeNodeList(iMdxDocument.getContent().asString(), "Instrument/Attributes");

        for (int attributeNodeLoop = 0; attributeNodeLoop < attributeNodeList.getLength(); attributeNodeLoop++) {
            Node attributeNode = attributeNodeList.item(attributeNodeLoop);
            NodeList attributeChildNodeList = attributeNode.getChildNodes();

            int count = 0;
            RefRegInstrumentUnderlying refRegInstrumentUnderlying = create(iMdxDocument);
            for (int attributeChildNodeLoop = 0; attributeChildNodeLoop < attributeChildNodeList.getLength();
                 attributeChildNodeLoop++) {
                Node attributeChildNode = attributeChildNodeList.item(attributeChildNodeLoop);

                switch (attributeChildNode.getNodeName()) {
                case "UnderlyingInstrumentIndexTermValue":
                    refRegInstrumentUnderlying
                            .setUnderlyingInstrumentIndexTermValue(new BigDecimal(attributeChildNode.getTextContent()));
                    count++;
                    break;
                case "UnderlyingInstrumentIndexTermUnit":
                    refRegInstrumentUnderlying
                            .setUnderlyingInstrumentIndexTermUnit(attributeChildNode.getTextContent());
                    count++;
                    break;
                case "UnderlyingInstrumentIndex":
                    if (attributeChildNode.getChildNodes().getLength() == 1) {
                        refRegInstrumentUnderlying.setUnderlyingInstrumentIndex(attributeChildNode.getTextContent());
                        count++;
                    }
                    break;
                }
            }
            if (count > 0) {
                refRegInstrumentUnderlying.setType("root");
                refRegInstrumentUnderlyings.add(refRegInstrumentUnderlying);
                count = 0;
            }
        }
    }

    //Case 5
    /*<Attributes>
	    <Underlying>
		    <UnderlyingInstrumentIndexTermValue>5</UnderlyingInstrumentIndexTermValue>
		    <UnderlyingInstrumentIndexTermUnit>YEAR</UnderlyingInstrumentIndexTermUnit>
		    <UnderlyingInstrumentIndex>CDX.NA.IG</UnderlyingInstrumentIndex>
	    </Underlying>
    </Attributes>*/
    static void addUnderlyingHierarchyAttributes(IMdxDocument iMdxDocument,
            List<RefRegInstrumentUnderlying> refRegInstrumentUnderlyings) {
        NodeList attributeNodeList = XmlXPathParser
                .getAttributeNodeList(iMdxDocument.getContent().asString(), "Instrument/Attributes");
        for (int attributeNodeLoop = 0; attributeNodeLoop < attributeNodeList.getLength(); attributeNodeLoop++) {
            Node attributeNode = attributeNodeList.item(attributeNodeLoop);
            NodeList attributeChildNodeList = attributeNode.getChildNodes();

            for (int attributeChildNodeLoop = 0; attributeChildNodeLoop < attributeChildNodeList.getLength();
                 attributeChildNodeLoop++) {
                int count = 0;
                RefRegInstrumentUnderlying refRegInstrumentUnderlying = create(iMdxDocument);
                Node attributeChildNode = attributeChildNodeList.item(attributeChildNodeLoop);
                switch (attributeChildNode.getNodeName()) {
                case "Underlying":
                    NodeList underlyingNodeList = attributeChildNode.getChildNodes();
                    for (int underlyingNodeLoop = 0; underlyingNodeLoop < underlyingNodeList.getLength();
                         underlyingNodeLoop++) {
                        Node underlyingNode = underlyingNodeList.item(underlyingNodeLoop);
                        switch (underlyingNode.getNodeName()) {
                        case "UnderlyingInstrumentIndexTermValue":
                            refRegInstrumentUnderlying.setUnderlyingInstrumentIndexTermValue(
                                    new BigDecimal(underlyingNode.getTextContent()));
                            break;
                        case "UnderlyingInstrumentIndexTermUnit":
                            refRegInstrumentUnderlying
                                    .setUnderlyingInstrumentIndexTermUnit(underlyingNode.getTextContent());
                            break;
                        case "UnderlyingInstrumentIndex":
                            if (underlyingNode.getChildNodes().getLength() == 1) {
                                refRegInstrumentUnderlying
                                        .setUnderlyingInstrumentIndex(underlyingNode.getTextContent());
                                count++;
                            }
                            break;
                        }
                    }
                    break;
                }
                if (count > 0) {
                    refRegInstrumentUnderlying.setType("Underlying");
                    refRegInstrumentUnderlyings.add(refRegInstrumentUnderlying);
                    count = 0;
                }
            }
        }
    }

    //Case 6 -- For UnderlyingInstrumentIndex
    /*<Attributes>
	    <Underlying>
		    <UnderlyingInstrumentIndex>
                <UnderlyingInstrumentIndexTermValue>5</UnderlyingInstrumentIndexTermValue>
                <UnderlyingInstrumentIndexTermUnit>YEAR</UnderlyingInstrumentIndexTermUnit>
                <UnderlyingInstrumentIndex>CDX.NA.IG</UnderlyingInstrumentIndex>
		    </UnderlyingInstrumentIndex>
		    <UnderlyingInstrumentIndexProp>
                <UnderlyingInstrumentIndexTermValue>5</UnderlyingInstrumentIndexTermValue>
                <UnderlyingInstrumentIndexTermUnit>YEAR</UnderlyingInstrumentIndexTermUnit>
                <UnderlyingInstrumentIndex>CDX.NA.IG</UnderlyingInstrumentIndex>
		    </UnderlyingInstrumentIndexProp>
	    <Underlying/>
    </Attributes>*/
    static void addIndexAndPropHierarchyAttributes(IMdxDocument iMdxDocument,
            List<RefRegInstrumentUnderlying> refRegInstrumentUnderlyings) {
        RefRegInstrumentUnderlying refRegInstrumentUnderlying = null;
        int count = 0;
        NodeList attributeNodeList = XmlXPathParser
                .getAttributeNodeList(iMdxDocument.getContent().asString(), "Instrument/Attributes");
        for (int attributeNodeLoop = 0; attributeNodeLoop < attributeNodeList.getLength(); attributeNodeLoop++) {
            Node attributeNode = attributeNodeList.item(attributeNodeLoop);
            NodeList attributeChildNodeList = attributeNode.getChildNodes();

            for (int attributeChildNodeLoop = 0; attributeChildNodeLoop < attributeChildNodeList.getLength();
                 attributeChildNodeLoop++) {
                Node attributeChildNode = attributeChildNodeList.item(attributeChildNodeLoop);
                switch (attributeChildNode.getNodeName()) {
                case "Underlying":
                    NodeList underlyingNodeList = attributeChildNode.getChildNodes();
                    for (int underlyingNodeLoop = 0; underlyingNodeLoop < underlyingNodeList.getLength();
                         underlyingNodeLoop++) {
                        Node underlyingNode = underlyingNodeList.item(underlyingNodeLoop);
                        switch (underlyingNode.getNodeName()) {
                        case "UnderlyingInstrumentIndex":
                            count = 0;
                            refRegInstrumentUnderlying = create(iMdxDocument);
                            NodeList underlyingInstrumentIndexNodeList = underlyingNode.getChildNodes();
                            for (int underlyingInstrumentIndexNodeLoop = 0;
                                 underlyingInstrumentIndexNodeLoop < underlyingInstrumentIndexNodeList.getLength();
                                 underlyingInstrumentIndexNodeLoop++) {

                                Node underlyingInstrumentIndexNode = underlyingInstrumentIndexNodeList
                                        .item(underlyingInstrumentIndexNodeLoop);
                                switch (underlyingInstrumentIndexNode.getNodeName()) {
                                case "UnderlyingInstrumentIndexTermValue":
                                    refRegInstrumentUnderlying.setUnderlyingInstrumentIndexTermValue(
                                            new BigDecimal(underlyingInstrumentIndexNode.getTextContent()));
                                    count++;
                                    break;
                                case "UnderlyingInstrumentIndexTermUnit":
                                    refRegInstrumentUnderlying.setUnderlyingInstrumentIndexTermUnit(
                                            underlyingInstrumentIndexNode.getTextContent());
                                    count++;
                                    break;
                                case "UnderlyingInstrumentIndex":
                                    refRegInstrumentUnderlying.setUnderlyingInstrumentIndex(
                                            underlyingInstrumentIndexNode.getTextContent());
                                    count++;
                                    break;
                                }
                            }
                            if (count > 0) {
                                refRegInstrumentUnderlying.setType("UnderlyingInstrumentIndex");
                                refRegInstrumentUnderlyings.add(refRegInstrumentUnderlying);
                            }
                            break;
                        case "UnderlyingInstrumentIndexProp":
                            count = 0;
                            refRegInstrumentUnderlying = create(iMdxDocument);
                            NodeList underlyingInstrumentIndexPropNodeList = underlyingNode.getChildNodes();
                            for (int underlyingInstrumentIndexPropNodeLoop = 0;
                                 underlyingInstrumentIndexPropNodeLoop < underlyingInstrumentIndexPropNodeList
                                         .getLength(); underlyingInstrumentIndexPropNodeLoop++) {
                                Node underlyingInstrumentIndexPropNode = underlyingInstrumentIndexPropNodeList
                                        .item(underlyingInstrumentIndexPropNodeLoop);
                                switch (underlyingInstrumentIndexPropNode.getNodeName()) {
                                case "UnderlyingInstrumentIndexTermValue":
                                    refRegInstrumentUnderlying.setUnderlyingInstrumentIndexTermValue(
                                            new BigDecimal(underlyingInstrumentIndexPropNode.getTextContent()));
                                    count++;
                                    break;
                                case "UnderlyingInstrumentIndexTermUnit":
                                    refRegInstrumentUnderlying.setUnderlyingInstrumentIndexTermUnit(
                                            underlyingInstrumentIndexPropNode.getTextContent());
                                    count++;
                                    break;
                                case "UnderlyingInstrumentIndex":
                                    refRegInstrumentUnderlying.setUnderlyingInstrumentIndex(
                                            underlyingInstrumentIndexPropNode.getTextContent());
                                    count++;
                                    break;
                                }
                            }
                            if (count > 0) {
                                refRegInstrumentUnderlying.setType("UnderlyingInstrumentIndexProp");
                                refRegInstrumentUnderlyings.add(refRegInstrumentUnderlying);
                            }
                            break;
                        }
                    }
                    break;
                }
            }
        }
    }

    //Case 7
    /*<Derived>
	    <ISOUnderlyingInstrumentIndex>CDX.NA.HY</ISOUnderlyingInstrumentIndex>
    </Derived>*/
    static void addDerivedISOUnderlyingInstrumentIndexAttributes(IMdxDocument iMdxDocument,
            List<RefRegInstrumentUnderlying> refRegInstrumentUnderlyings) {
        RefRegInstrumentUnderlying refRegInstrumentUnderlying = null;
        NodeList attributeNodeList = XmlXPathParser
                .getAttributeNodeList(iMdxDocument.getContent().asString(), "Instrument/Derived");
        for (int attributeNodeLoop = 0; attributeNodeLoop < attributeNodeList.getLength(); attributeNodeLoop++) {
            Node attributeNode = attributeNodeList.item(attributeNodeLoop);
            NodeList attributeChildNodeList = attributeNode.getChildNodes();

            for (int attributeChildNodeLoop = 0; attributeChildNodeLoop < attributeChildNodeList.getLength();
                 attributeChildNodeLoop++) {
                Node attributeChildNode = attributeChildNodeList.item(attributeChildNodeLoop);
                switch (attributeChildNode.getNodeName()) {
                case "ISOUnderlyingInstrumentIndex":
                    refRegInstrumentUnderlying = create(iMdxDocument);
                    refRegInstrumentUnderlying.setiSOUnderlyingInstrumentIndex(attributeChildNode.getTextContent());
                    refRegInstrumentUnderlying.setType("Derived");
                    refRegInstrumentUnderlyings.add(refRegInstrumentUnderlying);
                    break;
                }
            }
        }
    }
}
