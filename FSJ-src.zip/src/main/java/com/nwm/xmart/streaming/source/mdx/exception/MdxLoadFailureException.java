package com.nwm.xmart.streaming.source.mdx.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class MdxLoadFailureException extends Exception {

    public MdxLoadFailureException() {
        super();
    }

    public MdxLoadFailureException(String msg) {
        super(msg);
    }

    public MdxLoadFailureException(String msg, Throwable t) {
        super(msg, t);
    }
}
