package com.nwm.xmart.streaming.source.json;

/**
 * Created by gardlex on 18/10/2018.
 */
public class JSONTraverserException extends RuntimeException {

    public JSONTraverserException() {
        super();
    }

    public JSONTraverserException(String msg) {
        super(msg);
    }

    public JSONTraverserException(String msg, Throwable t) {
        super(msg, t);
    }
}
