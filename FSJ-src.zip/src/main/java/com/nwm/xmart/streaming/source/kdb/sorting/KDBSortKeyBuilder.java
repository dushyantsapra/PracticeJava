package com.nwm.xmart.streaming.source.kdb.sorting;

import com.nwm.xmart.streaming.source.kdb.exception.KDBMatrixDataParsingException;

import java.util.HashMap;
import java.util.Map;

import static java.util.Objects.isNull;

/**
 * Methods for converting the list of sort key column names for each KDB Function as provided in the job property file
 * into a SortKeyI class to sort the incoming KDB results.
 * <p>
 * Author: Alex Gardner
 */
public class KDBSortKeyBuilder {

    private final Map<KDBFunctionType, String[]> columnSortKeyNameMap = new HashMap<>();

    public KDBSortKeyBuilder(String sortKeyNameProperty) {
        parseSortKeyNameProperty(sortKeyNameProperty);
    }

    public SortKeyI createSortKeyForType(KDBFunctionType kdbFunctionType, String[] columnNames) {
        switch (kdbFunctionType) {
        case FI_MIFID_RFQ:
            return new DateTimeSortKey(
                    convertSortKeyValues(columnSortKeyNameMap.get(KDBFunctionType.FI_MIFID_RFQ), columnNames));
        case FI_MIFID_QEC:
            return new DateTimeSortKey(
                    convertSortKeyValues(columnSortKeyNameMap.get(KDBFunctionType.FI_MIFID_QEC), columnNames));
        case FX_MIFID_OMS:
            return new DateTimeSortKey(
                    convertSortKeyValues(columnSortKeyNameMap.get(KDBFunctionType.FX_MIFID_OMS), columnNames));
        case FX_MIFID_RFQ:
            return new DateTimeSortKey(
                    convertSortKeyValues(columnSortKeyNameMap.get(KDBFunctionType.FX_MIFID_RFQ), columnNames));
        case FX_MIFID_TRADE:
            return new DateTimeSortKey(
                    convertSortKeyValues(columnSortKeyNameMap.get(KDBFunctionType.FX_MIFID_TRADE), columnNames));
        case FX_MIFID_TRADE_ISIN:
            return new DateTimeSortKey(
                    convertSortKeyValues(columnSortKeyNameMap.get(KDBFunctionType.FX_MIFID_TRADE_ISIN), columnNames));
        case FX_MIFID_TRADE_ELIGIBILITY:
            return new DateTimeSortKey(
                    convertSortKeyValues(columnSortKeyNameMap.get(KDBFunctionType.FX_MIFID_TRADE_ELIGIBILITY),
                            columnNames));
        case FI_MIFID_FICC:
            return new DateTimeSortKey(
                    convertSortKeyValues(columnSortKeyNameMap.get(KDBFunctionType.FI_MIFID_FICC), columnNames));
        default:
            throw new KDBMatrixDataParsingException("Unsupported KDBFunctionType [ " + kdbFunctionType + " ]");
        }
    }

    /**
     * <p>
     * Parses the String property value and populates a map with the sort key names for each {@link KDBFunctionType}
     * <p>
     * Property in the form of:
     * <p>
     * kdb.sort.key.indexes=FI_MIFID_RFQ|date|time,FI_MIFID_QEC|date|time,...
     *
     * <p>
     * So the key elements are separated by comma, the first element is the sort key type and the subsequent
     * values are the names of the relevant key attributes
     * </p>
     *
     * @param sortKeyNameProperty the raw property from the job property file, containing all sort keys
     */
    private void parseSortKeyNameProperty(String sortKeyNameProperty) {
        this.columnSortKeyNameMap.putAll(SortKeyIndexPropertyParser.getSortKeyNamesFromString(sortKeyNameProperty));
    }

    private int[] convertSortKeyValues(String[] keyNames, String[] columnNames) {

        if (isNull(keyNames) || keyNames.length == 0) {
            throw new KDBMatrixDataParsingException("KDB key columns not populated - configuration invalid");
        }

        if (isNull(columnNames) || columnNames.length == 0) {
            throw new KDBMatrixDataParsingException(
                    "KDB result columns names not populated - KDB query response invalid");
        }

        int[] integerKeyIndexes = new int[keyNames.length];

        for (int keyCount = 0; keyCount < keyNames.length; keyCount++) {
            Boolean keyFound = false;
            for (int colCount = 0; colCount < columnNames.length; colCount++) {
                if (keyNames[keyCount].equals(columnNames[colCount])) {
                    integerKeyIndexes[keyCount] = colCount;
                    keyFound = true;
                }
            }
            if (!keyFound) {
                throw new KDBMatrixDataParsingException("Key column used for sorting not found: " + keyNames[keyCount]);
            }
        }

        return integerKeyIndexes;
    }
}
