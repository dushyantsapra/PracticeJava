package com.nwm.xmart.streaming.source.mdx.subscription;

import com.nwm.xmart.streaming.source.mdx.session.MdxSessionContext;
import org.apache.flink.streaming.api.functions.source.SourceFunction;

import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created by gardlex on 19/04/2018.
 */
public interface MdxSubscription<MdxSourceEvent> {
    MdxSubscription withMdxEventExchange(MdxRealTimeEventExchange<MdxSourceEvent> mdxEventExchange);
    MdxSubscription withMdxIdentifier(String identifier);
    MdxSubscription withMdxIdentifierWildcard(String wildcard);
    MdxSubscription withMdxSessionContext(MdxSessionContext mdxSessionContext);
    void startConsumingEvents();
    void close();
    MdxSourceEvent getMdxNextEvent();
    ReentrantLock getSubscriptionLock();
    MdxSubscription setISINList(Set<String> isinList);
    MdxSubscription withSourceFunction(SourceFunction<MdxSourceEvent> sourceFunction);
}
