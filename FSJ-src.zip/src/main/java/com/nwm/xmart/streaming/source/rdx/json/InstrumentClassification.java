
package com.nwm.xmart.streaming.source.rdx.json;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "BdlCertificateType",
    "BdlCouponType",
    "BdlIndustryGroup",
    "BdlIndustrySector",
    "BdlIndustrySubGroup",
    "BdlIssuerIndustry",
    "BdlMarketIssue",
    "BdlMarketSector",
    "BdlMortgageDealType",
    "BdlSecurityPaymentRanking",
    "BdlSecurityType",
    "BdlSecurityType2",
    "CouponType",
    "IssuerType",
    "LseSegment",
    "StripType",
    "YieldType",
    "EquipSecuritySubType",
    "UnderlyingAssetSubType",
    "UnderlyingAssetType",
    "GteSecurityClass",
    "GteSecuritySubClass",
    "GteSecurityType",
    "GteSecuritySubType",
    "MtgeCollateralType",
    "MarketSectorId",
    "MtgeAmortType",
    "MtgeType"
})
public class InstrumentClassification {

    @JsonProperty("BdlCertificateType")
    private Object bdlCertificateType;
    @JsonProperty("BdlCouponType")
    private String bdlCouponType;
    @JsonProperty("BdlIndustryGroup")
    private String bdlIndustryGroup;
    @JsonProperty("BdlIndustrySector")
    private String bdlIndustrySector;
    @JsonProperty("BdlIndustrySubGroup")
    private String bdlIndustrySubGroup;
    @JsonProperty("BdlIssuerIndustry")
    private String bdlIssuerIndustry;
    @JsonProperty("BdlMarketIssue")
    private String bdlMarketIssue;
    @JsonProperty("BdlMarketSector")
    private String bdlMarketSector;
    @JsonProperty("BdlMortgageDealType")
    private Object bdlMortgageDealType;
    @JsonProperty("BdlSecurityPaymentRanking")
    private String bdlSecurityPaymentRanking;
    @JsonProperty("BdlSecurityType")
    private String bdlSecurityType;
    @JsonProperty("BdlSecurityType2")
    private Object bdlSecurityType2;
    @JsonProperty("CouponType")
    private String couponType;
    @JsonProperty("IssuerType")
    private String issuerType;
    @JsonProperty("LseSegment")
    private Object lseSegment;
    @JsonProperty("StripType")
    private Object stripType;
    @JsonProperty("YieldType")
    private Object yieldType;
    @JsonProperty("EquipSecuritySubType")
    private Object equipSecuritySubType;
    @JsonProperty("UnderlyingAssetSubType")
    private String underlyingAssetSubType;
    @JsonProperty("UnderlyingAssetType")
    private Object underlyingAssetType;
    @JsonProperty("GteSecurityClass")
    private Object gteSecurityClass;
    @JsonProperty("GteSecuritySubClass")
    private Object gteSecuritySubClass;
    @JsonProperty("GteSecurityType")
    private Object gteSecurityType;
    @JsonProperty("GteSecuritySubType")
    private Object gteSecuritySubType;
    @JsonProperty("MtgeCollateralType")
    private Object mtgeCollateralType;
    @JsonProperty("MarketSectorId")
    private Integer marketSectorId;
    @JsonProperty("MtgeAmortType")
    private Object mtgeAmortType;
    @JsonProperty("MtgeType")
    private Object mtgeType;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("BdlCertificateType")
    public Object getBdlCertificateType() {
        return bdlCertificateType;
    }

    @JsonProperty("BdlCertificateType")
    public void setBdlCertificateType(Object bdlCertificateType) {
        this.bdlCertificateType = bdlCertificateType;
    }

    @JsonProperty("BdlCouponType")
    public String getBdlCouponType() {
        return bdlCouponType;
    }

    @JsonProperty("BdlCouponType")
    public void setBdlCouponType(String bdlCouponType) {
        this.bdlCouponType = bdlCouponType;
    }

    @JsonProperty("BdlIndustryGroup")
    public String getBdlIndustryGroup() {
        return bdlIndustryGroup;
    }

    @JsonProperty("BdlIndustryGroup")
    public void setBdlIndustryGroup(String bdlIndustryGroup) {
        this.bdlIndustryGroup = bdlIndustryGroup;
    }

    @JsonProperty("BdlIndustrySector")
    public String getBdlIndustrySector() {
        return bdlIndustrySector;
    }

    @JsonProperty("BdlIndustrySector")
    public void setBdlIndustrySector(String bdlIndustrySector) {
        this.bdlIndustrySector = bdlIndustrySector;
    }

    @JsonProperty("BdlIndustrySubGroup")
    public String getBdlIndustrySubGroup() {
        return bdlIndustrySubGroup;
    }

    @JsonProperty("BdlIndustrySubGroup")
    public void setBdlIndustrySubGroup(String bdlIndustrySubGroup) {
        this.bdlIndustrySubGroup = bdlIndustrySubGroup;
    }

    @JsonProperty("BdlIssuerIndustry")
    public String getBdlIssuerIndustry() {
        return bdlIssuerIndustry;
    }

    @JsonProperty("BdlIssuerIndustry")
    public void setBdlIssuerIndustry(String bdlIssuerIndustry) {
        this.bdlIssuerIndustry = bdlIssuerIndustry;
    }

    @JsonProperty("BdlMarketIssue")
    public String getBdlMarketIssue() {
        return bdlMarketIssue;
    }

    @JsonProperty("BdlMarketIssue")
    public void setBdlMarketIssue(String bdlMarketIssue) {
        this.bdlMarketIssue = bdlMarketIssue;
    }

    @JsonProperty("BdlMarketSector")
    public String getBdlMarketSector() {
        return bdlMarketSector;
    }

    @JsonProperty("BdlMarketSector")
    public void setBdlMarketSector(String bdlMarketSector) {
        this.bdlMarketSector = bdlMarketSector;
    }

    @JsonProperty("BdlMortgageDealType")
    public Object getBdlMortgageDealType() {
        return bdlMortgageDealType;
    }

    @JsonProperty("BdlMortgageDealType")
    public void setBdlMortgageDealType(Object bdlMortgageDealType) {
        this.bdlMortgageDealType = bdlMortgageDealType;
    }

    @JsonProperty("BdlSecurityPaymentRanking")
    public String getBdlSecurityPaymentRanking() {
        return bdlSecurityPaymentRanking;
    }

    @JsonProperty("BdlSecurityPaymentRanking")
    public void setBdlSecurityPaymentRanking(String bdlSecurityPaymentRanking) {
        this.bdlSecurityPaymentRanking = bdlSecurityPaymentRanking;
    }

    @JsonProperty("BdlSecurityType")
    public String getBdlSecurityType() {
        return bdlSecurityType;
    }

    @JsonProperty("BdlSecurityType")
    public void setBdlSecurityType(String bdlSecurityType) {
        this.bdlSecurityType = bdlSecurityType;
    }

    @JsonProperty("BdlSecurityType2")
    public Object getBdlSecurityType2() {
        return bdlSecurityType2;
    }

    @JsonProperty("BdlSecurityType2")
    public void setBdlSecurityType2(Object bdlSecurityType2) {
        this.bdlSecurityType2 = bdlSecurityType2;
    }

    @JsonProperty("CouponType")
    public String getCouponType() {
        return couponType;
    }

    @JsonProperty("CouponType")
    public void setCouponType(String couponType) {
        this.couponType = couponType;
    }

    @JsonProperty("IssuerType")
    public String getIssuerType() {
        return issuerType;
    }

    @JsonProperty("IssuerType")
    public void setIssuerType(String issuerType) {
        this.issuerType = issuerType;
    }

    @JsonProperty("LseSegment")
    public Object getLseSegment() {
        return lseSegment;
    }

    @JsonProperty("LseSegment")
    public void setLseSegment(Object lseSegment) {
        this.lseSegment = lseSegment;
    }

    @JsonProperty("StripType")
    public Object getStripType() {
        return stripType;
    }

    @JsonProperty("StripType")
    public void setStripType(Object stripType) {
        this.stripType = stripType;
    }

    @JsonProperty("YieldType")
    public Object getYieldType() {
        return yieldType;
    }

    @JsonProperty("YieldType")
    public void setYieldType(Object yieldType) {
        this.yieldType = yieldType;
    }

    @JsonProperty("EquipSecuritySubType")
    public Object getEquipSecuritySubType() {
        return equipSecuritySubType;
    }

    @JsonProperty("EquipSecuritySubType")
    public void setEquipSecuritySubType(Object equipSecuritySubType) {
        this.equipSecuritySubType = equipSecuritySubType;
    }

    @JsonProperty("UnderlyingAssetSubType")
    public String getUnderlyingAssetSubType() {
        return underlyingAssetSubType;
    }

    @JsonProperty("UnderlyingAssetSubType")
    public void setUnderlyingAssetSubType(String underlyingAssetSubType) {
        this.underlyingAssetSubType = underlyingAssetSubType;
    }

    @JsonProperty("UnderlyingAssetType")
    public Object getUnderlyingAssetType() {
        return underlyingAssetType;
    }

    @JsonProperty("UnderlyingAssetType")
    public void setUnderlyingAssetType(Object underlyingAssetType) {
        this.underlyingAssetType = underlyingAssetType;
    }

    @JsonProperty("GteSecurityClass")
    public Object getGteSecurityClass() {
        return gteSecurityClass;
    }

    @JsonProperty("GteSecurityClass")
    public void setGteSecurityClass(Object gteSecurityClass) {
        this.gteSecurityClass = gteSecurityClass;
    }

    @JsonProperty("GteSecuritySubClass")
    public Object getGteSecuritySubClass() {
        return gteSecuritySubClass;
    }

    @JsonProperty("GteSecuritySubClass")
    public void setGteSecuritySubClass(Object gteSecuritySubClass) {
        this.gteSecuritySubClass = gteSecuritySubClass;
    }

    @JsonProperty("GteSecurityType")
    public Object getGteSecurityType() {
        return gteSecurityType;
    }

    @JsonProperty("GteSecurityType")
    public void setGteSecurityType(Object gteSecurityType) {
        this.gteSecurityType = gteSecurityType;
    }

    @JsonProperty("GteSecuritySubType")
    public Object getGteSecuritySubType() {
        return gteSecuritySubType;
    }

    @JsonProperty("GteSecuritySubType")
    public void setGteSecuritySubType(Object gteSecuritySubType) {
        this.gteSecuritySubType = gteSecuritySubType;
    }

    @JsonProperty("MtgeCollateralType")
    public Object getMtgeCollateralType() {
        return mtgeCollateralType;
    }

    @JsonProperty("MtgeCollateralType")
    public void setMtgeCollateralType(Object mtgeCollateralType) {
        this.mtgeCollateralType = mtgeCollateralType;
    }

    @JsonProperty("MarketSectorId")
    public Integer getMarketSectorId() {
        return marketSectorId;
    }

    @JsonProperty("MarketSectorId")
    public void setMarketSectorId(Integer marketSectorId) {
        this.marketSectorId = marketSectorId;
    }

    @JsonProperty("MtgeAmortType")
    public Object getMtgeAmortType() {
        return mtgeAmortType;
    }

    @JsonProperty("MtgeAmortType")
    public void setMtgeAmortType(Object mtgeAmortType) {
        this.mtgeAmortType = mtgeAmortType;
    }

    @JsonProperty("MtgeType")
    public Object getMtgeType() {
        return mtgeType;
    }

    @JsonProperty("MtgeType")
    public void setMtgeType(Object mtgeType) {
        this.mtgeType = mtgeType;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("bdlCertificateType", bdlCertificateType).append("bdlCouponType", bdlCouponType).append("bdlIndustryGroup", bdlIndustryGroup).append("bdlIndustrySector", bdlIndustrySector).append("bdlIndustrySubGroup", bdlIndustrySubGroup).append("bdlIssuerIndustry", bdlIssuerIndustry).append("bdlMarketIssue", bdlMarketIssue).append("bdlMarketSector", bdlMarketSector).append("bdlMortgageDealType", bdlMortgageDealType).append("bdlSecurityPaymentRanking", bdlSecurityPaymentRanking).append("bdlSecurityType", bdlSecurityType).append("bdlSecurityType2", bdlSecurityType2).append("couponType", couponType).append("issuerType", issuerType).append("lseSegment", lseSegment).append("stripType", stripType).append("yieldType", yieldType).append("equipSecuritySubType", equipSecuritySubType).append("underlyingAssetSubType", underlyingAssetSubType).append("underlyingAssetType", underlyingAssetType).append("gteSecurityClass", gteSecurityClass).append("gteSecuritySubClass", gteSecuritySubClass).append("gteSecurityType", gteSecurityType).append("gteSecuritySubType", gteSecuritySubType).append("mtgeCollateralType", mtgeCollateralType).append("marketSectorId", marketSectorId).append("mtgeAmortType", mtgeAmortType).append("mtgeType", mtgeType).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(underlyingAssetType).append(bdlSecurityType).append(mtgeCollateralType).append(bdlMarketIssue).append(equipSecuritySubType).append(underlyingAssetSubType).append(gteSecurityClass).append(couponType).append(issuerType).append(yieldType).append(bdlMarketSector).append(marketSectorId).append(bdlIssuerIndustry).append(bdlSecurityPaymentRanking).append(gteSecuritySubClass).append(gteSecurityType).append(bdlSecurityType2).append(bdlIndustryGroup).append(bdlIndustrySector).append(mtgeType).append(bdlIndustrySubGroup).append(gteSecuritySubType).append(mtgeAmortType).append(lseSegment).append(bdlCertificateType).append(stripType).append(bdlCouponType).append(bdlMortgageDealType).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InstrumentClassification) == false) {
            return false;
        }
        InstrumentClassification rhs = ((InstrumentClassification) other);
        return new EqualsBuilder().append(underlyingAssetType, rhs.underlyingAssetType).append(bdlSecurityType, rhs.bdlSecurityType).append(mtgeCollateralType, rhs.mtgeCollateralType).append(bdlMarketIssue, rhs.bdlMarketIssue).append(equipSecuritySubType, rhs.equipSecuritySubType).append(underlyingAssetSubType, rhs.underlyingAssetSubType).append(gteSecurityClass, rhs.gteSecurityClass).append(couponType, rhs.couponType).append(issuerType, rhs.issuerType).append(yieldType, rhs.yieldType).append(bdlMarketSector, rhs.bdlMarketSector).append(marketSectorId, rhs.marketSectorId).append(bdlIssuerIndustry, rhs.bdlIssuerIndustry).append(bdlSecurityPaymentRanking, rhs.bdlSecurityPaymentRanking).append(gteSecuritySubClass, rhs.gteSecuritySubClass).append(gteSecurityType, rhs.gteSecurityType).append(bdlSecurityType2, rhs.bdlSecurityType2).append(bdlIndustryGroup, rhs.bdlIndustryGroup).append(bdlIndustrySector, rhs.bdlIndustrySector).append(mtgeType, rhs.mtgeType).append(bdlIndustrySubGroup, rhs.bdlIndustrySubGroup).append(gteSecuritySubType, rhs.gteSecuritySubType).append(mtgeAmortType, rhs.mtgeAmortType).append(lseSegment, rhs.lseSegment).append(bdlCertificateType, rhs.bdlCertificateType).append(stripType, rhs.stripType).append(bdlCouponType, rhs.bdlCouponType).append(bdlMortgageDealType, rhs.bdlMortgageDealType).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
