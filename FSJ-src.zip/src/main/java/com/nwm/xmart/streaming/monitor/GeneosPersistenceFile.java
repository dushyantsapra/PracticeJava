package com.nwm.xmart.streaming.monitor;


import com.nwm.xmart.streaming.monitor.exception.InactivityMonitorException;
import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by gardlex on 21/11/2017.
 */
public class GeneosPersistenceFile implements PersistenceFile {

    private static Logger logger = LoggerFactory.getLogger(GeneosPersistenceFile.class);
    private final Configuration configuration;
    private final String id;
    private final String watchTopicName;
    private final String jobName;
    private final String filePostfix;
    private final String fileLocation;
    private final String topicName;
    private final String topicID;
    private final SimpleDateFormat simpleDateFormat;


    public GeneosPersistenceFile(Configuration configuration) {
        this.configuration = configuration;
        this.watchTopicName = configuration.getString("flink.kafka.consumer.topic","");
        this.jobName = configuration.getString("flink.job.name", "NoJobNameSpecific");
        this.fileLocation = configuration.getString("kafka.inactivity.monitor.fileLocation", "");
        this.filePostfix = configuration.getString("kafka.inactivity.monitor.filename.postfix", "");
        this.id = jobName;
        this.topicName = configuration.getString("flink.kafka.consumer.topic.name", "");
        this.topicID = configuration.getString("flink.kafka.consumer.topic.ID", "");
        simpleDateFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");

        // Create file after Flink desserialises this class instance
        try {
            Path path = FileSystems.getDefault().getPath(fileLocation, jobName+filePostfix);
            logger.info("GeneosPersistenceFile: Path for filenamepath is = " + path.toString());
            BufferedWriter bufferedWriter = Files.newBufferedWriter(path , StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            logger.info("GeneosPersistenceFile: Created file (BufferedWriter) = " + bufferedWriter);
            bufferedWriter.close();
        } catch (IOException e) {
            logger.error("GeneosPersistenceFile: could not create inactivity file for jobName [ " + jobName + " ]");
            throw new InactivityMonitorException(e);
        }
    }

    @Override
    public void persistOffsetInfo(
            InactivityStatus inactivityStatus,
            long currentKafkaOffset,
            long lastOffset,
            long currentTimestamp,
            long lastTimestamp,
            long lastOffsetChangeTimestamp) throws IOException {
        // Persist but wipeout the file contents first
        Path path = FileSystems.getDefault().getPath(fileLocation, jobName+filePostfix);
        BufferedWriter bufferedWriter = Files.newBufferedWriter(path , StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

        // systime in Date format
        String currentTimestampDate = simpleDateFormat.format(new Date(currentTimestamp));
        String lastTimestampDate = simpleDateFormat.format(new Date(lastTimestamp));
        String lastOffsetChangeTimestampDate = simpleDateFormat.format(new Date(lastOffsetChangeTimestamp));
        BigDecimal currentTimestampBD = new BigDecimal(currentTimestamp);
        BigDecimal lastTimestampBD = new BigDecimal(lastTimestamp);
        BigDecimal lastOffsetChangeTimestampDateBD = new BigDecimal(lastOffsetChangeTimestamp);

        BigDecimal currentPreviousDeltaSecRoundedValue = currentTimestampBD.subtract(lastTimestampBD).divide(new BigDecimal(1000)).setScale(2, RoundingMode.DOWN);
        BigDecimal lastOffsetDelta = currentTimestampBD.subtract(lastOffsetChangeTimestampDateBD).divide(new BigDecimal(1000)).setScale(2, RoundingMode.DOWN);

        // Construct the persistence info
        StringBuilder sb = new StringBuilder();
        sb.append("ID, State, Topic ID, Topic Name, Watch Topic Name, Current Offset, Previous Offset, Delta Offset, Current Timestamp, Previous Timestamp, Current Previous Delta Secs, Last Offset Change Timestamp, Last Offset Delta Secs");
        sb.append(System.lineSeparator());
        sb.append(id);sb.append(",");
        sb.append(inactivityStatus.toString());sb.append(",");
        sb.append(topicID);sb.append(",");
        sb.append(topicName);sb.append(",");
        sb.append(watchTopicName);sb.append(",");
        sb.append(currentKafkaOffset);sb.append(",");
        sb.append(lastOffset);sb.append(",");
        sb.append(currentKafkaOffset - lastOffset);sb.append(",");
        sb.append(currentTimestampDate);sb.append(",");
        sb.append(lastTimestampDate);sb.append(",");
        sb.append(currentPreviousDeltaSecRoundedValue.toString());sb.append(",");
        sb.append(lastOffsetChangeTimestampDate);sb.append(",");
        sb.append(lastOffsetDelta.toString());

        String persistedOffSetInfo = sb.toString();

        //
        bufferedWriter.write(persistedOffSetInfo);
        bufferedWriter.flush();
        bufferedWriter.close();
    }
}
