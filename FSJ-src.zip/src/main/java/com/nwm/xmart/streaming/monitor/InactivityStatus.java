package com.nwm.xmart.streaming.monitor;

/**
 * Created by gardlex on 21/11/2017.
 */
public enum InactivityStatus {
    INACTIVE, ACTIVE_AT_LEAST_MIN_OFFSET_DELTA, ACTIVE_LESS_THAN_MIN_OFFSET_DELTA;
}
