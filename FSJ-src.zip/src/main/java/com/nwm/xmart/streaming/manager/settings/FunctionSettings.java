package com.nwm.xmart.streaming.manager.settings;

import java.util.HashMap;
import java.util.Map;

public class FunctionSettings {
    private final String functionName;
    private final String day;
    private Map<String, Object> extraParameters = new HashMap();

    public FunctionSettings(String functionName, String day) {
        this.functionName = functionName;
        this.day = day;
    }

    public FunctionSettings withExtraParameters(Map<String, Object> extraParameters) {
        this.extraParameters = extraParameters;
        return this;
    }

    public String getFunctionName() {
        return functionName;
    }

    public String getDay() {
        return day;
    }

    public Object getExtraParameter(String key) {
        return extraParameters.get(key);
    }
}
