package com.nwm.xmart.streaming.source.mdx.pull;

import com.nwm.xmart.streaming.source.mdx.subscription.MdxSubscription;
import com.nwm.xmart.streaming.source.mdx.cache.IsinCache;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.mdx.webService.interfaces.MdxException;

import java.util.*;

/**
 * Created by gardlex on 11/04/2018.
 */
public class TestTimeSeriesMdxInitialLoadEventExchange<MdxSourceEvent> implements MdxPullRequestDocumentLoader<MdxSourceEvent> {

    private static Logger logger = LoggerFactory.getLogger(TestTimeSeriesMdxInitialLoadEventExchange.class);
    private final Class<MdxSourceEvent> sourceEventClass;
//    private AtomicReference<PriorityBlockingQueue<MdxSourceEvent>> priorityQRef = new AtomicReference<>();
    private volatile int initialCapacity;
    private volatile int mdxReadBatchSize;
//    private volatile long lastXmlWriteTimeEpoch;
    private volatile String mdxIdentifier;
//    private volatile String mdxIdentifierWildcard;
//    private volatile String mdxSubscriptionIdentifier;
//    private volatile int noOfFullDocumentIdentifiersToFetch;

    public TestTimeSeriesMdxInitialLoadEventExchange(Class<MdxSourceEvent> sourceEventClass) {
        this.sourceEventClass = sourceEventClass;
    }

    @Override
    public MdxPullRequestDocumentLoader withInitialCapacity(int capacity) {
        this.initialCapacity = capacity;
        return this;
    }

    @Override
    public MdxPullRequestDocumentLoader withReadBatchSize(int readBatchSize) {
        this.mdxReadBatchSize = readBatchSize;
        return this;
    }

//    @Override
//    public MdxPullRequestDocumentLoader startWithXmlWriteTimeEpoch(long xmlWriteTimeEpoch) {
//        this.lastXmlWriteTimeEpoch = xmlWriteTimeEpoch;
//        return this;
//    }
//
//    @Override
//    public MdxPullRequestDocumentLoader withNoOfFullDocumentIdentifiersToFetch(int noOfFullDocumentIdentifiersToFetch) {
//        this.noOfFullDocumentIdentifiersToFetch = noOfFullDocumentIdentifiersToFetch;
//        return this;
//    }

    @Override
    public MdxPullRequestDocumentLoader withMdxIdentifier(String identifier) {
        this.mdxIdentifier = identifier;
        return this;
    }

    @Override
    public MdxPullRequestDocumentLoader withISINCache(IsinCache isinCache) {
        return null;
    }

    @Override
    public void setSourceContext(SourceFunction.SourceContext srcCtx) {

    }


    @Override
    public MdxPullRequestDocumentLoader withMdxDocumentStoreFetcher(MdxReader documentStoreFetcher) {
        return null;
    }

    @Override
    public void loadDocuments() throws MdxException {

    }

    @Override
    public MdxPullRequestDocumentLoader withCounter(IntCounter counter) {
        return null;
    }

    @Override
    public MdxPullRequestDocumentLoader withSubscription(MdxSubscription subscription) {
        return null;
    }

    @Override
    public void setInitialLoad(boolean isInitialLoad) {

    }

    @Override
    public MdxPullRequestDocumentLoader withSourceFunction(SourceFunction<MdxSourceEvent> sourceFunction) {
        return null;
    }

    @Override
    public void setLatestISINs(Set<String> latestIsinList, Set<String> newIsinList) {

    }

//    @Override
//    public MdxPullRequestDocumentLoader withMdxIdentifierWildcard(String wildcard) {
//        this.mdxIdentifierWildcard = wildcard;
//        return this;
//    }
//
//    @Override
//    public TestTimeSeriesMdxInitialLoadEventExchange withSubscriptionMdxIdentifier(String subscriptionIdentifier) {
//        this.mdxSubscriptionIdentifier = subscriptionIdentifier;
//        return this;
//    }
//
//    @Override
//    public MdxSourceEvent getNextMdxDocumentEvent() throws MdxException {
//        return priorityQRef.get().poll();
//    }
//
//    @Override
//    public int getSize() {
//        return priorityQRef.get().size();
//    }
//
//    @Override
//    public void cacheDocumentsForIndentifiers(MdxSessionContext mdxSessionContext, List<String> fullIdentifiersList) throws MdxException {
//        priorityQRef.set(new PriorityBlockingQueue<MdxSourceEvent>(initialCapacity, new WriteTimeComparator()));
//        int batchSize = 0;
//        List<String> batchList = new ArrayList<>();
//        IMdxDocumentCollection mdxBatchDocuments = null;
//        MdxSourceEvent mdxSourceEvent = null;
//
//        final PriorityBlockingQueue<MdxSourceEvent> priorityQ = priorityQRef.get();
//
//        for (int i=0; i < 55; i++) {
//
//            // MdxDateTime logicalTime, Date writeTime, double value, int version, String status
//            MdxTimePointContent timeSeriesContent = new MdxTimePointContent(MdxDateTime.getUtcNow(), 1, "Cnt-"+ i);
//
//            try {
//                priorityQ.add(ConstructorUtils.invokeConstructor(sourceEventClass, timeSeriesContent, System.nanoTime(), System.currentTimeMillis()));
//            } catch (Exception e) {
//                logger.error("Could not create MdxDocumentEvent constructor", e);
//                throw new MdxLoadFailureException("Could not create MdxDocumentEvent constructor", e);
//            }
//        }
//
//        logger.info("For Identifier [ " + mdxIdentifier + mdxIdentifierWildcard + " ], no of TIME SERIES documents retrieved is [ " + priorityQRef.get().size() + " ]");
//    }


    // TODO - use this
//    private void processTimeSeriesReader(IMdxTimeSeriesReader seriesReader) {
//        final PriorityBlockingQueue<MdxSourceEvent> priorityQ = priorityQRef.get();
//
//        for (int i=0; i < 55; i++) {
//
//            // MdxDateTime logicalTime, Date writeTime, double value, int version, String status
//            MdxTimePointContent timeSeriesContent = new MdxTimePointContent(MdxDateTime.getUtcNow(), 1, "Cnt-"+ i);
//
//            try {
//                priorityQ.add(ConstructorUtils.invokeConstructor(sourceEventClass, timeSeriesContent, System.nanoTime(), System.currentTimeMillis()));
//            } catch (Exception e) {
//                logger.error("Could not create MdxDocumentEvent constructor", e);
//                throw new MdxLoadFailureException("Could not create MdxDocumentEvent constructor", e);
//            }
//        }
//    }

//    @Override
//    public List<String> getFullDocumentIdentifiers(MdxSessionContext mdxSessionContext) throws MdxException {
////        String[] seriesViewFullIdentifiers = mdxSessionContext.getMdxSeriesViewSession().dir(mdxIdentifier+mdxIdentifierWildcard, true, noOfFullDocumentIdentifiersToFetch);
////        String[] timeSeriesFullIdentifiers = new String[seriesViewFullIdentifiers.length];
////        for (int i=0; i < seriesViewFullIdentifiers.length; i++) {
////            timeSeriesFullIdentifiers[i] = getTimeSeriesFullIdentifierFrom(seriesViewFullIdentifiers[i]);
////        }
////
////        logger.info("For Identifier [ " + mdxIdentifier +  mdxIdentifierWildcard + " ], no of FULL IDs retrieved is [ " + seriesViewFullIdentifiers.length + " ]");
////
////        return Arrays.asList(timeSeriesFullIdentifiers);
//        return new ArrayList<String>();
//    }

//    // TODO
//    private String getTimeSeriesFullIdentifierFrom(String seriesViewFullIdentifier) {
//        StringTokenizer st = new StringTokenizer(seriesViewFullIdentifier, "/");
//        st.nextElement();st.nextElement();st.nextElement();st.nextElement();
//        String isin = (String) st.nextElement();
//        String timeSeriesFullID = mdxSubscriptionIdentifier + isin + "/totv";
//
//        return timeSeriesFullID;
//    }
}
