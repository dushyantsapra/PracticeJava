package com.nwm.xmart.streaming.source.mdx.subscription;

/**
 * Created by gardlex on 15/11/2017.
 */
public class MdxSubscriptionFailureException extends RuntimeException {

    public MdxSubscriptionFailureException() {
        super();
    }

    public MdxSubscriptionFailureException(String msg) {
        super(msg);
    }

    public MdxSubscriptionFailureException(String msg, Throwable t) {
        super(msg, t);
    }
}
