package com.nwm.xmart.streaming.source.df.serialisation;

/**
 * Created by gardlex on 30/10/2017.
 */
public enum SourceDeserializerType {
    DATAFABRIC, ODC, UNKNOWN;

    public static SourceDeserializerType getType(String deserialiserType) {
        switch (deserialiserType) {
            case "DATAFABRIC" :
                return DATAFABRIC;
            case "ODC" :
                return ODC;
            default:
                return UNKNOWN;
        }
    }
}
