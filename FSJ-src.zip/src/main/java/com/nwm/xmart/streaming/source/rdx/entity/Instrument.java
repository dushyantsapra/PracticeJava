
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "AShareIndicator",
    "AssetClass",
    "AssetClassSubType",
    "BenchmarkTreasuryAtIssue",
    "BenchmarkIssueID",
    "CountryCode",
    "SettlementCalendar",
    "CountryOfDomicile",
    "CountryOfRegisterId",
    "CountryOfRegisterScheme",
    "CountryOfRegister",
    "CountryOfRiskId",
    "CountryOfRisk",
    "CountryOfRiskScheme",
    "EventCouponType",
    "DayCountDescription",
    "DefaultSettlementCondition",
    "UnderlyingName",
    "ExchangeMarketStatus",
    "FactorEffectiveDate",
    "FixToFloatDate",
    "FloatDaysPrior",
    "CountryCalenderCode",
    "CountryCalenderCodeClassSceheme",
    "CountryOfIncorporationId",
    "CountryofIncorporation",
    "CountryofIncorporationScheme",
    "InstrumentLongName",
    "InstrumentName",
    "InstrumentShortName",
    "IsGermanMTN",
    "IsGovernmentGuaranteed",
    "IsHybrid",
    "DefaultedIndicator",
    "IsIslamic",
    "LiquidityIndicator",
    "IsNonMarket",
    "IsPerpetual",
    "UserCreatedPvtPlacement",
    "IsSeasoned",
    "CountryOfIssueId",
    "CountryOfIssueScheme",
    "CountryOfIssue",
    "lastDeliveryDate",
    "LastTradeDate",
    "MinimumLot",
    "LSEEligibleFlag",
    "ListingStatus",
    "MaturityDate",
    "MbsTerm",
    "NormalMarketSize",
    "PayDay",
    "PctParQuoted",
    "PoolPayDelay",
    "QuotationIndicator",
    "ProviderZone",
    "QuoteType",
    "ReferenceIndex",
    "RegulatoryReporting",
    "ReportingMethod",
    "CouponRateFixingMethod",
    "SecurityRestrictUS",
    "SecurityFactorable",
    "DaysToSettleType",
    "DaysToSettlePeriod",
    "DaysToSettleMultiplier",
    "AccrualStartDate",
    "TradeStatus",
    "TrustPreferredIndicator",
    "IsTraceEligible",
    "ExchangeId",
    "StrikePrice",
    "ExerciseStartDate",
    "ConversionStartDate",
    "ExerciseEndDate",
    "ExerciseRatio",
    "IsCancelled",
    "IsPerforming",
    "CountryFullName",
    "IsIsinRequired",
    "BASEL3Designation",
    "AF300PriceFormat",
    "VendorInstrumentName",
    "TypeOfBond",
    "SecRegisteredSecurity",
    "TefraDIndicator",
    "VendorCountryOfIncorporation",
    "VendorCountryOfIssue",
    "VendorSecurityType",
    "SharesParAmount"
})
public class Instrument {

    @JsonProperty("AShareIndicator")
    private Object aShareIndicator;
    @JsonProperty("AssetClass")
    private String assetClass;
    @JsonProperty("AssetClassSubType")
    private String assetClassSubType;
    @JsonProperty("BenchmarkTreasuryAtIssue")
    private Object benchmarkTreasuryAtIssue;
    @JsonProperty("BenchmarkIssueID")
    private Object benchmarkIssueID;
    @JsonProperty("CountryCode")
    private String countryCode;
    @JsonProperty("SettlementCalendar")
    private Object settlementCalendar;
    @JsonProperty("CountryOfDomicile")
    private String countryOfDomicile;
    @JsonProperty("CountryOfRegisterId")
    private Object countryOfRegisterId;
    @JsonProperty("CountryOfRegisterScheme")
    private Object countryOfRegisterScheme;
    @JsonProperty("CountryOfRegister")
    private Object countryOfRegister;
    @JsonProperty("CountryOfRiskId")
    private String countryOfRiskId;
    @JsonProperty("CountryOfRisk")
    private String countryOfRisk;
    @JsonProperty("CountryOfRiskScheme")
    private String countryOfRiskScheme;
    @JsonProperty("EventCouponType")
    private Object eventCouponType;
    @JsonProperty("DayCountDescription")
    private Object dayCountDescription;
    @JsonProperty("DefaultSettlementCondition")
    private String defaultSettlementCondition;
    @JsonProperty("UnderlyingName")
    private Object underlyingName;
    @JsonProperty("ExchangeMarketStatus")
    private Object exchangeMarketStatus;
    @JsonProperty("FactorEffectiveDate")
    private Object factorEffectiveDate;
    @JsonProperty("FixToFloatDate")
    private Object fixToFloatDate;
    @JsonProperty("FloatDaysPrior")
    private Object floatDaysPrior;
    @JsonProperty("CountryCalenderCode")
    private Object countryCalenderCode;
    @JsonProperty("CountryCalenderCodeClassSceheme")
    private Object countryCalenderCodeClassSceheme;
    @JsonProperty("CountryOfIncorporationId")
    private Object countryOfIncorporationId;
    @JsonProperty("CountryofIncorporation")
    private Object countryofIncorporation;
    @JsonProperty("CountryofIncorporationScheme")
    private Object countryofIncorporationScheme;
    @JsonProperty("InstrumentLongName")
    private String instrumentLongName;
    @JsonProperty("InstrumentName")
    private String instrumentName;
    @JsonProperty("InstrumentShortName")
    private Object instrumentShortName;
    @JsonProperty("IsGermanMTN")
    private Object isGermanMTN;
    @JsonProperty("IsGovernmentGuaranteed")
    private Object isGovernmentGuaranteed;
    @JsonProperty("IsHybrid")
    private Object isHybrid;
    @JsonProperty("DefaultedIndicator")
    private Boolean defaultedIndicator;
    @JsonProperty("IsIslamic")
    private Object isIslamic;
    @JsonProperty("LiquidityIndicator")
    private Object liquidityIndicator;
    @JsonProperty("IsNonMarket")
    private Boolean isNonMarket;
    @JsonProperty("IsPerpetual")
    private Boolean isPerpetual;
    @JsonProperty("UserCreatedPvtPlacement")
    private Object userCreatedPvtPlacement;
    @JsonProperty("IsSeasoned")
    private Object isSeasoned;
    @JsonProperty("CountryOfIssueId")
    private Object countryOfIssueId;
    @JsonProperty("CountryOfIssueScheme")
    private Object countryOfIssueScheme;
    @JsonProperty("CountryOfIssue")
    private Object countryOfIssue;
    @JsonProperty("lastDeliveryDate")
    private Object lastDeliveryDate;
    @JsonProperty("LastTradeDate")
    private Object lastTradeDate;
    @JsonProperty("MinimumLot")
    private Double minimumLot;
    @JsonProperty("LSEEligibleFlag")
    private Object lSEEligibleFlag;
    @JsonProperty("ListingStatus")
    private Object listingStatus;
    @JsonProperty("MaturityDate")
    private String maturityDate;
    @JsonProperty("MbsTerm")
    private Object mbsTerm;
    @JsonProperty("NormalMarketSize")
    private Object normalMarketSize;
    @JsonProperty("PayDay")
    private Object payDay;
    @JsonProperty("PctParQuoted")
    private Boolean pctParQuoted;
    @JsonProperty("PoolPayDelay")
    private Object poolPayDelay;
    @JsonProperty("QuotationIndicator")
    private Object quotationIndicator;
    @JsonProperty("ProviderZone")
    private String providerZone;
    @JsonProperty("QuoteType")
    private Object quoteType;
    @JsonProperty("ReferenceIndex")
    private Object referenceIndex;
    @JsonProperty("RegulatoryReporting")
    private Object regulatoryReporting;
    @JsonProperty("ReportingMethod")
    private Object reportingMethod;
    @JsonProperty("CouponRateFixingMethod")
    private Object couponRateFixingMethod;
    @JsonProperty("SecurityRestrictUS")
    private Object securityRestrictUS;
    @JsonProperty("SecurityFactorable")
    private Object securityFactorable;
    @JsonProperty("DaysToSettleType")
    private String daysToSettleType;
    @JsonProperty("DaysToSettlePeriod")
    private Object daysToSettlePeriod;
    @JsonProperty("DaysToSettleMultiplier")
    private Integer daysToSettleMultiplier;
    @JsonProperty("AccrualStartDate")
    private Object accrualStartDate;
    @JsonProperty("TradeStatus")
    private Object tradeStatus;
    @JsonProperty("TrustPreferredIndicator")
    private Object trustPreferredIndicator;
    @JsonProperty("IsTraceEligible")
    private Object isTraceEligible;
    @JsonProperty("ExchangeId")
    private String exchangeId;
    @JsonProperty("StrikePrice")
    private Object strikePrice;
    @JsonProperty("ExerciseStartDate")
    private Object exerciseStartDate;
    @JsonProperty("ConversionStartDate")
    private Object conversionStartDate;
    @JsonProperty("ExerciseEndDate")
    private Object exerciseEndDate;
    @JsonProperty("ExerciseRatio")
    private Object exerciseRatio;
    @JsonProperty("IsCancelled")
    private Object isCancelled;
    @JsonProperty("IsPerforming")
    private Object isPerforming;
    @JsonProperty("CountryFullName")
    private Object countryFullName;
    @JsonProperty("IsIsinRequired")
    private Object isIsinRequired;
    @JsonProperty("BASEL3Designation")
    private Object bASEL3Designation;
    @JsonProperty("AF300PriceFormat")
    private Object aF300PriceFormat;
    @JsonProperty("VendorInstrumentName")
    private Object vendorInstrumentName;
    @JsonProperty("TypeOfBond")
    private Object typeOfBond;
    @JsonProperty("SecRegisteredSecurity")
    private Object secRegisteredSecurity;
    @JsonProperty("TefraDIndicator")
    private Object tefraDIndicator;
    @JsonProperty("VendorCountryOfIncorporation")
    private Object vendorCountryOfIncorporation;
    @JsonProperty("VendorCountryOfIssue")
    private Object vendorCountryOfIssue;
    @JsonProperty("VendorSecurityType")
    private Object vendorSecurityType;
    @JsonProperty("SharesParAmount")
    private Object sharesParAmount;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("AShareIndicator")
    public Object getAShareIndicator() {
        return aShareIndicator;
    }

    @JsonProperty("AShareIndicator")
    public void setAShareIndicator(Object aShareIndicator) {
        this.aShareIndicator = aShareIndicator;
    }

    @JsonProperty("AssetClass")
    public String getAssetClass() {
        return assetClass;
    }

    @JsonProperty("AssetClass")
    public void setAssetClass(String assetClass) {
        this.assetClass = assetClass;
    }

    @JsonProperty("AssetClassSubType")
    public String getAssetClassSubType() {
        return assetClassSubType;
    }

    @JsonProperty("AssetClassSubType")
    public void setAssetClassSubType(String assetClassSubType) {
        this.assetClassSubType = assetClassSubType;
    }

    @JsonProperty("BenchmarkTreasuryAtIssue")
    public Object getBenchmarkTreasuryAtIssue() {
        return benchmarkTreasuryAtIssue;
    }

    @JsonProperty("BenchmarkTreasuryAtIssue")
    public void setBenchmarkTreasuryAtIssue(Object benchmarkTreasuryAtIssue) {
        this.benchmarkTreasuryAtIssue = benchmarkTreasuryAtIssue;
    }

    @JsonProperty("BenchmarkIssueID")
    public Object getBenchmarkIssueID() {
        return benchmarkIssueID;
    }

    @JsonProperty("BenchmarkIssueID")
    public void setBenchmarkIssueID(Object benchmarkIssueID) {
        this.benchmarkIssueID = benchmarkIssueID;
    }

    @JsonProperty("CountryCode")
    public String getCountryCode() {
        return countryCode;
    }

    @JsonProperty("CountryCode")
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @JsonProperty("SettlementCalendar")
    public Object getSettlementCalendar() {
        return settlementCalendar;
    }

    @JsonProperty("SettlementCalendar")
    public void setSettlementCalendar(Object settlementCalendar) {
        this.settlementCalendar = settlementCalendar;
    }

    @JsonProperty("CountryOfDomicile")
    public String getCountryOfDomicile() {
        return countryOfDomicile;
    }

    @JsonProperty("CountryOfDomicile")
    public void setCountryOfDomicile(String countryOfDomicile) {
        this.countryOfDomicile = countryOfDomicile;
    }

    @JsonProperty("CountryOfRegisterId")
    public Object getCountryOfRegisterId() {
        return countryOfRegisterId;
    }

    @JsonProperty("CountryOfRegisterId")
    public void setCountryOfRegisterId(Object countryOfRegisterId) {
        this.countryOfRegisterId = countryOfRegisterId;
    }

    @JsonProperty("CountryOfRegisterScheme")
    public Object getCountryOfRegisterScheme() {
        return countryOfRegisterScheme;
    }

    @JsonProperty("CountryOfRegisterScheme")
    public void setCountryOfRegisterScheme(Object countryOfRegisterScheme) {
        this.countryOfRegisterScheme = countryOfRegisterScheme;
    }

    @JsonProperty("CountryOfRegister")
    public Object getCountryOfRegister() {
        return countryOfRegister;
    }

    @JsonProperty("CountryOfRegister")
    public void setCountryOfRegister(Object countryOfRegister) {
        this.countryOfRegister = countryOfRegister;
    }

    @JsonProperty("CountryOfRiskId")
    public String getCountryOfRiskId() {
        return countryOfRiskId;
    }

    @JsonProperty("CountryOfRiskId")
    public void setCountryOfRiskId(String countryOfRiskId) {
        this.countryOfRiskId = countryOfRiskId;
    }

    @JsonProperty("CountryOfRisk")
    public String getCountryOfRisk() {
        return countryOfRisk;
    }

    @JsonProperty("CountryOfRisk")
    public void setCountryOfRisk(String countryOfRisk) {
        this.countryOfRisk = countryOfRisk;
    }

    @JsonProperty("CountryOfRiskScheme")
    public String getCountryOfRiskScheme() {
        return countryOfRiskScheme;
    }

    @JsonProperty("CountryOfRiskScheme")
    public void setCountryOfRiskScheme(String countryOfRiskScheme) {
        this.countryOfRiskScheme = countryOfRiskScheme;
    }

    @JsonProperty("EventCouponType")
    public Object getEventCouponType() {
        return eventCouponType;
    }

    @JsonProperty("EventCouponType")
    public void setEventCouponType(Object eventCouponType) {
        this.eventCouponType = eventCouponType;
    }

    @JsonProperty("DayCountDescription")
    public Object getDayCountDescription() {
        return dayCountDescription;
    }

    @JsonProperty("DayCountDescription")
    public void setDayCountDescription(Object dayCountDescription) {
        this.dayCountDescription = dayCountDescription;
    }

    @JsonProperty("DefaultSettlementCondition")
    public String getDefaultSettlementCondition() {
        return defaultSettlementCondition;
    }

    @JsonProperty("DefaultSettlementCondition")
    public void setDefaultSettlementCondition(String defaultSettlementCondition) {
        this.defaultSettlementCondition = defaultSettlementCondition;
    }

    @JsonProperty("UnderlyingName")
    public Object getUnderlyingName() {
        return underlyingName;
    }

    @JsonProperty("UnderlyingName")
    public void setUnderlyingName(Object underlyingName) {
        this.underlyingName = underlyingName;
    }

    @JsonProperty("ExchangeMarketStatus")
    public Object getExchangeMarketStatus() {
        return exchangeMarketStatus;
    }

    @JsonProperty("ExchangeMarketStatus")
    public void setExchangeMarketStatus(Object exchangeMarketStatus) {
        this.exchangeMarketStatus = exchangeMarketStatus;
    }

    @JsonProperty("FactorEffectiveDate")
    public Object getFactorEffectiveDate() {
        return factorEffectiveDate;
    }

    @JsonProperty("FactorEffectiveDate")
    public void setFactorEffectiveDate(Object factorEffectiveDate) {
        this.factorEffectiveDate = factorEffectiveDate;
    }

    @JsonProperty("FixToFloatDate")
    public Object getFixToFloatDate() {
        return fixToFloatDate;
    }

    @JsonProperty("FixToFloatDate")
    public void setFixToFloatDate(Object fixToFloatDate) {
        this.fixToFloatDate = fixToFloatDate;
    }

    @JsonProperty("FloatDaysPrior")
    public Object getFloatDaysPrior() {
        return floatDaysPrior;
    }

    @JsonProperty("FloatDaysPrior")
    public void setFloatDaysPrior(Object floatDaysPrior) {
        this.floatDaysPrior = floatDaysPrior;
    }

    @JsonProperty("CountryCalenderCode")
    public Object getCountryCalenderCode() {
        return countryCalenderCode;
    }

    @JsonProperty("CountryCalenderCode")
    public void setCountryCalenderCode(Object countryCalenderCode) {
        this.countryCalenderCode = countryCalenderCode;
    }

    @JsonProperty("CountryCalenderCodeClassSceheme")
    public Object getCountryCalenderCodeClassSceheme() {
        return countryCalenderCodeClassSceheme;
    }

    @JsonProperty("CountryCalenderCodeClassSceheme")
    public void setCountryCalenderCodeClassSceheme(Object countryCalenderCodeClassSceheme) {
        this.countryCalenderCodeClassSceheme = countryCalenderCodeClassSceheme;
    }

    @JsonProperty("CountryOfIncorporationId")
    public Object getCountryOfIncorporationId() {
        return countryOfIncorporationId;
    }

    @JsonProperty("CountryOfIncorporationId")
    public void setCountryOfIncorporationId(Object countryOfIncorporationId) {
        this.countryOfIncorporationId = countryOfIncorporationId;
    }

    @JsonProperty("CountryofIncorporation")
    public Object getCountryofIncorporation() {
        return countryofIncorporation;
    }

    @JsonProperty("CountryofIncorporation")
    public void setCountryofIncorporation(Object countryofIncorporation) {
        this.countryofIncorporation = countryofIncorporation;
    }

    @JsonProperty("CountryofIncorporationScheme")
    public Object getCountryofIncorporationScheme() {
        return countryofIncorporationScheme;
    }

    @JsonProperty("CountryofIncorporationScheme")
    public void setCountryofIncorporationScheme(Object countryofIncorporationScheme) {
        this.countryofIncorporationScheme = countryofIncorporationScheme;
    }

    @JsonProperty("InstrumentLongName")
    public String getInstrumentLongName() {
        return instrumentLongName;
    }

    @JsonProperty("InstrumentLongName")
    public void setInstrumentLongName(String instrumentLongName) {
        this.instrumentLongName = instrumentLongName;
    }

    @JsonProperty("InstrumentName")
    public String getInstrumentName() {
        return instrumentName;
    }

    @JsonProperty("InstrumentName")
    public void setInstrumentName(String instrumentName) {
        this.instrumentName = instrumentName;
    }

    @JsonProperty("InstrumentShortName")
    public Object getInstrumentShortName() {
        return instrumentShortName;
    }

    @JsonProperty("InstrumentShortName")
    public void setInstrumentShortName(Object instrumentShortName) {
        this.instrumentShortName = instrumentShortName;
    }

    @JsonProperty("IsGermanMTN")
    public Object getIsGermanMTN() {
        return isGermanMTN;
    }

    @JsonProperty("IsGermanMTN")
    public void setIsGermanMTN(Object isGermanMTN) {
        this.isGermanMTN = isGermanMTN;
    }

    @JsonProperty("IsGovernmentGuaranteed")
    public Object getIsGovernmentGuaranteed() {
        return isGovernmentGuaranteed;
    }

    @JsonProperty("IsGovernmentGuaranteed")
    public void setIsGovernmentGuaranteed(Object isGovernmentGuaranteed) {
        this.isGovernmentGuaranteed = isGovernmentGuaranteed;
    }

    @JsonProperty("IsHybrid")
    public Object getIsHybrid() {
        return isHybrid;
    }

    @JsonProperty("IsHybrid")
    public void setIsHybrid(Object isHybrid) {
        this.isHybrid = isHybrid;
    }

    @JsonProperty("DefaultedIndicator")
    public Boolean getDefaultedIndicator() {
        return defaultedIndicator;
    }

    @JsonProperty("DefaultedIndicator")
    public void setDefaultedIndicator(Boolean defaultedIndicator) {
        this.defaultedIndicator = defaultedIndicator;
    }

    @JsonProperty("IsIslamic")
    public Object getIsIslamic() {
        return isIslamic;
    }

    @JsonProperty("IsIslamic")
    public void setIsIslamic(Object isIslamic) {
        this.isIslamic = isIslamic;
    }

    @JsonProperty("LiquidityIndicator")
    public Object getLiquidityIndicator() {
        return liquidityIndicator;
    }

    @JsonProperty("LiquidityIndicator")
    public void setLiquidityIndicator(Object liquidityIndicator) {
        this.liquidityIndicator = liquidityIndicator;
    }

    @JsonProperty("IsNonMarket")
    public Boolean getIsNonMarket() {
        return isNonMarket;
    }

    @JsonProperty("IsNonMarket")
    public void setIsNonMarket(Boolean isNonMarket) {
        this.isNonMarket = isNonMarket;
    }

    @JsonProperty("IsPerpetual")
    public Boolean getIsPerpetual() {
        return isPerpetual;
    }

    @JsonProperty("IsPerpetual")
    public void setIsPerpetual(Boolean isPerpetual) {
        this.isPerpetual = isPerpetual;
    }

    @JsonProperty("UserCreatedPvtPlacement")
    public Object getUserCreatedPvtPlacement() {
        return userCreatedPvtPlacement;
    }

    @JsonProperty("UserCreatedPvtPlacement")
    public void setUserCreatedPvtPlacement(Object userCreatedPvtPlacement) {
        this.userCreatedPvtPlacement = userCreatedPvtPlacement;
    }

    @JsonProperty("IsSeasoned")
    public Object getIsSeasoned() {
        return isSeasoned;
    }

    @JsonProperty("IsSeasoned")
    public void setIsSeasoned(Object isSeasoned) {
        this.isSeasoned = isSeasoned;
    }

    @JsonProperty("CountryOfIssueId")
    public Object getCountryOfIssueId() {
        return countryOfIssueId;
    }

    @JsonProperty("CountryOfIssueId")
    public void setCountryOfIssueId(Object countryOfIssueId) {
        this.countryOfIssueId = countryOfIssueId;
    }

    @JsonProperty("CountryOfIssueScheme")
    public Object getCountryOfIssueScheme() {
        return countryOfIssueScheme;
    }

    @JsonProperty("CountryOfIssueScheme")
    public void setCountryOfIssueScheme(Object countryOfIssueScheme) {
        this.countryOfIssueScheme = countryOfIssueScheme;
    }

    @JsonProperty("CountryOfIssue")
    public Object getCountryOfIssue() {
        return countryOfIssue;
    }

    @JsonProperty("CountryOfIssue")
    public void setCountryOfIssue(Object countryOfIssue) {
        this.countryOfIssue = countryOfIssue;
    }

    @JsonProperty("lastDeliveryDate")
    public Object getLastDeliveryDate() {
        return lastDeliveryDate;
    }

    @JsonProperty("lastDeliveryDate")
    public void setLastDeliveryDate(Object lastDeliveryDate) {
        this.lastDeliveryDate = lastDeliveryDate;
    }

    @JsonProperty("LastTradeDate")
    public Object getLastTradeDate() {
        return lastTradeDate;
    }

    @JsonProperty("LastTradeDate")
    public void setLastTradeDate(Object lastTradeDate) {
        this.lastTradeDate = lastTradeDate;
    }

    @JsonProperty("MinimumLot")
    public Double getMinimumLot() {
        return minimumLot;
    }

    @JsonProperty("MinimumLot")
    public void setMinimumLot(Double minimumLot) {
        this.minimumLot = minimumLot;
    }

    @JsonProperty("LSEEligibleFlag")
    public Object getLSEEligibleFlag() {
        return lSEEligibleFlag;
    }

    @JsonProperty("LSEEligibleFlag")
    public void setLSEEligibleFlag(Object lSEEligibleFlag) {
        this.lSEEligibleFlag = lSEEligibleFlag;
    }

    @JsonProperty("ListingStatus")
    public Object getListingStatus() {
        return listingStatus;
    }

    @JsonProperty("ListingStatus")
    public void setListingStatus(Object listingStatus) {
        this.listingStatus = listingStatus;
    }

    @JsonProperty("MaturityDate")
    public String getMaturityDate() {
        return maturityDate;
    }

    @JsonProperty("MaturityDate")
    public void setMaturityDate(String maturityDate) {
        this.maturityDate = maturityDate;
    }

    @JsonProperty("MbsTerm")
    public Object getMbsTerm() {
        return mbsTerm;
    }

    @JsonProperty("MbsTerm")
    public void setMbsTerm(Object mbsTerm) {
        this.mbsTerm = mbsTerm;
    }

    @JsonProperty("NormalMarketSize")
    public Object getNormalMarketSize() {
        return normalMarketSize;
    }

    @JsonProperty("NormalMarketSize")
    public void setNormalMarketSize(Object normalMarketSize) {
        this.normalMarketSize = normalMarketSize;
    }

    @JsonProperty("PayDay")
    public Object getPayDay() {
        return payDay;
    }

    @JsonProperty("PayDay")
    public void setPayDay(Object payDay) {
        this.payDay = payDay;
    }

    @JsonProperty("PctParQuoted")
    public Boolean getPctParQuoted() {
        return pctParQuoted;
    }

    @JsonProperty("PctParQuoted")
    public void setPctParQuoted(Boolean pctParQuoted) {
        this.pctParQuoted = pctParQuoted;
    }

    @JsonProperty("PoolPayDelay")
    public Object getPoolPayDelay() {
        return poolPayDelay;
    }

    @JsonProperty("PoolPayDelay")
    public void setPoolPayDelay(Object poolPayDelay) {
        this.poolPayDelay = poolPayDelay;
    }

    @JsonProperty("QuotationIndicator")
    public Object getQuotationIndicator() {
        return quotationIndicator;
    }

    @JsonProperty("QuotationIndicator")
    public void setQuotationIndicator(Object quotationIndicator) {
        this.quotationIndicator = quotationIndicator;
    }

    @JsonProperty("ProviderZone")
    public String getProviderZone() {
        return providerZone;
    }

    @JsonProperty("ProviderZone")
    public void setProviderZone(String providerZone) {
        this.providerZone = providerZone;
    }

    @JsonProperty("QuoteType")
    public Object getQuoteType() {
        return quoteType;
    }

    @JsonProperty("QuoteType")
    public void setQuoteType(Object quoteType) {
        this.quoteType = quoteType;
    }

    @JsonProperty("ReferenceIndex")
    public Object getReferenceIndex() {
        return referenceIndex;
    }

    @JsonProperty("ReferenceIndex")
    public void setReferenceIndex(Object referenceIndex) {
        this.referenceIndex = referenceIndex;
    }

    @JsonProperty("RegulatoryReporting")
    public Object getRegulatoryReporting() {
        return regulatoryReporting;
    }

    @JsonProperty("RegulatoryReporting")
    public void setRegulatoryReporting(Object regulatoryReporting) {
        this.regulatoryReporting = regulatoryReporting;
    }

    @JsonProperty("ReportingMethod")
    public Object getReportingMethod() {
        return reportingMethod;
    }

    @JsonProperty("ReportingMethod")
    public void setReportingMethod(Object reportingMethod) {
        this.reportingMethod = reportingMethod;
    }

    @JsonProperty("CouponRateFixingMethod")
    public Object getCouponRateFixingMethod() {
        return couponRateFixingMethod;
    }

    @JsonProperty("CouponRateFixingMethod")
    public void setCouponRateFixingMethod(Object couponRateFixingMethod) {
        this.couponRateFixingMethod = couponRateFixingMethod;
    }

    @JsonProperty("SecurityRestrictUS")
    public Object getSecurityRestrictUS() {
        return securityRestrictUS;
    }

    @JsonProperty("SecurityRestrictUS")
    public void setSecurityRestrictUS(Object securityRestrictUS) {
        this.securityRestrictUS = securityRestrictUS;
    }

    @JsonProperty("SecurityFactorable")
    public Object getSecurityFactorable() {
        return securityFactorable;
    }

    @JsonProperty("SecurityFactorable")
    public void setSecurityFactorable(Object securityFactorable) {
        this.securityFactorable = securityFactorable;
    }

    @JsonProperty("DaysToSettleType")
    public String getDaysToSettleType() {
        return daysToSettleType;
    }

    @JsonProperty("DaysToSettleType")
    public void setDaysToSettleType(String daysToSettleType) {
        this.daysToSettleType = daysToSettleType;
    }

    @JsonProperty("DaysToSettlePeriod")
    public Object getDaysToSettlePeriod() {
        return daysToSettlePeriod;
    }

    @JsonProperty("DaysToSettlePeriod")
    public void setDaysToSettlePeriod(Object daysToSettlePeriod) {
        this.daysToSettlePeriod = daysToSettlePeriod;
    }

    @JsonProperty("DaysToSettleMultiplier")
    public Integer getDaysToSettleMultiplier() {
        return daysToSettleMultiplier;
    }

    @JsonProperty("DaysToSettleMultiplier")
    public void setDaysToSettleMultiplier(Integer daysToSettleMultiplier) {
        this.daysToSettleMultiplier = daysToSettleMultiplier;
    }

    @JsonProperty("AccrualStartDate")
    public Object getAccrualStartDate() {
        return accrualStartDate;
    }

    @JsonProperty("AccrualStartDate")
    public void setAccrualStartDate(Object accrualStartDate) {
        this.accrualStartDate = accrualStartDate;
    }

    @JsonProperty("TradeStatus")
    public Object getTradeStatus() {
        return tradeStatus;
    }

    @JsonProperty("TradeStatus")
    public void setTradeStatus(Object tradeStatus) {
        this.tradeStatus = tradeStatus;
    }

    @JsonProperty("TrustPreferredIndicator")
    public Object getTrustPreferredIndicator() {
        return trustPreferredIndicator;
    }

    @JsonProperty("TrustPreferredIndicator")
    public void setTrustPreferredIndicator(Object trustPreferredIndicator) {
        this.trustPreferredIndicator = trustPreferredIndicator;
    }

    @JsonProperty("IsTraceEligible")
    public Object getIsTraceEligible() {
        return isTraceEligible;
    }

    @JsonProperty("IsTraceEligible")
    public void setIsTraceEligible(Object isTraceEligible) {
        this.isTraceEligible = isTraceEligible;
    }

    @JsonProperty("ExchangeId")
    public String getExchangeId() {
        return exchangeId;
    }

    @JsonProperty("ExchangeId")
    public void setExchangeId(String exchangeId) {
        this.exchangeId = exchangeId;
    }

    @JsonProperty("StrikePrice")
    public Object getStrikePrice() {
        return strikePrice;
    }

    @JsonProperty("StrikePrice")
    public void setStrikePrice(Object strikePrice) {
        this.strikePrice = strikePrice;
    }

    @JsonProperty("ExerciseStartDate")
    public Object getExerciseStartDate() {
        return exerciseStartDate;
    }

    @JsonProperty("ExerciseStartDate")
    public void setExerciseStartDate(Object exerciseStartDate) {
        this.exerciseStartDate = exerciseStartDate;
    }

    @JsonProperty("ConversionStartDate")
    public Object getConversionStartDate() {
        return conversionStartDate;
    }

    @JsonProperty("ConversionStartDate")
    public void setConversionStartDate(Object conversionStartDate) {
        this.conversionStartDate = conversionStartDate;
    }

    @JsonProperty("ExerciseEndDate")
    public Object getExerciseEndDate() {
        return exerciseEndDate;
    }

    @JsonProperty("ExerciseEndDate")
    public void setExerciseEndDate(Object exerciseEndDate) {
        this.exerciseEndDate = exerciseEndDate;
    }

    @JsonProperty("ExerciseRatio")
    public Object getExerciseRatio() {
        return exerciseRatio;
    }

    @JsonProperty("ExerciseRatio")
    public void setExerciseRatio(Object exerciseRatio) {
        this.exerciseRatio = exerciseRatio;
    }

    @JsonProperty("IsCancelled")
    public Object getIsCancelled() {
        return isCancelled;
    }

    @JsonProperty("IsCancelled")
    public void setIsCancelled(Object isCancelled) {
        this.isCancelled = isCancelled;
    }

    @JsonProperty("IsPerforming")
    public Object getIsPerforming() {
        return isPerforming;
    }

    @JsonProperty("IsPerforming")
    public void setIsPerforming(Object isPerforming) {
        this.isPerforming = isPerforming;
    }

    @JsonProperty("CountryFullName")
    public Object getCountryFullName() {
        return countryFullName;
    }

    @JsonProperty("CountryFullName")
    public void setCountryFullName(Object countryFullName) {
        this.countryFullName = countryFullName;
    }

    @JsonProperty("IsIsinRequired")
    public Object getIsIsinRequired() {
        return isIsinRequired;
    }

    @JsonProperty("IsIsinRequired")
    public void setIsIsinRequired(Object isIsinRequired) {
        this.isIsinRequired = isIsinRequired;
    }

    @JsonProperty("BASEL3Designation")
    public Object getBASEL3Designation() {
        return bASEL3Designation;
    }

    @JsonProperty("BASEL3Designation")
    public void setBASEL3Designation(Object bASEL3Designation) {
        this.bASEL3Designation = bASEL3Designation;
    }

    @JsonProperty("AF300PriceFormat")
    public Object getAF300PriceFormat() {
        return aF300PriceFormat;
    }

    @JsonProperty("AF300PriceFormat")
    public void setAF300PriceFormat(Object aF300PriceFormat) {
        this.aF300PriceFormat = aF300PriceFormat;
    }

    @JsonProperty("VendorInstrumentName")
    public Object getVendorInstrumentName() {
        return vendorInstrumentName;
    }

    @JsonProperty("VendorInstrumentName")
    public void setVendorInstrumentName(Object vendorInstrumentName) {
        this.vendorInstrumentName = vendorInstrumentName;
    }

    @JsonProperty("TypeOfBond")
    public Object getTypeOfBond() {
        return typeOfBond;
    }

    @JsonProperty("TypeOfBond")
    public void setTypeOfBond(Object typeOfBond) {
        this.typeOfBond = typeOfBond;
    }

    @JsonProperty("SecRegisteredSecurity")
    public Object getSecRegisteredSecurity() {
        return secRegisteredSecurity;
    }

    @JsonProperty("SecRegisteredSecurity")
    public void setSecRegisteredSecurity(Object secRegisteredSecurity) {
        this.secRegisteredSecurity = secRegisteredSecurity;
    }

    @JsonProperty("TefraDIndicator")
    public Object getTefraDIndicator() {
        return tefraDIndicator;
    }

    @JsonProperty("TefraDIndicator")
    public void setTefraDIndicator(Object tefraDIndicator) {
        this.tefraDIndicator = tefraDIndicator;
    }

    @JsonProperty("VendorCountryOfIncorporation")
    public Object getVendorCountryOfIncorporation() {
        return vendorCountryOfIncorporation;
    }

    @JsonProperty("VendorCountryOfIncorporation")
    public void setVendorCountryOfIncorporation(Object vendorCountryOfIncorporation) {
        this.vendorCountryOfIncorporation = vendorCountryOfIncorporation;
    }

    @JsonProperty("VendorCountryOfIssue")
    public Object getVendorCountryOfIssue() {
        return vendorCountryOfIssue;
    }

    @JsonProperty("VendorCountryOfIssue")
    public void setVendorCountryOfIssue(Object vendorCountryOfIssue) {
        this.vendorCountryOfIssue = vendorCountryOfIssue;
    }

    @JsonProperty("VendorSecurityType")
    public Object getVendorSecurityType() {
        return vendorSecurityType;
    }

    @JsonProperty("VendorSecurityType")
    public void setVendorSecurityType(Object vendorSecurityType) {
        this.vendorSecurityType = vendorSecurityType;
    }

    @JsonProperty("SharesParAmount")
    public Object getSharesParAmount() {
        return sharesParAmount;
    }

    @JsonProperty("SharesParAmount")
    public void setSharesParAmount(Object sharesParAmount) {
        this.sharesParAmount = sharesParAmount;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("aShareIndicator", aShareIndicator).append("assetClass", assetClass).append("assetClassSubType", assetClassSubType).append("benchmarkTreasuryAtIssue", benchmarkTreasuryAtIssue).append("benchmarkIssueID", benchmarkIssueID).append("countryCode", countryCode).append("settlementCalendar", settlementCalendar).append("countryOfDomicile", countryOfDomicile).append("countryOfRegisterId", countryOfRegisterId).append("countryOfRegisterScheme", countryOfRegisterScheme).append("countryOfRegister", countryOfRegister).append("countryOfRiskId", countryOfRiskId).append("countryOfRisk", countryOfRisk).append("countryOfRiskScheme", countryOfRiskScheme).append("eventCouponType", eventCouponType).append("dayCountDescription", dayCountDescription).append("defaultSettlementCondition", defaultSettlementCondition).append("underlyingName", underlyingName).append("exchangeMarketStatus", exchangeMarketStatus).append("factorEffectiveDate", factorEffectiveDate).append("fixToFloatDate", fixToFloatDate).append("floatDaysPrior", floatDaysPrior).append("countryCalenderCode", countryCalenderCode).append("countryCalenderCodeClassSceheme", countryCalenderCodeClassSceheme).append("countryOfIncorporationId", countryOfIncorporationId).append("countryofIncorporation", countryofIncorporation).append("countryofIncorporationScheme", countryofIncorporationScheme).append("instrumentLongName", instrumentLongName).append("instrumentName", instrumentName).append("instrumentShortName", instrumentShortName).append("isGermanMTN", isGermanMTN).append("isGovernmentGuaranteed", isGovernmentGuaranteed).append("isHybrid", isHybrid).append("defaultedIndicator", defaultedIndicator).append("isIslamic", isIslamic).append("liquidityIndicator", liquidityIndicator).append("isNonMarket", isNonMarket).append("isPerpetual", isPerpetual).append("userCreatedPvtPlacement", userCreatedPvtPlacement).append("isSeasoned", isSeasoned).append("countryOfIssueId", countryOfIssueId).append("countryOfIssueScheme", countryOfIssueScheme).append("countryOfIssue", countryOfIssue).append("lastDeliveryDate", lastDeliveryDate).append("lastTradeDate", lastTradeDate).append("minimumLot", minimumLot).append("lSEEligibleFlag", lSEEligibleFlag).append("listingStatus", listingStatus).append("maturityDate", maturityDate).append("mbsTerm", mbsTerm).append("normalMarketSize", normalMarketSize).append("payDay", payDay).append("pctParQuoted", pctParQuoted).append("poolPayDelay", poolPayDelay).append("quotationIndicator", quotationIndicator).append("providerZone", providerZone).append("quoteType", quoteType).append("referenceIndex", referenceIndex).append("regulatoryReporting", regulatoryReporting).append("reportingMethod", reportingMethod).append("couponRateFixingMethod", couponRateFixingMethod).append("securityRestrictUS", securityRestrictUS).append("securityFactorable", securityFactorable).append("daysToSettleType", daysToSettleType).append("daysToSettlePeriod", daysToSettlePeriod).append("daysToSettleMultiplier", daysToSettleMultiplier).append("accrualStartDate", accrualStartDate).append("tradeStatus", tradeStatus).append("trustPreferredIndicator", trustPreferredIndicator).append("isTraceEligible", isTraceEligible).append("exchangeId", exchangeId).append("strikePrice", strikePrice).append("exerciseStartDate", exerciseStartDate).append("conversionStartDate", conversionStartDate).append("exerciseEndDate", exerciseEndDate).append("exerciseRatio", exerciseRatio).append("isCancelled", isCancelled).append("isPerforming", isPerforming).append("countryFullName", countryFullName).append("isIsinRequired", isIsinRequired).append("bASEL3Designation", bASEL3Designation).append("aF300PriceFormat", aF300PriceFormat).append("vendorInstrumentName", vendorInstrumentName).append("typeOfBond", typeOfBond).append("secRegisteredSecurity", secRegisteredSecurity).append("tefraDIndicator", tefraDIndicator).append("vendorCountryOfIncorporation", vendorCountryOfIncorporation).append("vendorCountryOfIssue", vendorCountryOfIssue).append("vendorSecurityType", vendorSecurityType).append("sharesParAmount", sharesParAmount).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(pctParQuoted).append(countryOfRiskScheme).append(isIslamic).append(liquidityIndicator).append(bASEL3Designation).append(instrumentShortName).append(lSEEligibleFlag).append(countryofIncorporationScheme).append(assetClass).append(countryOfRisk).append(countryOfIssueId).append(typeOfBond).append(vendorCountryOfIssue).append(isTraceEligible).append(countryCalenderCodeClassSceheme).append(daysToSettlePeriod).append(maturityDate).append(regulatoryReporting).append(securityFactorable).append(daysToSettleType).append(isGermanMTN).append(countryofIncorporation).append(defaultedIndicator).append(conversionStartDate).append(dayCountDescription).append(eventCouponType).append(instrumentLongName).append(vendorSecurityType).append(benchmarkIssueID).append(countryOfRegisterScheme).append(instrumentName).append(userCreatedPvtPlacement).append(mbsTerm).append(providerZone).append(underlyingName).append(normalMarketSize).append(tradeStatus).append(countryOfIncorporationId).append(isHybrid).append(countryOfRiskId).append(sharesParAmount).append(additionalProperties).append(defaultSettlementCondition).append(exerciseRatio).append(strikePrice).append(referenceIndex).append(countryOfIssue).append(isGovernmentGuaranteed).append(tefraDIndicator).append(minimumLot).append(fixToFloatDate).append(vendorInstrumentName).append(assetClassSubType).append(quoteType).append(aF300PriceFormat).append(exchangeMarketStatus).append(isSeasoned).append(exerciseStartDate).append(accrualStartDate).append(quotationIndicator).append(countryCode).append(aShareIndicator).append(listingStatus).append(countryCalenderCode).append(lastTradeDate).append(isPerforming).append(isPerpetual).append(vendorCountryOfIncorporation).append(countryOfIssueScheme).append(daysToSettleMultiplier).append(factorEffectiveDate).append(reportingMethod).append(isCancelled).append(secRegisteredSecurity).append(countryFullName).append(benchmarkTreasuryAtIssue).append(trustPreferredIndicator).append(countryOfRegisterId).append(countryOfDomicile).append(countryOfRegister).append(poolPayDelay).append(lastDeliveryDate).append(securityRestrictUS).append(exerciseEndDate).append(couponRateFixingMethod).append(exchangeId).append(floatDaysPrior).append(isIsinRequired).append(isNonMarket).append(payDay).append(settlementCalendar).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Instrument) == false) {
            return false;
        }
        Instrument rhs = ((Instrument) other);
        return new EqualsBuilder().append(pctParQuoted, rhs.pctParQuoted).append(countryOfRiskScheme, rhs.countryOfRiskScheme).append(isIslamic, rhs.isIslamic).append(liquidityIndicator, rhs.liquidityIndicator).append(bASEL3Designation, rhs.bASEL3Designation).append(instrumentShortName, rhs.instrumentShortName).append(lSEEligibleFlag, rhs.lSEEligibleFlag).append(countryofIncorporationScheme, rhs.countryofIncorporationScheme).append(assetClass, rhs.assetClass).append(countryOfRisk, rhs.countryOfRisk).append(countryOfIssueId, rhs.countryOfIssueId).append(typeOfBond, rhs.typeOfBond).append(vendorCountryOfIssue, rhs.vendorCountryOfIssue).append(isTraceEligible, rhs.isTraceEligible).append(countryCalenderCodeClassSceheme, rhs.countryCalenderCodeClassSceheme).append(daysToSettlePeriod, rhs.daysToSettlePeriod).append(maturityDate, rhs.maturityDate).append(regulatoryReporting, rhs.regulatoryReporting).append(securityFactorable, rhs.securityFactorable).append(daysToSettleType, rhs.daysToSettleType).append(isGermanMTN, rhs.isGermanMTN).append(countryofIncorporation, rhs.countryofIncorporation).append(defaultedIndicator, rhs.defaultedIndicator).append(conversionStartDate, rhs.conversionStartDate).append(dayCountDescription, rhs.dayCountDescription).append(eventCouponType, rhs.eventCouponType).append(instrumentLongName, rhs.instrumentLongName).append(vendorSecurityType, rhs.vendorSecurityType).append(benchmarkIssueID, rhs.benchmarkIssueID).append(countryOfRegisterScheme, rhs.countryOfRegisterScheme).append(instrumentName, rhs.instrumentName).append(userCreatedPvtPlacement, rhs.userCreatedPvtPlacement).append(mbsTerm, rhs.mbsTerm).append(providerZone, rhs.providerZone).append(underlyingName, rhs.underlyingName).append(normalMarketSize, rhs.normalMarketSize).append(tradeStatus, rhs.tradeStatus).append(countryOfIncorporationId, rhs.countryOfIncorporationId).append(isHybrid, rhs.isHybrid).append(countryOfRiskId, rhs.countryOfRiskId).append(sharesParAmount, rhs.sharesParAmount).append(additionalProperties, rhs.additionalProperties).append(defaultSettlementCondition, rhs.defaultSettlementCondition).append(exerciseRatio, rhs.exerciseRatio).append(strikePrice, rhs.strikePrice).append(referenceIndex, rhs.referenceIndex).append(countryOfIssue, rhs.countryOfIssue).append(isGovernmentGuaranteed, rhs.isGovernmentGuaranteed).append(tefraDIndicator, rhs.tefraDIndicator).append(minimumLot, rhs.minimumLot).append(fixToFloatDate, rhs.fixToFloatDate).append(vendorInstrumentName, rhs.vendorInstrumentName).append(assetClassSubType, rhs.assetClassSubType).append(quoteType, rhs.quoteType).append(aF300PriceFormat, rhs.aF300PriceFormat).append(exchangeMarketStatus, rhs.exchangeMarketStatus).append(isSeasoned, rhs.isSeasoned).append(exerciseStartDate, rhs.exerciseStartDate).append(accrualStartDate, rhs.accrualStartDate).append(quotationIndicator, rhs.quotationIndicator).append(countryCode, rhs.countryCode).append(aShareIndicator, rhs.aShareIndicator).append(listingStatus, rhs.listingStatus).append(countryCalenderCode, rhs.countryCalenderCode).append(lastTradeDate, rhs.lastTradeDate).append(isPerforming, rhs.isPerforming).append(isPerpetual, rhs.isPerpetual).append(vendorCountryOfIncorporation, rhs.vendorCountryOfIncorporation).append(countryOfIssueScheme, rhs.countryOfIssueScheme).append(daysToSettleMultiplier, rhs.daysToSettleMultiplier).append(factorEffectiveDate, rhs.factorEffectiveDate).append(reportingMethod, rhs.reportingMethod).append(isCancelled, rhs.isCancelled).append(secRegisteredSecurity, rhs.secRegisteredSecurity).append(countryFullName, rhs.countryFullName).append(benchmarkTreasuryAtIssue, rhs.benchmarkTreasuryAtIssue).append(trustPreferredIndicator, rhs.trustPreferredIndicator).append(countryOfRegisterId, rhs.countryOfRegisterId).append(countryOfDomicile, rhs.countryOfDomicile).append(countryOfRegister, rhs.countryOfRegister).append(poolPayDelay, rhs.poolPayDelay).append(lastDeliveryDate, rhs.lastDeliveryDate).append(securityRestrictUS, rhs.securityRestrictUS).append(exerciseEndDate, rhs.exerciseEndDate).append(couponRateFixingMethod, rhs.couponRateFixingMethod).append(exchangeId, rhs.exchangeId).append(floatDaysPrior, rhs.floatDaysPrior).append(isIsinRequired, rhs.isIsinRequired).append(isNonMarket, rhs.isNonMarket).append(payDay, rhs.payDay).append(settlementCalendar, rhs.settlementCalendar).isEquals();
    }

}
