package com.nwm.xmart.streaming.source.mdx.entity;

public class RefRegInstrumentDerivedFields {
    private String derivedShortName;
    private String issuerorOperatoroftheTradingVenueIdentifier;
    private String commodityDerivativeIndicator;
    private String fXType;
    private String fullName;
    private String shortName;
    private String classificationType;
    private String iSOReferenceRate;
    private String singleorMultiCurrency;

    private RefRegInstrumentGenericFields refRegInstrumentGenericFields;

    public String getIssuerorOperatoroftheTradingVenueIdentifier() {
        return issuerorOperatoroftheTradingVenueIdentifier;
    }

    public void setIssuerorOperatoroftheTradingVenueIdentifier(String issuerorOperatoroftheTradingVenueIdentifier) {
        this.issuerorOperatoroftheTradingVenueIdentifier = issuerorOperatoroftheTradingVenueIdentifier;
    }

    public String getCommodityDerivativeIndicator() {
        return commodityDerivativeIndicator;
    }

    public void setCommodityDerivativeIndicator(String commodityDerivativeIndicator) {
        this.commodityDerivativeIndicator = commodityDerivativeIndicator;
    }

    public String getfXType() {
        return fXType;
    }

    public void setfXType(String fXType) {
        this.fXType = fXType;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getDerivedShortName() {
        return derivedShortName;
    }

    public void setDerivedShortName(String derivedShortName) {
        this.derivedShortName = derivedShortName;
    }

    public String getClassificationType() {
        return classificationType;
    }

    public void setClassificationType(String classificationType) {
        this.classificationType = classificationType;
    }

    public String getiSOReferenceRate() {
        return iSOReferenceRate;
    }

    public void setiSOReferenceRate(String iSOReferenceRate) {
        this.iSOReferenceRate = iSOReferenceRate;
    }

    public String getSingleorMultiCurrency() {
        return singleorMultiCurrency;
    }

    public void setSingleorMultiCurrency(String singleorMultiCurrency) {
        this.singleorMultiCurrency = singleorMultiCurrency;
    }

    public RefRegInstrumentGenericFields getRefRegInstrumentGenericFields() {
        return refRegInstrumentGenericFields;
    }

    public void setRefRegInstrumentGenericFields(RefRegInstrumentGenericFields refRegInstrumentGenericFields) {
        this.refRegInstrumentGenericFields = refRegInstrumentGenericFields;
    }
}
