package com.nwm.xmart.streaming.source.crm;

import com.nwm.xmart.streaming.source.crm.exception.CRMException;
import com.nwm.xmart.streaming.source.df.serialisation.DFSourceDeserializer;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import com.nwm.xmart.util.MDCUtil;
import com.rbs.datafabric.client.DataFabricClient;
import com.rbs.datafabric.domain.OffsetCommitter;
import com.rbs.datafabric.domain.WatchContext;
import com.rbs.datafabric.domain.client.StartFrom;
import com.rbs.datafabric.domain.client.builder.ConsumerConfigurationBuilder;
import com.rbs.datafabric.domain.client.builder.ResumeDurableWatchScanRequestBuilder;
import com.rbs.datafabric.domain.event.ContinuousQueryEvent;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static java.lang.String.format;

public class CRMSource<CRMSourceEvent> extends RichParallelSourceFunction<CRMSourceEvent>
        implements CheckpointedFunction, CheckpointListener {
    private static final long serialVersionUID = -6188869053630002089L;
    private final IntCounter numSubscriptionSourceEvents = new IntCounter();
    private Logger logger = LoggerFactory.getLogger(CRMSource.class);
    private String watchId;
    private String watchName;
    private String watchGroupId;
    private DataFabricUtil dataFabricUtil;
    private transient DataFabricClient dataFabricClient;
    private transient WatchContext<ContinuousQueryEvent> watchContext;
    private transient OffsetCommitter offsetCommitter;
    private transient ListState<Long> state;
    private volatile Long offset;
    private volatile boolean isSubscriptionRunning = true;
    private boolean isStartFromOffset = false;
    private Long specificOffset = 0L;

    private CRMSubscriber crmSubscriber;

    public CRMSource(String topic, String topciName, String groupId, DataFabricUtil dataFabricUtil,
            boolean isStartFromOffset, Long specificOffset) {
        this.watchId = topic;
        this.watchName = topciName;
        this.watchGroupId = groupId;
        this.dataFabricUtil = dataFabricUtil;
        this.isStartFromOffset = isStartFromOffset;
        this.specificOffset = specificOffset;
    }

    @Override
    public void run(SourceContext<CRMSourceEvent> ctx) {
        //MDC for logging
        ParameterTool parameters = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        MDCUtil.putJobNameInMDC(parameters);

        DFSourceDeserializer dfSourceDeserializer = new DFSourceDeserializer(dataFabricUtil);
        crmSubscriber = new CRMSubscriber(this, watchContext, watchId, watchName, dfSourceDeserializer, parameters);
        crmSubscriber.startSubscription();

        CRMSourceEvent crmSourceEvent = null;
        while (isSubscriptionRunning) {
            crmSourceEvent = (CRMSourceEvent) crmSubscriber.getCRMEvent();
            synchronized (ctx.getCheckpointLock()) {
                ctx.collect(crmSourceEvent);
                offset = ((com.nwm.xmart.streaming.source.crm.event.CRMSourceEvent) crmSourceEvent).getOffset();
                this.numSubscriptionSourceEvents.add(1);
            }
        }
    }

    @Override
    public void open(Configuration configuration) throws Exception {
        ParameterTool params = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        MDCUtil.putJobNameInMDC(params);

        dataFabricClient = dataFabricUtil.getDataFabricClient();
        logger.info("DataFabric client initialized, version = {}, for watch id = {}",
                dataFabricClient.getClientVersion().getBuildVersion(), watchId);

        ConsumerConfigurationBuilder consumerConfiguration = ConsumerConfigurationBuilder.create()
                                                                                         .withGroupId(watchGroupId)
                                                                                         .withAutoCommit(false)
                                                                                         .withSessionTimeoutInMs(
                                                                                                 Integer.MAX_VALUE)
                                                                                         /*.withRequestTimeoutInMs(
                                                                                                 Integer.MAX_VALUE)*/;

        if (isStartFromOffset) {
            logger.info("Starting with Manually provided offset {}, watchName {}", specificOffset, watchName);
            offset = specificOffset;
        }

        if (offset != null) {
            consumerConfiguration.withStartOffset(offset);
        } else {
            consumerConfiguration.withStartFrom(StartFrom.BEGINNING);
        }

        logger.info("Resuming durable watch scan, watchId = {}, offset={}", watchId, offset);

        try {
            watchContext = dataFabricClient.resumeDurableWatchScan(ResumeDurableWatchScanRequestBuilder.create(watchId)
                                                                                                       .withConsumerConfiguration(
                                                                                                               consumerConfiguration
                                                                                                                       .build()));
        } catch (Exception e) {
            throw new CRMException(
                    format("Failed to resume durable watch scan, offset = %s, topic=%s", offset, watchName), e);
        }

        logger.info("Durable watch scan resumed, topic = {}, offset={}", watchName, offset);
        offsetCommitter = watchContext.getOffsetCommitter();

        getRuntimeContext()
                .addAccumulator("numSubscription" + watchName + "SourceEvents ", this.numSubscriptionSourceEvents);
    }

    @Override
    public void notifyCheckpointComplete(long l) throws Exception {
        if (offset != null) {
            logger.info("Checkpoint complete, now committing to kafka, offset={}, topic = {}", offset, watchName);
            try {
                offsetCommitter.commit();
            } catch (Exception e) {
                logger.error("Offset commit to Kafka failed, offset={}, topic = {}", offset, watchName);
                throw new CRMException(
                        format("Offset commit to Kafka failed, offset = %s, topic = %s", offset, watchName), e);
            }
            logger.info("Offset committed to Kafka, offset={}, topic = {}", offset, watchName);
        }
    }

    @Override
    public void snapshotState(FunctionSnapshotContext functionSnapshotContext) {
        try {
            if (offset != null) {
                state.clear();
                logger.info("Checkpoint requested, offset={}, Topic = {}", offset, watchName);
                state.add(offset);
                logger.info("Checkpoint Saved, offset={}, Topic = {}", offset, watchName);
            } else {
                logger.info("Checkpoint requested, but no update to state, offset={}, Topic = {}", offset, watchName);
            }
        } catch (Exception e) {
            logger.error("snapshotState error offset = {}, Topic = {}", offset, watchName);
            throw new CRMException(format("snapshotState error offset = %s, topic = %s", offset, watchName), e);
        }
    }

    @Override
    public void initializeState(FunctionInitializationContext context) {
        try {
            state = context.getOperatorStateStore().getListState(new ListStateDescriptor<Long>(watchName, Long.class));

            if (context.isRestored()) {
                for (Long offset : state.get()) {
                    this.offset = offset;
                }

                if (offset != null) {
                    logger.info("State restored, topic={} offset={}", watchName, offset);
                }
            } else {
                logger.info("State initialized, topic={}", watchName);
            }
        } catch (Exception e) {
            logger.error("initializeState error, topic={}", watchName);
            throw new CRMException("initializeState error, topic=" + watchName, e);
        }
    }

    @Override
    public void cancel() {
        if (crmSubscriber != null) {
            try {
                crmSubscriber.getSubscription().unsubscribe();
            } catch (Exception e) {
                logger.error("Exception occurred while unsubscribe, watchName = {}", watchName, e);
            }
        }
        dataFabricUtil.close();
    }
}
