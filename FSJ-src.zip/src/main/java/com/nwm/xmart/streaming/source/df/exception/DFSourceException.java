package com.nwm.xmart.streaming.source.df.exception;

public class DFSourceException extends RuntimeException {
    public DFSourceException() {
        super();
    }

    public DFSourceException(String msg) {
        super(msg);
    }

    public DFSourceException(String msg, Throwable t) {
        super(msg, t);
    }

}
