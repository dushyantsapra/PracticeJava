package com.nwm.xmart.streaming.source.rdx.exception;

/**
 * Created by gardlex on 15/11/2017.
 */
public class RdxDataReaderException extends RuntimeException {

    public RdxDataReaderException() {
        super();
    }

    public RdxDataReaderException(String msg) {
        super(msg);
    }

    public RdxDataReaderException(String msg, Throwable t) {
        super(msg, t);
    }
}
