package com.nwm.xmart.streaming.source.kdb.data;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.mdx.utils.analytics.IAnalyticResult;

/**
 * Created by gardlex on 20/06/2018.
 */
public class ResultValidator {

    private static Logger logger = LoggerFactory.getLogger(ResultValidator.class);

    public static ProcessingResult validateResult(IAnalyticResult result, String kdbSourceFunction, String processingDay) {
        if (result == null) { // can be NULL if (this) Source has been interrupted by Flink
            return new ProcessingResult(false, false);
        }

        if (!result.getSuccess()) {
            return new ProcessingResult(false, false);
        }

        Object firstColData = (result.getData())[0];
        if (firstColData == null) {
            return new ProcessingResult(true, false);
        }

        // if IS NOT a primitive array then just cast to Object
        if (!firstColData.getClass().getComponentType().isPrimitive()) {
            Object[] nestedColData = (Object[]) firstColData;
            if (nestedColData == null || nestedColData.length == 0) {
                return new ProcessingResult(true, false);
            }
        } else {
            Class<?> componentTypeClass = firstColData.getClass().getComponentType();
            switch(componentTypeClass.getName()) {
                case "int" :
                    int[] intArray = (int[])firstColData;
                    return new ProcessingResult(true, validatePrimtiveArrayLength(intArray, kdbSourceFunction, processingDay, result));
                case "char" :
                    char[] charArray = (char[])firstColData;
                    return new ProcessingResult(true, validatePrimtiveArrayLength(charArray, kdbSourceFunction, processingDay, result));
                case "short" :
                    short[] shortArray = (short[])firstColData;
                    return new ProcessingResult(true, validatePrimtiveArrayLength(shortArray, kdbSourceFunction, processingDay, result));
                case "long" :
                    long[] longArray = (long[])firstColData;
                    return new ProcessingResult(true, validatePrimtiveArrayLength(longArray, kdbSourceFunction, processingDay, result));
                case "boolean" :
                    boolean[] booleanArray = (boolean[])firstColData;
                    return new ProcessingResult(true, validatePrimtiveArrayLength(booleanArray, kdbSourceFunction, processingDay, result));
                case "float" :
                    float[] floatArray = (float[])firstColData;
                    return new ProcessingResult(true, validatePrimtiveArrayLength(floatArray, kdbSourceFunction, processingDay, result));
                case "double" :
                    double[] doubleArray = (double[])firstColData;
                    return new ProcessingResult(true, validatePrimtiveArrayLength(doubleArray, kdbSourceFunction, processingDay, result));
                default:
            }
        }

        return new ProcessingResult(true, true);
    }

    private static boolean validatePrimtiveArrayLength(int[] array, String kdbSourceFunction, String processingDay, IAnalyticResult result) {
        if (array == null || array.length == 0) {
            return false;
        }

        return true;
    }

    private static boolean validatePrimtiveArrayLength(char[] array, String kdbSourceFunction, String processingDay, IAnalyticResult result) {
        if (array == null || array.length == 0) {
            return false;
        }

        return true;
    }

    private static boolean validatePrimtiveArrayLength(short[] array, String kdbSourceFunction, String processingDay, IAnalyticResult result) {
        if (array == null || array.length == 0) {
            return false;
        }

        return true;
    }

    private static boolean validatePrimtiveArrayLength(long[] array, String kdbSourceFunction, String processingDay, IAnalyticResult result) {
        if (array == null || array.length == 0) {
            return false;
        }

        return true;
    }

    private static boolean validatePrimtiveArrayLength(boolean[] array, String kdbSourceFunction, String processingDay, IAnalyticResult result) {
        if (array == null || array.length == 0) {
            return false;
        }

        return true;
    }

    private static boolean validatePrimtiveArrayLength(float[] array, String kdbSourceFunction, String processingDay, IAnalyticResult result) {
        if (array == null || array.length == 0) {
            return false;
        }

        return true;
    }

    private static boolean validatePrimtiveArrayLength(double[] array, String kdbSourceFunction, String processingDay, IAnalyticResult result) {
        if (array == null || array.length == 0) {
             return false;
        }

        return true;
    }



}
