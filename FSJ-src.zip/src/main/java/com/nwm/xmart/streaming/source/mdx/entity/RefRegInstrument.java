package com.nwm.xmart.streaming.source.mdx.entity;

import java.util.Date;

public class RefRegInstrument extends HeaderFields {
    private RefRegInstrumentHeaderFields refRegInstrumentHeaderFields;
    private RefRegInstrumentAttributesFields refRegInstrumentAttributesFields;
    private RefRegInstrumentIsinFields refRegInstrumentIsinFields;
    private Integer templateVersion;
    private RefRegInstrumentDerivedFields refRegInstrumentDerivedFields;

    public RefRegInstrument(String mdxTransport, String mdxTypeName, String mdxPath, int mdxDocumentVersion,
            Date mdxWrittenOnUTC, String mdxValuationDate, String xmlWriteTime) {
        super(mdxTransport, mdxTypeName, mdxPath, mdxDocumentVersion, mdxWrittenOnUTC, mdxValuationDate, xmlWriteTime);
    }

    public RefRegInstrumentHeaderFields getRefRegInstrumentHeaderFields() {
        return refRegInstrumentHeaderFields;
    }

    public void setRefRegInstrumentHeaderFields(RefRegInstrumentHeaderFields refRegInstrumentHeaderFields) {
        this.refRegInstrumentHeaderFields = refRegInstrumentHeaderFields;
    }

    public RefRegInstrumentAttributesFields getRefRegInstrumentAttributesFields() {
        return refRegInstrumentAttributesFields;
    }

    public void setRefRegInstrumentAttributesFields(RefRegInstrumentAttributesFields refRegInstrumentAttributesFields) {
        this.refRegInstrumentAttributesFields = refRegInstrumentAttributesFields;
    }

    public RefRegInstrumentIsinFields getRefRegInstrumentIsinFields() {
        return refRegInstrumentIsinFields;
    }

    public void setRefRegInstrumentIsinFields(RefRegInstrumentIsinFields refRegInstrumentIsinFields) {
        this.refRegInstrumentIsinFields = refRegInstrumentIsinFields;
    }

    public Integer getTemplateVersion() {
        return templateVersion;
    }

    public void setTemplateVersion(Integer templateVersion) {
        this.templateVersion = templateVersion;
    }

    public RefRegInstrumentDerivedFields getRefRegInstrumentDerivedFields() {
        return refRegInstrumentDerivedFields;
    }

    public void setRefRegInstrumentDerivedFields(RefRegInstrumentDerivedFields refRegInstrumentDerivedFields) {
        this.refRegInstrumentDerivedFields = refRegInstrumentDerivedFields;
    }
}
