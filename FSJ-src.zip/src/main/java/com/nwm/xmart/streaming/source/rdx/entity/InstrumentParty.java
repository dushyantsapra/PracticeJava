
package com.nwm.xmart.streaming.source.rdx.entity;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "GuarantorPariPassu",
    "PartyCode",
    "PartyName",
    "PartyNameVendor",
    "PartyLongNameVendor",
    "PartyRoleType",
    "PartyAlias",
    "LegalEntityIdentifier",
    "CISCode",
    "DFIdentifier",
    "CountryOfResidenceId",
    "CountryOfResidenceName",
    "CountryOfResidenceIsoScheme",
    "CountryOfIncorporationId",
    "CountryOfIncorporationName",
    "CountryOfIncorporationIsoScheme",
    "CountryOfRiskId",
    "CountryOfRiskName",
    "CountryOfRiskIsoScheme"
})
public class InstrumentParty {

    @JsonProperty("GuarantorPariPassu")
    private Object guarantorPariPassu;
    @JsonProperty("PartyCode")
    private Object partyCode;
    @JsonProperty("PartyName")
    private Object partyName;
    @JsonProperty("PartyNameVendor")
    private Object partyNameVendor;
    @JsonProperty("PartyLongNameVendor")
    private Object partyLongNameVendor;
    @JsonProperty("PartyRoleType")
    private Object partyRoleType;
    @JsonProperty("PartyAlias")
    private Object partyAlias;
    @JsonProperty("LegalEntityIdentifier")
    private String legalEntityIdentifier;
    @JsonProperty("CISCode")
    private Object cISCode;
    @JsonProperty("DFIdentifier")
    private Object dFIdentifier;
    @JsonProperty("CountryOfResidenceId")
    private Object countryOfResidenceId;
    @JsonProperty("CountryOfResidenceName")
    private Object countryOfResidenceName;
    @JsonProperty("CountryOfResidenceIsoScheme")
    private Object countryOfResidenceIsoScheme;
    @JsonProperty("CountryOfIncorporationId")
    private Object countryOfIncorporationId;
    @JsonProperty("CountryOfIncorporationName")
    private Object countryOfIncorporationName;
    @JsonProperty("CountryOfIncorporationIsoScheme")
    private Object countryOfIncorporationIsoScheme;
    @JsonProperty("CountryOfRiskId")
    private Object countryOfRiskId;
    @JsonProperty("CountryOfRiskName")
    private Object countryOfRiskName;
    @JsonProperty("CountryOfRiskIsoScheme")
    private Object countryOfRiskIsoScheme;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("GuarantorPariPassu")
    public Object getGuarantorPariPassu() {
        return guarantorPariPassu;
    }

    @JsonProperty("GuarantorPariPassu")
    public void setGuarantorPariPassu(Object guarantorPariPassu) {
        this.guarantorPariPassu = guarantorPariPassu;
    }

    @JsonProperty("PartyCode")
    public Object getPartyCode() {
        return partyCode;
    }

    @JsonProperty("PartyCode")
    public void setPartyCode(Object partyCode) {
        this.partyCode = partyCode;
    }

    @JsonProperty("PartyName")
    public Object getPartyName() {
        return partyName;
    }

    @JsonProperty("PartyName")
    public void setPartyName(Object partyName) {
        this.partyName = partyName;
    }

    @JsonProperty("PartyNameVendor")
    public Object getPartyNameVendor() {
        return partyNameVendor;
    }

    @JsonProperty("PartyNameVendor")
    public void setPartyNameVendor(Object partyNameVendor) {
        this.partyNameVendor = partyNameVendor;
    }

    @JsonProperty("PartyLongNameVendor")
    public Object getPartyLongNameVendor() {
        return partyLongNameVendor;
    }

    @JsonProperty("PartyLongNameVendor")
    public void setPartyLongNameVendor(Object partyLongNameVendor) {
        this.partyLongNameVendor = partyLongNameVendor;
    }

    @JsonProperty("PartyRoleType")
    public Object getPartyRoleType() {
        return partyRoleType;
    }

    @JsonProperty("PartyRoleType")
    public void setPartyRoleType(Object partyRoleType) {
        this.partyRoleType = partyRoleType;
    }

    @JsonProperty("PartyAlias")
    public Object getPartyAlias() {
        return partyAlias;
    }

    @JsonProperty("PartyAlias")
    public void setPartyAlias(Object partyAlias) {
        this.partyAlias = partyAlias;
    }

    @JsonProperty("LegalEntityIdentifier")
    public String getLegalEntityIdentifier() {
        return legalEntityIdentifier;
    }

    @JsonProperty("LegalEntityIdentifier")
    public void setLegalEntityIdentifier(String legalEntityIdentifier) {
        this.legalEntityIdentifier = legalEntityIdentifier;
    }

    @JsonProperty("CISCode")
    public Object getCISCode() {
        return cISCode;
    }

    @JsonProperty("CISCode")
    public void setCISCode(Object cISCode) {
        this.cISCode = cISCode;
    }

    @JsonProperty("DFIdentifier")
    public Object getDFIdentifier() {
        return dFIdentifier;
    }

    @JsonProperty("DFIdentifier")
    public void setDFIdentifier(Object dFIdentifier) {
        this.dFIdentifier = dFIdentifier;
    }

    @JsonProperty("CountryOfResidenceId")
    public Object getCountryOfResidenceId() {
        return countryOfResidenceId;
    }

    @JsonProperty("CountryOfResidenceId")
    public void setCountryOfResidenceId(Object countryOfResidenceId) {
        this.countryOfResidenceId = countryOfResidenceId;
    }

    @JsonProperty("CountryOfResidenceName")
    public Object getCountryOfResidenceName() {
        return countryOfResidenceName;
    }

    @JsonProperty("CountryOfResidenceName")
    public void setCountryOfResidenceName(Object countryOfResidenceName) {
        this.countryOfResidenceName = countryOfResidenceName;
    }

    @JsonProperty("CountryOfResidenceIsoScheme")
    public Object getCountryOfResidenceIsoScheme() {
        return countryOfResidenceIsoScheme;
    }

    @JsonProperty("CountryOfResidenceIsoScheme")
    public void setCountryOfResidenceIsoScheme(Object countryOfResidenceIsoScheme) {
        this.countryOfResidenceIsoScheme = countryOfResidenceIsoScheme;
    }

    @JsonProperty("CountryOfIncorporationId")
    public Object getCountryOfIncorporationId() {
        return countryOfIncorporationId;
    }

    @JsonProperty("CountryOfIncorporationId")
    public void setCountryOfIncorporationId(Object countryOfIncorporationId) {
        this.countryOfIncorporationId = countryOfIncorporationId;
    }

    @JsonProperty("CountryOfIncorporationName")
    public Object getCountryOfIncorporationName() {
        return countryOfIncorporationName;
    }

    @JsonProperty("CountryOfIncorporationName")
    public void setCountryOfIncorporationName(Object countryOfIncorporationName) {
        this.countryOfIncorporationName = countryOfIncorporationName;
    }

    @JsonProperty("CountryOfIncorporationIsoScheme")
    public Object getCountryOfIncorporationIsoScheme() {
        return countryOfIncorporationIsoScheme;
    }

    @JsonProperty("CountryOfIncorporationIsoScheme")
    public void setCountryOfIncorporationIsoScheme(Object countryOfIncorporationIsoScheme) {
        this.countryOfIncorporationIsoScheme = countryOfIncorporationIsoScheme;
    }

    @JsonProperty("CountryOfRiskId")
    public Object getCountryOfRiskId() {
        return countryOfRiskId;
    }

    @JsonProperty("CountryOfRiskId")
    public void setCountryOfRiskId(Object countryOfRiskId) {
        this.countryOfRiskId = countryOfRiskId;
    }

    @JsonProperty("CountryOfRiskName")
    public Object getCountryOfRiskName() {
        return countryOfRiskName;
    }

    @JsonProperty("CountryOfRiskName")
    public void setCountryOfRiskName(Object countryOfRiskName) {
        this.countryOfRiskName = countryOfRiskName;
    }

    @JsonProperty("CountryOfRiskIsoScheme")
    public Object getCountryOfRiskIsoScheme() {
        return countryOfRiskIsoScheme;
    }

    @JsonProperty("CountryOfRiskIsoScheme")
    public void setCountryOfRiskIsoScheme(Object countryOfRiskIsoScheme) {
        this.countryOfRiskIsoScheme = countryOfRiskIsoScheme;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("guarantorPariPassu", guarantorPariPassu).append("partyCode", partyCode).append("partyName", partyName).append("partyNameVendor", partyNameVendor).append("partyLongNameVendor", partyLongNameVendor).append("partyRoleType", partyRoleType).append("partyAlias", partyAlias).append("legalEntityIdentifier", legalEntityIdentifier).append("cISCode", cISCode).append("dFIdentifier", dFIdentifier).append("countryOfResidenceId", countryOfResidenceId).append("countryOfResidenceName", countryOfResidenceName).append("countryOfResidenceIsoScheme", countryOfResidenceIsoScheme).append("countryOfIncorporationId", countryOfIncorporationId).append("countryOfIncorporationName", countryOfIncorporationName).append("countryOfIncorporationIsoScheme", countryOfIncorporationIsoScheme).append("countryOfRiskId", countryOfRiskId).append("countryOfRiskName", countryOfRiskName).append("countryOfRiskIsoScheme", countryOfRiskIsoScheme).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(partyAlias).append(legalEntityIdentifier).append(dFIdentifier).append(partyNameVendor).append(partyRoleType).append(countryOfResidenceId).append(countryOfResidenceIsoScheme).append(countryOfIncorporationIsoScheme).append(countryOfRiskIsoScheme).append(countryOfResidenceName).append(guarantorPariPassu).append(cISCode).append(partyCode).append(partyName).append(partyLongNameVendor).append(countryOfIncorporationId).append(countryOfRiskId).append(additionalProperties).append(countryOfRiskName).append(countryOfIncorporationName).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InstrumentParty) == false) {
            return false;
        }
        InstrumentParty rhs = ((InstrumentParty) other);
        return new EqualsBuilder().append(partyAlias, rhs.partyAlias).append(legalEntityIdentifier, rhs.legalEntityIdentifier).append(dFIdentifier, rhs.dFIdentifier).append(partyNameVendor, rhs.partyNameVendor).append(partyRoleType, rhs.partyRoleType).append(countryOfResidenceId, rhs.countryOfResidenceId).append(countryOfResidenceIsoScheme, rhs.countryOfResidenceIsoScheme).append(countryOfIncorporationIsoScheme, rhs.countryOfIncorporationIsoScheme).append(countryOfRiskIsoScheme, rhs.countryOfRiskIsoScheme).append(countryOfResidenceName, rhs.countryOfResidenceName).append(guarantorPariPassu, rhs.guarantorPariPassu).append(cISCode, rhs.cISCode).append(partyCode, rhs.partyCode).append(partyName, rhs.partyName).append(partyLongNameVendor, rhs.partyLongNameVendor).append(countryOfIncorporationId, rhs.countryOfIncorporationId).append(countryOfRiskId, rhs.countryOfRiskId).append(additionalProperties, rhs.additionalProperties).append(countryOfRiskName, rhs.countryOfRiskName).append(countryOfIncorporationName, rhs.countryOfIncorporationName).isEquals();
    }

}
