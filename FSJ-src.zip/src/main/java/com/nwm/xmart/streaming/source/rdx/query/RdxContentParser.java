package com.nwm.xmart.streaming.source.rdx.query;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nwm.xmart.streaming.source.rdx.exception.RdxContentParserException;
import com.nwm.xmart.streaming.source.rdx.json.RdxFixedIncome;
import org.apache.flink.util.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by gardlex on 23/05/2018.
 */
public class RdxContentParser {
    private static Logger logger = LoggerFactory.getLogger(RdxContentParser.class);
    private final ObjectMapper objectMapper = new ObjectMapper();

    public RdxFixedIncome getJSONPojoForContent(String content) {
        try {
            return objectMapper.readValue(content, RdxFixedIncome.class);
        } catch (Exception e) {
            logger.error("Could not create JSON for rdx instrument", e);
            throw new RdxContentParserException("Could not create JSON for rdx instrument", e);
        }
    }
}
