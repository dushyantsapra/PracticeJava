package com.nwm.xmart.streaming.source.mdx.subscription;


import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.streaming.source.mdx.event.ProcessingType;
import com.nwm.xmart.streaming.source.mdx.exception.MdxLoadFailureException;
import com.nwm.xmart.streaming.source.mdx.session.MdxSessionContext;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.mdx.webService.impl.MdxDateTime;
import rbs.gbm.mdx.webService.impl.MdxTimePointContent;
import rbs.gbm.mdx.webService.interfaces.IMdxTimeSeriesChangeHandler;
import rbs.gbm.mdx.webService.interfaces.IMdxTimeSeriesSession;
import rbs.gbm.mdx.webService.interfaces.MdxException;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantLock;


/**
 * Encapsulates the logic required for capturing real time publication of new MDX Document events.
 *
 * Created by gardlex on 23/03/2018.
 */
public class TestTimeSeriesMdxSubscription<T> implements IMdxTimeSeriesChangeHandler, MdxSubscription<T> {

    private static Logger logger = LoggerFactory.getLogger(TestTimeSeriesMdxSubscription.class);
    private volatile boolean isMdxSessionClosed;
    private final Class<T> sourceEventClass;
    private volatile String mdxIdentifier;
    private volatile String mdxIdentifierWildcard;
    private AtomicReference<MdxRealTimeEventExchange<T>> mdxEventExchangeRef = new AtomicReference<>();
    private final AtomicReference<MdxSessionContext> mdxSessionContextRef = new AtomicReference<>();

    public TestTimeSeriesMdxSubscription(Class<T> sourceEventClass) {
        this.sourceEventClass = sourceEventClass;
    }

    @Override
    public MdxSubscription withMdxEventExchange(MdxRealTimeEventExchange<T> mdxEventExchange) {
        this.mdxEventExchangeRef.set(mdxEventExchange);
        return this;
    }

    @Override
    public MdxSubscription withMdxIdentifier(String identifier) {
        this.mdxIdentifier = identifier;
        return this;
    }

    @Override
    public MdxSubscription withMdxIdentifierWildcard(String wildcard) {
        this.mdxIdentifierWildcard = wildcard;
        return this;
    }

    @Override
    public MdxSubscription withMdxSessionContext(MdxSessionContext mdxSessionContext) {
        this.mdxSessionContextRef.set(mdxSessionContext);
        return this;
    }

    public void startConsumingEvents() {
        try {
            subscribeToRealTimeEvents();
        } catch (Exception e) {
            logger.error("Could not start the TimeSeriesMdxSubscription", e);
            close();
        }
    }

    private void subscribeToRealTimeEvents() throws MdxLoadFailureException {
//        String identifier = "saved/reference.regulatory.instrument/public/Credit/%";  ///>"; Rates
//        Object ooo = mdxSessionContextRef.get().getMdxTimeSeriesSession().subscribe(mdxIdentifier+mdxIdentifierWildcard, this, "TimeSeriesMdxSubscription");

        for (int i=0; i < 55; i++) {

            // MdxDateTime logicalTime, Date writeTime, double value, int version, String status
            MdxTimePointContent timeSeriesContent = new MdxTimePointContent(MdxDateTime.getUtcNow(), 1, "Cnt-"+ i);

            try {
                onMdxTimeSeriesChange(mdxSessionContextRef.get().getMdxTimeSeriesSession(), null, null, "", timeSeriesContent, 1);
            } catch (Exception e) {
                logger.error("Could not create MdxDocumentEvent constructor", e);
                throw new MdxLoadFailureException("Could not create MdxDocumentEvent constructor", e);
            }
        }

    }

    public void close() {
        try
        {
            mdxSessionContextRef.get().getMdxTimeSeriesSession().close();
        } catch (MdxException e)
        {
            logger.warn("Close(): Could not close the TimeSeriesMdxSubscription session", e);
        }
    }

    /**
     * When called, blocks current thread until the RendezvousSingleEventExchange has an event for consumption
     *
     * @return
     * @throws MdxSubscriptionFailureException
     */
    public T getMdxNextEvent() {
            // TODO - make sure that the method can perform an early check to see if MDX session is dead, if do
           return mdxEventExchangeRef.get().getNextMdxDocumentEvent();
    }

    @Override
    public ReentrantLock getSubscriptionLock() {
        return null;
    }

    @Override
    public MdxSubscription setISINList(Set<String> isinList) {
        return null;
    }

    @Override
    public MdxSubscription withSourceFunction(SourceFunction<T> sourceFunction) {
        return null;
    }

    @Override
    public void onMdxTimeSeriesChange(IMdxTimeSeriesSession iMdxTimeSeriesSession, Object o, Object o1, String s, MdxTimePointContent mdxTimePointContent, long l) {
        // TODO - check document Operation Type

//                long epochXmlWriteTime = mdxTimePointContent.getWriteTime().getTime();
                try {
                    mdxEventExchangeRef.get().putMdxDocumentEvent((T) MdxDocumentEvent.ofMdxTimePointContent("TEST", 1, mdxTimePointContent, System.currentTimeMillis(), System.currentTimeMillis(), 1, "identifier", ProcessingType.SUBSCRIPTION));
                } catch (Exception e) {
                    logger.error("Could not create MdxDocumentEvent constructor", e);
                    throw new MdxSubscriptionFailureException("Could not create MdxDocumentEvent constructor", e);
                }
    }

    @Override
    public void onMdxAddTimeSeriesMetadata(IMdxTimeSeriesSession iMdxTimeSeriesSession, Object o, Object o1, String s, Map<String, String> map, long l) {

    }

    @Override
    public void onSubscriptionRevoked(IMdxTimeSeriesSession iMdxTimeSeriesSession, Object o, Object o1) {
// TODO stop the main processing loop in teh SOURCE - feed this event
    }
}
