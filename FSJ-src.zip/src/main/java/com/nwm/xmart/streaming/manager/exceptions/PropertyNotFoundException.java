package com.nwm.xmart.streaming.manager.exceptions;

public class PropertyNotFoundException extends RuntimeException {

    public PropertyNotFoundException() {
        super();
    }

    public PropertyNotFoundException(String msg) {
        super(msg);
    }

    public PropertyNotFoundException(String msg, Throwable t) {
        super(msg, t);
    }
}
