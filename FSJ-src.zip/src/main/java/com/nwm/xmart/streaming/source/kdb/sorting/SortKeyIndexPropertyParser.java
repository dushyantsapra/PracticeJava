package com.nwm.xmart.streaming.source.kdb.sorting;



import java.util.*;

/**
 * Utility class to convert raw property containing the list of KDB sort keys into a map of funtion and key names.
 *
 * Author: Alex Gardner
 */
public class SortKeyIndexPropertyParser {

    public static void main(String[] args) {
        Map<KDBFunctionType, String[]> sortKeyMap =
                SortKeyIndexPropertyParser.getSortKeyNamesFromString("FI_MIFID_RFQ|0|1,FI_MIFID_QEC|0|1,FX_MIFID_RFQ|0|12,FX_MIFID_OMS|0|2,FX_MIFID_TRADE|0|2,FX_MIFID_TRADE_ISIN|0|2");

        if(sortKeyMap.size() != 6){
            throw new RuntimeException("getSortKeyNamesFromString failed - incorrect number of items in map");
        }
    }

    static Map<KDBFunctionType, String[]> getSortKeyNamesFromString(String sortKeyTypeNames) {
        StringTokenizer sortKeyTypeTokenizer = new StringTokenizer(sortKeyTypeNames, ",");
        Map<KDBFunctionType, String[]> sortKeyMap = new HashMap<>();

        while (sortKeyTypeTokenizer.hasMoreTokens()) {
            String sortKeyTypeAndIndexes = sortKeyTypeTokenizer.nextToken();
            StringTokenizer sortKeyIndexesTokenizer = new StringTokenizer(sortKeyTypeAndIndexes, "|");

            String sortKeyType = null;
            if (sortKeyIndexesTokenizer.hasMoreTokens()) {
                sortKeyType = sortKeyIndexesTokenizer.nextToken();
            }

            List<String> indexKeyList = new ArrayList<>();
            while (sortKeyIndexesTokenizer.hasMoreTokens()) {
                indexKeyList.add(sortKeyIndexesTokenizer.nextToken());
            }

            String[] indexKeyArray = new String[indexKeyList.size()];
            sortKeyMap.put(KDBFunctionType.valueOf(sortKeyType), indexKeyList.toArray(indexKeyArray));

        }

        return sortKeyMap;
    }

}
