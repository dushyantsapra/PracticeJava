package com.nwm.xmart.streaming.source.kdb;

//import org.joda.time.Instant;
import com.nwm.xmart.streaming.source.kdb.data.KDBDataTransformer;
import com.nwm.xmart.streaming.source.kdb.event.KDBSourceEvent;
import com.nwm.xmart.streaming.source.kdb.exception.KDBMatrixDataParsingException;
import com.nwm.xmart.streaming.source.kdb.session.KDBSession;
import com.nwm.xmart.streaming.source.kdb.sorting.DateTimeSortKey;
import com.nwm.xmart.streaming.source.kdb.sorting.KDBFunctionType;
import com.nwm.xmart.streaming.source.kdb.sorting.KDBSortComparatorBuilder;
import com.nwm.xmart.streaming.source.kdb.sorting.KDBSortKeyBuilder;
import com.nwm.xmart.streaming.source.mdx.session.MDXSessionType;
import com.nwm.xmart.streaming.source.kdb.sorting.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.mdx.Analytics.AnalyticSessionFactory;
import rbs.gbm.mdx.Analytics.IAnalyticsSession;
import rbs.gbm.mdx.utils.analytics.DailyAnalyticResult;
import rbs.gbm.mdx.utils.analytics.IAnalyticResult;
import rbs.gbm.mdx.utils.analytics.KdbRequestBuilder;
import rbs.gbm.mdx.utils.interfaces.IAnalyticRequestIdentifierBuilder;
import rbs.gbm.mdx.webService.interfaces.IMdxDailyAnalyticSession;

import java.io.FileWriter;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by gardlex on 27/04/2018.
 */
public class Tester {
    private static final Logger logger = LoggerFactory.getLogger(Tester.class);
    public static void main(String[] args) throws Exception {
        Tester t = new Tester();
//        t.kdbMdxAccessConnectivity();
            t.kdbIAnalyticSessionSSOConnectivity();

        //        t.kdbSSOSessionTest();
            //        t.kdbSSOSessionTest();
//        t.object();
//        t.kdbMdxSessionTest();
//        t.dates();
    }

    public void object() {
        int[] x = new int[] {1,2,3,4,5};
        Integer[] xx = new Integer[] {1,2,null,4,5};

        int y = 123;
        Object c = y;
        Object value = getValueForVerticalIndex(x, 2);
        int f = (int)value;

        logger.info(value + " " + f);

        String[] s = new String[] {"a", "b", "c", "d", "e"};
        Object strValue = getValueForVerticalIndex(s, 3);
        String ss = (String) strValue;
        logger.info(strValue + " " + ss);
    }

    private Object getValueForVerticalIndex(Object horizontalColumnRow, int horizontalRowIndex) {
        try {
            // if NOT primitive array then just cast to Object
            if (!horizontalColumnRow.getClass().getComponentType().isPrimitive()) {
                return ((Object[]) horizontalColumnRow)[horizontalRowIndex];
            }

            // If IT IS a primitive array then return as Wrapper based primitive
            return Array.get(horizontalColumnRow, horizontalRowIndex);
        } catch (IllegalArgumentException e) {
            throw new KDBMatrixDataParsingException("Illegal argument found whilst extracting a column value", e);
        } catch (ArrayIndexOutOfBoundsException a) {
            throw new KDBMatrixDataParsingException("Invalid index specified whilst extracting a column value", a);
        }
    }


    //                .function("FICCgetRawData")
    //                .parameter("tableName", "fi_voice_quote")
    //"fi.uat")   //"fi.prl")
    public void kdbMdxAccessConnectivity() throws Exception {
        IAnalyticsSession analyticSession = new AnalyticSessionFactory()
                .createTickAnalyticSession("Bdx", "1", "MdxUat");   //"MdxUat");

        IAnalyticRequestIdentifierBuilder kdbRequestBuilder = new KdbRequestBuilder();
        String tempQuery = kdbRequestBuilder.environment("live.fi.prl")   // live.fi.prl,   live.fx.prl live.fx.uat


                .function("FImifidRFQ") // fi
                .parameter("startDate", "2018.05.07") //"2018.02.28") 2018.04.26
                .parameter("endDate", "2018.05.07") //"2018.02.28")   2018.04.26

//                .function("FImifidQEC") // fi
//                .parameter("startDate", "2018.05.07") //"2018.02.28") 2018.04.26
//                .parameter("endDate", "2018.05.07") //"2018.02.28") 2018.04.26


//                .function("FXmifidRFQ")    // needs live.fx.prl
//                .parameter("startDate", "2018.05.07")  // 2018.03.01
//                .parameter("endDate", "2018.05.07")

//                .function("FXmifidOMS")        // needs live.fx.prl
//                .parameter("startDate", "2018.05.07") // 2018.03.01
//                .parameter("endDate", "2018.05.07")

//                .function("FXmifidTrade")       // needs live.fx.prl
//                .parameter("startDate", "2018.05.07")     // 2018.03.01
//                .parameter("endDate", "2018.05.07")

//                .function("FXmifidTradeIsin")     // needs live.fx.uat
//                .parameter("startDate", "2018.03.02")   // 2018.03.01
//                .parameter("endDate", "2018.03.02")     // 2018.03.01

                //                .function("FXmifidTradeIsin")     // needs live.fx.uat
//                .parameter("startDate", "2018.03.02")   // 2018.03.01
//                .parameter("endDate", "2018.03.02")     // 2018.03.01

//                                .function("FXmifidTradeEligibility")     // needs live.fx.uat
//                .parameter("startDate", "2018.03.01")   // 2018.03.01
//                .parameter("endDate", "2018.03.01")     // 2018.03.01

                .build();
        IAnalyticResult result = analyticSession.CallAnalytic(tempQuery);
        Object firstColData = (result.getData())[0];
        Object secondColData = (result.getData())[1];

        Object[] nestedColData = (Object[])firstColData;
        if (firstColData == null) {
            logger.info("First column data is NULL");
        }
        if (nestedColData == null || nestedColData.length == 0) {
            logger.info("First nested column data is NULL or EMPTY");
        }

//        if ((result.getData())[0]) {
//            logger.info("No data returned");
//        }
        int c = 0;

        String filename = "FImifidRFQ"; // FImifidRFQ, FImifidQEC, FXmifidRFQ, FXmifidOMS, FXmifidTrade. FXmifidTradeIsin
        FileWriter fw = new FileWriter("C:\\DEV\\flink-sources-investigation\\KDB\\" + filename + ".csv");

        KDBSortKeyBuilder sortKeyBuilder =
                new KDBSortKeyBuilder(
                        "FI_MIFID_RFQ|0|1,FI_MIFID_QEC|0|1,FX_MIFID_RFQ|0|12,FX_MIFID_OMS|0|2,FX_MIFID_TRADE|0|2,FX_MIFID_TRADE_ISIN|0|2");

        KDBDataTransformer transformer = new KDBDataTransformer(KDBFunctionType.FI_MIFID_QEC, sortKeyBuilder);
        List<KDBSourceEvent> sourceEvents = transformer.convertTo2DArraySourceEvents("", "FImifidQEC","", "2018.05.07", result);
        for (KDBSourceEvent event : sourceEvents) {
            String csvStr = event.toCSVFormet();
            fw.write(csvStr + System.lineSeparator());
            fw.flush();
//            int d = 0;
        }

        fw.close();
    }

    public void kdbIAnalyticSessionSSOConnectivity() throws Exception {
        IAnalyticsSession analyticSession = new AnalyticSessionFactory()
                .createTickAnalyticSession("Bdx", "1", "MdxUat",
                        "FmGsJjNRG+0K8BuS1rgEFYpBjFkmhZOTQ3OGaGQSyaB/iUCzQrJASqCtVGfGjHAWZRg+qh/TV+1XPEQCH2ZbGbhhMAPEBmpUbvLLU5Son70KOn5o2D5l4YwEVeZlKrytTAa5cgoSlwPwDSg4LyiPZ9bH4wOKI67B18tCdKGY+Fw=|0|svc-xmartappuat|Mdx|20180810170359|604800|");


        IAnalyticRequestIdentifierBuilder kdbRequestBuilder = new KdbRequestBuilder();

        String tempQuery = kdbRequestBuilder.environment("live.fi.prl")
                .function("FImifidRFQ")
                .parameter("startDate", "2018.06.25")  //"2018.02.28")  2018.05.07
                .parameter("endDate", "2018.06.25")   //"2018.02.28")
                .build();
        IAnalyticResult result = analyticSession.CallAnalytic(tempQuery);
        int x = 0;
    }

    public void kdbDailyTickSSOConnectivity() throws Exception {
        IMdxDailyAnalyticSession analyticSession = new AnalyticSessionFactory()
                .createDailyAnalyticSession("Bdx", "1", "MdxUat",
                        "hMdU2rA+mHOK7t28tp65c6iIMVjBi1f2wlh2siCWIeMT/RKPEqTuTSnumSyWdCJyzTEthNeTgEhLOHTAVxeTZZqR0hd2UzStFrPRc6i6ttIO/3FFyD3t/qysrC8yg/FjTP29Mby8wDCXKIh2ioeyyAIaQOcnRScLag4KDBrnNH8=|0|ahmadar|Mdx|20180510170618|604800|");

        IAnalyticRequestIdentifierBuilder kdbRequestBuilder = new KdbRequestBuilder();

        String tempQuery = kdbRequestBuilder.environment("live.fi.prl")
                .function("FImifidRFQ")
                .parameter("startDate", "2018.02.28")
                .parameter("endDate", "2018.02.28")
                .build();
        DailyAnalyticResult result = analyticSession.callAnalytic(tempQuery);
    }

    public void kdbMdxSessionTest() throws Exception {

        KDBSortKeyBuilder sortKeyBuilder =
                new KDBSortKeyBuilder(
                        "FI_MIFID_RFQ|0|1,FI_MIFID_QEC|0|1,FX_MIFID_RFQ|0|12,FX_MIFID_OMS|0|2,FX_MIFID_TRADE|0|2,FX_MIFID_TRADE_ISIN|0|2");

        KDBDataTransformer transformer = new KDBDataTransformer(KDBFunctionType.FI_MIFID_RFQ, sortKeyBuilder);
        KDBSession kdbSession = new KDBSession()
                .withIAnalyticRequestIdentifierBuilder(new KdbRequestBuilder())
                .withApplicationName("Bdx")
                .withApplicationVersion("1")
                .withMdxEnvironmentName("MdxUat")
                .withKdbEnvironmentName("live.fi.prl")
                .withKdbFunctionName("FImifidRFQ")
                .withParameter("startDate", "2018.02.28")
                .withParameter("endDate", "2018.02.28")
                .withKDBSessionType(MDXSessionType.MDX_ACCESS);
        kdbSession.build();

        IAnalyticResult result = kdbSession.getMDXAccessKDBData();

        List<KDBSourceEvent> sourceEvents = transformer.convertTo2DArraySourceEvents("", "FImifidRFQ","", "2018.02.28", result);
        long start = System.currentTimeMillis();
        Collections.sort(sourceEvents, KDBSortComparatorBuilder
                .createSortComparatorForType(KDBFunctionType.FI_MIFID_RFQ));
        long end = System.currentTimeMillis();
        logger.info("took:  " + (end-start) + " millis");
        int f=0;
    }

    public void kdbSSOSessionTest() throws Exception {
        KDBSortKeyBuilder sortKeyBuilder =
                new KDBSortKeyBuilder(
                        "FI_MIFID_RFQ|0|1,FI_MIFID_QEC|0|1,FX_MIFID_RFQ|0|12,FX_MIFID_OMS|0|2,FX_MIFID_TRADE|0|2,FX_MIFID_TRADE_ISIN|0|2");

        KDBDataTransformer transformer = new KDBDataTransformer(KDBFunctionType.FI_MIFID_RFQ, sortKeyBuilder);
        KDBSession kdbSession = new KDBSession()
                .withIAnalyticRequestIdentifierBuilder(new KdbRequestBuilder())
                .withApplicationName("Bdx")
                .withApplicationVersion("1")
                .withMdxEnvironmentName("MdxUat")
                .withKdbEnvironmentName("live.fi.prl")
                .withKdbFunctionName("FImifidRFQ")
                .withParameter("startDate", "2018.02.28")
                .withParameter("endDate", "2018.02.28")
                .withSSOToken(
"")
                .withKDBSessionType(MDXSessionType.SSO);

        kdbSession.build();

        IAnalyticResult result = kdbSession.getMDXAccessKDBData();

        int fff=0;
        List<KDBSourceEvent> sourceEvents = transformer.convertTo2DArraySourceEvents("", "","", "2018.02.28", result);
//        long start = System.currentTimeMillis();
//        Collections.sort(sourceEvents, KDBSortComparatorBuilder.createSortComparatorForType(KDBFunctionType.FI_MIFID_RFQ));
//        long end = System.currentTimeMillis();
//        logger.info("took:  " + (end-start) + " millis");
//        int f=0;
    }

    public void dates() throws Exception {
//        Instant i = Instant.parse("2018-02-28" + "T" + "13:22:46" + ".00z");
//        i.toEpochMilli();


        DateTimeSortKey key1 = new DateTimeSortKey(new int[] {0,1});
        key1.setSortKeyColumnValue("2018-02-28", 0);
        key1.setSortKeyColumnValue("13:22:46", 1);
        KDBSourceEvent event1 = new KDBSourceEvent("", "","",true,"","",null,null,1, key1, KDBFunctionType.FI_MIFID_RFQ, "");

        DateTimeSortKey key2 = new DateTimeSortKey(new int[] {0,1});
        key2.setSortKeyColumnValue("2018-02-28", 0);
        key2.setSortKeyColumnValue("13:33:46", 1);
        KDBSourceEvent event2 = new KDBSourceEvent("", "","",true,"","",null,null,1, key2, KDBFunctionType.FI_MIFID_RFQ, "");

        DateTimeSortKey key3 = new DateTimeSortKey(new int[] { 0, 1});
        key3.setSortKeyColumnValue("2018-02-21", 0);
        key3.setSortKeyColumnValue("13:22:46", 1);
        KDBSourceEvent event3 = new KDBSourceEvent("", "","",true,"","",null,null,1, key3, KDBFunctionType.FI_MIFID_RFQ, "");

        List<KDBSourceEvent> list = new ArrayList<>();
        list.add(event1);
        list.add(event2);
        list.add(event3);
//        Collections.sort(list, new DateTimeComparator());
        logger.info("list = " + list);

    }
}
//                .function("FICCgetRawData")
//                .parameter("tableName", "fi_voice_quote")