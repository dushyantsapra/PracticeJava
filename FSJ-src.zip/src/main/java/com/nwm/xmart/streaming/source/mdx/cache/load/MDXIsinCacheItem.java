package com.nwm.xmart.streaming.source.mdx.cache.load;

/**
 * Created by gardlex on 13/05/2018.
 */
public class MDXIsinCacheItem implements CacheItem {
    private final String identifier;
    private final Integer version;
    private final Long epochXmlWriteTime;

    public MDXIsinCacheItem(String identifier, int version, long epochXmlWriteTime) {
        this.identifier = identifier;
        this.version = version;
        this.epochXmlWriteTime = epochXmlWriteTime;
    }

    @Override
    public String getIdentifier() {
        return identifier;
    }

    public int getVersion() {
        return version;
    }

    public long getEpochXmlWriteTime() {
        return epochXmlWriteTime;
    }
}
