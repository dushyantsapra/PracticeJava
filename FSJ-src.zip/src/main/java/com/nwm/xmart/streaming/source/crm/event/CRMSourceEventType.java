package com.nwm.xmart.streaming.source.crm.event;

import java.util.HashMap;
import java.util.Map;

public enum CRMSourceEventType {
    AccountCoverage, CallLog, CallReport, Contact, ContactCoverage, Organization, User, UserRole, Interest, AccountDesk;

    private static final Map<String, CRMSourceEventType> STRING_CRM_SOURCE_EVENT_TYPE_MAP = new HashMap<>();

    static {
        for (CRMSourceEventType value : CRMSourceEventType.values()) {
            STRING_CRM_SOURCE_EVENT_TYPE_MAP.put(value.name(), value);
        }
    }

    public static CRMSourceEventType get(String name) {
        return STRING_CRM_SOURCE_EVENT_TYPE_MAP.get(name);
    }
}
