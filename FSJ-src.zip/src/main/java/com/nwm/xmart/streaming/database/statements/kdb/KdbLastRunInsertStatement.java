package com.nwm.xmart.streaming.database.statements.kdb;

import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.nwm.xmart.streaming.database.statements.StatementParameters;
import com.nwm.xmart.streaming.database.statements.XmartStatement;

import java.sql.SQLException;

public class KdbLastRunInsertStatement extends XmartStatement {

    public KdbLastRunInsertStatement() {
        super();

        statementName = "usp_ProcessStateSet";
        PROC_COMMAND = "EXEC [fwk].[usp_ProcessStateSet] ?,?";
    }

    @Override
    public SQLServerCallableStatement getPreparedStatement(Object obj) throws SQLException {

        preparedStatement.clearParameters();
        SQLServerCallableStatement sqlServerCallableStatement = (SQLServerCallableStatement) preparedStatement;

        StatementParameters statementParameters = (StatementParameters) obj;

        int index = 1;

        sqlServerCallableStatement.setObject(index++, "kdb-function-" + statementParameters.get("functionName"));
        sqlServerCallableStatement.setObject(index++, statementParameters.get("date"));

        sqlServerCallableStatement.addBatch();

        return sqlServerCallableStatement;
    }
}