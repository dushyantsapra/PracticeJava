package com.nwm.xmart.streaming.source.rdx.session;

/**
 * Created by gardlex on 12/09/2018.
 */
public enum RDXSessionContextType {
    SUBSCRIPTION, LOADER;
}
