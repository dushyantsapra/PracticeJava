package com.nwm.xmart.streaming.source.rdx;

import com.nwm.xmart.streaming.source.rdx.event.RDXSourceEvent;
import com.nwm.xmart.streaming.source.mdx.cache.IsinCache;
import com.nwm.xmart.streaming.source.mdx.cache.load.CacheItem;
import com.nwm.xmart.streaming.source.mdx.cache.load.ISINCacheLoader;
import com.nwm.xmart.streaming.source.mdx.cache.load.XmartISINCacheLoader;
import com.nwm.xmart.streaming.source.rdx.cache.RDXIsinCache;
import com.nwm.xmart.streaming.source.rdx.cache.load.RDXEventLoader;
import com.nwm.xmart.streaming.source.rdx.cache.load.RDXIsinCacheItem;
import com.nwm.xmart.streaming.source.rdx.cache.load.RDXReferenceDataLoader;
import com.nwm.xmart.streaming.source.rdx.exception.RdxSubscriptionException;
import com.nwm.xmart.streaming.source.rdx.query.RdxDataReader;
import com.nwm.xmart.streaming.source.rdx.query.RdxLoaderCriteriaBuilder;
import com.nwm.xmart.streaming.source.rdx.query.RdxSubscriptionCriteriaBuilder;
import com.nwm.xmart.streaming.source.rdx.session.RDXSessionContext;
import com.nwm.xmart.streaming.source.rdx.session.RDXSessionContextType;
import com.nwm.xmart.streaming.source.rdx.subscription.ReferenceDataRdxSubscription;
import org.apache.flink.api.common.accumulators.IntCounter;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.state.OperatorStateStore;
import org.apache.flink.api.java.tuple.Tuple5;
import org.apache.flink.api.java.typeutils.TupleTypeInfo;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import rbs.gbm.dx.webService.impl.DxValuationDate;
import rbs.gbm.dx.webService.impl.rdx.RdxType;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.ReentrantLock;

import static com.nwm.xmart.streaming.sso.GenerateSSOToken.getSsoToken;
import static com.nwm.xmart.util.MDCUtil.putJobNameInMDC;

/**
 * Created by gardlex on 22/03/2018.
 */

// TODO - like straemevent - use String for json, changeID, timestamp, subscritpion info
public class RdxSource<RdxSourceEvent> extends RichParallelSourceFunction<RdxSourceEvent> implements CheckpointedFunction, CheckpointListener {

    private static Logger logger = LoggerFactory.getLogger(RdxSource.class);
    private volatile long changeId;
    private ReferenceDataRdxSubscription<RdxSourceEvent> rdxSubscription;
    private volatile boolean isRunning = true;
    private volatile boolean isRestored;
    private final Class<RdxSourceEvent> sourceEventClass;
    private transient ListState<Long> changeIdSourceState;
    private final IntCounter noOfLoadRdxEvents = new IntCounter();
    private final IntCounter noOfSubscriptionRdxEvents = new IntCounter();
    private volatile RDXEventLoader<RdxSourceEvent> rdxEventLoader;
    private final String rdxSourceName;
    private final ConcurrentMap<CacheItem, String> restoredCacheItems = new ConcurrentHashMap<>();
    private volatile IsinCache isinCache;
    private transient ListState<Tuple5<String, Integer, Integer, Integer, Integer>> isinListState;
    private volatile String listStateDescriptorName;
    private volatile ISINCacheLoader isinCacheLoader;
    private volatile boolean isHistoricalLoad;
    private volatile boolean isHistoricalLoadComplete;
    private volatile Thread currentThread;
    private volatile RDXSessionContext loaderRdxSessionContext;
    private volatile RDXSessionContext subscriptionRdxSessionContext;

    public RdxSource(Class<RdxSourceEvent> sourceEventClass,
                     String rdxSourceName) {

        this.sourceEventClass = sourceEventClass;
        this.rdxSourceName = rdxSourceName;

    }


    @Override
    public void run(SourceContext<RdxSourceEvent> ctx) throws Exception {

        ParameterTool parameter = (ParameterTool) getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        //MDC
        putJobNameInMDC(parameter);

        // perform initial load
        rdxEventLoader.setInitialLoad(true);
        rdxEventLoader.setSourceContext(ctx);
        long lastChangeIdAfterLoad = rdxEventLoader.loadRdxEvents();

        // For historical load loop eternally
        if (isHistoricalLoad) {
            isHistoricalLoadComplete = true;
            logger.info("Historical load has completed, waiting for first checkpoint after which job will finish");
            while(isHistoricalLoad) {
                Thread.sleep(10000);
            }

            // Checkpoint after load has completed means we're out of the loop and can cancel the job -  automatically
            throw new Exception("Cancelling job: First Checkpoint has been created after Historic load completed. Resume job from this checkpoint.");
        }

        // Start the ISIN cache refresh cycle
        isinCache.startPeriodicRefreshLoad();

        // Now start the subscription
        rdxSubscription.setStartChangeID(lastChangeIdAfterLoad);
        rdxSubscription.startCachingSubscriptionEvents();

        ReentrantLock subscriptionLock = rdxSubscription.getSubscriptionLock();
        final Object checkpointLock = ctx.getCheckpointLock();
        RdxSourceEvent rdxSourceEvent = null;
        RDXSourceEvent srcEvent = null;
        RDXIsinCacheItem rdxIsinCacheItem = null;

        // start consuming the cached subscription events
        currentThread = Thread.currentThread();

        while (isRunning) {
            try {
                logger.info("RDX SUBSCRIPTION - retrieving subscription event");
                rdxSourceEvent = rdxSubscription.getNextRdxEvent();
                logger.info("RDX SUBSCRIPTION - Getting subscription lock");

                subscriptionLock.lock();
                logger.info("RDX SUBSCRIPTION - Got subscription lock");
                try {
                    logger.info("RDX SUBSCRIPTION - about to enter checkpointLock");
                    synchronized (checkpointLock) {
                        logger.info("RDX SUBSCRIPTION - in checkpointLock");
                        srcEvent = (RDXSourceEvent) rdxSourceEvent;

                        logger.info("RDX SUBSCRIPTION - retrieved subscription event {}, {}, {}, {}, {}"
                                ,srcEvent.getChangeID()
                                ,srcEvent.getRdxId()
                                ,srcEvent.getRdxSeriesId()
                                ,srcEvent.getValuationDate()
                                ,srcEvent.getVersion());

                        rdxIsinCacheItem = new RDXIsinCacheItem(
                                RdxDataReader.getIsinFromAliasFor(srcEvent.getRdxFixedIncome()),
                                srcEvent.getValuationDate(),
                                srcEvent.getVersion());
                        if (isinCache.putISINCacheItem(rdxIsinCacheItem)) {
                            logger.info("RDX SUBSCRIPTION - loading new event {}, {}, {}, {}, {}"
                                    ,srcEvent.getChangeID()
                                    ,srcEvent.getRdxId()
                                    ,srcEvent.getRdxSeriesId()
                                    ,srcEvent.getValuationDate()
                                    ,srcEvent.getVersion());
                            ctx.collect(rdxSourceEvent);
                            this.noOfSubscriptionRdxEvents.add(1);
                            changeId = srcEvent.getChangeID();
                        }
                    }
                    logger.info("RDX SUBSCRIPTION - left checkpointLock");
                } finally {
                    logger.info("RDX SUBSCRIPTION - Unlocking subscription lock");
                    subscriptionLock.unlock();
                }
            } catch (RdxSubscriptionException e) {
                logger.error("ReferenceDataRdxSubscription has failed due to exception", e);
                isRunning = false;
                Thread.currentThread().interrupt();
                rdxSubscription.close();
                throw new RdxSubscriptionException("ReferenceDataRdxSubscription has failed due to exception", e);
            }
        }
    }

    @Override
    public void cancel() {
        isRunning = false;
        isHistoricalLoad = false;
        loaderRdxSessionContext.close();
        subscriptionRdxSessionContext.close();
        rdxSubscription.close();
        rdxEventLoader.close();
        isinCacheLoader.close();
        isinCache.close();
        logger.error("cancel() has been called in RdxSource by thread [ " + Thread.currentThread().getName() + " ], as a result, now interrupting main RdxSource run() to fail the Flink job ");
        currentThread.interrupt();
    }

    @Override
    @SuppressWarnings("unchecked")
    public void open(Configuration parameters) throws Exception {
        ParameterTool params = (ParameterTool)getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        // MDC logging
        String mdcJobNameKey =  params.get("nwm.job.param","jobName");
        String jobName = params.get("flink.job.name", "No Job Name Specific");
        MDC.put(mdcJobNameKey,jobName);

        isHistoricalLoad = params.getBoolean("rdx.historical.load");

        // Load Criteria builder
        RdxLoaderCriteriaBuilder loaderCriteriaBuilder
                = new RdxLoaderCriteriaBuilder()
                .withInstrumentAssetClass(params.get("rdx.field.criteria.asset.class"), params.get("rdx.field.criteria.asset.subclass"))
                .withRdxType(RdxType.Instrument.FixedIncome)
                .withRequestedFacets(params.get("rdx.facet.data"));

        if (isHistoricalLoad) {
            loaderCriteriaBuilder.withLatestValudationDate(
                    params.getInt("rdx.historical.load.year"),
                    params.getInt("rdx.historical.load.month"),
                    params.getInt("rdx.historical.load.day"),
                    params.getInt("rdx.historical.load.hour"),
                    params.getInt("rdx.historical.load.min"),
                    params.getInt("rdx.historical.load.sec")
            );
        }

        // Subscription criteria builder
        RdxSubscriptionCriteriaBuilder subscriptionCriteriaBuilder
                = new RdxSubscriptionCriteriaBuilder()
                .withRdxType(RdxType.Instrument.FixedIncome);

        // Rdx Sessions
        subscriptionRdxSessionContext
                = new RDXSessionContext()
                .withRdxEnvironmentName(params.get("rdx.rdxEnvironmentName",""))
                .withApplicationName(params.get("rdx.applicationName", ""))
                .withApplicationVersion(params.get("rdx.applicationVersion",""))
                .withSsoToken(getSsoToken(params))
                .withRDXSessionContextType(RDXSessionContextType.SUBSCRIPTION)
                .withFlinkParameters(params);
        subscriptionRdxSessionContext.build();

        loaderRdxSessionContext
                = new RDXSessionContext()
                .withRdxEnvironmentName(params.get("rdx.rdxEnvironmentName",""))
                .withApplicationName(params.get("rdx.applicationName", ""))
                .withApplicationVersion(params.get("rdx.applicationVersion",""))
                .withSsoToken(getSsoToken(params))
                .withRDXSessionContextType(RDXSessionContextType.LOADER)
                .withFlinkParameters(params);
        loaderRdxSessionContext.build();

        // Subscription
        this.rdxSubscription = new ReferenceDataRdxSubscription<RdxSourceEvent>(sourceEventClass);
        rdxSubscription
                .withApplicationSubscriptionName(params.get("rdx.applicationSubscriptionName", ""))
                .withInitialCapacity(params.getInt("rdx.subscription.initialCapacity"))
                .withRDXSession(subscriptionRdxSessionContext)
                .withRdxSubscriptionCriteriaBuilder(subscriptionCriteriaBuilder)
                .withSourceFunction(this);

        // Flink accumlators / counters
        getRuntimeContext().addAccumulator("noOfLoadRdxEvents", this.noOfLoadRdxEvents);
        getRuntimeContext().addAccumulator("noOfSubscriptionRdxEvents", this.noOfSubscriptionRdxEvents);

        // ISIN Cache
        isinCacheLoader = new XmartISINCacheLoader(params.get("mdx.sql.isin.query"), params);  // XmartISINCacheLoader  TestMdxISINCacheLoader  new XmartISINCacheLoader(params)
        isinCache = new RDXIsinCache(isinCacheLoader, rdxSourceName, params);

        // Check if we're resuming from a checkpoint, if so then set the RDXIsinCache to the restored state
        if (isRestored) {
            isinCache.setRestoredISINS(restoredCacheItems.keySet());
        }

        // RDX loader
        this.rdxEventLoader = new RDXReferenceDataLoader<RdxSourceEvent>(sourceEventClass, isHistoricalLoad);
        rdxEventLoader
                .withCounter(noOfLoadRdxEvents)
                .withISINCache(isinCache)
                .withRdxLoaderCriteriaBuilder(loaderCriteriaBuilder)
                .withRDXSession(loaderRdxSessionContext)
                .withRdxSubscription(rdxSubscription)
                .withSourceFunction(this)
        .withFlinkParameters(params);

        // register Loader with ISIN cache for periodic refresh
        isinCache.registerCacheListener(rdxEventLoader);
    }

    @Override
    public void notifyCheckpointComplete(long checkpointId) throws Exception {
        logger.info("Checkpoint Complete ID [ " + checkpointId + " ]");

        // Enable the job to finish if the load has completed and also the first checkpoint has completed (after) the initial load is complete...
        if (isHistoricalLoadComplete) {
            isHistoricalLoad = false;
        }
    }

    @Override
    public void snapshotState(FunctionSnapshotContext context) throws Exception {
        ParameterTool params = (ParameterTool)getRuntimeContext().getExecutionConfig().getGlobalJobParameters();

        // MDC logging
        String mdcJobNameKey =  params.get("nwm.job.param","jobName");
        String jobName = params.get("flink.job.name", "No Job Name Specific");
        MDC.put(mdcJobNameKey,jobName);

        // The checkpoint lock is held when this method is called by Flink
        Collection<CacheItem> cacheItems = isinCache.getValues();

        // write the changeID ro the list of operator states
        this.isinListState.clear();
        for (CacheItem cacheItem : cacheItems) {
            RDXIsinCacheItem rdxIsinCacheItem = (RDXIsinCacheItem) cacheItem;
            this.isinListState.add(Tuple5.of(
                    rdxIsinCacheItem.getIdentifier(),
                    rdxIsinCacheItem.getDxValuationDate().getYear(),
                    rdxIsinCacheItem.getDxValuationDate().getMonth(),
                    rdxIsinCacheItem.getDxValuationDate().getDay(),
                    rdxIsinCacheItem.getVersion()));
        }

        logger.info("Checkpoint taken with isinList size [ " + cacheItems.size() + " ] for checkpointID [ " + context.getCheckpointId() + " ]");
    }

    @Override
    public void initializeState(FunctionInitializationContext context) throws Exception {
        // MDC logging
        ParameterTool params = (ParameterTool)getRuntimeContext().getExecutionConfig().getGlobalJobParameters();
        String mdcJobNameKey =  params.get("nwm.job.param","jobName");
        String jobName = params.get("flink.job.name", "No Job Name Specific");
        MDC.put(mdcJobNameKey,jobName);

        // register the state with the backend
        OperatorStateStore stateStore = context.getOperatorStateStore();
        this.listStateDescriptorName = "rdx-" + rdxSourceName + "-ISIN-list";

        logger.info("Registering state for [ " + listStateDescriptorName + " ]");
        TupleTypeInfo<Tuple5<String, Integer, Integer, Integer, Integer>> typeInfo = TupleTypeInfo. getBasicAndBasicValueTupleTypeInfo(new Class[] {String.class, Integer.class, Integer.class, Integer.class, Integer.class});

        this.isinListState = stateStore.getListState(new ListStateDescriptor<Tuple5<String, Integer, Integer, Integer, Integer>>(listStateDescriptorName, typeInfo));

        // if the job was restarted, we set the restored isinCache values
        if (context.isRestored()) {
            for (Tuple5<String, Integer, Integer, Integer, Integer> restoredCacheItem : this.isinListState.get()) {
                RDXIsinCacheItem newCacheItem = new RDXIsinCacheItem(restoredCacheItem.f0, new DxValuationDate(restoredCacheItem.f1, restoredCacheItem.f2, restoredCacheItem.f3), restoredCacheItem.f4);
                restoredCacheItems.put(newCacheItem, "");
            }
            logger.info("initializeState: restored [ " + restoredCacheItems.size() + " ] ISIN cache items from checkpoint");

            isRestored = true;
        }
    }
}
