package com.nwm.xmart.streaming.source.df;

import org.apache.flink.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;

import static java.util.Objects.isNull;

public class DFWatchSourceConnectionDetails implements Serializable {

    private static final Logger logger = LoggerFactory.getLogger(DFWatchSourceConnectionDetails.class);

    private final String sourceId;
    private final String sourceName;
    private final String watchId;
    private final String consumerGroupId;
    private final boolean isStartFromOffset;
    private final Long specificOffset;

    public DFWatchSourceConnectionDetails(String watchId, String sourceId, String sourceName, String consumerGroupId, boolean isStartFromOffset, Long specificOffset) {
        this.sourceId = sourceId;
        this.sourceName = sourceName;
        this.watchId = watchId;
        this.consumerGroupId = consumerGroupId;
        this.isStartFromOffset = isStartFromOffset;
        this.specificOffset = specificOffset;
    }

    public DFWatchSourceConnectionDetails(String jobPrefix, Configuration config) {
        this.sourceId = config.getString(jobPrefix + ".source.id", "");
        this.sourceName = config.getString(jobPrefix + ".source.name", "");
        this.watchId = config.getString(jobPrefix + ".watch.id", "");
        this.consumerGroupId = config.getString("datafabric.consumer.group.id", "");
        this.isStartFromOffset = config.getBoolean(jobPrefix + ".start.from.offset", false);
        this.specificOffset = config.getLong(jobPrefix + ".start.from.offset.value", 0L);
    }

    private void checkConnectionDetails(){
        if(isNull(sourceId)){
            throw new IllegalArgumentException("A source id must be specified for a DF API based source.");
        }
        if(isNull(sourceName)){
            throw new IllegalArgumentException("A source name must be specified for a DF API based source.");
        }
        if(isNull(watchId)){
            throw new IllegalArgumentException("A watch id must be specified for a DF API based source.");
        }
        if(isNull(consumerGroupId)){
            throw new IllegalArgumentException("A consumer group id must be specified for a DF API based source.");
        }
        if(isStartFromOffset && specificOffset <= -1L){
            throw new IllegalArgumentException("A specific offset of zero or greater must be specified if specific offset is to be used.");
        }
    }

    public String getSourceId() {
        return sourceId;
    }

    public String getSourceName() {
        return sourceName;
    }

    public String getWatchId() {
        return watchId;
    }

    public String getConsumerGroupId() {
        return consumerGroupId;
    }

    public boolean isStartFromOffset() {
        return isStartFromOffset;
    }

    public Long getSpecificOffset() {
        return specificOffset;
    }

}
