package com.nwm.xmart.streaming.source.mdx.entity;

public class RefRegInstrumentAttributesFields {
    private RefRegInstrumentGenericFields refRegInstrumentGenericFields;

    public RefRegInstrumentGenericFields getRefRegInstrumentGenericFields() {
        return refRegInstrumentGenericFields;
    }

    public void setRefRegInstrumentGenericFields(RefRegInstrumentGenericFields refRegInstrumentGenericFields) {
        this.refRegInstrumentGenericFields = refRegInstrumentGenericFields;
    }
}
