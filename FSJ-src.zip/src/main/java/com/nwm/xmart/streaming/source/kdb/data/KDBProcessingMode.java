package com.nwm.xmart.streaming.source.kdb.data;

/**
 * Created by gardlex on 21/06/2018.
 */
public enum KDBProcessingMode {
    OPERATIONAL_DEFAULT_DAILY, OPERATIONAL_DEFAULT_DATE_RANGE, REPAIR_DATE_RANGE, SPECIFIED_DATE_RANGE;
}
