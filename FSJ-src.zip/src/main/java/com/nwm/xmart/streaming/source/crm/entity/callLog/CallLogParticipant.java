package com.nwm.xmart.streaming.source.crm.entity.callLog;

import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonInclude;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonProperty;
import com.rbs.datafabric.shaded.com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(
        { "CallLogId", "Direction", "Name", "Number", "StartTime", "EndTime", "Duration", "ParticipantSeq", "ContactId",
          "UserId", "RecordType" })
public class CallLogParticipant implements Serializable {
    private static final long serialVersionUID = -3869434813671692176L;

    @JsonProperty("CallLogId")
    private String callLogId;
    @JsonProperty("Direction")
    private String direction;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Number")
    private String number;
    @JsonProperty("StartTime")
    private String startTime;
    @JsonProperty("EndTime")
    private String endTime;
    @JsonProperty("Duration")
    private Long duration;
    @JsonProperty("ParticipantSeq")
    private Long participantSeq;
    @JsonProperty("ContactId")
    private String contactId;
    @JsonProperty("UserId")
    private String userId;
    @JsonProperty("RecordType")
    private String recordType;

    @JsonProperty("CallLogId")
    public String getCallLogId() {
        return callLogId;
    }

    @JsonProperty("CallLogId")
    public void setCallLogId(String callLogId) {
        this.callLogId = callLogId;
    }

    @JsonProperty("Direction")
    public String getDirection() {
        return direction;
    }

    @JsonProperty("Direction")
    public void setDirection(String direction) {
        this.direction = direction;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("Number")
    public String getNumber() {
        return number;
    }

    @JsonProperty("Number")
    public void setNumber(String number) {
        this.number = number;
    }

    @JsonProperty("StartTime")
    public String getStartTime() {
        return startTime;
    }

    @JsonProperty("StartTime")
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    @JsonProperty("EndTime")
    public String getEndTime() {
        return endTime;
    }

    @JsonProperty("EndTime")
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    @JsonProperty("Duration")
    public Long getDuration() {
        return duration;
    }

    @JsonProperty("Duration")
    public void setDuration(Long duration) {
        this.duration = duration;
    }

    @JsonProperty("ParticipantSeq")
    public Long getParticipantSeq() {
        return participantSeq;
    }

    @JsonProperty("ParticipantSeq")
    public void setParticipantSeq(Long participantSeq) {
        this.participantSeq = participantSeq;
    }

    @JsonProperty("ContactId")
    public String getContactId() {
        return contactId;
    }

    @JsonProperty("ContactId")
    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    @JsonProperty("UserId")
    public String getUserId() {
        return userId;
    }

    @JsonProperty("UserId")
    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getRecordType() {
        return recordType;
    }

    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CallLogParticipant{");
        sb.append("callLogId='").append(callLogId).append('\'');
        sb.append(", direction='").append(direction).append('\'');
        sb.append(", name='").append(name).append('\'');
        sb.append(", number='").append(number).append('\'');
        sb.append(", startTime='").append(startTime).append('\'');
        sb.append(", endTime='").append(endTime).append('\'');
        sb.append(", duration=").append(duration);
        sb.append(", participantSeq='").append(participantSeq).append('\'');
        sb.append(", contactId='").append(contactId).append('\'');
        sb.append(", userId='").append(userId).append('\'');
        sb.append(", recordType='").append(recordType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
