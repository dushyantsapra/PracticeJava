package com.nwm.xmart.streaming.source.kdb;

import com.nwm.xmart.streaming.source.kdb.parameters.DateParameterUtil;

import java.time.LocalDate;

/**
 * Created by gardlex on 08/08/2018.
 */
public class RestoredProcessingDayTime {
    private volatile String functionName;
    private volatile String processingDay;
    private volatile long epochTime;

    public RestoredProcessingDayTime(String functionName, String processingDay, long epochTime) {
        this.functionName = functionName;
        this.processingDay = processingDay;
        this.epochTime = epochTime;
    }

    public String getFunctionName() {
        return functionName;
    }

    public String getProcessingDay() {
        return processingDay;
    }

    public long getEpochTime() {
        return epochTime;
    }
}
