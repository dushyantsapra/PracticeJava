package com.nwm.xmart.streaming.source.kdb.sorting;

/**
 * Created by gardlex on 01/05/2018.
 */
public interface SortKeyI {
    int[] getColumnSortKeyIndexes();
    void setSortKeyColumnValue(Object o, int index);
    Object getSortKeyValue();
    Object[] getSortKeyIndexValues();

    boolean isSortKeyIndex(int verticalRowIndex);
}
