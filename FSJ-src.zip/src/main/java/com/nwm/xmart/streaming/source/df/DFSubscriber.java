package com.nwm.xmart.streaming.source.df;

import com.nwm.xmart.streaming.source.crm.exception.CRMException;
import com.nwm.xmart.streaming.source.df.event.DataFabricWatchEvent;
import com.nwm.xmart.streaming.source.df.exception.DFSourceException;
import com.nwm.xmart.util.MDCParameter;
import com.nwm.xmart.util.MDCUtil;
import com.rbs.datafabric.domain.*;
import com.rbs.datafabric.domain.event.*;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Subscriber;
import rx.Subscription;

import java.io.Serializable;

import static com.nwm.xmart.streaming.source.df.event.DataFabricWatchEvent.isValidDFWatchEvent;

public class DFSubscriber extends Subscriber<ContinuousQueryEvent> implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(DFSubscriber.class);
    private static final long serialVersionUID = 7742543646306023313L;

    private final DFWatchSource sourceFunction;
    private final WatchContext<ContinuousQueryEvent> watchContext;
    private final String sourceName;
    private final SourceFunction.SourceContext<DataFabricWatchEvent> flinkContext;
    private final MDCParameter mdcParameter;
    private Subscription subscription;

    DFSubscriber(DFWatchSource dfWatchSource,
            SourceFunction.SourceContext<DataFabricWatchEvent> flinkContext,
            WatchContext<ContinuousQueryEvent> watchContext,
            String sourceName,
            MDCParameter mdcParameter) {
        this.sourceFunction = dfWatchSource;
        this.flinkContext = flinkContext;
        this.watchContext = watchContext;
        this.sourceName = sourceName;
        this.mdcParameter = mdcParameter;
    }

    void startSubscription() {
        MDCUtil.putInMDC(mdcParameter);
        this.subscription = watchContext.getSubject().subscribe(this);
    }

    @Override
    public void onCompleted() {
        MDCUtil.putInMDC(mdcParameter);
        logger.info("On Completed method called ");
        sourceFunction.cancel();
    }

    @Override
    public void onError(Throwable throwable) {
        MDCUtil.putInMDC(mdcParameter);
        logger.error("On Error method called ", throwable);
        sourceFunction.cancel();
        throw new DFSourceException("On Error method called", throwable);
    }

    @Override
    public void onNext(ContinuousQueryEvent event) {
        MDCUtil.putInMDC(mdcParameter);
        if(isValidDFWatchEvent(sourceName, event)) {
            synchronized (flinkContext.getCheckpointLock()) {
                flinkContext.collect(getDFWatchEvent(event));
                sourceFunction.incrementOffsetTracker(event.getOffset());
            }
        }
    }

    private DataFabricWatchEvent getDFWatchEvent(ContinuousQueryEvent continuousQueryEvent){
        return new DataFabricWatchEvent(continuousQueryEvent);
    }

    public Subscription getSubscription() {
        return subscription;
    }
}
