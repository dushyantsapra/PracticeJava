package com.nwm.xmart.streaming.source.rdx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * Simple Bounded blocking queue with capacity of 1.
 * Ensures that Source Function processes an event from
 * an event publisher before accepting the next event.
 *
 *
 * Created by gardlex on 26/03/2018.
 */
public class RendezvousSingleEventExchange<Event> implements Serializable {

    private static Logger logger = LoggerFactory.getLogger(RendezvousSingleEventExchange.class);
    private Event data;
    private final int SINGLE_CAPACITY = 1;
    private int count;
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition notFull = lock.newCondition();
    private final Condition notEmpty = lock.newCondition();

    public Event getEvent() throws InterruptedException {
        final ReentrantLock lock = this.lock;
        lock.lockInterruptibly();
        try {
            while (count == 0) {
                notEmpty.await();
            }
            count--;
            notFull.signal();
            return data;
        } finally {
            lock.unlock();
        }
    }

    public void putEvent(Event e) throws InterruptedException {
        checkNotNull(e);
        final ReentrantLock lock = this.lock;
        lock.lockInterruptibly();
        try {
            while (count == SINGLE_CAPACITY)
                notFull.await();
            data = e;
            count++;
            notEmpty.signal();
        } finally {
            lock.unlock();
        }
    }

    private void checkNotNull(Object v) {
        if (v == null)
            throw new NullPointerException();
    }
}
