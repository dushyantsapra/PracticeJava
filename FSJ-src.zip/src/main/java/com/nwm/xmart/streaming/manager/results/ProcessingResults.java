package com.nwm.xmart.streaming.manager.results;

public class ProcessingResults {
    private boolean connectionSuccessful;
    private boolean dataProcessedSuccessfully;
    private boolean dataAvailable;

    public ProcessingResults(boolean connectionSuccessful, boolean dataProcessedSuccessfully, boolean dataAvailable) {
        this.connectionSuccessful = connectionSuccessful;
        this.dataProcessedSuccessfully = dataProcessedSuccessfully;
        this.dataAvailable = dataAvailable;
    }

    public boolean isDataProcessedSuccessfully() {
        return dataProcessedSuccessfully;
    }

    public void setDataProcessedSuccessfully(boolean dataProcessedSuccessfully) {
        this.dataProcessedSuccessfully = dataProcessedSuccessfully;
    }

    public boolean isDataAvailable() {
        return dataAvailable;
    }

    public void setDataAvailable(boolean dataAvailable) {
        this.dataAvailable = dataAvailable;
    }

    public boolean isConnectionSuccessful() {
        return connectionSuccessful;
    }

    public void setConnectionSuccessful(boolean connectionSuccessful) {
        this.connectionSuccessful = connectionSuccessful;
    }


}
