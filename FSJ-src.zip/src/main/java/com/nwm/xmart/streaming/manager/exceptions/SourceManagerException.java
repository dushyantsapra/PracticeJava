package com.nwm.xmart.streaming.manager.exceptions;

public class SourceManagerException extends RuntimeException {

    public SourceManagerException() {
        super();
    }

    public SourceManagerException(String msg) {
        super(msg);
    }

    public SourceManagerException(String msg, Throwable t) {
        super(msg, t);
    }
}
