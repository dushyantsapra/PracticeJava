package com.nwm.xmart.streaming.source.mdx.subscription;


import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.streaming.source.mdx.event.ProcessingType;
import com.nwm.xmart.streaming.source.mdx.identifier.TimeSeriesIdentifierGenerator;
import com.nwm.xmart.streaming.source.mdx.session.MdxSessionContext;
import org.apache.commons.lang3.reflect.ConstructorUtils;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.util.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rbs.gbm.mdx.webService.impl.MdxTimePointContent;
import rbs.gbm.mdx.webService.interfaces.*;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantLock;


/**
 * Encapsulates the logic required for capturing real time publication of new MDX Document events.
 *
 * Created by gardlex on 23/03/2018.
 */
public class TimeSeriesMdxSubscription<T> implements IMdxTimeSeriesChangeHandler, MdxSubscription<T> {

    private static Logger logger = LoggerFactory.getLogger(TimeSeriesMdxSubscription.class);
    private final Class<T> sourceEventClass;
    private volatile String mdxIdentifier;
    private volatile String mdxIdentifierWildcard;
    private final AtomicReference<MdxRealTimeEventExchange<T>> mdxEventExchangeRef = new AtomicReference<>();
    private final AtomicReference<MdxSessionContext> mdxSessionContextRef = new AtomicReference<>();
    private final ReentrantLock subscriptionLock = new ReentrantLock();
    private final ConcurrentMap<String, String> isinMap = new ConcurrentHashMap<>();
    private final AtomicReference<SourceFunction<T>> sourceFunctionRef = new AtomicReference<>();
    private final AtomicReference<TimeSeriesIdentifierGenerator> identifierGenerator = new AtomicReference<>();
    private final String sourceID;
    private final AtomicLong currentJobEventIDCounter;

    public TimeSeriesMdxSubscription(Class<T> sourceEventClass, String sourceID, AtomicLong currentJobEventIDCounter) {
        this.sourceEventClass = sourceEventClass;
        this.sourceID = sourceID;
        this.currentJobEventIDCounter = currentJobEventIDCounter;
    }

    @Override
    public MdxSubscription withMdxEventExchange(MdxRealTimeEventExchange<T> mdxEventExchange) {
        this.mdxEventExchangeRef.set(mdxEventExchange);
        return this;
    }

    @Override
    public MdxSubscription withMdxIdentifier(String identifier) {
        this.mdxIdentifier = identifier;
        this.identifierGenerator.set(new TimeSeriesIdentifierGenerator(identifier));
        return this;
    }

    @Override
    public MdxSubscription withMdxIdentifierWildcard(String wildcard) {
        this.mdxIdentifierWildcard = wildcard;
        return this;
    }

    @Override
    public MdxSubscription withMdxSessionContext(MdxSessionContext mdxSessionContext) {
        this.mdxSessionContextRef.set(mdxSessionContext);
        return this;
    }

    @Override
    public MdxSubscription setISINList(Set<String> isinList) {
        subscriptionLock.lock();
        try {
            isinMap.clear();
            for (String isin : isinList) {
                isinMap.put(isin, "");
            }
        } finally {
            subscriptionLock.unlock();
        }

        return this;
    }

    @Override
    public MdxSubscription withSourceFunction(SourceFunction<T> sourceFunction) {
        this.sourceFunctionRef.set(sourceFunction);

        return this;
    }

    public void startConsumingEvents() {
        try {
            subscribeToRealTimeEvents();
        }
        catch (Exception e)
        {
            logger.error("Could not start the TimeSeriesMdxSubscription", e);
            close();
        }
    }

    private void subscribeToRealTimeEvents() throws MdxException {
        Object ooo = mdxSessionContextRef.get().getMdxTimeSeriesSession().subscribe(mdxIdentifier+mdxIdentifierWildcard, this, "TimeSeriesMdxSubscription");
    }

    public void close() {
        try
        {
            mdxSessionContextRef.get().getMdxTimeSeriesSession().close();
        } catch (MdxException e)
        {
            logger.warn("Close(): Could not close the TimeSeriesMdxSubscription session", e);
        }
    }

    /**
     * When called, blocks current thread until the RendezvousSingleEventExchange has an event for consumption
     *
     * @return
     * @throws MdxSubscriptionFailureException
     */
    public T getMdxNextEvent() {
        return mdxEventExchangeRef.get().getNextMdxDocumentEvent();
    }

    @Override
    public ReentrantLock getSubscriptionLock() {
        return subscriptionLock;
    }

    @Override
    public void onMdxTimeSeriesChange(IMdxTimeSeriesSession iMdxTimeSeriesSession, Object o, Object o1, String identifier, MdxTimePointContent mdxTimePointContent, long l) {
        // filter out any events that aren't in the ISIN list
        if (isinMap.get(identifierGenerator.get().extractISINFromIdentifier(identifier)) == null) {
            return;
        }

        long epochXmlWriteTime = mdxTimePointContent.getWriteTime().getTime();
        int version = mdxTimePointContent.getVersion();
        try {
            mdxEventExchangeRef.get().putMdxDocumentEvent((T) MdxDocumentEvent.ofMdxTimePointContent(sourceID, currentJobEventIDCounter.incrementAndGet(), mdxTimePointContent, System.currentTimeMillis(), epochXmlWriteTime, version, identifier, ProcessingType.SUBSCRIPTION));
        } catch (Exception e) {
            logger.error("Could not create MdxDocumentEvent constructor", e);
            throw new MdxSubscriptionFailureException("Could not create MdxDocumentEvent constructor", e);
        }
    }

    @Override
    public void onMdxAddTimeSeriesMetadata(IMdxTimeSeriesSession iMdxTimeSeriesSession, Object o, Object o1, String s, Map<String, String> map, long l) {
        // TODO - Mike B (MDX) says this event is not needed
    }

    @Override
    public void onSubscriptionRevoked(IMdxTimeSeriesSession iMdxTimeSeriesSession, Object o, Object o1) {
        logger.error("onSubscriptionRevoked");
        sourceFunctionRef.get().cancel();
    }
}
