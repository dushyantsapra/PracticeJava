package com.nwm.xmart.util;

public interface ConfigParams {

    // Guice injection bind names
    String LOGGER_DAO = "LoggerDao";
    String SQL_SVR_DAO = "SqlServerDao";
    String LOGGER_SINK = "LoggerSink";
    String BDX_SINK = "BdxSink";
    String XML_TRANS_MPR = "XmartTransactionMapper";
    String XMART_WDW_MPR = "XmartWindowMapper";
    String XMART_XML_MPR = "XmartXmlMapper";

    /**
     * Param: parameter to take from configuration for job name
     */
    String JOB_NAME_LOOKUP = "nwm.job.param";

    /**
     * Param: ODC transaction processor job name for log file
     */
    String JOB_NAME_PARAM = "flink.job.name";

    /**
     * ParamName: Parameter to control if the xml should be logged.
     */
    String LOG_XML_PARAM = "nwm.log.xml";
}
