package com.nwm.xmart.util;

import org.apache.flink.api.java.utils.ParameterTool;

import static java.util.Objects.isNull;

public class MDCParameter {

    private final String name;
    private final String value;

    private MDCParameter(){
        // to prevent invalid construction
        this.name = null;
        this.value = null;
    }

    private MDCParameter(String name, String value){
        this.name = name;
        this.value = value;
    }

    public static MDCParameter of(String name, String value) {
        return new MDCParameter(name, value);
    }

    public static MDCParameter jobNameFrom(ParameterTool parameters) {
        String name = parameters.get("nwm.job.param", null);
        if(isNull(name)){
            throw new IllegalStateException("The job configuration does not contain the details ofthe MDC parameter to store the job name.");
        }
        String value = parameters.get("nwm.job.name", "JOB_NAME_UNKNOWN");

        return new MDCParameter(name, value);
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }

}
