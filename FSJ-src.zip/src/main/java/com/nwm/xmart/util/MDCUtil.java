package com.nwm.xmart.util;

import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.slf4j.MDC;

/**
 * Utility class to provide Logback's {@link MDC} related functionality.
 *
 * @author vashpan
 */
public final class MDCUtil {

    private MDCUtil() {
    }

    /**
     * Utility method to add ODC Transaction Processor job name in the MDC. This
     * is meant to be called specifically from the ODC Transatiocn procesing
     * source, mappers, aggregaters, sinks et.al.
     *
     * @param conf {@link Configuration} for the current filnk job
     */
    public static void putJobNameInMDC(Configuration conf) {
        putInMDC(conf, conf.getString(ConfigParams.JOB_NAME_PARAM, "_JOB_NAME_NOT_SET_"));
    }

    /**
     * Utility method to add ODC Transaction Processor job name in the MDC. This
     * is meant to be called specifically from the ODC Transaction processing
     * source, mappers, aggregaters, sinks et.al.
     *
     * @param parameters {@link ParameterTool} for the current Flink job
     */
    public static void putJobNameInMDC(ParameterTool parameters) {
        putInMDC(parameters, parameters.get(ConfigParams.JOB_NAME_PARAM, "_JOB_NAME_NOT_SET_"));
    }

    /**
     * Utility method to set the value of the job name in the {@link MDC}.
     *
     * @param conf    {@link Configuration} for the current Flink job
     * @param jobName name of the job that is to appear in the log messages
     */
    public static void putInMDC(Configuration conf, String jobName) {
        put(conf.getString(ConfigParams.JOB_NAME_LOOKUP, "NAME_PARAM_UNKNOWN"), jobName);
    }

    /**
     * Put the value in {@link MDC} taking from {@link ParameterTool}
     *
     * @param paramTool    {@link ParameterTool} The global job parameters.
     * @param jobNameValue Name of the job to go in the log messages.
     */
    public static void putInMDC(ParameterTool paramTool, String jobNameValue) {
        put(paramTool.get(ConfigParams.JOB_NAME_LOOKUP, "NAME_PARAM_UNKNOWN"), jobNameValue);
    }

    public static void putInMDC(MDCParameter parameter) {
        put(parameter.getName(), parameter.getValue());
    }

    private static void put(String key, String value) {
        MDC.put(key, value);
    }
}
