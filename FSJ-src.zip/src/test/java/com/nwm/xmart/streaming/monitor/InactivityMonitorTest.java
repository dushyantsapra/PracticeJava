package com.nwm.xmart.streaming.monitor;

import org.apache.flink.configuration.Configuration;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

/**
 * Created by gardlex on 18/11/2017.
 */
public class InactivityMonitorTest {


    private Configuration configuration;

    @Before
    public void getConfiguration() {
        configuration = new Configuration();
        configuration.setString("flink.job.name", "JobName");
        configuration.setString("kafka.inactivity.monitor.fileLocation", "");
        configuration.setString("kafka.inactivity.monitor.filename.postfix", "No Job Name Specific");
        configuration.setString("flink.kafka.consumer.topic","testTopic");
        configuration.setString("kafka.inactivity.monitor.interval.seconds", "5");
        configuration.setString("kafka.inactivity.monitor.interval.minOffsetDelta", "100");
    }

    @Test
    public void testInactivityMonitor() throws Exception {
        InactivityMonitor inactivityMonitor = new InactiveKafkaMonitor(configuration, new PersistenceFile() {
            @Override
            public void persistOffsetInfo(InactivityStatus inactivityStatus, long currentKafkaOffset, long lastOffset, long currentTimestamp, long lastTimestamp, long lastOffsetChangeTimestamp) throws IOException {
                // do nothing
            }
        });

        inactivityMonitor.updateStreamPosition(0);
        Assert.assertEquals("First Status should in INACTIVE", InactivityStatus.INACTIVE,inactivityMonitor.getLastInactivityStatus());
        inactivityMonitor.updateStreamPosition(99);
        Assert.assertEquals("First Status should in INACTIVE", InactivityStatus.ACTIVE_LESS_THAN_MIN_OFFSET_DELTA,inactivityMonitor.getLastInactivityStatus());
        inactivityMonitor.updateStreamPosition(1000);
        Assert.assertEquals("First Status should in INACTIVE", InactivityStatus.ACTIVE_AT_LEAST_MIN_OFFSET_DELTA,inactivityMonitor.getLastInactivityStatus());
        inactivityMonitor.updateStreamPosition(1000);
        Assert.assertEquals("First Status should in INACTIVE", InactivityStatus.INACTIVE,inactivityMonitor.getLastInactivityStatus());
        inactivityMonitor.updateStreamPosition(1050);
        Assert.assertEquals("First Status should in INACTIVE", InactivityStatus.ACTIVE_LESS_THAN_MIN_OFFSET_DELTA,inactivityMonitor.getLastInactivityStatus());
        inactivityMonitor.updateStreamPosition(2000);
        Assert.assertEquals("First Status should in INACTIVE", InactivityStatus.ACTIVE_AT_LEAST_MIN_OFFSET_DELTA,inactivityMonitor.getLastInactivityStatus());
    }
}
