package com.nwm.xmart.streaming.source.json;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.NumericNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import com.jayway.jsonpath.*;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.json.JacksonJsonProvider;
import com.jayway.jsonpath.spi.json.JsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;
import com.jayway.jsonpath.spi.mapper.MappingProvider;
import com.nwm.xmart.streaming.source.json.JSONDocumentTraverser;
import jdk.nashorn.internal.scripts.JS;

import java.io.IOException;
import java.util.*;

/**
 * Created by gardlex on 27/09/2018.
 */
public class JSONTest {
    public static void main(String[] args) {

        String bookStore = "{\n" +
                "    \"store\": {\n" +
                "        \"book\": [\n" +
                "            {\n" +
                "                \"category\": \"reference\",\n" +
                "                \"author\": \"Nigel Rees\",\n" +
                "                \"title\": \"Sayings of the Century\",\n" +
                "                \"price\": 8.95\n" +
                "            },\n" +
                "            {\n" +
                "                \"category\": \"fiction\",\n" +
                "                \"author\": \"Evelyn Waugh\",\n" +
                "                \"title\": \"Sword of Honour\",\n" +
                "                \"price\": 12.99\n" +
                "            },\n" +
                "            {\n" +
                "                \"category\": \"fiction\",\n" +
                "                \"author\": \"Herman Melville\",\n" +
                "                \"title\": \"Moby Dick\",\n" +
                "                \"isbn\": \"0-553-21311-3\",\n" +
                "                \"price\": 8.99\n" +
                "            },\n" +
                "            {\n" +
                "                \"category\": \"fiction\",\n" +
                "                \"author\": \"J. R. R. Tolkien\",\n" +
                "                \"title\": \"The Lord of the Rings\",\n" +
                "                \"isbn\": \"0-395-19395-8\",\n" +
                "                \"price\": 22.99\n" +
                "            }\n" +
                "        ],\n" +
                "        \"bicycle\": {\n" +
                "            \"color\": \"red\",\n" +
                "            \"price\": 19.95\n" +
                "        }\n" +
                "    },\n" +
                "    \"expensive\": 10\n" +
                "}\n" +
                "                        ";
        String jsonObject = "{\"brand\":\"ford\", \"doors\":5}";
        String data  = "{ \"_schema\" : { \"_name\" : \"instrumentTransactionPut\", \"_semanticVersion\" : \"4.0.1\" }, \"notificationHeader\" : { \"publishingSystem\" : \"Ignite\", \"notificationId\" : \"90cd70cf-954c-403c-8e66-b7284dae4768\", \"businessDate\" : { \"date\" : \"2017-11-20\" }, \"createdDateTime\" : { \"dateAndTime\" : \"2017-11-20T08:14:26.612Z\" } }, \"primaryIdentifier\" : { \"sourceSystemIdentifier\" : \"Ignite\", \"sourceSystemTransactionIdentifier\" : \"703692\", \"version\" : \"1\" }, \"detail\" : { \"transactionHeader\" : { \"alternativeTransactionIdentifier\" : [{ \"sourceSystemIdentifier\" : \"Rosetta\", \"alternateTransactionIdentifier\" : \"50047351\", \"version\" : 0 }, { \"sourceSystemIdentifier\" : \"Bloomberg\", \"alternateTransactionIdentifier\" : \"911413\", \"version\" : 0 }, { \"sourceSystemIdentifier\" : \"MTS\", \"alternateTransactionIdentifier\" : \"400039\", \"version\" : 0, \"alternateTransactionIdentifierDescription\" : \"Venue Transaction Identifier\" }], \"transactionState\" : [{ \"RBSProcessName\" : \"Transaction Lifecycle\", \"transactionStateValue\" : \"New\" }], \"tradingParty\" : [{ \"tradingPartyIdentifier\" : [{ \"sourceSystemIdentifier\" : \"Bloomberg\", \"tradingPartyIdentifier\" : \"GEM-LONG\", \"tradingPartyIdentifierType\" : \"Book Code\" }], \"tradingPartyRole\" : [\"Trading\"], \"transactionEmployeeRole\" : [{ \"personIdentifier\" : \"FM\\\\MOHANMF\", \"personIdentifierType\" : \"Person Identifier\", \"sourceSystemIdentifier\" : \"ECD\", \"employeeRoleType\" : [\"Trader\"] }] }, { \"tradingPartyIdentifier\" : [{ \"sourceSystemIdentifier\" : \"Nucleus\", \"tradingPartyIdentifier\" : \"2030831\", \"tradingPartyIdentifierType\" : \"Nucleus Party Code\" }, { \"sourceSystemIdentifier\" : \"Bloomberg\", \"tradingPartyIdentifier\" : \"RBSMTN\", \"tradingPartyIdentifierType\" : \"Party Code\" }], \"tradingPartyRole\" : [\"Trading\", \"Counterparty\"] }], \"sourceBook\" : { \"sourceSystemIdentifier\" : \"Bloomberg\", \"sourceSystemBookIdentifier\" : \"GEM-LONG\" }, \"investmentDecisionAlgorithimId\" : { \"systemIdentifier\" : \"Algo\", \"tradingAlgorithmIdentifier\" : \"120220\" }, \"tradeExecutionAlgorithimId\" : { \"systemIdentifier\" : \"Algo\", \"tradingAlgorithmIdentifier\" : \"120220\" }, \"agreementDate\" : { \"date\" : \"2017-11-20\" }, \"agreementTime\" : { \"time\" : \"08:18:31.000\" }, \"bookingEntity\" : { \"tradingParty\" : { \"sourceSystemIdentifier\" : \"Bloomberg\", \"tradingPartyIdentifier\" : \"GEM-LONG\", \"tradingPartyIdentifierType\" : \"Book Code\" }, \"direction\" : \"Sell\" }, \"securitiesFinancingTransactionIndicator\" : false, \"settlementDate\" : \"2017-11-22\" }, \"instrumentTrade\" : { \"buyer\" : { \"sourceSystemIdentifier\" : \"Nucleus\", \"tradingPartyIdentifier\" : \"2030831\", \"tradingPartyIdentifierType\" : \"Nucleus Party Code\" }, \"seller\" : { \"sourceSystemIdentifier\" : \"Bloomberg\", \"tradingPartyIdentifier\" : \"GEM-LONG\", \"tradingPartyIdentifierType\" : \"Book Code\" }, \"accruedInterest\" : { \"monetaryAmount\" : 2119178.08, \"currency\" : \"EUR\" }, \"initialPrincipalAmount\" : { \"principalAmount\" : { \"monetaryAmount\" : 2.414400236E8, \"currency\" : \"EUR\" }, \"principalType\" : \"Principal\" }, \"instrumentIdentifier\" : [{ \"instrumentIdentifier\" : \"EH8565820\", \"instrumentIdentifierClassification\" : \"CUSIP\" }, { \"instrumentIdentifier\" : \"DE0001030526\", \"instrumentIdentifierClassification\" : \"ISIN\" }, { \"instrumentIdentifier\" : \"90956\", \"instrumentIdentifierClassification\" : \"Rdx Series Id\" }, { \"instrumentIdentifier\" : \"1Y6K-C0C4T-1\", \"instrumentIdentifierClassification\" : \"Rdx Id\" }, { \"instrumentIdentifier\" : \"B5ZXQF5\", \"instrumentIdentifierClassification\" : \"SEDOL\" }, { \"instrumentIdentifier\" : \"50159941\", \"instrumentIdentifierClassification\" : \"Helios\" }], \"quantity\" : { \"quantityAmount\" : 2.0E8, \"quantityUnitOfMeasure\" : \"Face Amount\" }, \"settlementAmount\" : { \"monetaryAmount\" : 2.4380136016E8, \"currency\" : \"EUR\" }, \"settlementCurrency\" : \"EUR\", \"shortSellingClassification\" : \"No short sale\", \"unitPrice\" : [{ \"percentagePrice\" : 108.34, \"priceQuoteBasis\" : \"Percentage\", \"priceCleanlinessType\" : \"Clean\" }, { \"yield\" : -0.01635256, \"priceQuoteBasis\" : \"Yield\" }] } } }";
        String data2 = "{ \"_schema\" : { \"_name\" : \"instrumentTransactionPut\", \"_semanticVersion\" : \"4.0.1\" }, \"notificationHeader\" : { \"publishingSystem\" : \"Ignite\", \"notificationId\" : \"90cd70cf-954c-403c-8e66-b7284dae4768\", \"businessDate\" : { \"date\" : \"2017-11-20\" }, \"createdDateTime\" : { \"dateAndTime\" : \"2017-11-20T08:14:26.612Z\" } }, \"primaryIdentifier\" : { \"sourceSystemIdentifier\" : \"Ignite\", \"sourceSystemTransactionIdentifier\" : \"703692\", \"version\" : \"1\" }, \"detail\" : { \"transactionHeader\" : { \"alternativeTransactionIdentifier\" : [{ \"sourceSystemIdentifier\" : \"Rosetta\", \"alternateTransactionIdentifier\" : \"50047351\", \"version\" : 0 }, { \"sourceSystemIdentifier\" : \"Bloomberg\", \"alternateTransactionIdentifier\" : \"911413\", \"version\" : 0 }, { \"sourceSystemIdentifier\" : \"MTS\", \"alternateTransactionIdentifier\" : \"400039\", \"version\" : 0, \"alternateTransactionIdentifierDescription\" : \"Venue Transaction Identifier\" }], \"transactionState\" : [{ \"RBSProcessName\" : \"Transaction Lifecycle\", \"transactionStateValue\" : \"New\" }], \"tradingParty\" : [{ \"tradingPartyIdentifier\" : [{ \"sourceSystemIdentifier\" : \"Bloomberg\", \"tradingPartyIdentifier\" : \"GEM-LONG\", \"tradingPartyIdentifierType\" : \"Book Code\" }], \"tradingPartyRole\" : [\"Trading\"], \"transactionEmployeeRole\" : [{ \"personIdentifier\" : \"FM\\\\MOHANMF\", \"personIdentifierType\" : \"Person Identifier\", \"sourceSystemIdentifier\" : \"ECD\", \"employeeRoleType\" : [\"Trader\"] }] }, { \"tradingPartyIdentifier\" : [{ \"sourceSystemIdentifier\" : \"Nucleus\", \"tradingPartyIdentifier\" : \"2030831\", \"tradingPartyIdentifierType\" : \"Nucleus Party Code\" }, { \"sourceSystemIdentifier\" : \"Bloomberg\", \"tradingPartyIdentifier\" : \"RBSMTN\", \"tradingPartyIdentifierType\" : \"Party Code\" }], \"tradingPartyRole\" : [\"Trading\", \"Counterparty\"] }], \"sourceBook\" : { \"sourceSystemIdentifier\" : \"Bloomberg\", \"sourceSystemBookIdentifier\" : \"GEM-LONG\" }, \"investmentDecisionAlgorithimId\" : { \"systemIdentifier\" : \"Algo\", \"tradingAlgorithmIdentifier\" : \"120220\" }, \"tradeExecutionAlgorithimId\" : { \"systemIdentifier\" : \"Algo\", \"tradingAlgorithmIdentifier\" : \"120220\" }, \"agreementDate\" : { \"date\" : \"2017-11-20\" }, \"agreementTime\" : { \"time\" : \"08:18:31.000\" }, \"bookingEntity\" : { \"tradingParty\" : { \"sourceSystemIdentifier\" : \"Bloomberg\", \"tradingPartyIdentifier\" : \"GEM-LONG\", \"tradingPartyIdentifierType\" : \"Book Code\" }, \"direction\" : \"Sell\" }, \"securitiesFinancingTransactionIndicator\" : false, \"settlementDate\" : \"2017-11-22\" }, \"instrumentTrade\" : { \"someNode\" : [{\"buyer\" : { \"sourceSystemIdentifier\" : \"xxx\", \"tradingPartyIdentifier\" : \"111\", \"tradingPartyIdentifierType\" : \"wtf\" }}, \n" +
                "              {\"buyer\" : { \"sourceSystemIdentifier\" : \"xxx2\", \"tradingPartyIdentifier\" : \"222\", \"tradingPartyIdentifierType\" : \"wtf\"}}], \"seller\" : { \"sourceSystemIdentifier\" : \"Bloomberg\", \"tradingPartyIdentifier\" : \"GEM-LONG\", \"tradingPartyIdentifierType\" : \"Book Code\" }, \"accruedInterest\" : { \"monetaryAmount\" : 2119178.08, \"currency\" : \"EUR\" }, \"initialPrincipalAmount\" : { \"principalAmount\" : { \"monetaryAmount\" : 2.414400236E8, \"currency\" : \"EUR\" }, \"principalType\" : \"Principal\" }, \"instrumentIdentifier\" : [{ \"instrumentIdentifier\" : \"EH8565820\", \"instrumentIdentifierClassification\" : \"CUSIP\" }, { \"instrumentIdentifier\" : \"DE0001030526\", \"instrumentIdentifierClassification\" : \"ISIN\" }, { \"instrumentIdentifier\" : \"90956\", \"instrumentIdentifierClassification\" : \"Rdx Series Id\" }, { \"instrumentIdentifier\" : \"1Y6K-C0C4T-1\", \"instrumentIdentifierClassification\" : \"Rdx Id\" }, { \"instrumentIdentifier\" : \"B5ZXQF5\", \"instrumentIdentifierClassification\" : \"SEDOL\" }, { \"instrumentIdentifier\" : \"50159941\", \"instrumentIdentifierClassification\" : \"Helios\" }], \"quantity\" : { \"quantityAmount\" : 2.0E8, \"quantityUnitOfMeasure\" : \"Face Amount\" }, \"settlementAmount\" : { \"monetaryAmount\" : 2.4380136016E8, \"currency\" : \"EUR\" }, \"settlementCurrency\" : \"EUR\", \"shortSellingClassification\" : \"No short sale\", \"unitPrice\" : [{ \"percentagePrice\" : 108.34, \"priceQuoteBasis\" : \"Percentage\", \"priceCleanlinessType\" : \"Clean\" }, { \"yield\" : -0.01635256, \"priceQuoteBasis\" : \"Yield\" }] } } }";
        String data3 = "{\n" +
                "  \"_schema\": {\n" +
                "    \"_name\": \"instrumentTransactionPut\",\n" +
                "    \"_semanticVersion\": \"4.0.1\"\n" +
                "  },\n" +
                "  \"notificationHeader\": {\n" +
                "    \"publishingSystem\": \"Ignite\",\n" +
                "    \"notificationId\": \"7661f6ce-fbc9-4f6e-aed3-27868170f192\",\n" +
                "    \"businessDate\": {\n" +
                "      \"date\": \"2017-09-28\",\n" +
                "      \"businessCentre\": \"USNY\"\n" +
                "    },\n" +
                "    \"createdDateTime\": {\n" +
                "      \"dateAndTime\": \"2017-10-24T12:06:23.265Z\"\n" +
                "    }\n" +
                "  },\n" +
                "  \"primaryIdentifier\": {\n" +
                "    \"sourceSystemIdentifier\": \"Ignite\",\n" +
                "    \"sourceSystemTransactionIdentifier\": \"666707\",\n" +
                "    \"version\": \"1\"\n" +
                "  },\n" +
                "  \"detail\": {\n" +
                "    \"transactionHeader\": {\n" +
                "      \"alternativeTransactionIdentifier\": [\n" +
                "        {\n" +
                "          \"sourceSystemIdentifier\": \"GTE Electronic Trade Link\",\n" +
                "          \"alternateTransactionIdentifier\": \"BTC-1ns1AwBYp1wwSZr\",\n" +
                "          \"version\": 0\n" +
                "        }\n" +
                "      ],\n" +
                "      \"transactionState\": [\n" +
                "        {\n" +
                "          \"RBSProcessName\": \"Transaction Lifecycle\",\n" +
                "          \"transactionStateValue\": \"New\",\n" +
                "          \"stateTransitionDateTime\": {\n" +
                "            \"dateAndTime\": \"2017-10-24T12:06:23.265Z\"\n" +
                "          }\n" +
                "        },\n" +
                "        {\n" +
                "          \"RBSProcessName\": \"Post Trade Transparency\",\n" +
                "          \"transactionStateValue\": \"Public Publication\",\n" +
                "          \"stateTransitionDateTime\": {\n" +
                "            \"dateAndTime\": \"2017-10-26T12:06:23.265Z\"\n" +
                "          }\n" +
                "        }\n" +
                "      ],\n" +
                "      \"tradingParty\": [\n" +
                "        {\n" +
                "          \"tradingPartyIdentifier\": [\n" +
                "            {\n" +
                "              \"sourceSystemIdentifier\": \"GTE\",\n" +
                "              \"tradingPartyIdentifier\": \"WBSTA\",\n" +
                "              \"tradingPartyIdentifierType\": \"Book Code\"\n" +
                "            }\n" +
                "          ],\n" +
                "          \"tradingPartyRole\": [\n" +
                "            \"Trading\"\n" +
                "          ]\n" +
                "        },\n" +
                "        {\n" +
                "          \"tradingPartyIdentifier\": [\n" +
                "            {\n" +
                "              \"sourceSystemIdentifier\": \"GTE\",\n" +
                "              \"tradingPartyIdentifier\": \"DD50800\",\n" +
                "              \"tradingPartyIdentifierType\": \"Party Code\"\n" +
                "            },\n" +
                "            {\n" +
                "              \"sourceSystemIdentifier\": \"ICE\",\n" +
                "              \"tradingPartyIdentifier\": \"ICAP ELEC BROK\",\n" +
                "              \"tradingPartyIdentifierType\": \"Party Code\"\n" +
                "            },\n" +
                "            {\n" +
                "              \"sourceSystemIdentifier\": \"Nucleus\",\n" +
                "              \"tradingPartyIdentifier\": \"2037136\",\n" +
                "              \"tradingPartyIdentifierType\": \"Nucleus Party Code\"\n" +
                "            }\n" +
                "          ],\n" +
                "          \"tradingPartyRole\": [\n" +
                "            \"Counterparty\",\n" +
                "            \"Trading\"\n" +
                "          ]\n" +
                "        },\n" +
                "        {\n" +
                "          \"tradingPartyIdentifier\": [\n" +
                "            {\n" +
                "              \"sourceSystemIdentifier\": \"Ignite\",\n" +
                "              \"tradingPartyIdentifier\": \"XXXX\",\n" +
                "              \"tradingPartyIdentifierType\": \"Operating Market Identifier Code\"\n" +
                "            }\n" +
                "          ],\n" +
                "          \"tradingPartyRole\": [\n" +
                "            \"Trade Execution Facility\"\n" +
                "          ]\n" +
                "        }\n" +
                "      ],\n" +
                "      \"sourceBook\": {\n" +
                "        \"sourceSystemIdentifier\": \"GTE\",\n" +
                "        \"sourceSystemBookIdentifier\": \"WBSTA\"\n" +
                "      },\n" +
                "      \"agreementDate\": {\n" +
                "        \"date\": \"2017-09-28\",\n" +
                "        \"businessCentre\": \"USNY\"\n" +
                "      },\n" +
                "      \"agreementTime\": {\n" +
                "        \"time\": \"12:06:23.265\",\n" +
                "        \"businessCentre\": \"USNY\"\n" +
                "      },\n" +
                "      \"bookingEntity\": {\n" +
                "        \"tradingParty\": {\n" +
                "          \"sourceSystemIdentifier\": \"GTE\",\n" +
                "          \"tradingPartyIdentifier\": \"WBSTA\",\n" +
                "          \"tradingPartyIdentifierType\": \"Book Code\"\n" +
                "        },\n" +
                "        \"direction\": \"Sell\"\n" +
                "      },\n" +
                "      \"securitiesFinancingTransactionIndicator\": false,\n" +
                "      \"settlementDate\": \"2017-09-29\",\n" +
                "      \"businessCentre\": \"USNY\"\n" +
                "    },\n" +
                "    \"instrumentTrade\": {\n" +
                "      \"buyer\": {\n" +
                "        \"sourceSystemIdentifier\": \"Nucleus\",\n" +
                "        \"tradingPartyIdentifier\": \"2037136\",\n" +
                "        \"tradingPartyIdentifierType\": \"Nucleus Party Code\"\n" +
                "      },\n" +
                "      \"seller\": {\n" +
                "        \"sourceSystemIdentifier\": \"GTE\",\n" +
                "        \"tradingPartyIdentifier\": \"WBSTA\",\n" +
                "        \"tradingPartyIdentifierType\": \"Book Code\"\n" +
                "      },\n" +
                "      \"instrumentIdentifier\": [\n" +
                "        {\n" +
                "          \"instrumentIdentifier\": \"912810RY6\",\n" +
                "          \"instrumentIdentifierClassification\": \"CUSIP\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"instrumentIdentifier\": \"US912810RY64\",\n" +
                "          \"instrumentIdentifierClassification\": \"ISIN\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"instrumentIdentifier\": \"192781\",\n" +
                "          \"instrumentIdentifierClassification\": \"Rdx Series Id\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"instrumentIdentifier\": \"44R1-C0C1W-2\",\n" +
                "          \"instrumentIdentifierClassification\": \"Rdx Id\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"instrumentIdentifier\": \"BF53YK6\",\n" +
                "          \"instrumentIdentifierClassification\": \"SEDOL\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"instrumentIdentifier\": \"51300122\",\n" +
                "          \"instrumentIdentifierClassification\": \"Helios\"\n" +
                "        }\n" +
                "      ],\n" +
                "      \"quantity\": {\n" +
                "        \"quantityAmount\": 1000000.0,\n" +
                "        \"quantityUnitOfMeasure\": \"Face Amount\"\n" +
                "      },\n" +
                "      \"settlementCurrency\": \"USD\",\n" +
                "      \"unitPrice\": [\n" +
                "        {\n" +
                "          \"percentagePrice\": 97.28125,\n" +
                "          \"priceQuoteBasis\": \"Percentage\",\n" +
                "          \"priceCleanlinessType\": \"Clean\"\n" +
                "        }\n" +
                "      ]\n" +
                "    }\n" +
                "  }\n" +
                "}";

        String data4 = "{\n" +
                "  \"_schema\": {\n" +
                "    \"_name\": \"instrumentTransactionPut\",\n" +
                "    \"_semanticVersion\": \"7.13.0\"\n" +
                "  },\n" +
                "  \"notificationHeader\": {\n" +
                "    \"publishingSystem\": \"Ignite\",\n" +
                "    \"notificationId\": \"a2955598-2e2d-41eb-9e4c-a01f6b84169c\",\n" +
                "    \"businessDate\": {\n" +
                "      \"date\": \"2018-10-17T01:00:00.000+01:00\",\n" +
                "      \"businessCentre\": \"GBLO\"\n" +
                "    },\n" +
                "    \"createdDateTime\": {\n" +
                "      \"dateAndTime\": \"2018-10-17T11:29:15.619+01:00\"\n" +
                "    }\n" +
                "  },\n" +
                "  \"primaryIdentifier\": {\n" +
                "    \"sourceSystemIdentifier\": \"Ignite\",\n" +
                "    \"sourceSystemTransactionIdentifier\": \"4177102\",\n" +
                "    \"version\": \"1\"\n" +
                "  },\n" +
                "  \"detail\": {\n" +
                "    \"transactionHeader\": {\n" +
                "      \"alternativeTransactionIdentifier\": [\n" +
                "        {\n" +
                "          \"sourceSystemIdentifier\": \"Rosetta\",\n" +
                "          \"alternateTransactionIdentifier\": \"29805337\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"sourceSystemIdentifier\": \"Bloomberg\",\n" +
                "          \"alternateTransactionIdentifier\": \"787121\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"sourceSystemIdentifier\": \"Ignite\",\n" +
                "          \"alternateTransactionIdentifier\": \"4177102\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"sourceSystemIdentifier\": \"GTE Electronic Trade Link\",\n" +
                "          \"alternateTransactionIdentifier\": \"IL1539772143351-094-2\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"sourceSystemIdentifier\": \"Centralised Pricing\",\n" +
                "          \"applicationSubcomponent\": {\n" +
                "            \"softwareComponentName\": \"FI-ETRADING\"\n" +
                "          },\n" +
                "          \"alternateTransactionIdentifier\": \"IL1539772143351-094-2\"\n" +
                "        }\n" +
                "      ],\n" +
                "      \"transactionState\": [\n" +
                "        {\n" +
                "          \"RBSProcessName\": \"Validation\",\n" +
                "          \"transactionStateValue\": \"Authorised\",\n" +
                "          \"stateTransitionDateTime\": {\n" +
                "            \"dateAndTime\": \"2018-10-17T11:29:15.664+01:00\"\n" +
                "          }\n" +
                "        },\n" +
                "        {\n" +
                "          \"RBSProcessName\": \"Transaction Lifecycle\",\n" +
                "          \"transactionStateValue\": \"New\"\n" +
                "        }\n" +
                "      ],\n" +
                "      \"tradingParty\": [\n" +
                "        {\n" +
                "          \"tradingPartyIdentifier\": [\n" +
                "            {\n" +
                "              \"sourceSystemIdentifier\": \"Ignite\",\n" +
                "              \"tradingPartyIdentifier\": \"NWMS\",\n" +
                "              \"tradingPartyIdentifierType\": \"Market Identifier Code\"\n" +
                "            }\n" +
                "          ],\n" +
                "          \"tradingPartyRole\": [\n" +
                "            \"Trade Execution Facility\"\n" +
                "          ]\n" +
                "        },\n" +
                "        {\n" +
                "          \"tradingPartyIdentifier\": [\n" +
                "            {\n" +
                "              \"sourceSystemIdentifier\": \"Bloomberg\",\n" +
                "              \"tradingPartyIdentifier\": \"ART-EUR1\",\n" +
                "              \"tradingPartyIdentifierType\": \"Book Code\"\n" +
                "            }\n" +
                "          ],\n" +
                "          \"tradingPartyRole\": [\n" +
                "            \"Trading\"\n" +
                "          ],\n" +
                "          \"transactionEmployeeRole\": [\n" +
                "            {\n" +
                "              \"personIdentifier\": \"FM\\\\MCNEEBR\",\n" +
                "              \"personIdentifierType\": \"Person Identifier\",\n" +
                "              \"sourceSystemIdentifier\": \"ECD\",\n" +
                "              \"employeeRoleType\": [\n" +
                "                \"Trade Executor\",\n" +
                "                \"Trader\",\n" +
                "                \"Investment Decision Maker\"\n" +
                "              ]\n" +
                "            }\n" +
                "          ]\n" +
                "        },\n" +
                "        {\n" +
                "          \"tradingPartyIdentifier\": [\n" +
                "            {\n" +
                "              \"sourceSystemIdentifier\": \"Bloomberg\",\n" +
                "              \"tradingPartyIdentifier\": \"ART-EUR2\",\n" +
                "              \"tradingPartyIdentifierType\": \"Book Code\"\n" +
                "            }\n" +
                "          ],\n" +
                "          \"tradingPartyRole\": [\n" +
                "            \"Trading\",\n" +
                "            \"Counterparty\"\n" +
                "          ]\n" +
                "        },\n" +
                "        {\n" +
                "          \"tradingPartyIdentifier\": [\n" +
                "            {\n" +
                "              \"sourceSystemIdentifier\": \"Ignite\",\n" +
                "              \"tradingPartyIdentifier\": \"SINT\",\n" +
                "              \"tradingPartyIdentifierType\": \"Market Identifier Code\"\n" +
                "            }\n" +
                "          ],\n" +
                "          \"tradingPartyRole\": [\n" +
                "            \"Trade Execution Facility\"\n" +
                "          ]\n" +
                "        }\n" +
                "      ],\n" +
                "      \"sourceBook\": {\n" +
                "        \"sourceSystemIdentifier\": \"Bloomberg\",\n" +
                "        \"sourceSystemBookIdentifier\": \"ART-EUR1\"\n" +
                "      },\n" +
                "      \"agreementDate\": {\n" +
                "        \"date\": \"2018-10-17T01:00:00.000+01:00\",\n" +
                "        \"businessCentre\": \"GBLO\"\n" +
                "      },\n" +
                "      \"agreementTime\": {\n" +
                "        \"time\": \"10:29:03.352\",\n" +
                "        \"businessCentre\": \"GBLO\"\n" +
                "      },\n" +
                "      \"bookingEntity\": {\n" +
                "        \"tradingParty\": {\n" +
                "          \"sourceSystemIdentifier\": \"Bloomberg\",\n" +
                "          \"tradingPartyIdentifier\": \"ART-EUR1\",\n" +
                "          \"tradingPartyIdentifierType\": \"Book Code\"\n" +
                "        },\n" +
                "        \"direction\": \"Sell\"\n" +
                "      },\n" +
                "      \"securitiesFinancingTransactionIndicator\": false,\n" +
                "      \"settlementDate\": \"2018-10-19T01:00:00.000+01:00\",\n" +
                "      \"businessCentre\": \"GBLO\"\n" +
                "    },\n" +
                "    \"instrumentTrade\": {\n" +
                "      \"buyer\": {\n" +
                "        \"sourceSystemIdentifier\": \"Bloomberg\",\n" +
                "        \"tradingPartyIdentifier\": \"ART-EUR2\",\n" +
                "        \"tradingPartyIdentifierType\": \"Book Code\"\n" +
                "      },\n" +
                "      \"seller\": {\n" +
                "        \"sourceSystemIdentifier\": \"Bloomberg\",\n" +
                "        \"tradingPartyIdentifier\": \"ART-EUR1\",\n" +
                "        \"tradingPartyIdentifierType\": \"Book Code\"\n" +
                "      },\n" +
                "      \"initialPrincipalAmount\": {\n" +
                "        \"principalAmount\": {\n" +
                "          \"monetaryAmount\": 13559.13,\n" +
                "          \"currency\": \"EUR\"\n" +
                "        },\n" +
                "        \"principalType\": \"Principal\"\n" +
                "      },\n" +
                "      \"instrumentIdentifier\": [\n" +
                "        {\n" +
                "          \"instrumentIdentifier\": \"2BXV-C0JRK-1\",\n" +
                "          \"instrumentIdentifierClassification\": \"Rdx Id\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"instrumentIdentifier\": \"50159501\",\n" +
                "          \"instrumentIdentifierClassification\": \"Helios\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"instrumentIdentifier\": \"108787\",\n" +
                "          \"instrumentIdentifierClassification\": \"Rdx Series Id\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"instrumentIdentifier\": \"B63Q9G5\",\n" +
                "          \"instrumentIdentifierClassification\": \"SEDOL\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"instrumentIdentifier\": \"IT0004634132\",\n" +
                "          \"instrumentIdentifierClassification\": \"ISIN\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"instrumentIdentifier\": \"EI3856339\",\n" +
                "          \"instrumentIdentifierClassification\": \"CUSIP\"\n" +
                "        }\n" +
                "      ],\n" +
                "      \"quantity\": {\n" +
                "        \"quantityAmount\": 13000.0,\n" +
                "        \"quantityUnitOfMeasure\": \"Face Amount\"\n" +
                "      },\n" +
                "      \"settlementAmount\": {\n" +
                "        \"monetaryAmount\": 13623.769999999999,\n" +
                "        \"currency\": \"EUR\"\n" +
                "      },\n" +
                "      \"settlementCurrency\": \"EUR\",\n" +
                "      \"shortSellingClassification\": \"Short sale with exemption\",\n" +
                "      \"unitPrice\": [\n" +
                "        {\n" +
                "          \"priceQuoteBasis\": \"Percentage\",\n" +
                "          \"percentagePrice\": 104.301,\n" +
                "          \"priceCleanlinessType\": \"Clean\"\n" +
                "        },\n" +
                "        {\n" +
                "          \"priceQuoteBasis\": \"Yield\",\n" +
                "          \"yield\": 0.01891947\n" +
                "        }\n" +
                "      ]\n" +
                "    }\n" +
                "  }\n" +
                "}";


        Map<String, Object> jsonMap;
                    ObjectMapper objectMapper = new ObjectMapper();
        try {
//           jsonMap = objectMapper.readValue(jsonObject,
//                    new TypeReference(){});

//            ObjectNode jsonObjectNode = (ObjectNode) new ObjectMapper().readTree(data3);
            JsonNode convertedJsonNode =  new ObjectMapper().readTree(data4);
            JSONDocumentTraverser rootNode = new JSONDocumentTraverser(convertedJsonNode);

            JsonNode trade = convertedJsonNode.at("/detail/instrumentTrade");
            JSONDocumentTraverser tradeJson = new JSONDocumentTraverser(trade);
            JSONDocumentTraverser unitprice = tradeJson.getNodeAt("/unitPrice");
            // "[?((@.priceCleanlinessType == 'Clean' && @.percentagePrice) || (!@.priceCleanlinessType && @.percentagePrice))]"
            JSONDocumentTraverser absPriceResultNodes = unitprice.getNodeUsingQuery("[?((@.priceCleanlinessType == 'Clean' && @.absolutePrice) || (!@.priceCleanlinessType && @.absolutePrice))]");
            Double absPrice = absPriceResultNodes.getDoubleAttributeFromArrayNode("0", "/percentagePrice");
            long ss1 = System.currentTimeMillis();
            JSONDocumentTraverser percentPriceResultNodes = unitprice.getNodeUsingQuery("[?((@.priceCleanlinessType == 'Clean' && @.percentagePrice) || (!@.priceCleanlinessType && @.percentagePrice))]");
            Double percentPrice = percentPriceResultNodes.getDoubleAttributeFromArrayNode("0", "/percentagePrice");
            long ee1 = System.currentTimeMillis();
            System.out.println("percent = " + percentPrice + " TOOK = " + (ee1-ss1));


            String txHdrStr = "{\"alternativeTransactionIdentifier\":[{\"sourceSystemIdentifier\":\"Rosetta\",\"alternateTransactionIdentifier\":\"29805337\"},{\"sourceSystemIdentifier\":\"Bloomberg\",\"alternateTransactionIdentifier\":\"787121\"},{\"sourceSystemIdentifier\":\"Ignite\",\"alternateTransactionIdentifier\":\"4177102\"},{\"sourceSystemIdentifier\":\"GTE Electronic Trade Link\",\"alternateTransactionIdentifier\":\"IL1539772143351-094-2\"},{\"sourceSystemIdentifier\":\"Centralised Pricing\",\"applicationSubcomponent\":{\"softwareComponentName\":\"FI-ETRADING\"},\"alternateTransactionIdentifier\":\"IL1539772143351-094-2\"}],\"transactionState\":[{\"RBSProcessName\":\"Validation\",\"transactionStateValue\":\"Authorised\",\"stateTransitionDateTime\":{\"dateAndTime\":\"2018-10-17T11:29:15.664+01:00\"}},{\"RBSProcessName\":\"Transaction Lifecycle\",\"transactionStateValue\":\"New\"}],\"tradingParty\":[{\"tradingPartyIdentifier\":[{\"sourceSystemIdentifier\":\"Ignite\",\"tradingPartyIdentifier\":\"NWMS\",\"tradingPartyIdentifierType\":\"Market Identifier Code\"}],\"tradingPartyRole\":[\"Trade Execution Facility\"]},{\"tradingPartyIdentifier\":[{\"sourceSystemIdentifier\":\"Bloomberg\",\"tradingPartyIdentifier\":\"ART-EUR1\",\"tradingPartyIdentifierType\":\"Book Code\"}],\"tradingPartyRole\":[\"Trading\"],\"transactionEmployeeRole\":[{\"personIdentifier\":\"FM\\\\MCNEEBR\",\"personIdentifierType\":\"Person Identifier\",\"sourceSystemIdentifier\":\"ECD\",\"employeeRoleType\":[\"Trade Executor\",\"Trader\",\"Investment Decision Maker\"]}]},{\"tradingPartyIdentifier\":[{\"sourceSystemIdentifier\":\"Bloomberg\",\"tradingPartyIdentifier\":\"ART-EUR2\",\"tradingPartyIdentifierType\":\"Book Code\"}],\"tradingPartyRole\":[\"Trading\",\"Counterparty\"]},{\"tradingPartyIdentifier\":[{\"sourceSystemIdentifier\":\"Ignite\",\"tradingPartyIdentifier\":\"SINT\",\"tradingPartyIdentifierType\":\"Market Identifier Code\"}],\"tradingPartyRole\":[\"Trade Execution Facility\"]}],\"sourceBook\":{\"sourceSystemIdentifier\":\"Bloomberg\",\"sourceSystemBookIdentifier\":\"ART-EUR1\"},\"agreementDate\":{\"date\":\"2018-10-17T01:00:00.000+01:00\",\"businessCentre\":\"GBLO\"},\"agreementTime\":{\"time\":\"10:29:03.352\",\"businessCentre\":\"GBLO\"},\"bookingEntity\":{\"tradingParty\":{\"sourceSystemIdentifier\":\"Bloomberg\",\"tradingPartyIdentifier\":\"ART-EUR1\",\"tradingPartyIdentifierType\":\"Book Code\"},\"direction\":\"Sell\"},\"securitiesFinancingTransactionIndicator\":false,\"settlementDate\":\"2018-10-19T01:00:00.000+01:00\",\"businessCentre\":\"GBLO\"}";
            JsonNode txHdrNodeStr = new ObjectMapper().readTree(txHdrStr);

            JsonNode tradingParties = txHdrNodeStr.at("/tradingParty"); // tradingParty
//            JsonNode books = convertedJsonNode.at("/store/book");


            String s = "[{\"tradingPartyIdentifier\":[{\"sourceSystemIdentifier\":\"Ignite\",\"tradingPartyIdentifier\":\"NWMS\",\"tradingPartyIdentifierType\":\"Market Identifier Code\"}],\"tradingPartyRole\":[\"Trade Execution Facility\"]},{\"tradingPartyIdentifier\":[{\"sourceSystemIdentifier\":\"Bloomberg\",\"tradingPartyIdentifier\":\"ART-EUR1\",\"tradingPartyIdentifierType\":\"Book Code\"}],\"tradingPartyRole\":[\"Trading\"],\"transactionEmployeeRole\":[{\"personIdentifier\":\"FM\\\\MCNEEBR\",\"personIdentifierType\":\"Person Identifier\",\"sourceSystemIdentifier\":\"ECD\",\"employeeRoleType\":[\"Trade Executor\",\"Trader\",\"Investment Decision Maker\"]}]},{\"tradingPartyIdentifier\":[{\"sourceSystemIdentifier\":\"Bloomberg\",\"tradingPartyIdentifier\":\"ART-EUR2\",\"tradingPartyIdentifierType\":\"Book Code\"}],\"tradingPartyRole\":[\"Trading\",\"Counterparty\"]},{\"tradingPartyIdentifier\":[{\"sourceSystemIdentifier\":\"Ignite\",\"tradingPartyIdentifier\":\"SINT\",\"tradingPartyIdentifierType\":\"Market Identifier Code\"}],\"tradingPartyRole\":[\"Trade Execution Facility\"]}]";
//            String s = tradingParties.toString();
//            String s = "[\n" +
//                    " {\"tpi\":[{\"ssi\":\"xxx\",\"tpi\":\"xxxxx\",\"tpiType\":\"Book Code\"}],\"tpr\":[\"tring\"]}\n" +
//                    ",{\"tpi\":[{\"ssi\":\"xxx\",\"tpi\":\"xxxx\",\"tpiType\":\"Party Code\"}\n" +
//                    ",{\"ssi\":\"xxx\",\"tpi\":\"xxx\",\"tpiType\":\"non PC\"}\n" +
//                    ",{\"ssi\":\"Xxxxx\",\"tpi\":\"1234567\",\"tpiType\":\"dfg\"}]\n" +
//                    ",\"tpr\":[\"Cp\",\"tring\"]}\n" +
//                    ",{\"tpi\":[{\"ssi\":\"aDummySystem\",\"tpi\":\"XXXX\",\"tpiType\":\"Some code value\"}]\n" +
//                    ",\"tpr\":[\"Some sort of something\"]}" +
//                    "]";


            final Configuration JACKSON_JSON_NODE_CONFIGURATION = Configuration
                    .builder()
                    .mappingProvider(new JacksonMappingProvider())
                    .jsonProvider(new JacksonJsonNodeJsonProvider())
                    .build();

            // JSONPATH
            // [*].tpi[*][?(@.tpiType =~ /Book Code.*?/i)]
            // [*].tradingPartyIdentifier[*][?(@.tradingPartyIdentifierType =~ /Book Code.*?/i)]
//            List<Map<String, Object>> queryNodes = JsonPath.parse(s).read("$[*].tpi[*][?(@.tpiType =~ /Book Code.*?/i)]");
//            JsonNode jsonNodeQry = JsonPath.using(JACKSON_JSON_NODE_CONFIGURATION).parse(s).read("$[*].tpi[*][?(@.tpiType =~ /Book Code.*?/i)]");


            // approx 2ms
            long s1 = System.nanoTime();
            ParseContext parseContext = JsonPath.using(JACKSON_JSON_NODE_CONFIGURATION);
            long e1 = System.nanoTime();
            System.out.println("JsonPath.using TIME: " + (e1-s1));

            // 76ms
            long s2 = System.nanoTime();
            String jsonStr = "[\n" +
                    "        {\n" +
                    "          \"pp\": 94.083,\n" +
                    "          \"pqb\": \"AAA\",\n" +
                    "          \"pct\": \"BBB\"\n" +
                    "        },\n" +
                    "        {\n" +
                    "          \"y\": 0.01757184,\n" +
                    "          \"pqb\": \"YYY\"\n" +
                    "        }\n" +
                    "      ]";
                    //unitprice.getJsonNode().toString();
            DocumentContext documentContext = parseContext.parse(unitprice.getJsonNode());
            long e2 = System.nanoTime();
            System.out.println("parseContext.parse TIME: " + (e2-s2));

            // 36ms
            long s3 = System.nanoTime();
            // [*].tradingPartyIdentifier[*][?(@.tradingPartyIdentifierType =~ /Book Code.*?/i)].sourceSystemIdentifier

            JsonNode jsonNodeQry = documentContext.read("[?((@.priceCleanlinessType == 'Clean' && @.percentagePrice) || (!@.priceCleanlinessType && @.yield))]");
                    //"[?((@.pqb ==  'AAA' && @.pp) || (!@.pqb== 'YYY' && @.y))]");
                    //"[?((@.priceQuoteBasis == 'priceCleanlinessType' && @.percentagePrice) || (!@.priceQuoteBasis == 'priceCleanlinessType' && @.yield))]");
            long e3 = System.nanoTime();
            System.out.println("documentContext.read TIME: " + (e3-s3));

//            JsonNode xxx = jsonNodeQry.at("/");
//            JsonNode zeroIndex = jsonNodeQry.get(0);
            // .read("$[?(@.tradingPartyIdentifierType =~ /Book Code.*?/i)]",
//                            .read("$.tradingParty..[?(@.tradingPartyIdentifierType =~ /Book Code.*?/i)]",

            JSONDocumentTraverser accrdIntNode = rootNode.getNodeAt("/detail/instrumentTrade/accruedInteres");
            JSONDocumentTraverser monetaryAmountNode = accrdIntNode.getNodeAt("/monetaryAmount");
            rootNode.getNodeDoubleValueAt("/detail/instrumentTrade/accruedInterest/monetaryAmount");
            Double missingValue  = rootNode.getNodeDoubleValueAt("/detail/instrumentTrade/accruedInterest/monetaryAmount");

//            System.out.println(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(convertedJsonNode));

           int x = 0;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
