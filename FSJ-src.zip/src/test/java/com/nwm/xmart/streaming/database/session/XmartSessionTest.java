package com.nwm.xmart.streaming.database.session;

import com.nwm.xmart.streaming.database.SqlServerConnectionDetails;
import com.nwm.xmart.streaming.database.dao.SqlServerDao;
import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.time.LocalDate;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.mockito.PowerMockito.whenNew;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ XmartSession.class, SqlServerDao.class, SqlServerConnectionDetails.class})
public class XmartSessionTest {

    SqlServerConnectionDetails connectionDetails = mock(SqlServerConnectionDetails.class);;

    SqlServerDao mockdao = mock(SqlServerDao.class);

    XmartSession requestedSession = new XmartSession("session_A" ,"handler_A");
    XmartSession openSession = requestedSession.setSessionId(100);

    private void setMocks() throws Exception {

        when(mockdao.readSession(any(XmartSession.class))).thenReturn(openSession);

        whenNew(SqlServerDao.class).withAnyArguments().thenReturn(mockdao);

        when(connectionDetails.getSessionRetryLimit()).thenReturn(2);
        when(connectionDetails.getSessionRetryPeriod()).thenReturn(100);
    }

    @BeforeAll
    public void setup() throws Exception {

    }

    @Test
    public void initialiseSession() throws Exception {
        setMocks();
        System.out.println(connectionDetails.getSessionRetryLimit());
        XmartSession initialisedSession = requestedSession.openSession(connectionDetails);
        assertEquals("session_A", initialisedSession.getSessionName());
        assertEquals("handler_A", initialisedSession.getPayloadHandlerName());
        assertEquals(100, initialisedSession.getSessionId());
        assertEquals(0, initialisedSession.getRowCount());
        assertTrue(initialisedSession.isOpenSession());
    }

    @Test
    public void setSessionId() throws Exception {
        XmartSession openedSession = requestedSession.setSessionId(100);
        assertEquals("test sessionName", "session_A", openedSession.getSessionName());
        assertEquals("test payloadHandlerName", "handler_A", openedSession.getPayloadHandlerName());
        assertEquals("test sessionId", 100, openedSession.getSessionId());
        assertEquals("test rowCount", 0, openedSession.getRowCount());
        assertTrue("test isOpenSession", openedSession.isOpenSession());
    }

    @Test
    public void setRowCount() throws Exception {
        XmartSession completeSession = requestedSession.setRowCount(10);
        assertEquals("session_A", completeSession.getSessionName());
        assertEquals("handler_A", completeSession.getPayloadHandlerName());
        assertEquals(0, completeSession.getSessionId());
        assertEquals(10, completeSession.getRowCount());
        assertTrue(!completeSession.isOpenSession());
    }

    @Test
    public void getInitialDateTime() throws Exception {
        assertEquals(LocalDate.now().getYear(), requestedSession.getInitialDateTime().getYear());
    }

}