package com.nwm.xmart.streaming.source.df.serialisation;

import com.nwm.xmart.sso.EncryptDecryptAES;
import com.nwm.xmart.streaming.util.DataFabricUtil;
import com.rbs.datafabric.agile.commons.lang.StartableException;
import com.rbs.datafabric.client.DataFabricClient;
import com.rbs.datafabric.client.DataFabricClientFactory;
import com.rbs.datafabric.domain.*;
import com.rbs.datafabric.domain.event.RecordModifiedEvent;
import com.rbs.datafabric.domain.event.WatchEventEnvelope;
import com.rbs.datafabric.protocol.Datafabric;
import com.rbs.datafabric.protocol.ProtocolMessageEncoder;
import com.rbs.datafabric.protocol.ProtocolMessageEncoderFactory;
import com.rbs.datafabric.protocol.exception.EncoderException;
import com.rbs.datafabric.shaded.com.google.protobuf.ByteString;
import com.nwm.xmart.streaming.monitor.InactiveKafkaMonitor;
import com.nwm.xmart.streaming.monitor.InactivityMonitor;
import com.nwm.xmart.streaming.monitor.InactivityStatus;
import com.nwm.xmart.streaming.monitor.PersistenceFile;
import com.nwm.xmart.streaming.source.df.event.DataFabricStreamEvent;
import com.rbs.odc.access.domain.TransactionId;
import com.rbs.odc.core.domain.ODCValue;
import com.rbs.odc.core.domain.TransactionImpl;
import com.rbs.odc.datafabric.OdcDataFabricRecordSerialiser;
import com.rbs.odc.datafabric.OdcTypeUtils;
import com.rbs.odc.datafabric.wrapper.DataFabricDocumentSerialiser;
import com.rbs.odc.datafabric.wrapper.DataFabricTypeReference;
import com.rbs.odc.datafabric.wrapper.DefaultDataFabricRecordSerialiser;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.util.serialization.KeyedDeserializationSchema;
import org.junit.*;

import java.io.FileInputStream;
import java.io.IOException;

/**
 * Created by gardlex on 18/11/2017.
 */
@Ignore
public class FlinkDeserialisationTest {

    private final String username = "svc-XMartAppUat";
    private final String password = "Gl6c8x+8lGbkwF0HWPDRSg== ";
    private final String host = "DATAFABRIC-TST";
    private final String accesstoken = "9k1IyB07YGjc1r5rQf1MgrdZH6XNdr1WT0UEWLz1XmVX7tupKZdtPA2t/iljneNe";
    private OdcDataFabricRecordSerialiser odcDataFabricRecordSerialiser;
    private Configuration configuration;
    private KeyedDeserializationSchema<DataFabricStreamEvent<ODCValue>> flinkDeserialiser;
    private DataFabricUtil dataFabricUtil;
    private DataFabricClient dataFabricClient;


    @Before
    public void dataFabricClientInfo() throws ClassNotFoundException {

        // Create Flink Configuration object
        getConfiguration();

        // Get ODC Serialise
        odcDataFabricRecordSerialiser = getODCDeserializer();

        // Get the FlinkDeserializer
        flinkDeserialiser = getFlinkDeserializationSchema();
    }

    private void getConfiguration() {
        configuration = new Configuration();
        configuration.setString("flink.job.name", "JobName");
        configuration.setString("operator.source.name","OperatorName");
        configuration.setString("flink.datafabric.deserialiser.type", "ODC");
        configuration.setString("flink.datafabric.error.deserialiser.type", "ODC");
        configuration.setString("datafabric.credentials.username", username);
        configuration.setString("datafabric.credentials.password", EncryptDecryptAES.decrypt(password));
//        configuration.setString("datafabric.credentials.password", password);
        configuration.setString("datafabric.credentials.host", host);
        configuration.setString("datafabric.credentials.accesstoken", EncryptDecryptAES.decrypt(accesstoken));
//        configuration.setString("datafabric.credentials.accesstoken", accesstoken);
        configuration.setInteger("error.event.operator.limit", 1);
        configuration.setString("flink.datafabric.client.odc.serialiser.idType.class", "com.rbs.odc.access.domain.TransactionId");
        configuration.setString("flink.datafabric.client.odc.serialiser.domainType.class", "com.rbs.odc.core.domain.TransactionImpl");
        configuration.setString("kafka.inactivity.monitor.interval.minOffsetDelta", "100");

    }

    @Test
    public void testODCValueDeserialisation() throws Exception {

        try {
            // File to serialize object to
            ODCValue odcValue = getOdcValue();

            // Serialise the odcValue
            Document document = odcDataFabricRecordSerialiser.serialise(odcValue);

            // Construct the WatchEventEnvelope
            WatchEventEnvelope watchEventEnvelope = getWatchEventEnvelope(document);

            // Get the raw byte[] that would be persisted to the Kafka Topic
            byte[] bytes = encodeWatchEventEnvelop(watchEventEnvelope);

            // Use FlinkDeserializer to extract the deserialized ODCValue object
            DataFabricStreamEvent<ODCValue> dataFabricStreamEvent = flinkDeserialiser.deserialize(null, bytes, "topic", 0, 123);
            ODCValue deserializedODCValue = dataFabricStreamEvent.getEventPayload();
            TransactionId txId = (TransactionId)deserializedODCValue.getId();
            TransactionImpl tx = (TransactionImpl)deserializedODCValue.getDomainObject();

            // Test the ODCValue is still in correct form
            Assert.assertEquals("SystemX", txId.getSourceSystemId().javaName());
            Assert.assertEquals("18171LN014741D", txId.getSourceSystemTransactionId());

            Assert.assertEquals("11392", tx.getSourceBookId().getSourceSystemBookId());
            Assert.assertEquals("SingleBarrierEuropeanOption", tx.getProductId().getAtomicProductIdentifier());

        }  finally {
            dataFabricClient.close();
        }
    }

    private KeyedDeserializationSchema<DataFabricStreamEvent<ODCValue>> getFlinkDeserializationSchema() {
        dataFabricUtil = new DataFabricUtil(configuration);

        final TypeInformation<DataFabricStreamEvent<ODCValue>> info = TypeInformation.of(new TypeHint<DataFabricStreamEvent<ODCValue>>(){});
        Class<DataFabricStreamEvent<ODCValue>> sourceClassRef = info.getTypeClass();

        InactivityMonitor inactivityMonitor = new InactiveKafkaMonitor(configuration, new PersistenceFile() {
            @Override
            public void persistOffsetInfo(InactivityStatus inactivityStatus, long currentKafkaOffset, long lastOffset, long currentTimestamp, long lastTimestamp, long lastOffsetChangeTimestamp) throws IOException {
                // do nothing
            }
        });

        // The deserializer itself
        return new FlinkDeserializer<DataFabricStreamEvent<ODCValue>, ODCValue, ODCValue>(
                dataFabricUtil,
                sourceClassRef,
                ODCValue.class,
                inactivityMonitor,
                configuration);
    }

    private byte[] encodeWatchEventEnvelop(WatchEventEnvelope watchEventEnvelope) throws EncoderException {
        ProtocolMessageEncoder encoder = ProtocolMessageEncoderFactory.create();
        Datafabric.Message message = encoder.encode(watchEventEnvelope);
        Datafabric.Message.ByteBufferFormat format = message.getByteBufferFormat();
        ByteString byteString = message.toByteString();// getByteBuffer();  //getDomainTypeNameBytes();
        return byteString.toByteArray();
    }

    private WatchEventEnvelope getWatchEventEnvelope(Document document) {
        RecordModifiedEvent rme = new RecordModifiedEvent();
        WatchEventEnvelope watchEventEnvelope = new WatchEventEnvelope();
        Record record = new Record();
        record.setId(new RecordId());
        Lifetime lifetime = new Lifetime();
        lifetime.setFrom(new Timestamp().withValue(System.currentTimeMillis()));
        lifetime.setTo(new Timestamp().withValue(System.currentTimeMillis()+1L));
        record.setLifetime(lifetime);
        record.setDocument(document);
        rme.setRecord(record);
        watchEventEnvelope.setRecordModifiedEvent(rme);
        return watchEventEnvelope;
    }

    private ODCValue getOdcValue() throws IOException {
        FileInputStream fis = new FileInputStream("src/test/resources/ODCTrade-3.11.4-12477809.ser"); //"C:\\DEV\\ODCValue-serialised\\testSerialization-75520613.ser");
        ODCValue odcValue = SerializationUtils.deserialize(fis);
        fis.close();
        return odcValue;
    }

    private DataFabricClient createDataFabricClient(String username, String password, String host, String accesstoken) {
        ClientConfiguration clientConfiguration = (new ClientConfiguration()). withCredentials((new Credentials()).withUsername(username).withPassword(password)).withHost(host).withAccessToken(accesstoken);
//withSimulatorClient(true);

        try {
            dataFabricClient = DataFabricClientFactory.createDataFabricClient(clientConfiguration);
        } catch (StartableException var9) {
            String msg = "Could not instantiate DataFabricClient";

            throw new RuntimeException(msg, var9);
        }
        return dataFabricClient;
    }

    private OdcDataFabricRecordSerialiser getODCDeserializer() throws ClassNotFoundException {
        Class idType = Class.forName("com.rbs.odc.access.domain.TransactionId");
        Class domainType = Class.forName("com.rbs.odc.core.domain.TransactionImpl");
        DataFabricTypeReference dataFabricTypeReference = OdcTypeUtils.odcValueType(idType, domainType);

        DataFabricClient dataFabricClient = this.createDataFabricClient(username, password, host, accesstoken);
        DataFabricDocumentSerialiser dataFabricDocumentSerialiser = new DataFabricDocumentSerialiser(dataFabricClient.getDataFabricSerializer());
        OdcDataFabricRecordSerialiser odcDataFabricRecordSerialiser = new OdcDataFabricRecordSerialiser(new DefaultDataFabricRecordSerialiser(dataFabricDocumentSerialiser));

        return odcDataFabricRecordSerialiser;
    }
}
