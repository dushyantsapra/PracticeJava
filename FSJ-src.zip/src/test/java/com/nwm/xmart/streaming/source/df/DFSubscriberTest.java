package com.nwm.xmart.streaming.source.df;

import com.nwm.xmart.streaming.source.df.event.DataFabricWatchEvent;
import com.nwm.xmart.streaming.source.df.exception.DFSourceException;
import com.nwm.xmart.util.MDCParameter;
import com.rbs.datafabric.domain.*;
import com.rbs.datafabric.domain.event.ContinuousQuerySnapshotStreamEvent;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.Mockito;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.when;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class DFSubscriberTest {

    private DFWatchSource mockedSource = Mockito.mock(DFWatchSource.class);
    private SourceFunction.SourceContext mockedSourceContext = Mockito.mock(SourceFunction.SourceContext.class);

    private WatchContext mockedWatchContext = Mockito.mock(WatchContext.class);
    private Subscription mockedSubscription = Mockito.mock(Subscription.class);
    private Observable.OnSubscribe mockedObservableOnSubscribe = Mockito.mock(Observable.OnSubscribe.class);
    private Observable observable = Observable.create(mockedObservableOnSubscribe);

    private MDCParameter mdcParameter = MDCParameter.of("jobName", "TEST_JOB");

    private DFSubscriber subscriber = null;

    @BeforeAll
    void setUp() throws Exception {

        when(mockedSourceContext.getCheckpointLock()).thenReturn(new String("TEST"));
        when(mockedWatchContext.getSubject()).thenReturn(observable);

        String sourceName = "TEST_SOURCE";
        subscriber = new DFSubscriber(mockedSource,
                                        mockedSourceContext,
                                        mockedWatchContext,
                                        sourceName,
                                        mdcParameter);

    }

    @Test
    void startSubscription() {
        subscriber.startSubscription();
        verify(mockedWatchContext, times(1)).getSubject();
    }

    @Test
    void onCompleted() {
        subscriber.onCompleted();
        verify(mockedSource, times(1)).cancel();
    }

    @Test
    void onError() {
        assertThrows(DFSourceException.class, () -> {
            subscriber.onError(new Exception("TEST_EXCEPTION"));
        });
        verify(mockedSource, times(2)).cancel();
    }

    @Test
    void onNext() {

        JsonDocument document = new JsonDocument();
        document.withContents("{\"firstName\": \"Steve\", \"lastName\": \"Smith\",\"isAlive\": true, \"address\": {\"address1\": \"1 A Road\", \"city\": \"London\"}}");

        RecordId id = Mockito.mock(RecordId.class);
        when(id.getKey()).thenReturn("key");
        when(id.getVersion()).thenReturn(100L);

        Record record = Mockito.mock(Record.class);
        when(record.getId()).thenReturn(id);
        when(record.getDocument()).thenReturn(document);

        ContinuousQuerySnapshotStreamEvent event = Mockito.mock(ContinuousQuerySnapshotStreamEvent.class);
        when(event.getOffset()).thenReturn(100L);
        when(event.getRecord()).thenReturn(record);
        when(event.getOffset()).thenReturn(100L);
        when(event.getDatabaseName()).thenReturn("DATABASE_NAME");
        when(event.getCollectionName()).thenReturn("COLLECTION_NAME");
        subscriber.onNext(event);

        verify(mockedSourceContext, times(1)).collect(any(DataFabricWatchEvent.class));
        verify(mockedSource, times(1)).incrementOffsetTracker(100L);

    }

    @Test
    void getSubscription() {

        Subscription subscription = subscriber.getSubscription();

        assertNotNull(subscription);

    }
}