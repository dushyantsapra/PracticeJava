package com.nwm.xmart.streaming.encryption;

import org.junit.Assert;
import org.junit.Test;
import com.nwm.xmart.sso.EncryptDecryptAES;

/**
 * Created by gardlex on 02/07/2018.
 */
public class EncryptDecryptAESTest {
    @Test
    public void testEncryption() {
        String strToEncrypt = "TheString!!!";
        String encryptedString = EncryptDecryptAES.encrypt(strToEncrypt);
        String decryptedString = EncryptDecryptAES.decrypt(encryptedString);
        Assert.assertEquals("Decryption of decrypyted password", strToEncrypt, decryptedString);
    }
}
