package com.nwm.xmart.streaming.source.mdx.identifier;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by gardlex on 17/05/2018.
 */
public class IsinExtractorTest {

    @Test
    public void testTimeSeriesISINExtract() {
        TimeSeriesIdentifierGenerator generator = new TimeSeriesIdentifierGenerator("/timeseries/esma/shared/mdx/");
        String isin = generator.extractISINFromIdentifier("timeseries/esma/shared/mdx/EZ11QVQMZ900/totv");

        Assert.assertEquals("EZ11QVQMZ900", isin);
    }

    @Test
    public void testSeriesViewISINExtract() {
        SeriesViewIdentifierGenerator generator = new SeriesViewIdentifierGenerator("saved/reference.regulatory.instrument/public/Credit/");
        String isin = generator.extractISINFromIdentifier("public/Credit/EZ8ZJ7DJ70C3");

        Assert.assertEquals("EZ8ZJ7DJ70C3", isin);
    }
}
