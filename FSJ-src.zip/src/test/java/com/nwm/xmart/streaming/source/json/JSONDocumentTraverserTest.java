package com.nwm.xmart.streaming.source.json;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Created by gardlex on 29/11/2018.
 */

public class JSONDocumentTraverserTest {

    private String jsonTDXIgniteBond;

    @Before
    public void setUpJSONData() throws FileNotFoundException, IOException {
        jsonTDXIgniteBond = new String(Files.readAllBytes(Paths.get("src/test/resources/InstrumentTradePut-TDX-Ignite-Bond-JSON-7-13-0.json")));
    }

    @Test
    public void testSingleTextNodeSelection() throws IOException {
        JSONDocumentTraverser jsonDocumentTraverser = new JSONDocumentTraverser(jsonTDXIgniteBond);
        Assert.assertEquals("USD",
                jsonDocumentTraverser.getNodeStringValueAt("/detail/instrumentTrade/settlementAmount/currency"));
    }

    @Test
    public void testSingleDoubleNodeSelection() throws IOException {
        JSONDocumentTraverser jsonDocumentTraverser = new JSONDocumentTraverser(jsonTDXIgniteBond);
        Assert.assertEquals(new Double(965334.58d),
                jsonDocumentTraverser.getNodeDoubleValueAt("/detail/instrumentTrade/settlementAmount/monetaryAmount"));
    }

    @Test
    public void testSingleIntegerNodeSelection() throws IOException {
        String dummyIntegerJson = "{ \"age\":30 }";

        JSONDocumentTraverser jsonDocumentTraverser = new JSONDocumentTraverser(dummyIntegerJson);
        Assert.assertEquals(new Integer(30),
                jsonDocumentTraverser.getNodeIntegerValueAt("/age"));
    }

    @Test
    public void testJSONQueryUsingJsonPath() throws IOException {
        JSONDocumentTraverser jsonTrade = new JSONDocumentTraverser(jsonTDXIgniteBond);
        JSONDocumentTraverser unitPriceNodes = jsonTrade.getNodeAt("/detail/instrumentTrade/unitPrice");

        JSONDocumentTraverser percentPriceResultNodes = unitPriceNodes.getNodeUsingQuery("[?((@.priceCleanlinessType == 'Clean' && @.percentagePrice) || (!@.priceCleanlinessType  == 'Clean' && @.yield))]");
        Double percentPrice = percentPriceResultNodes.getDoubleAttributeFromArrayNode("0", "/percentagePrice");
        Assert.assertEquals(Double.valueOf(96.19921875d), percentPrice);
    }
}
