package com.nwm.xmart.streaming.source.kdb.parameters;

import org.junit.Assert;
import org.junit.Test;

import java.util.List;

/**
 * Created by gardlex on 12/06/2018.
 */
public class DateParameterTest {

    @Test
    public void testIsSameDate() {
        Assert.assertEquals("valid data range", true, DateParameterUtil.isSameDate("2018.05.07", "2018.05.07"));
    }

    @Test
    public void testValidDateRangeEqual() {
        Assert.assertEquals("valid data range", true, DateParameterUtil.validateDateRange("2018.05.07", "2018.05.07"));
    }

    @Test
    public void testValidDateRangeAfter() {
        Assert.assertEquals("valid data range", true, DateParameterUtil.validateDateRange("2018.05.07", "2018.05.08"));
    }

    @Test
    public void testValidDateRangeBefore() {
        Assert.assertEquals("valid data range", false, DateParameterUtil.validateDateRange("2018.05.07", "2018.05.06"));
    }

    @Test
    public void testNoOfDatesSingleDay() {
        List<String> noOfDaysToLoad = DateParameterUtil.getDaysToLoad("2018.05.07", "2018.05.08");
        Assert.assertEquals("noOfDays invalid", 2, noOfDaysToLoad.size());
    }

    @Test
    public void testNoOfDatesMultipleDays() {
        List<String> noOfDaysToLoad = DateParameterUtil.getDaysToLoad("2018.05.31", "2018.06.02");
        Assert.assertEquals("noOfDays invalid", 3, noOfDaysToLoad.size());
    }

    @Test
    public void testNoOfDatesSameDay() {
        List<String> noOfDaysToLoad = DateParameterUtil.getDaysToLoad("2018.05.07", "2018.05.07");
        Assert.assertEquals("noOfDays invalid", 1, noOfDaysToLoad.size());
    }
}
