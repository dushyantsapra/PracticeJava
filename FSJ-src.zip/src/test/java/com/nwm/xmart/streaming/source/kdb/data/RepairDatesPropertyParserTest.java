package com.nwm.xmart.streaming.source.kdb.data;

import org.junit.Assert;
import org.junit.Test;

import java.util.List;

/**
 * Created by gardlex on 21/06/2018.
 */
public class RepairDatesPropertyParserTest {

    @Test
    public void testRepairDatesSorted() {
        List<String> dates = RepairDatesPropertyParser.getRepairDatesFrom("2018.11.01,2017.04.23,2019.04.17");
        Assert.assertTrue("First Date", dates.get(0).equals("2017.04.23"));
        Assert.assertTrue("First Date", dates.get(1).equals("2018.11.01"));
        Assert.assertTrue("First Date", dates.get(2).equals("2019.04.17"));
    }
}
