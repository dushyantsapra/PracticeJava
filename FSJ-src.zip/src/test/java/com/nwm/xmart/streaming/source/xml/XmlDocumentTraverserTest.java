package com.nwm.xmart.streaming.source.xml;

import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SuppressWarnings("ConstantConditions")
public class XmlDocumentTraverserTest {

    private XmlDocumentTraverser fullXmlTraverser;

    private XmlDocumentTraverser simpleXmlTraverser;

    @Before
    public void setUp() throws Exception {
        String xmlFragment = "<fxRates>\n"
                + "<fxRate>\n"
                + "<id>100</id>\n"
                + "<currency><base>AUD</base><quoted>USD</quoted></currency>\n"
                + "<product>SPOT</product>\n"
                + "<rate><tenor>SPOT</tenor><valueDate>2019-01-15</valueDate><lhs>0.72065</lhs><mid>0.72065</mid><rhs>0.72065</rhs></rate>\n"
                + "<publicationInformation><producedIn>Nyk</producedIn></publicationInformation>\n"
                + "</fxRate> \n"
                + "<fxRate>\n"
                + "<id>101</id>\n"
                + "<currency><base>AUD</base><quoted>USD</quoted></currency>\n"
                + "<product>SPOT</product>\n"
                + "<rate><tenor>SPOT</tenor><valueDate>2019-01-15</valueDate><lhs>0.72065</lhs><mid>0.72065</mid><rhs>0.72065</rhs></rate>\n"
                + "<publicationInformation><producedIn>Nyk</producedIn></publicationInformation>\n"
                + "</fxRate> \n"
                + "<fxRate>\n"
                + "<id>102</id>\n"
                + "<currency><base>AUD</base><quoted>USD</quoted></currency>\n"
                + "<product>SPOT</product>\n"
                + "<rate><tenor>SPOT</tenor><valueDate>2019-01-15</valueDate><lhs>0.72065</lhs><mid>0.72065</mid><rhs>0.72065</rhs></rate>\n"
                + "<publicationInformation><producedIn>Nyk</producedIn></publicationInformation>\n"
                + "</fxRate> \n"
                + "</fxRates> \n";

        fullXmlTraverser = new XmlDocumentTraverser(xmlFragment);

        xmlFragment = "<product attribute='test'>SPOT</product>\n"
                + "<integer attribute='101'>102</integer>\n"
                + "<double attribute='123.4567'>123.4567</double>\n"
                + "<date attribute='2019-01-01'>2018-12-31</date>\n"
                + "<invalidInteger attribute='101.1'>102x</invalidInteger>\n"
                + "<invalidDouble attribute='123.4567x'>123.4567x</invalidDouble>\n"
                + "<invalidDate attribute='2018-31-12'>2018-31-12</invalidDate>\n";

        simpleXmlTraverser = new XmlDocumentTraverser(xmlFragment);

    }

    @Test
    public void getNodeName() throws Exception {
        assertEquals("root", fullXmlTraverser.getNodeName());
    }

    @Test
    public void getNumberOfChildren() throws Exception {
        assertEquals(1, fullXmlTraverser.getNumberOfChildren());
        assertEquals(3, fullXmlTraverser.getObjectNode("fxRates").getNumberOfChildren());
    }

    @Test
    public void getSingleNode() throws Exception {

        assertEquals("fxRates", fullXmlTraverser.getObjectNode("fxRates").getNodeName());

        assertNull(fullXmlTraverser.getObjectNode("fxRate"));

        assertThrows(XmlFormatException.class,
                ()-> fullXmlTraverser.getObjectNode("fxRates").getObjectNode("fxRate"));
    }

    @Test
    public void objectToString() throws Exception {
        assertEquals("product:SPOT", simpleXmlTraverser.getObjectNode("product").toString());
    }


    @Test
    public void getMultipleNodes() throws Exception {

        List<XmlDocumentTraverser> list = fullXmlTraverser.getListOfNodes("fxRates");
        assertEquals(1, list.size());
        assertEquals("fxRates", list.get(0).getNodeName());

        list = fullXmlTraverser.getObjectNode("fxRates").getListOfNodes("fxRate");
        assertEquals(3, list.size());
        assertEquals("fxRate", list.get(0).getNodeName());

        list = fullXmlTraverser.getListOfNodes("nodeNotThere");
        assertEquals(0, list.size());

    }

    @Test
    public void getValue() throws Exception {
        assertEquals("SPOT", simpleXmlTraverser.getTextValueNode("product"));
    }

    @Test
    public void getAttributeValue() throws Exception {
        assertEquals("test", simpleXmlTraverser.getObjectNode("product").getAttributeValue("attribute"));
    }

    @Test
    public void getDoubleAttributeValue() throws Exception {
        assertEquals((Object)123.4567D, simpleXmlTraverser.getObjectNode("double").getDoubleAttributeValue("attribute"));

        assertThrows(XmlFormatException.class,
                ()-> simpleXmlTraverser.getObjectNode("invalidDouble").getDoubleAttributeValue("attribute"));
    }

    @Test
    public void getIntegerAttributeValue() throws Exception {
        assertEquals((Object)101, simpleXmlTraverser.getObjectNode("integer").getIntegerAttributeValue("attribute"));

        assertThrows(XmlFormatException.class,
                ()-> simpleXmlTraverser.getObjectNode("invalidInteger").getIntegerAttributeValue("attribute"));
    }

    @Test
    public void getDateAttributeValue() throws Exception {
        assertEquals(LocalDate.of(2019, 1, 1),
                simpleXmlTraverser.getObjectNode("date").getDateAttributeValue("attribute"));

        assertThrows(XmlFormatException.class,
                ()-> simpleXmlTraverser.getObjectNode("invalidDate").getDateAttributeValue("attribute"));
    }

    @Test
    public void getDoubleValue() throws Exception {
        assertEquals((Object)123.4567D, simpleXmlTraverser.getDoubleValueNode("double"));

        assertThrows(XmlFormatException.class,
                ()-> simpleXmlTraverser.getDoubleValueNode("invalidDouble"));
    }

    @Test
    public void getIntegerValue() throws Exception {
        assertEquals((Object)102, simpleXmlTraverser.getIntegerValueNode("integer"));

        assertThrows(XmlFormatException.class,
                ()-> simpleXmlTraverser.getIntegerValueNode("invalidInteger"));
    }

    @Test
    public void getDateValue() throws Exception {
        assertEquals(LocalDate.of(2018, 12, 31),
                simpleXmlTraverser.getDateValueNode("date"));

        assertThrows(XmlFormatException.class,
                ()-> simpleXmlTraverser.getDateValueNode("invalidDate"));
    }
}