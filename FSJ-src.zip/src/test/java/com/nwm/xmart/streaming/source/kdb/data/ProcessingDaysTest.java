package com.nwm.xmart.streaming.source.kdb.data;

import com.nwm.xmart.streaming.database.exceptions.XmartSqlServerException;
import com.nwm.xmart.streaming.source.kdb.parameters.DateParameterUtil;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by gardlex on 22/06/2018.
 */
public class ProcessingDaysTest {

    @Test
    public void testFunctionParameters() throws XmartSqlServerException {
        Configuration config = new Configuration();
        config.setString("kdb.mode", "range");
        
        ParameterTool params = ParameterTool.fromMap(config.toMap());
        Map<String,String> functionParams = new HashMap<>();
        functionParams.put("startDate", "2018.06.20");
        functionParams.put("endDate", "2018.06.22");

        ProcessingDays processingDays = DateParameterUtil.getProcessingDays(params, functionParams);
        Assert.assertTrue("KDB processing type", processingDays.getKdbProcessingMode().equals(KDBProcessingMode.SPECIFIED_DATE_RANGE));
        Assert.assertTrue("no of days", processingDays.getDaysToLoad().size() == 3);
        List<String> daysToLoad = processingDays.getDaysToLoad();
        Assert.assertTrue("day1", daysToLoad.get(0).equals("2018.06.20"));
        Assert.assertTrue("day2", daysToLoad.get(1).equals("2018.06.21"));
        Assert.assertTrue("day3", daysToLoad.get(2).equals("2018.06.22"));
    }

    @Test
    public void testRepairDate() throws XmartSqlServerException {
        Configuration config = new Configuration();
        config.setString("kdb.mode", "repair");
        config.setString("kdb.repair.dates", "2018.06.20,2018.06.07,2018.06.01");
        ParameterTool params = ParameterTool.fromMap(config.toMap());

        // These should be ignored
        Map<String,String> functionParams = new HashMap<>();
        functionParams.put("startDate", "2018.06.20");
        functionParams.put("endDate", "2018.06.22");

        ProcessingDays processingDays = DateParameterUtil.getProcessingDays(params, functionParams);
        Assert.assertEquals("KDB processing type", KDBProcessingMode.REPAIR_DATE_RANGE, processingDays.getKdbProcessingMode());
        Assert.assertEquals("no of days", 3, processingDays.getDaysToLoad().size());
        List<String> daysToLoad = processingDays.getDaysToLoad();
        Assert.assertTrue("day1", daysToLoad.get(0).equals("2018.06.01"));
        Assert.assertTrue("day2", daysToLoad.get(1).equals("2018.06.07"));
        Assert.assertTrue("day3", daysToLoad.get(2).equals("2018.06.20"));
    }

    @Test
    public void testDefaultDate() throws XmartSqlServerException {
        // These should be ignored
        Configuration config = new Configuration();
        config.setString("kdb.mode", "single");

        ParameterTool params = ParameterTool.fromMap(config.toMap());

        Map<String,String> functionParams = new HashMap<>();
        functionParams.put("startDate", "OPERATIONAL_DEFAULT_DATE_RANGE");
        functionParams.put("endDate", "OPERATIONAL_DEFAULT_DATE_RANGE");

        ProcessingDays processingDays = DateParameterUtil.getProcessingDays(params, functionParams);
        Assert.assertEquals("The KDB processing type", KDBProcessingMode.OPERATIONAL_DEFAULT_DATE_RANGE, processingDays.getKdbProcessingMode());

        DayOfWeek dayOfWeek = LocalDate.now().getDayOfWeek();

        switch (dayOfWeek) {
            case MONDAY:
                Assert.assertEquals("no of days", 3, processingDays.getDaysToLoad().size());
                List<String> daysToLoad = processingDays.getDaysToLoad();
                Assert.assertEquals("Day1 = Friday", DayOfWeek.FRIDAY, (DateParameterUtil.getLocalDateFor(daysToLoad.get(0))).getDayOfWeek() );
                Assert.assertEquals("Day2 = Saturday", DayOfWeek.SATURDAY, (DateParameterUtil.getLocalDateFor(daysToLoad.get(1))).getDayOfWeek());
                Assert.assertEquals("Day3 = Sunday", DayOfWeek.SUNDAY, (DateParameterUtil.getLocalDateFor(daysToLoad.get(2))).getDayOfWeek());
                break;
            case TUESDAY:
            case WEDNESDAY:
            case THURSDAY:
            case FRIDAY:
                Assert.assertEquals("no of days", 1, processingDays.getDaysToLoad().size());
                List<String> daysToLoadOther = processingDays.getDaysToLoad();
                Assert.assertEquals("Day1 = Friday", dayOfWeek.minus(1), (DateParameterUtil.getLocalDateFor(daysToLoadOther.get(0))).getDayOfWeek() );
                break;
            default:
        }



    }

}
