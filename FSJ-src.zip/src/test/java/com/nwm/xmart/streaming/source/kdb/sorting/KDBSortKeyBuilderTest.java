package com.nwm.xmart.streaming.source.kdb.sorting;

import com.nwm.xmart.streaming.source.kdb.exception.KDBMatrixDataParsingException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import static org.junit.Assert.*;

/**
 * Testing of KDBSortKeyBuilder - introduced when moving from index based to name based sorting
 */
public class KDBSortKeyBuilderTest {

    @Rule
    public ExpectedException thrown= ExpectedException.none();

    private KDBSortKeyBuilder keyBuilder = null;

    @Before
    public void setUp() throws Exception {

        String property = "FI_MIFID_RFQ|date|time,FI_MIFID_QEC|date|requestTime,FX_MIFID_OMS|date|time|thirdDimension,FX_MIFID_RFQ|date,FX_MIFID_TRADE|date|timeMissing";

        keyBuilder = new KDBSortKeyBuilder(property);

    }

    @Test
    public void invalidKdbType(){

        thrown.expect(IllegalArgumentException.class);
        thrown.expectMessage("No enum constant com.nwm.xmart.streaming.source.kdb.sorting.KDBFunctionType.FX_XX");

        String property = "FI_MIFID_RFQ|date|time,FI_MIFID_QEC|date|time,FX_XX|date|time";

        new KDBSortKeyBuilder(property);

    }

    @Test
    public void createSortKeyForTypeFiMifidRfq(){

        // Valid config: FI_MIFID_RFQ|date|time

        String[] colNames = {"date","time","test1","test2"};

        SortKeyI sortKey = keyBuilder.createSortKeyForType(KDBFunctionType.FI_MIFID_RFQ, colNames);

        int[] actualKeyIndexes = sortKey.getColumnSortKeyIndexes();

        int[] expectedKeyIndexes = {0,1};

        assertArrayEquals(expectedKeyIndexes,actualKeyIndexes);

    }

    @Test
    public void createSortKeyForTypeFiMifidQec(){

        // Valid config: FI_MIFID_QEC|date|requestTime

        String[] colNames = {"date","time","test1","requestTime"};

        SortKeyI sortKey = keyBuilder.createSortKeyForType(KDBFunctionType.FI_MIFID_QEC, colNames);

        int[] actualKeyIndexes = sortKey.getColumnSortKeyIndexes();

        int[] expectedKeyIndexes = {0,3};

        assertArrayEquals(expectedKeyIndexes,actualKeyIndexes);

    }

    @Test
    public void createSortKeyForTypeFxMifidOms(){

        // Valid config (three columns): FX_MIFID_OMS|date|time|thirdDimension

        String[] colNames = {"date","time","test1","requestTime","thirdDimension"};

        SortKeyI sortKey = keyBuilder.createSortKeyForType(KDBFunctionType.FX_MIFID_OMS, colNames);

        int[] actualKeyIndexes = sortKey.getColumnSortKeyIndexes();

        int[] expectedKeyIndexes = {0,1,4};

        assertArrayEquals(expectedKeyIndexes,actualKeyIndexes);

    }

    @Test
    public void createSortKeyForTypeFxMifidRfq(){

        // Invalid config (only one column): FX_MIFID_RFQ|date

        String[] colNames = {"date","time","test1","test2"};

        SortKeyI sortKey = keyBuilder.createSortKeyForType(KDBFunctionType.FX_MIFID_RFQ, colNames);

        int[] actualKeyIndexes = sortKey.getColumnSortKeyIndexes();

        int[] expectedKeyIndexes = {0};

        assertArrayEquals(expectedKeyIndexes,actualKeyIndexes);

    }

    @Test
    public void invalidSortKeyForTypeFxMifidTrade(){

        // Invalid config (column not present): FX_MIFID_TRADE|date|timeMissing

        thrown.expect(KDBMatrixDataParsingException.class);
        thrown.expectMessage("Key column used for sorting not found: timeMissing");

        String[] colNames = {"date","time","test1","test2"};

        keyBuilder.createSortKeyForType(KDBFunctionType.FX_MIFID_TRADE, colNames);

    }
}