package com.nwm.xmart.streaming.source.kdb;

import com.nwm.xmart.streaming.source.kdb.data.KDBDataTransformer;
import com.nwm.xmart.streaming.source.kdb.data.KDBProcessingMode;
import com.nwm.xmart.streaming.source.kdb.data.ProcessingDays;
import com.nwm.xmart.streaming.source.kdb.parameters.BdxKdbFunctionDetails;
import com.nwm.xmart.streaming.source.kdb.session.BdxKdbFunctionContext;
import com.nwm.xmart.streaming.source.kdb.session.KDBSession;
import com.nwm.xmart.streaming.source.kdb.sorting.KDBFunctionType;
import com.nwm.xmart.streaming.source.mdx.session.MDXSessionType;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Created by gardlex on 08/08/2018.
 */
public class KDBFunctionSelectorTest {

    @Test
    public void testFunctionRotation() {

        BdxKdbFunctionDetails fiMifidRfqDetails = getFiRqfFunctionDetails();
        BdxKdbFunctionDetails fiMifidQECDetails = getFiQECFunctionDetails();
        BdxKdbFunctionDetails fxMifidRFQDetails = getFXRFQFunctionDetails();

        List<BdxKdbFunctionDetails> functionDetailsList = new ArrayList<>();
        functionDetailsList.add(fiMifidRfqDetails);
        functionDetailsList.add(fiMifidQECDetails);
        functionDetailsList.add(fxMifidRFQDetails);

        ConcurrentMap<String, BdxKdbFunctionContext> functionContextMap = new ConcurrentHashMap<>();

        BdxKdbFunctionContext kdbFunctionContext = new BdxKdbFunctionContext();
        functionContextMap.put("FI-RFQ-sourceName", getFiRqfFunctionContext());
        functionContextMap.put("FI-QEC-sourceName", getFiQECFunctionContext());
        functionContextMap.put("FX-RFQ-sourceName", getFxRqfFunctionContext());

        KDBFunctionSelector selector = new KDBFunctionSelector(functionDetailsList, functionContextMap);

        // Test rotation of the circular linked list first
        Assert.assertEquals("dayAvailable", true, selector.isFunctionProcessingDayAvailable());
        Assert.assertEquals("nextFunction", "FI-RFQ-sourceName", selector.getNextFunctionToProcess());
        Assert.assertEquals("nextFunction", "FI-QEC-sourceName", selector.getNextFunctionToProcess());
        Assert.assertEquals("nextFunction", "FX-RFQ-sourceName", selector.getNextFunctionToProcess());

        // Test Processing Days Rotation
        Assert.assertEquals("dayAvailable", true, selector.isFunctionProcessingDayAvailable());
        String nextFunction = selector.getNextFunctionToProcess();
        Assert.assertEquals("nextFunction", "FI-RFQ-sourceName", nextFunction);
        Assert.assertEquals("nextProcessingDay", "2018.05.07", selector.getNextProcessingDayForFunction(nextFunction));

        Assert.assertEquals("dayAvailable", true, selector.isFunctionProcessingDayAvailable());
        nextFunction = selector.getNextFunctionToProcess();
        Assert.assertEquals("nextFunction", "FI-QEC-sourceName", nextFunction);
        Assert.assertEquals("nextProcessingDay", "2018.08.07", selector.getNextProcessingDayForFunction(nextFunction));

        Assert.assertEquals("dayAvailable", true, selector.isFunctionProcessingDayAvailable());
        nextFunction = selector.getNextFunctionToProcess();
        Assert.assertEquals("nextFunction", "FX-RFQ-sourceName", nextFunction);
        Assert.assertEquals("nextProcessingDay", "2018.06.07", selector.getNextProcessingDayForFunction(nextFunction));

        Assert.assertEquals("dayAvailable", true, selector.isFunctionProcessingDayAvailable());
        nextFunction = selector.getNextFunctionToProcess();
        Assert.assertEquals("nextFunction", "FI-RFQ-sourceName", nextFunction);
        Assert.assertEquals("nextProcessingDay", "2018.05.08", selector.getNextProcessingDayForFunction(nextFunction));

        Assert.assertEquals("dayAvailable", true, selector.isFunctionProcessingDayAvailable());
        nextFunction = selector.getNextFunctionToProcess();
        Assert.assertEquals("nextFunction", "FX-RFQ-sourceName", nextFunction);
        Assert.assertEquals("nextProcessingDay", "2018.06.08", selector.getNextProcessingDayForFunction(nextFunction));

        Assert.assertEquals("dayAvailable", true, selector.isFunctionProcessingDayAvailable());
        nextFunction = selector.getNextFunctionToProcess();
        Assert.assertEquals("nextFunction", "FI-RFQ-sourceName", nextFunction);
        Assert.assertEquals("nextProcessingDay", "2018.05.09", selector.getNextProcessingDayForFunction(nextFunction));

        Assert.assertEquals("dayAvailable", false, selector.isFunctionProcessingDayAvailable());
    }

    private BdxKdbFunctionDetails getFiRqfFunctionDetails() {
        ConcurrentMap<String,String> functionParameters = new ConcurrentHashMap<>();
        functionParameters.put("startDate","2018.05.07");
        functionParameters.put("endDate","2018.05.09");

        return new BdxKdbFunctionDetails(
                "FI-RFQ-sourceID",
                "FI-RFQ-kdbFunctionName",
                "FI-RFQ-sourceName",
                KDBFunctionType.FI_MIFID_RFQ,
                MDXSessionType.SSO,
                functionParameters,
                "MdxUat",
                "fi.prl",
                "");
    }

    private BdxKdbFunctionContext getFiRqfFunctionContext() {
        BdxKdbFunctionContext ctx = new BdxKdbFunctionContext();

        List<String> daysToLoad = new ArrayList<>();
        daysToLoad.add("2018.05.07");
        daysToLoad.add("2018.05.08");
        daysToLoad.add("2018.05.09");

        ctx.setKdbSession(null);
        ctx.setProcessingDays(new ProcessingDays(daysToLoad, KDBProcessingMode.OPERATIONAL_DEFAULT_DATE_RANGE));
        ctx.setKdbDataTransformer(null);
        ctx.setSourceID("FI-RFQ-sourceID");
        ctx.setSourceName("FI-RFQ-sourceName");
        ctx.setFunctionName("FI-RFQ-kdbFunctionName");

        return ctx;
    }

    private BdxKdbFunctionDetails getFiQECFunctionDetails() {
        ConcurrentMap<String,String> functionParameters = new ConcurrentHashMap<>();
        functionParameters.put("startDate","2018.08.07");
        functionParameters.put("endDate","2018.08.07");

        return new BdxKdbFunctionDetails(
                "FI-QEC-sourceID",
                "FI-QEC-kdbFunctionName",
                "FI-QEC-sourceName",
                KDBFunctionType.FI_MIFID_QEC,
                MDXSessionType.SSO,
                functionParameters,
                "MdxUat",
                "fi.prl",
                "");
    }

    private BdxKdbFunctionContext getFiQECFunctionContext() {
        BdxKdbFunctionContext ctx = new BdxKdbFunctionContext();

        List<String> daysToLoad = new ArrayList<>();
        daysToLoad.add("2018.08.07");

        ctx.setKdbSession(null);
        ctx.setProcessingDays(new ProcessingDays(daysToLoad, KDBProcessingMode.OPERATIONAL_DEFAULT_DATE_RANGE));
        ctx.setKdbDataTransformer(null);
        ctx.setSourceID("FI-QEC-sourceID");
        ctx.setSourceName("FI-QEC-sourceName");
        ctx.setFunctionName("FI-QEC-kdbFunctionName");

        return ctx;
    }

    private BdxKdbFunctionDetails getFXRFQFunctionDetails() {
        ConcurrentMap<String,String> functionParameters = new ConcurrentHashMap<>();
        functionParameters.put("startDate","2018.06.07");
        functionParameters.put("endDate","2018.06.08");

        return new BdxKdbFunctionDetails(
                "FX-RFQ-sourceID",
                "FX-RFQ-kdbFunctionName",
                "FX-RFQ-sourceName",
                KDBFunctionType.FX_MIFID_RFQ,
                MDXSessionType.SSO,
                functionParameters,
                "MdxUat",
                "fx.prl",
                "");
    }

    private BdxKdbFunctionContext getFxRqfFunctionContext() {
        BdxKdbFunctionContext ctx = new BdxKdbFunctionContext();

        List<String> daysToLoad = new ArrayList<>();
        daysToLoad.add("2018.06.07");
        daysToLoad.add("2018.06.08");

        ctx.setKdbSession(null);
        ctx.setProcessingDays(new ProcessingDays(daysToLoad, KDBProcessingMode.OPERATIONAL_DEFAULT_DATE_RANGE));
        ctx.setKdbDataTransformer(null);
        ctx.setSourceID("FX-RFQ-sourceID");
        ctx.setSourceName("FX-RFQ-sourceName");
        ctx.setFunctionName("FX-RFQ-kdbFunctionName");

        return ctx;
    }
}
