package com.nwm.xmart.streaming.source.df;

import com.nwm.xmart.streaming.util.DataFabricUtil;
import com.nwm.xmart.util.MDCParameter;
import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@RunWith(PowerMockRunner.class)
@PrepareForTest(DFWatchSource.class)
class DFWatchSourceTest {

    private SourceFunction.SourceContext mockedSourceContext = mock(SourceFunction.SourceContext.class);

    private DFWatchSource source = null;
    private DFWatchSource spySource = null;

    @BeforeAll
    void setUp() {

        DFWatchSourceConnectionDetails connectionDetails = new DFWatchSourceConnectionDetails("123456780", "900", "TEST_SOURCE", "TEST_CONSUMER_GROUP_ID", true, 100L);
        Configuration configuration = mock(Configuration.class);
        when(configuration.getString("flink.datafabric.deserialiser.type", "")).thenReturn("DATAFABRIC");
        when(configuration.getString("datafabric.credentials.username", "")).thenReturn("TEST");
        when(configuration.getString("datafabric.credentials.password", "")).thenReturn("DATAFABRIC");
        when(configuration.getString("datafabric.credentials.host", "")).thenReturn("DATAFABRIC");
        when(configuration.getString("datafabric.credentials.accesstoken", "")).thenReturn("DATAFABRIC");

        DataFabricUtil dataFabricUtil = mock(DataFabricUtil.class);


        DFSubscriber subscriber = mock(DFSubscriber.class);

        try {
            whenNew(DFSubscriber.class).withAnyArguments().thenReturn(subscriber);
        } catch (Exception e) {
            throw new RuntimeException("Error in mocking constructor", e);
        }

        try {
            source = new DFWatchSource(connectionDetails, dataFabricUtil);
        } catch(Exception e){
            throw new RuntimeException("Error constructing DFWatchSource", e);
        }

        spySource = PowerMockito.spy(source);

        ParameterTool parameterTool = mock(ParameterTool.class);
        when(parameterTool.get("nwm.job.param", null)).thenReturn("jobName");
        when(parameterTool.get("nwm.job.name", null)).thenReturn("TEST_JOB");
        ExecutionConfig executionConfig = mock(ExecutionConfig.class);
        when(executionConfig.getGlobalJobParameters()).thenReturn(parameterTool);
        RuntimeContext runtimeContext = mock(RuntimeContext.class);
        when(runtimeContext.getExecutionConfig()).thenReturn(executionConfig);
        PowerMockito.doReturn(runtimeContext).when(spySource).getRuntimeContext();
        PowerMockito.doNothing().when(spySource).startSubscription(any(SourceFunction.SourceContext.class),any(MDCParameter.class));
        PowerMockito.doNothing().when(spySource).waitForStreamTermination();
    }

    @Test
    void run() {
        spySource.run(mockedSourceContext);
        verify(spySource, times(1)).startSubscription(any(SourceFunction.SourceContext.class),any(MDCParameter.class));
        verify(spySource, times(1)).waitForStreamTermination();
    }

    @Test
    void incrementOffsetTracker() {
        spySource.incrementOffsetTracker(100L);
    }

    @Test
    void open() {
    }

    @Test
    void notifyCheckpointComplete() {
    }

    @Test
    void snapshotState() {
    }

    @Test
    void initializeState() {
    }

    @Test
    void cancel() {
    }
}