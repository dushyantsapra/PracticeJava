package com.nwm.xmart.streaming.manager;

import com.nwm.xmart.streaming.manager.results.ProcessingResults;
import com.nwm.xmart.streaming.manager.settings.FunctionSettings;
import com.nwm.xmart.streaming.manager.settings.SourceManagerParameters;
import com.nwm.xmart.streaming.manager.utils.SourceManagerSqlUtilInterface;
import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import javafx.util.Pair;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.junit.Assert;
import org.junit.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;
import java.util.List;

public class SourceManagerTest {

    public static List<Pair<String, String>> insertedValues = new LinkedList<>();

    @Test
    public void test_daily_system_test() {
        Configuration config = new Configuration();
        config.setString("source.manager.mode", "daily");
        config.setString("source.manager.functions", "functionOne,functionTwo,functionThree");
        config.setString("source.manager.outputFormat", "yyyyMMdd");
        config.setString("source.manager.daily.jobName", "test");
        config.setString("source.manager.sleep.duration.minutes", "1");

        // Set date to be 3 days before today
        LocalDate startDate = LocalDate.now().minus(4, ChronoUnit.DAYS);
        config.setString("source.manager.daily.initialLastSuccessfulDay", startDate.format(DateTimeFormatter.ofPattern("yyyyMMdd")));

        ParameterTool params = ParameterTool.fromMap(config.toMap());

        try {
            // create a mock interface
            SourceManagerSqlUtilInterface mockSqlUtil = getMockSourceManagerSqlUtilInterface();

            // create source manager
            SourceManager<MdxDocumentEvent> sourceManager = new SourceManager<MdxDocumentEvent>(params)
                    .withSourceManagerSqlUtil(mockSqlUtil);

            // run method which requires the function selector
            sourceManager.run(this::mockRunForDayFunction);

            //Day one
            String dayOneString = startDate.plus(1, ChronoUnit.DAYS).format(DateTimeFormatter.ofPattern("yyyyMMdd"));
            Assert.assertEquals("first name", "functionOne", insertedValues.get(0).getKey());
            Assert.assertEquals("first date", dayOneString, insertedValues.get(0).getValue());

            Assert.assertEquals("second name", "functionTwo", insertedValues.get(1).getKey());
            Assert.assertEquals("second date", dayOneString, insertedValues.get(1).getValue());

            Assert.assertEquals("third name", "functionThree", insertedValues.get(2).getKey());
            Assert.assertEquals("third date", dayOneString, insertedValues.get(2).getValue());

            //Day two
            String dayTwoString = startDate.plus(2, ChronoUnit.DAYS).format(DateTimeFormatter.ofPattern("yyyyMMdd"));
            Assert.assertEquals("fourth name", "functionOne", insertedValues.get(3).getKey());
            Assert.assertEquals("fourth date", dayTwoString, insertedValues.get(3).getValue());

            Assert.assertEquals("fifth name", "functionTwo", insertedValues.get(4).getKey());
            Assert.assertEquals("fifth date", dayTwoString, insertedValues.get(4).getValue());

            Assert.assertEquals("sixth name", "functionThree", insertedValues.get(5).getKey());
            Assert.assertEquals("sixth date", dayTwoString, insertedValues.get(5).getValue());

            //Day three
            String dayThreeString = startDate.plus(3, ChronoUnit.DAYS).format(DateTimeFormatter.ofPattern("yyyyMMdd"));
            Assert.assertEquals("seventh name", "functionOne", insertedValues.get(6).getKey());
            Assert.assertEquals("seventh date", dayThreeString, insertedValues.get(6).getValue());

            Assert.assertEquals("eighth name", "functionTwo", insertedValues.get(7).getKey());
            Assert.assertEquals("eighth date", dayThreeString, insertedValues.get(7).getValue());

            Assert.assertEquals("ninth name", "functionThree", insertedValues.get(8).getKey());
            Assert.assertEquals("ninth date", dayThreeString, insertedValues.get(8).getValue());

        } catch (Exception ex) {
            Assert.fail(ex.toString());
        }
    }

    private ProcessingResults mockRunForDayFunction(FunctionSettings settings) {
        return new ProcessingResults(true, true, true);
    }

    private SourceManagerSqlUtilInterface getMockSourceManagerSqlUtilInterface() {

        return new SourceManagerSqlUtilInterface() {
            @Override
            public LocalDate getLastSuccessfulDateForFunction(ParameterTool params, String functionName) {
                try {
                    String lastSuccessDateString = SourceManagerParameters.getDailyInitialLastSuccessfulDay(params);
                    DateTimeFormatter outputFormat = SourceManagerParameters.getOutputFormat(params);
                    return LocalDate.parse(lastSuccessDateString, outputFormat);
                } catch (Exception ex) {
                    return null;
                }
            }

            @Override
            public void insertLastSuccessfulDateForFunction(ParameterTool params, String functionName, String date) {
                System.out.println("Adding - " + functionName + " ---- " + date);
                insertedValues.add(new Pair<>(functionName, date));
            }
        };
    }
}