package com.nwm.xmart.streaming.manager.utils;

import com.nwm.xmart.streaming.manager.enums.ProcessingMode;
import com.nwm.xmart.streaming.manager.exceptions.ParameterException;
import com.nwm.xmart.streaming.manager.settings.SourceManagerParameters;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.junit.Assert;
import org.junit.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class ProcessingDateUtilTest {

    @Test
    public void test_repair() {
        Configuration config = new Configuration();
        config.setString("source.manager.mode", "REPAIR");
        config.setString("source.manager.functions", "functionOne,functionTwo,functionThree");
        config.setString("source.manager.repair.dates", "2018.06.20,2018.06.07,2018.06.01");
        config.setString("source.manager.outputFormat", "yyyy.MM.dd");

        ParameterTool params = ParameterTool.fromMap(config.toMap());

        try {
            Map<String, LinkedList<String>> functionProcessingDays = ProcessingDateUtil.getProcessingDays(params, null);

            Assert.assertEquals("processing mode", ProcessingMode.REPAIR, SourceManagerParameters.getMode(params));
            functionProcessingDays.entrySet().forEach(e ->
                    Assert.assertEquals("no of days", 3, e.getValue().size())
            );

            functionProcessingDays.entrySet().forEach(e -> {
                List<String> daysToLoad = e.getValue();
                Assert.assertTrue("day1", daysToLoad.get(0).equals("2018.06.01"));
                Assert.assertTrue("day2", daysToLoad.get(1).equals("2018.06.07"));
                Assert.assertTrue("day3", daysToLoad.get(2).equals("2018.06.20"));
            });

        } catch (Exception ex) {
            Assert.fail(ex.toString());
        }
    }

    @Test
    public void test_range_zero_days() {
        Configuration config = new Configuration();
        config.setString("source.manager.mode", "range");
        config.setString("source.manager.functions", "functionOne,functionTwo,functionThree");
        config.setString("source.manager.range.startDate", "2018.01.02");
        config.setString("source.manager.range.endDate", "2018.01.01");
        config.setString("source.manager.outputFormat", "yyyy.MM.dd");

        ParameterTool params = ParameterTool.fromMap(config.toMap());

        try {
            // this should error as start is after end
            ProcessingDateUtil.getProcessingDays(params, null);

        } catch (ParameterException parameterException) {
            Assert.assertTrue("correct exception", true);
        } catch (Exception exception) {
            Assert.fail(exception.toString());
        }
    }

    @Test
    public void test_range_one_days() {
        Configuration config = new Configuration();
        config.setString("source.manager.mode", "range");
        config.setString("source.manager.functions", "functionOne,functionTwo,functionThree");
        config.setString("source.manager.range.startDate", "2018.01.01");
        config.setString("source.manager.range.endDate", "2018.01.01");
        config.setString("source.manager.outputFormat", "yyyy.MM.dd");

        ParameterTool params = ParameterTool.fromMap(config.toMap());

        try {
            Map<String, LinkedList<String>> functionProcessingDays = ProcessingDateUtil.getProcessingDays(params, null);

            Assert.assertEquals("processing mode", ProcessingMode.RANGE, SourceManagerParameters.getMode(params));

            functionProcessingDays.entrySet().forEach(e ->
                    Assert.assertEquals("no of days", 1, e.getValue().size())
            );

            functionProcessingDays.entrySet().forEach(e -> {
                List<String> daysToLoad = e.getValue();
                Assert.assertTrue("day1", daysToLoad.get(0).equals("2018.01.01"));
            });
        } catch (Exception exception) {
            Assert.fail(exception.toString());
        }
    }

    @Test
    public void test_range_two_days() {
        Configuration config = new Configuration();
        config.setString("source.manager.mode", "RANGE");
        config.setString("source.manager.functions", "functionOne,functionTwo,functionThree");
        config.setString("source.manager.range.startDate", "2018.01.01");
        config.setString("source.manager.range.endDate", "2018.01.02");
        config.setString("source.manager.outputFormat", "yyyy.MM.dd");

        ParameterTool params = ParameterTool.fromMap(config.toMap());

        try {
            Map<String, LinkedList<String>> functionProcessingDays = ProcessingDateUtil.getProcessingDays(params, null);

            Assert.assertEquals("processing mode", ProcessingMode.RANGE, SourceManagerParameters.getMode(params));

            functionProcessingDays.entrySet().forEach(e ->
                    Assert.assertEquals("no of days", 2, e.getValue().size())
            );

            functionProcessingDays.entrySet().forEach(e -> {
                List<String> daysToLoad = e.getValue();
                Assert.assertTrue("day1", daysToLoad.get(0).equals("2018.01.01"));
                Assert.assertTrue("day2", daysToLoad.get(1).equals("2018.01.02"));
            });

        } catch (Exception ex) {
            Assert.fail(ex.toString());
        }
    }

    @Test
    public void test_range_many_days() {
        Configuration config = new Configuration();
        config.setString("source.manager.mode", "RANGE");
        config.setString("source.manager.functions", "functionOne,functionTwo,functionThree");
        config.setString("source.manager.range.startDate", "2018.01.01");
        config.setString("source.manager.range.endDate", "2018.01.05");
        config.setString("source.manager.outputFormat", "yyyy.MM.dd");

        ParameterTool params = ParameterTool.fromMap(config.toMap());

        try {
            Map<String, LinkedList<String>> functionProcessingDays = ProcessingDateUtil.getProcessingDays(params, null);

            Assert.assertEquals("processing mode", ProcessingMode.RANGE, SourceManagerParameters.getMode(params));

            functionProcessingDays.entrySet().forEach(e ->
                    Assert.assertEquals("no of days", 5, e.getValue().size())
            );

            functionProcessingDays.entrySet().forEach(e -> {
                List<String> daysToLoad = e.getValue();
                Assert.assertTrue("day1", daysToLoad.get(0).equals("2018.01.01"));
                Assert.assertTrue("day2", daysToLoad.get(1).equals("2018.01.02"));
                Assert.assertTrue("day3", daysToLoad.get(2).equals("2018.01.03"));
                Assert.assertTrue("day4", daysToLoad.get(3).equals("2018.01.04"));
                Assert.assertTrue("day5", daysToLoad.get(4).equals("2018.01.05"));
            });

        } catch (Exception ex) {
            Assert.fail(ex.toString());
        }
    }

    @Test
    public void test_daily_zero_days() {
        Configuration config = new Configuration();
        config.setString("source.manager.mode", "daily");
        config.setString("source.manager.functions", "functionOne,functionTwo,functionThree");
        config.setString("source.manager.outputFormat", "yyyy.MM.dd");
        config.setString("source.manager.daily.jobName", "test");
        // Set date to be 3 days before today
        LocalDate startDate = LocalDate.now().minus(1, ChronoUnit.DAYS);
        config.setString("source.manager.daily.initialLastSuccessfulDay", startDate.format(DateTimeFormatter.ofPattern("yyyy.MM.dd")));

        ParameterTool params = ParameterTool.fromMap(config.toMap());

        try {
            // create a mock interface
            SourceManagerSqlUtilInterface mockSqlUtil = getMockSourceManagerSqlUtilInterface();

            Map<String, LinkedList<String>> functionProcessingDays = ProcessingDateUtil.getProcessingDays(params, mockSqlUtil);

            Assert.assertEquals("processing mode", ProcessingMode.DAILY, SourceManagerParameters.getMode(params));

            functionProcessingDays.entrySet().forEach(e ->
                    Assert.assertEquals("no of days", 0, e.getValue().size())
            );

        } catch (Exception ex) {
            Assert.fail(ex.toString());
        }
    }

    @Test
    public void test_daily_one_days() {
        Configuration config = new Configuration();
        config.setString("source.manager.mode", "daily");
        config.setString("source.manager.functions", "functionOne,functionTwo,functionThree");
        config.setString("source.manager.outputFormat", "yyyy.MM.dd");
        config.setString("source.manager.daily.jobName", "test");
        // Set date to be 3 days before today
        LocalDate startDate = LocalDate.now().minus(2, ChronoUnit.DAYS);
        config.setString("source.manager.daily.initialLastSuccessfulDay", startDate.format(DateTimeFormatter.ofPattern("yyyy.MM.dd")));

        ParameterTool params = ParameterTool.fromMap(config.toMap());

        try {
            // create a mock interface
            SourceManagerSqlUtilInterface mockSqlUtil = getMockSourceManagerSqlUtilInterface();

            Map<String, LinkedList<String>> functionProcessingDays = ProcessingDateUtil.getProcessingDays(params, mockSqlUtil);

            Assert.assertEquals("processing mode", ProcessingMode.DAILY, SourceManagerParameters.getMode(params));

            functionProcessingDays.entrySet().forEach(e ->
                    Assert.assertEquals("no of days", 1, e.getValue().size())
            );

            functionProcessingDays.entrySet().forEach(e -> {
                List<String> daysToLoad = e.getValue();
                String day1 = startDate.plus(1, ChronoUnit.DAYS).format(DateTimeFormatter.ofPattern("yyyy.MM.dd"));
                Assert.assertTrue("day1", daysToLoad.get(0).equals(day1));
            });

        } catch (Exception ex) {
            Assert.fail(ex.toString());
        }
    }

    @Test
    public void test_daily_three_days() {
        Configuration config = new Configuration();
        config.setString("source.manager.mode", "daily");
        config.setString("source.manager.functions", "functionOne,functionTwo,functionThree");
        config.setString("source.manager.outputFormat", "yyyy.MM.dd");
        config.setString("source.manager.daily.jobName", "test");
        // Set date to be 3 days before today
        LocalDate startDate = LocalDate.now().minus(4, ChronoUnit.DAYS);
        config.setString("source.manager.daily.initialLastSuccessfulDay", startDate.format(DateTimeFormatter.ofPattern("yyyy.MM.dd")));

        ParameterTool params = ParameterTool.fromMap(config.toMap());

        try {
            // create a mock interface
            SourceManagerSqlUtilInterface mockSqlUtil = getMockSourceManagerSqlUtilInterface();

            Map<String, LinkedList<String>> functionProcessingDays = ProcessingDateUtil.getProcessingDays(params, mockSqlUtil);

            Assert.assertEquals("processing mode", ProcessingMode.DAILY, SourceManagerParameters.getMode(params));

            functionProcessingDays.entrySet().forEach(e ->
                    Assert.assertEquals("no of days", 3, e.getValue().size())
            );

            functionProcessingDays.entrySet().forEach(e -> {
                List<String> daysToLoad = e.getValue();
                String day1 = startDate.plus(1, ChronoUnit.DAYS).format(DateTimeFormatter.ofPattern("yyyy.MM.dd"));
                Assert.assertTrue("day1", daysToLoad.get(0).equals(day1));
                String day2 = startDate.plus(2, ChronoUnit.DAYS).format(DateTimeFormatter.ofPattern("yyyy.MM.dd"));
                Assert.assertTrue("day2", daysToLoad.get(1).equals(day2));
                String day3 = startDate.plus(3, ChronoUnit.DAYS).format(DateTimeFormatter.ofPattern("yyyy.MM.dd"));
                Assert.assertTrue("day2", daysToLoad.get(2).equals(day3));
            });

        } catch (Exception ex) {
            Assert.fail(ex.toString());
        }
    }

    @Test
    public void test_daily_three_days_alt_date_format() {
        Configuration config = new Configuration();
        config.setString("source.manager.mode", "daily");
        config.setString("source.manager.functions", "functionOne,functionTwo,functionThree");
        config.setString("source.manager.outputFormat", "yyyyMMdd");
        config.setString("source.manager.daily.jobName", "test");
        // Set date to be 3 days before today
        LocalDate startDate = LocalDate.now().minus(4, ChronoUnit.DAYS);
        config.setString("source.manager.daily.initialLastSuccessfulDay", startDate.format(DateTimeFormatter.ofPattern("yyyyMMdd")));

        ParameterTool params = ParameterTool.fromMap(config.toMap());

        try {
            // create a mock interface
            SourceManagerSqlUtilInterface mockSqlUtil = getMockSourceManagerSqlUtilInterface();

            Map<String, LinkedList<String>> functionProcessingDays = ProcessingDateUtil.getProcessingDays(params, mockSqlUtil);

            Assert.assertEquals("processing mode", ProcessingMode.DAILY, SourceManagerParameters.getMode(params));

            functionProcessingDays.entrySet().forEach(e ->
                    Assert.assertEquals("no of days", 3, e.getValue().size())
            );

            functionProcessingDays.entrySet().forEach(e -> {
                List<String> daysToLoad = e.getValue();
                String day1 = startDate.plus(1, ChronoUnit.DAYS).format(DateTimeFormatter.ofPattern("yyyyMMdd"));
                Assert.assertTrue("day1", daysToLoad.get(0).equals(day1));
                String day2 = startDate.plus(2, ChronoUnit.DAYS).format(DateTimeFormatter.ofPattern("yyyyMMdd"));
                Assert.assertTrue("day2", daysToLoad.get(1).equals(day2));
                String day3 = startDate.plus(3, ChronoUnit.DAYS).format(DateTimeFormatter.ofPattern("yyyyMMdd"));
                Assert.assertTrue("day2", daysToLoad.get(2).equals(day3));
            });

        } catch (Exception ex) {
            Assert.fail(ex.toString());
        }
    }

    private SourceManagerSqlUtilInterface getMockSourceManagerSqlUtilInterface() {

        return new SourceManagerSqlUtilInterface() {
            @Override
            public LocalDate getLastSuccessfulDateForFunction(ParameterTool params, String functionName) {
                try {
                    String lastSuccessDateString = SourceManagerParameters.getDailyInitialLastSuccessfulDay(params);
                    DateTimeFormatter outputFormat = SourceManagerParameters.getOutputFormat(params);
                    return LocalDate.parse(lastSuccessDateString, outputFormat);
                } catch (Exception ex) {
                    return null;
                }
            }

            @Override
            public void insertLastSuccessfulDateForFunction(ParameterTool params, String functionName, String date) {
            }
        };
    }
}
