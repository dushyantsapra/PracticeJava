package com.nwm.xmart.streaming.source.mdx.pull;

import com.nwm.xmart.streaming.source.mdx.event.MdxDocumentEvent;
import com.nwm.xmart.streaming.source.mdx.session.MdxSessionContext;
import com.nwm.xmart.streaming.source.mdx.session.MdxSessionContextBuilder;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.junit.Ignore;
import org.junit.Test;
import rbs.gbm.mdx.webService.interfaces.*;

import java.util.ArrayList;
import java.util.List;
import static org.easymock.EasyMock.*;

/**
 * Created by gardlex on 23/04/2018.
 */
public class SeriesViewInitialLoadTest {

    @Test
    @Ignore
    public void testMdxReadBatchResults() throws Exception {
        final TypeInformation<MdxDocumentEvent> mdxSourceEventType =
                TypeInformation.of(new TypeHint<MdxDocumentEvent>(){});
        SeriesViewMdxLoader eventExchange = new SeriesViewMdxLoader();
        eventExchange.withInitialCapacity(10000);
        eventExchange.withReadBatchSize(100);

        // List of IDs
        List<String> idList = new ArrayList<>();
        for (int i=1; i <= 1000; i++) {
            idList.add(i + "");
        }

        IMdxSession mockSession = mock(IMdxSession.class);
        IMdxSessionFactory mockMdxSessionFactory = mock(IMdxSessionFactory.class);

        MdxSessionContext sessionContext = new MdxSessionContextBuilder()
                .withSeriesViewMdxSession()
                .withSeriesViewMdxSessionFactory(mockMdxSessionFactory)
                .build();

//        eventExchange.cacheDocumentsForIndentifiers(sessionContext, idList);

    }
}
