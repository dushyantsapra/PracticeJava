package com.nwm.bdx.file;

import java.io.File;

public class SharedFileReader {

    public static void main(String[] args) {
        File share = new File("\\\\Smifileserver\\smifileshare\\SALESMI\\PROD1\\Imports\\Cremant\\CVA\\done");
        System.out.println(share.getAbsolutePath());
        System.out.println(share.isFile());
        System.out.println(share.isDirectory());
        if (share.isDirectory()) {
            for (File file : share.listFiles())
                System.out.println(file.getAbsolutePath());
        }
    }
}
