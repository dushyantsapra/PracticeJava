package com.nwm.xml.stax;

import java.io.StringReader;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

public class StaxParser {

    public static void main(String[] args) {
        XMLInputFactory factory = XMLInputFactory.newInstance();
        String xml = "<Employee><name type=\"first\">Peter</name><age>25</age></Employee>";

        XMLEventReader eventReader;
        try {
            eventReader = factory.createXMLEventReader(new StringReader(xml));
            Employee emp = null;

            while (eventReader.hasNext()) {
                // read node
                XMLEvent event = eventReader.nextEvent();

                if (event.isStartElement()) {
                    StartElement startElement = event.asStartElement();
                    // root node
                    if (startElement.getName().getLocalPart().equalsIgnoreCase("Employee")) {
                        System.out.println(startElement.getName().getLocalPart());
                        System.out.println("Before adding a new node ----------------");
                        emp = new Employee();
                    }
                    if (startElement.getName().getLocalPart().equalsIgnoreCase("name")) {
                        // get attribut values
                        Attribute attr = startElement.getAttributeByName(new QName("type"));
                        if (attr != null && attr.getName().toString().equals("type")) {
                            emp.setType(attr.getValue());
                        }
                        // element data
                        event = eventReader.nextEvent();
                        emp.setName(event.asCharacters().getData());
                    } else if (startElement.getName().getLocalPart().equalsIgnoreCase("age")) {
                        // element data
                        event = eventReader.nextEvent();
                        emp.setAge(new Integer(event.asCharacters().getData()));
                    }
                }

                if (event.isEndElement()) {
                    EndElement endElement = event.asEndElement();
                    if (endElement.getName().getLocalPart().equalsIgnoreCase("Employee")) {
                        System.out.println(emp);
                    }
                }
            }
        } catch (XMLStreamException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
