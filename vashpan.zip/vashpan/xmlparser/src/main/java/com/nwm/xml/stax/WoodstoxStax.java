package com.nwm.xml.stax;

import org.codehaus.stax2.XMLInputFactory2;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringBufferInputStream;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

public class WoodstoxStax {

    public static void main(String[] args) throws XMLStreamException, IOException {
        InputStream xmlIStream = new StringBufferInputStream(
                "<Employee><name type=\"first\">Peter</name><age>25</age></Employee>");
        XMLInputFactory2 xmlInputFactory2 = (XMLInputFactory2) XMLInputFactory.newInstance();
        XMLEventReader xmlStreamReader2 = xmlInputFactory2.createXMLEventReader(xmlIStream);

        while (xmlStreamReader2.hasNext()) {
            XMLEvent xmlEvent = xmlStreamReader2.nextEvent();
            switch (xmlEvent.getEventType()) {
            case XMLEvent.START_DOCUMENT:
                System.out.println("start Document " + xmlEvent);
                break;
            case XMLEvent.START_ELEMENT:
                System.out.println("start Element "+xmlEvent.asStartElement().getName());
                break;
            case XMLEvent.END_DOCUMENT:
                System.out.println("End Document ");
                break;
            case XMLEvent.END_ELEMENT:
                System.out.println("End Element");
                break;
            case XMLEvent.CHARACTERS:
                System.out.println("characters;");
                break;
            }
        }

        xmlIStream.close();
    }
}
