package com.rbs.datafabric.streaming.common.operators.source.mdx.sso.encryption;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.*;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

class EncryptDecryptAESTest {
    private static final int HALF_MAX = 999999;
    private static int threadPoolSize = 10;
    private List<Future<EncDecResult>> futures = new ArrayList<>(HALF_MAX);

    @Test
    void encryptDecryptSingleThread() {
        //Run for thousands of values
        for (int i = 0; i <= HALF_MAX; i++) {
            String str = UUID.randomUUID().toString();
            try {
                assertEquals(str, EncryptDecryptAES.decrypt(EncryptDecryptAES.encrypt(str)),
                        "Encryption / Decryption failed for " + str);
            } catch (BadPaddingException | IllegalBlockSizeException e) {
                fail("failed in encrypt decrypt with exception ", e);
            }
        }
    }

    @Test
    void encryptDecryptMultiThread() throws InterruptedException {
        //Run for thousands of values with hundreds of threads :P
        ExecutorService executor = Executors.newFixedThreadPool(threadPoolSize);
        for (int i = 0; i <= HALF_MAX; i++) {
            futures.add(executor.submit(new EncryptDecryptTask(new EncDecResult(UUID.randomUUID().toString()))));
        }

        executor.shutdown();
        if (!executor.awaitTermination(100, TimeUnit.MILLISECONDS)) {
            System.out.println("Waiting");
        }

        for (Future<EncDecResult> encDecResultFuture : futures) {
            try {
                EncDecResult encDecResult = encDecResultFuture.get();
                assertEquals(encDecResult.getOrig(), encDecResult.getEncryptedDecrypted(), "values not match ");
            } catch (InterruptedException | ExecutionException e) {
                fail("Failed for value ", e);
            }
        }
    }
}

class EncryptDecryptTask implements Callable<EncDecResult> {
    private EncDecResult encDecResult;
    public EncryptDecryptTask(EncDecResult encDecResult) {
        this.encDecResult = encDecResult;
    }

    public EncDecResult getEncDecResult() {
        return encDecResult;
    }

    @Override
    public EncDecResult call() throws Exception {
        encDecResult.setEncryptedDecrypted(EncryptDecryptAES.decrypt(EncryptDecryptAES.encrypt(encDecResult.getOrig())));
        return encDecResult;
    }
}

class EncDecResult {
    private final String orig;
    private String encryptedDecrypted;

    public EncDecResult(String orig) {
        this.orig = orig;
    }

    public String getOrig() {
        return orig;
    }

    public String getEncryptedDecrypted() {
        return encryptedDecrypted;
    }

    public void setEncryptedDecrypted(String encryptedDecrypted) {
        this.encryptedDecrypted = encryptedDecrypted;
    }
}