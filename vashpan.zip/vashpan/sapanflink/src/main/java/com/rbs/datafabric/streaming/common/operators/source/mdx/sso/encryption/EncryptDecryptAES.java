package com.rbs.datafabric.streaming.common.operators.source.mdx.sso.encryption;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import static java.util.Objects.isNull;

public class EncryptDecryptAES {

    private static final Logger LOGGER = LoggerFactory.getLogger(EncryptDecryptAES.class);
    // can be 16 24 or 32 length; Taking 32
    private static final String encryptDecryptKey = "xmart-encryption-decryption-keys";
    private static Cipher encryptCipher;
    private static Cipher decryptCipher;
    private static EncryptionException failureException;

    static {
        try {
            SecretKeySpec secretKey = new SecretKeySpec(encryptDecryptKey.getBytes(), "AES");

            encryptCipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            encryptCipher.init(Cipher.ENCRYPT_MODE, secretKey);

            decryptCipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            decryptCipher.init(Cipher.DECRYPT_MODE, secretKey);
        } catch (NoSuchAlgorithmException | InvalidKeyException | NoSuchPaddingException e) {
            encryptCipher = null;
            decryptCipher = null;
            failureException = new EncryptionException("Failed to initialize ciphers", e);
            LOGGER.error("Initialization of ciphers failed ", e);
        }
    }

    public static String encrypt(String strToEncrypt) throws EncryptionException {
        if (isNull(encryptCipher)) {
            LOGGER.error("Initialization had failed", failureException);
            throw failureException;
        }

        try {
            return Base64.getEncoder().encodeToString(encryptCipher.doFinal(strToEncrypt.getBytes("UTF-8")));
        } catch (BadPaddingException | IllegalBlockSizeException | UnsupportedEncodingException e) {
            LOGGER.error("Could not encrypt " + strToEncrypt, e);
            throw new EncryptionException("Could not encrypt " + strToEncrypt, e);
        }
    }

    public static String decrypt(String strToDecrypt) throws BadPaddingException, IllegalBlockSizeException {
        if (isNull(decryptCipher)) {
            LOGGER.error("Initialization had failed", failureException);
            throw failureException;
        }

        try {
            return new String(decryptCipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
        } catch (BadPaddingException | IllegalBlockSizeException e) {
            LOGGER.error("Could not decrypt " + strToDecrypt, e);
            throw new EncryptionException("Could not decrypt " + strToDecrypt, e);
        }
    }
}
