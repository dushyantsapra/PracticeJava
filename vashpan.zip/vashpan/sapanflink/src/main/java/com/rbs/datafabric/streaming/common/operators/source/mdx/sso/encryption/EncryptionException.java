package com.rbs.datafabric.streaming.common.operators.source.mdx.sso.encryption;

public class EncryptionException extends RuntimeException {

    public EncryptionException() {
        super();
    }

    public EncryptionException(String msg) {
        super(msg);
    }

    public EncryptionException(String msg, Throwable t) {
        super(msg, t);
    }
}