package com.sapan.flink;

public interface Names {
    String counter = "SapanCounter";
}
