package com.sapan.flink;

import com.sapan.bean.BeanCreater;
import com.sapan.bean.SapanBean;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.util.Random;

public class SapanSource extends RichParallelSourceFunction<SapanBean>
        implements CheckpointedFunction, CheckpointListener {
    private static final Random RANDOM = new Random();
    private static final Logger LOGGER = LoggerFactory.getLogger(SapanSource.class);
    private volatile boolean keepRunning = true;
    private Counter count;

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        LOGGER.info("Started Source " + parameters);
        count = getRuntimeContext().getMetricGroup().counter(Names.counter);
        count.inc(1000);
    }

    @Override
    public void run(SourceContext<SapanBean> ctx) throws Exception {
        while (keepRunning) {
            System.out.println("Emitting for " + count.getCount());
            MDC.put("jobName", "LOGGINGJOB");
            SapanBean bean = BeanCreater.get(count.getCount());
            LOGGER.info(bean.toString());
            ctx.collectWithTimestamp(bean, System.currentTimeMillis());
            //Thread.sleep(500);
            count.dec();
            if (count.getCount() == 0) {
                System.out.println("Done , sleeping");
                Thread.sleep(100000);
            }
        }
    }

    @Override
    public void cancel() {
        keepRunning = false;
    }

    @Override
    public void snapshotState(FunctionSnapshotContext context) throws Exception {
        LOGGER.info("initializeState " + context);
    }

    @Override
    public void initializeState(FunctionInitializationContext context) throws Exception {
        LOGGER.info("initializeState " + context);
    }

    @Override
    public void notifyCheckpointComplete(long checkpointId) throws Exception {
        LOGGER.info("notifyCheckpointComplete " + checkpointId);
    }
}
