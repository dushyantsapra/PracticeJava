package com.sapan.flink;

import com.sapan.bean.SapanBean;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SapanProcessWindowFunction extends ProcessWindowFunction<SapanBean, SapanBean, Integer, TimeWindow> {
    private static final Logger LOGGER = LoggerFactory.getLogger(SapanProcessWindowFunction.class);

    @Override
    public void process(Integer s, Context context, Iterable<SapanBean> elements, Collector<SapanBean> out)
            throws Exception {
        int size = 0;
        LOGGER.info("workng "+elements);
        for (SapanBean in : elements) {
            LOGGER.info("workng "+in);
            size++;
            in.setSetMe("Passed through");
            out.collect(in);
        }
        LOGGER.info("SIZE " + size);
    }
}
