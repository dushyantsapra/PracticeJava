package com.sapan.flink;

import java.sql.Date;

public class Test {
    public static void main(String[] args) {
                System.out.println(new Date(1532152960758l));
    }
}
