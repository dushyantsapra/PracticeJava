package com.sapan.flink;

import org.jboss.netty.util.internal.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.Map;

public abstract class LoggingComp implements Serializable {

    private static final Map<Class, Logger> CLASS_LOGGER_MAP = new ConcurrentHashMap<>();

    /**
     *
     * @param clazz
     */
    public static void log(Class clazz) {
        CLASS_LOGGER_MAP.putIfAbsent(clazz, LoggerFactory.getLogger(clazz));

    }
}
