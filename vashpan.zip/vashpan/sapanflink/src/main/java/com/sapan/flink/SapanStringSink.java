package com.sapan.flink;

import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.atomic.AtomicInteger;

public class SapanStringSink extends RichSinkFunction<String> implements CheckpointedFunction, CheckpointListener {


    private static AtomicInteger int1 = new AtomicInteger();
    private Counter count;

    /**
     * @param parameters
     *
     * @throws Exception
     */
    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        count = getRuntimeContext().getMetricGroup().counter(Names.counter);
    }

    @Override
    public void invoke(String value) throws Exception {

        if (count.getCount() == 0) {
            System.out.println("Source has finished ");
//            throw new RuntimeException("Job has to end now");
        }
    }

    @Override
    public void notifyCheckpointComplete(long checkpointId) throws Exception {

    }

    @Override
    public void snapshotState(FunctionSnapshotContext context) throws Exception {

    }

    @Override
    public void initializeState(FunctionInitializationContext context) throws Exception {

    }
}
