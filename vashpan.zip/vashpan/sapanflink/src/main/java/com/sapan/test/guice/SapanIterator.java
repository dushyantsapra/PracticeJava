package com.sapan.test.guice;

import java.util.Iterator;
import java.util.function.Consumer;

public class SapanIterator implements Iterator<String> {
    @Override
    public boolean hasNext() {
        return false;
    }

    @Override
    public String next() {
        return null;
    }

    @Override
    public void remove() {

    }

    @Override
    public void forEachRemaining(Consumer<? super String> action) {

    }
}
