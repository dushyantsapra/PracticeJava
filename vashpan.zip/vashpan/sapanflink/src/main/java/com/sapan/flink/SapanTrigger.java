package com.sapan.flink;

import com.sapan.bean.SapanBean;
import org.apache.flink.streaming.api.windowing.triggers.Trigger;
import org.apache.flink.streaming.api.windowing.triggers.TriggerResult;
import org.apache.flink.streaming.api.windowing.windows.Window;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SapanTrigger extends Trigger<SapanBean, Window> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SapanTrigger.class);

    @Override
    public TriggerResult onElement(SapanBean sapanBean, long timestamp, Window window, TriggerContext ctx)
            throws Exception {

        LOGGER.debug(sapanBean.toString());
        return TriggerResult.CONTINUE;
    }

    @Override
    public TriggerResult onProcessingTime(long time, Window window, TriggerContext ctx) throws Exception {
        LOGGER.debug(window.toString());
        return TriggerResult.FIRE_AND_PURGE;
    }

    @Override
    public TriggerResult onEventTime(long time, Window window, TriggerContext ctx) throws Exception {
        LOGGER.debug(window.toString());
        return TriggerResult.FIRE_AND_PURGE;
    }

    @Override
    public void clear(Window window, TriggerContext ctx) throws Exception {

    }
}
