package com.sapan.flink;

import com.sapan.bean.SapanBean;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SapanProcessor {
    private static final Logger logger = LoggerFactory.getLogger(SapanProcessor.class);
    private static StreamExecutionEnvironment env;

    public static void main(String[] args) throws Exception {

        env = getWindowedStream();
        configureCP(env);
        env.setRestartStrategy(new RestartStrategies.NoRestartStrategyConfiguration());

        try {
            logger.info("ENVIRONMNET " + env.getExecutionPlan());
            env.execute(args[0]);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    private static void configureCP(StreamExecutionEnvironment env) {
        env.enableCheckpointing(1000, CheckpointingMode.EXACTLY_ONCE);

        env.getCheckpointConfig().setCheckpointTimeout(10000);
        env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);
        env.getCheckpointConfig().setMinPauseBetweenCheckpoints(1000);
    }

    private static StreamExecutionEnvironment getWindowedStream() {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);

        SingleOutputStreamOperator<SapanBean> sapanStream = env.addSource(new SapanSource())
                                                               .uid(getName(SapanSource.class))
                                                               .name(getName(SapanSource.class)).forceNonParallel();

        SingleOutputStreamOperator<SapanBean> windowStream = sapanStream.keyBy(new SapanKeySelector())
                                                                        .window(TumblingProcessingTimeWindows
                                                                                .of(Time.seconds(1)))
                                                                        .trigger(new SapanTrigger())
                                                                        .process(new SapanProcessWindowFunction())
                                                                        .setParallelism(5);

        windowStream.addSink(new SapanLoggerSink()).name(getName(SapanLoggerSink.class))
                    .uid(getName(SapanLoggerSink.class)).setParallelism(10);
        return env;
    }

    private static String getName(Class c) {
        return c.getSimpleName();
    }
}

