package com.sapan.flink;

import com.sapan.bean.SapanBean;
import org.apache.flink.api.java.functions.KeySelector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

public class SapanKeySelector extends LoggingComp implements KeySelector<SapanBean, Integer> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SapanKeySelector.class);

    @Override
    public Integer getKey(SapanBean bean) throws Exception {
        MDC.put("jobName", "LOGGINGJOB");
        LOGGER.debug(String.valueOf(bean));
        return bean.getId();
    }
}
