package com.sapan.flink;

import com.sapan.bean.SapanBean;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.metrics.Counter;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SapanMapper extends RichMapFunction<SapanBean, SapanBean> implements CheckpointedFunction, CheckpointListener {
    private static final Logger LOGGER = LoggerFactory.getLogger(SapanMapper.class);

    private transient Counter counter;
    private Configuration configuration;

    @Override
    public void open(Configuration parameters) throws Exception {
        LOGGER.info("Open");
        this.counter = getRuntimeContext().getMetricGroup().counter("myCounter");
        super.open(parameters);
        configuration = parameters;
    }

    @Override
    public void close() throws Exception {
        LOGGER.info("close");
        super.close();
    }

    @Override
    public SapanBean map(SapanBean value) {
        LOGGER.debug("MAP "+value);
        counter.inc();
       return value;
    }

    @Override
    public void notifyCheckpointComplete(long checkpointId) {
        LOGGER.info("notifyCheckpointComplete " + checkpointId);
    }

    @Override
    public void snapshotState(FunctionSnapshotContext context) {
        LOGGER.info("snapshotState");
    }

    @Override
    public void initializeState(FunctionInitializationContext context) {
        LOGGER.info("initializeState");
    }
}
