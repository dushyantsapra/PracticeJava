package com.sapan.test.guice;

import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.name.Named;

import java.util.Iterator;

public class TestGuice {

    @Inject(optional = false)
    @Named("sapanset")
    Iterator<String> injectedSet;

    public static void main(String[] args) throws ClassNotFoundException {
        Class clazz = Class.forName("java.lang.String");
        System.out.println(clazz.getName());

        System.out.println(Guice.createInjector(new SapanModule()).getInstance(TestGuice.class).injectedSet.hasNext());
    }
}
