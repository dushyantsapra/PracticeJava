package com.sapan.bean;

import java.io.Serializable;

public class SapanBean implements Serializable {

    private static final long serialVersionUID = -1928348931693547609L;

    private int id;

    public SapanBean() {
    }

    private String name;
    private long eventTime;
    private String setMe;

    public SapanBean(int id, String name) {
        this.id = id;
        this.name = name;
        this.eventTime = System.currentTimeMillis();
    }

    @Override
    public String toString() {
        return "SapanBean{" + "id=" + id + ", name='" + name + '\'' + ", eventTime=" + eventTime + ", setMe='" + setMe
                + '\'' + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getEventTime() {
        return eventTime;
    }

    public void setEventTime(long eventTime) {
        this.eventTime = eventTime;
    }

    public String getSetMe() {
        return setMe;
    }

    public void setSetMe(String setMe) {
        this.setMe = setMe;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
