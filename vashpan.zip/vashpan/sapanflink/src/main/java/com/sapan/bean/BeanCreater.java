package com.sapan.bean;

import java.util.Random;

public class BeanCreater {
    private static final Random random = new Random();

    public static SapanBean get() {
        return get(random.nextInt(10));
    }

    public static SapanBean get(long n) {
        return new SapanBean((int) n, "Name" + n);
    }
}
