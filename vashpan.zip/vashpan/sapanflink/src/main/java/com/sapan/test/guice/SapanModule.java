package com.sapan.test.guice;

import com.google.inject.AbstractModule;
import com.google.inject.TypeLiteral;
import com.google.inject.name.Names;

import java.util.Iterator;

public class SapanModule extends AbstractModule {

    @Override
    protected void configure() {
        bind(new TypeLiteral<Iterator<String>>() {
        }).annotatedWith(Names.named("sapanset")).to(SapanIterator.class);
    }
}
