package com.sapan.flink;

import com.sapan.bean.SapanBean;
import org.apache.flink.runtime.state.CheckpointListener;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SapanProcessFunction extends ProcessFunction<SapanBean, SapanBean>
        implements CheckpointedFunction, CheckpointListener {

    private static final Logger logger = LoggerFactory.getLogger(SapanProcessFunction.class);

    @Override
    public void processElement(SapanBean value, Context ctx, Collector<SapanBean> out) throws Exception {
        out.collect(value);
    }

    @Override
    public void snapshotState(FunctionSnapshotContext context) throws Exception {
        logger.info("snapshot state");
    }

    @Override
    public void initializeState(FunctionInitializationContext context) throws Exception {
        logger.info("initialize state");
    }

    @Override
    public void notifyCheckpointComplete(long checkpointId) throws Exception {
        logger.info("notifyCheckpointComplete " + checkpointId);
    }
}
