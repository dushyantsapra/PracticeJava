package com.sapan.flink;

import org.apache.flink.util.OutputTag;

public class SapanOutputTagSingleton {
    private static final String MY_TAG = "SAPAN_SIDE_OUT_TAG";
    public static final OutputTag<String> SIDE_OUTPUT = new OutputTag<String>(MY_TAG){};
}
