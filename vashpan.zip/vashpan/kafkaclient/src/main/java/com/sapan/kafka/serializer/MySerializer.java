package com.sapan.kafka.serializer;

import com.sapan.kafka.message.MyKafkaMessage;
import org.apache.kafka.common.serialization.Serializer;

import java.util.Map;

public class MySerializer implements Serializer<MyKafkaMessage> {
    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {

    }

    @Override
    public byte[] serialize(String topic, MyKafkaMessage data) {
        return new byte[0];
    }

    @Override
    public void close() {

    }
}
