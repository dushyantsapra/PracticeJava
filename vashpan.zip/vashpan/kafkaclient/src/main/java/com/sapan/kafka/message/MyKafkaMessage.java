package com.sapan.kafka.message;

public class MyKafkaMessage {



}
