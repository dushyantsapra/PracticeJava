package com.sapan.kafka.client;

interface Test {
    void myMethod();

    default void metho() {
        System.out.println("Hello");
    }
}

class TestClass implements Test {

    @Override
    public void myMethod() {

    }
}

