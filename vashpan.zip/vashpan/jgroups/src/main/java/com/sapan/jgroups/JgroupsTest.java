package com.sapan.jgroups;

import java.io.Serializable;

public class JgroupsTest implements Serializable {
}
