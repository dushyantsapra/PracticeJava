package com.rbs.smart.ignite;

import org.apache.ignite.plugin.PluginConfiguration;

public class WhiteListPluginConfiguration implements PluginConfiguration {
}
