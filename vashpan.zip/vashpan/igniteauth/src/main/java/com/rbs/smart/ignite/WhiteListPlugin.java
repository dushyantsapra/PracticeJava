package com.rbs.smart.ignite;


import org.apache.ignite.plugin.IgnitePlugin;

public class WhiteListPlugin implements IgnitePlugin {

}
