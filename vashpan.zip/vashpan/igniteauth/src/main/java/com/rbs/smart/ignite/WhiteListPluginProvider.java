package com.rbs.smart.ignite;

import org.apache.ignite.IgniteCheckedException;
import org.apache.ignite.cluster.ClusterNode;
import org.apache.ignite.plugin.*;
import org.jetbrains.annotations.Nullable;

import java.io.Serializable;
import java.util.UUID;

public class WhiteListPluginProvider implements PluginProvider<WhiteListPluginConfiguration> {
    @Override
    public String name() {
        return "XmartIgniteConfiguration";
    }

    @Override
    public String version() {
        System.out.println("returning verssion 1.0.1");
        return "1.0.1";
    }

    @Override
    public String copyright() {
        System.out.println("returning Copyright null");
        return null;
    }

    @Override
    public <T extends IgnitePlugin> T plugin() {
        System.out.println("returning WhiteListPlugin");
        return (T) new WhiteListPlugin();
    }

    @Override
    public void initExtensions(PluginContext pluginContext, ExtensionRegistry extensionRegistry)
            throws IgniteCheckedException {
        System.out.println("init extensions called");
    }

    @Nullable
    @Override
    public <T> T createComponent(PluginContext pluginContext, Class<T> aClass) {
        System.out.println("createComponent called");
        return null;
    }

    @Override
    public CachePluginProvider createCacheProvider(CachePluginContext cachePluginContext) {
        System.out.println("createCacheProvider");
        return null;
    }

    @Override
    public void start(PluginContext pluginContext) throws IgniteCheckedException {
        System.out.println("start called");
    }

    @Override
    public void stop(boolean b) throws IgniteCheckedException {
        System.out.println("stop called");
    }

    @Override
    public void onIgniteStart() throws IgniteCheckedException {
        System.out.println("onIgniteStart called");
    }

    @Override
    public void onIgniteStop(boolean b) {
        System.out.println("onIgniteStop called");
    }

    @Nullable
    @Override
    public Serializable provideDiscoveryData(UUID uuid) {
        System.out.println("provideDiscoveryData called");
        return null;
    }

    @Override
    public void receiveDiscoveryData(UUID uuid, Serializable serializable) {
        System.out.println("receiveDiscoveryData called "+uuid);
    }

    @Override
    public void validateNewNode(ClusterNode clusterNode) throws PluginValidationException {
        System.out.println("validateNewNode called " + clusterNode);
    }
}
