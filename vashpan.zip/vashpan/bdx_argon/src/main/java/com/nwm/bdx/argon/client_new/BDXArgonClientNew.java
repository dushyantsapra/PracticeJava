package com.nwm.bdx.argon.client_new;

import com.rbsfm.argon.client.cga.*;

import java.util.Iterator;

import static com.rbsfm.argon.client.cga.LogSettings.LEVEL_DEBUG;

public class BDXArgonClientNew {

    public static void main(String[] args) {
        Client client = new Client();

        String argonConnectionFile = BDXArgonClientNew.class.getClassLoader()
                                                            .getResource("argon/main_argon_connection.xml").getFile();
        String argonSettingsFile = BDXArgonClientNew.class.getClassLoader().getResource("argon/argon_settings.xml")
                                                          .getFile();
        System.setProperty("argon.bootstrap.file", argonConnectionFile);
        System.setProperty("argon.settings", argonSettingsFile);
        System.setProperty("EnableFileSSL", "false");

        try {
            if (!client.getConnected()) {
                //client.connect(new ClientNodeAddress("ln:pre:bdx:salesday1_feed_sk"), "?0vhVUm_nS@Z85yC");
                client.connect(new ClientNodeAddress("ln:main:bdx:salesday1_feed_sk"), "bZ*ZU0-N*@KYR$VG");
            }



            client.getLogSettings().setLevel(LEVEL_DEBUG);
            StreamList streams = new StreamList();
            streams.addStream("file_xfer", new ClientNodeAddress("ln:main:cremant:salesday1_feed_src"));

            Receiver receiver = client.createReceiver(streams);

            boolean loop = true;
            while (loop) {
                ReceivedMessage message = null;
                try {
                    message = receiver.receive(20000);
                    print(message);
                    Iterator iterator1 = message.getAssociatedFileList().iterator();
                    if (iterator1.hasNext()) {
                        ReceivedAssociatedFile s = (ReceivedAssociatedFile) iterator1.next();
                        s.writeToFile("C:\\Users\\vashpan\\work\\BDX\\ArgonSources\\wwwe\\" + s.getFileName());
                    }
                } catch (Exception e) {
                    System.out.println("Exception in processing message ");
                    e.printStackTrace();
                  /*  if (message != null)
                        message.acknowledge();*/
                }
            }
            System.out.println(client.getConnected());
        } catch (ClientException e) {
            e.printStackTrace();
        } finally {
            try {
                client.disconnect();
                System.out.println(client.getConnected());
            } catch (ClientException e) {
                e.printStackTrace();
            }
        }
    }

    private static void print(ReceivedMessage message) throws ClientException {
        System.out.println(message.getMessageType());
        System.out.println(message.getSourceClientNodeAddress());
        System.out.println(message.getSchema());
        System.out.println(message.getXMLText());
        System.out.println(message.getJSONText());
        System.out.println(message.getDocument());
        System.out.println(message.getApplicationID());
    }
}
