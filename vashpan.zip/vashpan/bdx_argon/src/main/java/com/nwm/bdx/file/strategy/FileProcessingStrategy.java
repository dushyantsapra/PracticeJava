package com.nwm.bdx.file.strategy;

import com.nwm.bdx.file.Parameters;

public interface FileProcessingStrategy {
    void validateFile(String filename, Parameters parameters);

    void processFile(String fileName);
}
