package com.nwm.bdx.file;

import java.util.Map;

/**
 * Parameters that will be used for different file operations
 */
public interface Parameters {
    /**
     * Get a parameter value
     *
     * @param paramName name of parameter to get
     *
     * @return parameter type.
     */
    String getParameter(String paramName);

    /**
     * @return map of all parameters in this parameter object
     */
    Map getAllParameters();
}
