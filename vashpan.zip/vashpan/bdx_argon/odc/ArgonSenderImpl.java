package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.core.logging.Log;
import com.rbs.odc.core.logging.LogFactory;

@SuppressWarnings("unchecked")
public class ArgonSenderImpl implements ArgonSender {

    private static final Log LOGGER = LogFactory.getLog(ArgonSenderImpl.class);

    private final Argon argonClient;
    private final MessageSender messageSender;
    
    public ArgonSenderImpl(Argon argonClient, MessageSender messageSender) {
        this.argonClient = argonClient;
        this.messageSender = messageSender;
    }

    @Override
    public void connect() {
    	LOGGER.info("Connecting Argon Sender....");
        argonClient.connect();
        LOGGER.info("Argon Sender connected....successfully");
    }

    @Override
    public void disconnect() {
        argonClient.disconnect();		
        LOGGER.info("Argon Sender disconnected....successfully");
    }
    
	@Override
    public Long send(SentMessage message) throws MessageSenderException{
		return messageSender.send(message);
	}
	
	@Override
	public String getRouteAddress(){
		return argonClient.getRouteAddress();
	}
}
