package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.vest.storage.services.FeedService;

public class ArgonSequenceHelper {

    private final FeedService feedService;
    private final ArgonDestRouteMapping route;
    private final long argonSequenceNumber;

    public ArgonSequenceHelper(ArgonDestRouteMapping route, long argonSequenceNumber, FeedService feedService) {
        this.route = route;
        this.feedService = feedService;
        this.argonSequenceNumber = argonSequenceNumber;
    }

    public boolean isDuplicateMessage() {
        return isValid() && argonSequenceNumber <= getCurrentArgonId();
    }

    public boolean isOutOfOrder() {
        return isValid() && argonSequenceNumber > (getCurrentArgonId() + 1);
    }

    public void saveCurrentArgonSequenceNumber() {
        if (isValid()) {
            String sink = route.getSinkRoute();
            String canonicalName = route.getSourceRoute();
            String messageType = route.getMessageType();
            feedService.saveArgonSequenceNumber(sink, canonicalName, messageType, argonSequenceNumber);
        }
    }

    private long getCurrentArgonId() {
        if (isValid()) {
            String sink = route.getSinkRoute();
            String canonicalName = route.getSourceRoute();
            String messageType = route.getMessageType();
            return feedService.getCurrentArgonId(sink, canonicalName, messageType);
        }
        return 0;
    }

    private boolean isValid() {
        return route != null && argonSequenceNumber >= 0;
    }
}
