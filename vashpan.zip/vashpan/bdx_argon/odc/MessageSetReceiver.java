package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.core.logging.Log;
import com.rbs.odc.core.logging.LogFactory;
import com.rbs.odc.vest.core.feed.message.ArgonMessage;
import com.rbs.odc.vest.core.feed.message.MessageBackupCreator;
import com.rbs.odc.vest.core.feed.message.MessageSetMessage;
import com.rbsfm.argon.client.cga.ClientException;
import com.rbsfm.argon.client.cga.ReceivedMessageSet;
import com.rbsfm.argon.client.cga.Receiver;

public class MessageSetReceiver implements MessageReceiver {
    private static final Log LOGGER = LogFactory.getLog(MessageSetReceiver.class);

    private final Receiver receiver;
    private final long messageSetTimeOut;

    public MessageSetReceiver(Receiver receiver, long messageSetTimeOut) {
        this.receiver = receiver;
        this.messageSetTimeOut = messageSetTimeOut;
    }

    public ArgonMessage receive(long timeOut) throws MessageReceiverException {
        try {
            ReceivedMessageSet set = receiver.receiveSet(messageSetTimeOut);
            if (set != null ) {
                return new MessageSetMessage(set, new MessageBackupCreator());
            }
            return null;
        } catch (ClientException e) {
            LOGGER.warn("Exception encountered while receiving message.", e);
            throw new MessageReceiverException(e);
        }
    }
}
