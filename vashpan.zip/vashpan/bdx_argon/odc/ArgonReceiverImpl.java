package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.access.exception.ODCAccessException;
import com.rbs.odc.core.exception.ODCRuntimeException;
import com.rbs.odc.core.instrumentation.impl.InstrumentationLogger;
import com.rbs.odc.core.logging.Log;
import com.rbs.odc.core.logging.LogFactory;
import com.rbs.odc.core.util.ODCProperties;
import com.rbs.odc.vest.core.feed.FailedToBackupMessageException;
import com.rbs.odc.vest.core.feed.FeedDefinition;
import com.rbs.odc.vest.core.feed.message.ArgonMessage;
import com.rbs.odc.vest.core.feed.message.FeedMessage;
import com.rbs.odc.vest.core.feed.message.FeedMessageHelper;
import com.rbs.odc.vest.core.util.FileNamePatternHelper;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;

import static com.rbs.odc.vest.core.util.VestPropertiesHelper.ARGON_RECEIVER_TIMEOUT;
import static com.rbs.odc.vest.core.util.VestPropertiesHelper.vestProperties;
import static java.lang.Boolean.getBoolean;

public class ArgonReceiverImpl implements ArgonReceiver {

    private static final Log LOG = LogFactory.getLog(ArgonReceiverImpl.class);
    private static final long DEFAULT_TIMEOUT = 4000L;
    private static final boolean isInstrumenting = Boolean.getBoolean("odc.argon.instrumentation");

    private final Argon argonClient;
    private final Map<FeedDefinition, SourceMessageListener> listeners
            = new HashMap<FeedDefinition, SourceMessageListener>();
    private final MessageReceiver messageReceiver;
    private final Executor feedMessageExecutor;
    private SourceMessageListener theMessageListener;
    private FileNamePatternHelper fileNamePatternHelper = new FileNamePatternHelper();

    public ArgonReceiverImpl(com.rbs.odc.vest.core.feed.argon.Argon argonClient, com.rbs.odc.vest.core.feed.argon.MessageReceiver messageReceiver,
            Executor executor) {
        this.argonClient = argonClient;
        this.messageReceiver = messageReceiver;
        this.feedMessageExecutor = executor;
    }

    @Override
    public void connect() {
        LOG.info("Connecting Argon Receiver....");
        argonClient.connect();
        LOG.info("Argon Receiver connected....successfully");
    }

    @Override
    public void disconnect() {
        argonClient.disconnect();
        LOG.info("Argon Receiver disconnected....successfully");
    }

    @Override
    public void receive() {
        ArgonMessage message = receiveMessage();
        while (message != null) {
            processMessage(message);
            message = receiveMessage();
        }
    }

    private void processMessage(final ArgonMessage message) {
        final InstrumentationLogger logger = new InstrumentationLogger("ArgonReceiver-processMessage");
        long start = 0;
        if (isInstrumenting) {
            logger.emitOperationStarting();
            start = System.currentTimeMillis();
        }
        feedMessageExecutor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    processAndAck(message, logger);
                } catch (FailedToBackupMessageException failedBackup) {
                    LOG.warn("Failed to backup argon message", failedBackup);
                    nack(message);
                } catch (ODCAccessException odcae) {
                    nakAndLogAndThrow(message, "Something terrible has happened! Cluster is not available!!", odcae);
                } catch (ODCRuntimeException odcae) {
                    nakAndLogAndThrow(message,
                            "Something terrible has happened! Possible EMS problem!: " + odcae.getMessage(), odcae);
                } catch (Throwable t) {
                    handleMalformedFeeds(message, t);
                }
            }
        });
        if (isInstrumenting) {
            logger.emitOperationFinished(System.currentTimeMillis() - start);
        }
    }

    private void nakAndLogAndThrow(final ArgonMessage message, String logMessage, RuntimeException runtimeException) {
        LOG.error(logMessage, runtimeException);
        nack(message);
        throw runtimeException;
    }

    private void processAndAck(ArgonMessage message, InstrumentationLogger logger) {
        long step = 0;
        if (isInstrumenting) {
            step = System.currentTimeMillis();
        }
        findListener(message).processMessage(message);
        if (isInstrumenting) {
            step = logger.emitStepWithStartTime("processStep", step);
        }
        ack(message);
        if (isInstrumenting) {
            logger.emitStepWithStartTime("ack", step);
        }
    }

    private void handleMalformedFeeds(final ArgonMessage message, Throwable t) {
        if (getBoolean(ODCProperties.ACK_MALFORMED_AUTOMAPPER_FEEDS)) {
            LOG.error(
                    "Got a RuntimeException, possiblly ParseException from trace for this feed!! Was it modified incorrectly by hand?",
                    t);
            ack(message);
        } else {
            LOG.error("Something terrible has happened!!", t);
            nack(message);
        }
    }

    private SourceMessageListener findListener(ArgonMessage feedMessage) {
        if (theMessageListener != null) {
            return theMessageListener;
        }
        if (isXMLMessage(feedMessage)) {
            return findListenerForXMLMessage(feedMessage);
        }
        return findListenerBasedOnFileNamePattern(feedMessage);
    }

    private SourceMessageListener findListenerBasedOnFileNamePattern(FeedMessage feedMessage) {
        String fileName = FeedMessageHelper.normalizeFileName(feedMessage.getAttachedFileName());
        for (FeedDefinition feedDefinition : listeners.keySet()) {
            if (fileNamePatternHelper.fileNameMatchesFeedPattern(fileName, feedDefinition)) {
                return listeners.get(feedDefinition);
            }
        }
        LOG.warn("Could not find feed definition matching file name[" + fileName + "].");
        return new NullListener();
    }

    private SourceMessageListener findListenerForXMLMessage(FeedMessage feedMessage) {
        if (listeners.size() > 1) {
            return findListenerForXMLMessageBasedOnAppIDPattern(feedMessage);
        }
        LOG.info("Returning first listener as feedMessage does not have attachedFiles");
        return listeners.values().iterator().next();
    }

    private SourceMessageListener findListenerForXMLMessageBasedOnAppIDPattern(FeedMessage feedMessage) {
        String fileName = feedMessage.getApplicationID() + ".xml";
        for (FeedDefinition feedDefinition : listeners.keySet()) {
            if (fileNamePatternHelper.fileNameMatchesFeedPattern(fileName, feedDefinition)) {
                return listeners.get(feedDefinition);
            }
        }
        throw new IllegalArgumentException("Cannot have more than one feed associated with an xml input");
    }

    private boolean isXMLMessage(ArgonMessage feedMessage) {
        return !feedMessage.hasAttachedFiles();
    }

    @Override
    public void addMessageListener(FeedDefinition definition, SourceMessageListener sourceMessageListener) {
        listeners.put(definition, sourceMessageListener);
    }

    @Override
    public void setMessageListener(SourceMessageListener sourceMessageListener) {
        this.theMessageListener = sourceMessageListener;
    }

    private void ack(ArgonMessage message) {
        try {
            message.acknowledge();
        } catch (ArgonAcknowledgementFailed argonAcknowledgementFailed) {
            LOG.error("Failed to acknowledge message", argonAcknowledgementFailed);
        }
    }

    private void nack(ArgonMessage message) {
        try {
            message.nack();
        } catch (ArgonAcknowledgementFailed argonNackFailure) {
            LOG.error("Failed to Nack Argon message", argonNackFailure);
        }
    }

    private ArgonMessage receiveMessage() {
        final InstrumentationLogger logger = new InstrumentationLogger("ArgonReceiver-receiveMessage");
        long start = 0;
        if (isInstrumenting) {
            logger.emitOperationStarting();
            start = System.currentTimeMillis();
        }
        try {
            return messageReceiver.receive(getTimeOut());
        } catch (MessageReceiverException e) {
            LOG.warn("Failed to receive message", e);
        } finally {
            if (isInstrumenting) {
                logger.emitOperationFinished(System.currentTimeMillis() - start);
            }
        }
        return null;
    }

    private long getTimeOut() {
        String timeoutStr = vestProperties().getString(ARGON_RECEIVER_TIMEOUT);
        if (timeoutStr == null) {
            return DEFAULT_TIMEOUT;
        }
        return Long.parseLong(timeoutStr);
    }

    private static class NullListener implements SourceMessageListener<ArgonMessage> {
        private static final Log LOGGER = LogFactory.getLog(NullListener.class);

        @Override
        public void processMessage(ArgonMessage message) {
            LOGGER.info("Ignoring message [" + message + "] as no matching feed pattern found associated with it.");
        }
    }
}
