package com.rbs.odc.vest.core.feed.argon;

import com.github.rholder.retry.Attempt;
import com.github.rholder.retry.RetryException;
import com.github.rholder.retry.RetryListener;
import com.github.rholder.retry.Retryer;
import com.github.rholder.retry.RetryerBuilder;
import com.github.rholder.retry.StopStrategies;
import com.github.rholder.retry.WaitStrategies;
import com.rbs.odc.common.parser.TdxFeed;
import com.rbs.odc.core.instrumentation.impl.InstrumentationLogger;
import com.rbs.odc.core.logging.Log;
import com.rbs.odc.core.util.ODCProperties;
import com.rbs.odc.vest.core.feed.message.MessageBackupCreator;
import com.rbs.odc.vest.core.feed.message.TdxEventMessageImpl;
import com.tdx.client.api.streams.TDXDatasetEventConsumer;
import com.tdx.client.api.streams.TDXDatasetStreamEvent;
import com.tdx.schema.TDXDocument;
import com.tdx.schema.TDXDocumentId;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import static com.rbs.odc.core.logging.LogFactory.getLog;

/**
 * Created by srivagc on 8/2/17.
 */
public abstract class AbstractTdxEventDataProcessor implements TDXDatasetEventConsumer {
    protected static final Log LOGGER = getLog(AbstractTdxEventDataProcessor.class);
    private final SourceMessageListener sourceMessageListener;
    protected final TdxFeed tdxFeed;
    private static final boolean isInstrumenting = Boolean.getBoolean("odc.argon.instrumentation");
    private final TdxMessageHeaderExtractor headerExtractor = new TdxMessageHeaderExtractor();

    private final int maxAttempts;
    private final long multiplier;
    private final long maximumTime;

    public AbstractTdxEventDataProcessor(SourceMessageListener listener, TdxFeed tdxFeed) {
        this.sourceMessageListener = listener;
        this.tdxFeed = tdxFeed;
        this.maxAttempts = Integer.getInteger(ODCProperties.TDX_VEST_MAX_RETRY, 100);
        this.multiplier = Long.getLong(ODCProperties.TDX_VEST_RETRY_MULTIPLIER, 100);
        this.maximumTime = Long.getLong(ODCProperties.TDX_VEST_RETRY_DELAY_MAX, 5);
    }

    public void consume(TDXDatasetStreamEvent event) {

        process(event);
    }

    protected void process(TDXDatasetStreamEvent event, boolean remap) {
        long start = System.currentTimeMillis();
        long step = start;
        boolean isErrored = false;
        InstrumentationLogger instrumentationLogger = new InstrumentationLogger("Processing Message record id :" + event.getDocument().getDocumentId().getKey());
        try {
            TDXDocument document = event.getDocument();
            TDXDocumentId docId = document.getDocumentId();

            LOGGER.info("Consumed Document id={key-" + docId.getKey() + " version-" + docId.getVersion().getValue() + "}");
            step = instrumentIt(instrumentationLogger, "retrieved event ", step);

            createRetryer(String.format("Error occurred while consuming message with record id : %s", event.getDocument().getDocumentId().getKey())).call(() -> {
                sourceMessageListener.processMessage(new TdxEventMessageImpl(document, new MessageBackupCreator(), headerExtractor.extractHeaderFromEvent(event, remap, tdxFeed.getName())));
                return true;
            });

            createRetryer(String.format("Error occured while marking message as consumed with record id : %s", event.getDocument().getDocumentId().getKey())).call(() -> {
                event.markAsConsumed();
                return true;
            });
            instrumentIt(instrumentationLogger, "event marked as consumed", step);
        } catch (Throwable e) {
            // something unexpected went wrong with the underlying streaming mechanism, retry later
            isErrored = true;
            LOGGER.error("Error occurred while consuming message with record id : " + event.getDocument().getDocumentId().getKey(), e);
            throw new RuntimeException(e);
        } finally {
            endInstrumenting(instrumentationLogger, isErrored, start);
        }
    }


    private void endInstrumenting(InstrumentationLogger instrumentationLogger, boolean isErrored, long start) {
        if (isErrored) {
            instrumentationLogger.emitOperationFailed(System.currentTimeMillis() - start);
        } else {
            instrumentationLogger.emitOperationFinished(System.currentTimeMillis() - start);
        }
    }

    private long instrumentIt(InstrumentationLogger instrumentationLogger, String stepName, long start) {
        if (isInstrumenting) {
            return instrumentationLogger.emitStepWithStartTime(stepName, start);
        }
        return start;
    }

    public abstract void onError(Throwable throwable);

    protected abstract void process(TDXDatasetStreamEvent event);

    private <T> Retryer<T> createRetryer(String exceptionMessage) throws ExecutionException, RetryException {
        return RetryerBuilder
                .<T>newBuilder()
                .retryIfException()
                .withStopStrategy(StopStrategies.stopAfterAttempt(maxAttempts))
                .withWaitStrategy(WaitStrategies.fibonacciWait(multiplier, maximumTime, TimeUnit.MINUTES))
                .withRetryListener(new RetryListener() {
                    @Override
                    public <V> void onRetry(Attempt<V> attempt) {
                        if (attempt.hasException()) {
                            LOGGER.error(exceptionMessage + String.format(" Retry Count=%d ", attempt.getAttemptNumber()), attempt.getExceptionCause());
                        }
                    }
                })
                .build();
    }
}
