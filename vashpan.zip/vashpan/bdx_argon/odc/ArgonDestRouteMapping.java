package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.vest.core.feed.Feed;

import java.util.ArrayList;
import java.util.List;

public class ArgonDestRouteMapping {
    private String name;
    private String sinkRoute;
    private String sourceRoute;
    private String messageType;
    private int messageVersion;
    private String receiverType;
    private String routePassword;
    private final List<Feed> feeds = new ArrayList<Feed>();

    public String getSinkRoute() {
        return sinkRoute;
    }

    public void setSinkRoute(String sinkRoute) {
        this.sinkRoute = sinkRoute;
    }

    public String getSourceRoute() {
        return sourceRoute;
    }

    public void setSourceRoute(String sourceRoute) {
        this.sourceRoute = sourceRoute;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public int getMessageVersion() {
        return messageVersion;
    }

    public void setMessageVersion(int messageVersion) {
        this.messageVersion = messageVersion;
    }

    public String getRoutePassword() { return routePassword; }

    public void setRoutePassword(String routePassword) { this.routePassword = routePassword; }

    @Override
    public String toString() {
        return "<ArgonDestRouteMapping>" +
                "\nName            [" + name + "]" +
                "\nSink Route      [" + sinkRoute + "]" +
                "\nSource Route    [" + sourceRoute + "]" +
                "\nMessage type    [" + messageType + "]" +
                "\nMessage version [" + messageVersion + "]" +
                "\nReceiver type [" + receiverType + "]" +
                "\nRoute password [" + routePassword + "]" +
                "</ArgonDestRouteMapping>";
    }

    public void add(Feed feed) {
        feeds.add(feed);
    }

    public List<Feed> getFeeds() {
        return feeds;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getReceiverType() {
        return receiverType;
    }

    public void setReceiverType(String receiverType) {
        this.receiverType = receiverType;
    }
}
