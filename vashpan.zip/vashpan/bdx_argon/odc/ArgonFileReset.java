package com.rbs.odc.vest.core.feed.argon;

import java.io.File;

import static com.rbs.odc.vest.core.feed.argon.simulator.ArgonClientSimulator.ACK_MARKER;

public class ArgonFileReset {

    public static void main(String[] args) {
        ArgonFileReset instance = new ArgonFileReset();
        for (String directoryName : args) {
            instance.process(new File(directoryName));
        }
    }

    public void process(File directory) {
        if (directory.isDirectory()) {
            System.out.println(String.format("Scanning directory '%s'.", directory));
            final File[] files = directory.listFiles();
            for (File file : files) {
                process(file);
            }
        } else {
            rename(directory);
        }
    }

    private void rename(File childFile) {
        if (childFile.getAbsolutePath().endsWith(ACK_MARKER)) {
            final String childPath = childFile.getAbsolutePath();
            final File newFile = new File(childPath.substring(0, (childPath.length() - ACK_MARKER.length())));
            System.out.print(String.format("Renaming '%s' to '%s' : ", childFile.getName(), newFile.getName()));
            if (rename(childFile, newFile)) {
                System.out.println("OK");
            } else {
                System.out.println("Failed");
            }
        } else {
            System.out.println("Ignoring file:" + childFile);
        }
    }

    protected boolean rename(File childFile, File newFile) {
        return childFile.renameTo(newFile);
    }

}
