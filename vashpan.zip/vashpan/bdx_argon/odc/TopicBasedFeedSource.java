package com.rbs.odc.vest.core.feed.argon;


import com.rbs.odc.common.parser.TDXMappingParser;
import com.rbs.odc.common.parser.TdxFeed;
import com.rbs.odc.core.event.InterProcessEventsSubscriber;
import com.rbs.odc.core.event.impl.TdxMessageReplayEventImpl;
import com.rbs.odc.core.event.listener.EventSubscriberFactory;
import com.rbs.odc.core.event.listener.JMSExceptionListeners;
import com.rbs.odc.core.event.listener.NullHeartbeater;
import com.rbs.odc.core.event.listener.TopicConnectionProvider;
import com.rbs.odc.core.logging.Log;
import com.rbs.odc.core.logging.LogFactory;
import com.rbs.odc.core.util.ODCProperties;
import com.rbs.odc.vest.core.exception.VestFeedException;
import com.rbs.odc.vest.core.feed.FeedDefinition;
import com.rbs.odc.vest.core.util.TdxReplayEventListener;

import static com.rbs.odc.vest.core.util.FeedContextUtil.getAccessLayerInstance;

public class TopicBasedFeedSource implements FeedSource {

    private static final Log LOGGER = LogFactory.getLog(TopicBasedFeedSource.class);
    private EventSubscriberFactory tdxReplayEventSubscriberFactory;
    private TopicConnectionProvider topicConnectionProvider;
    private InterProcessEventsSubscriber tdxReplayEventSubscriber;
    private TdxReplayEventListener tdxReplayEventListener;
    private final TDXMappingParser parser;

    public TopicBasedFeedSource(TDXMappingParser parser) {
        this.parser = parser;
    }

    @Override
    public void subscribe(FeedDefinition definition, SourceMessageListener sourceMessageListener) throws VestFeedException {

    }

    @Override
    public void subscribe(String feedName, SourceMessageListener listener) throws VestFeedException {
        try {
            ODCProperties odcProperties = new ODCProperties();
            topicConnectionProvider = TopicConnectionProvider.getInstance(odcProperties, new NullHeartbeater());
            String topicKey = ODCProperties.TIBCO_TDX_REPLAY_TOPIC_KEY;
            String topicName = odcProperties.getTdxReplayTopicName();
            String ClientId = feedName + "-ODC-" + odcProperties.getEnvironment();
            tdxReplayEventSubscriberFactory = new EventSubscriberFactory(topicConnectionProvider, topicKey,
                    topicName, new JMSExceptionListeners());
            tdxReplayEventSubscriber = (InterProcessEventsSubscriber) tdxReplayEventSubscriberFactory.createAutoAckDurableSubscriber(odcProperties.getTdxReplayDurableSubscriberName(), ClientId,
                    TdxMessageReplayEventImpl.getMessageSelector(feedName), getAccessLayerInstance());

            TdxFeed tdxFeed = parser.getMappingForFeed(feedName);
            tdxReplayEventListener = new TdxReplayEventListener(listener, tdxFeed);
        } catch (Exception e) {
            throw new VestFeedException("Exception while Subscribing to Topic: ", e);
        }
    }

    @Override
    public void start() {
        tdxReplayEventSubscriber.subscribe(tdxReplayEventListener, null);

    }
}
