package com.rbs.odc.vest.core.feed.argon;

public class ArgonException extends Exception{
    public ArgonException(String message, Throwable cause) {
        super(message, cause);
    }
    public ArgonException(Throwable cause) {
        super(cause);
    }
}
