package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.core.logging.Log;
import com.rbs.odc.core.logging.LogFactory;
import com.rbs.odc.vest.core.feed.argon.MessageReceiver.ReceiverType;
import com.rbs.odc.vest.core.feed.argon.MessageSender.SenderType;
import com.rbsfm.argon.client.cga.Client;
import com.rbsfm.argon.client.cga.ClientException;
import com.rbsfm.argon.client.cga.ClientNodeAddress;
import com.rbsfm.argon.client.cga.Receiver;
import com.rbsfm.argon.client.cga.Sender;
import com.rbsfm.argon.client.cga.StreamList;

public class ArgonClient implements com.rbs.odc.vest.core.feed.argon.Argon {

    private static final Log LOGGER = LogFactory.getLog(ArgonClient.class);

    private final Client client;
    private final String routeAddress;
    private final String clientPassword;
    private final StreamList streamList;

    public ArgonClient(String routeAddress, String clientPassword) {
        this(routeAddress, clientPassword, null, new com.rbs.odc.vest.core.feed.argon.RealArgonClientFactory());
    }

    public ArgonClient(String routeAddress, String clientPassword, StreamList streamList, com.rbs.odc.vest.core.feed.argon.ArgonClientFactory argonClient) {
        this.routeAddress = routeAddress;
        this.clientPassword = clientPassword;
        this.streamList = streamList;
        this.client = argonClient.newArgonClient();
        LOGGER.info("Created Argon client for route  [" + routeAddress + "].");
    }


    @Override
    public void connect() {
        try {
            if (!client.getConnected()) {
                client.connect(new ClientNodeAddress(routeAddress), clientPassword);
            }
            LOGGER.info("Argon client connected.[" + routeAddress + "]");
        } catch (ClientException e) {
            LOGGER.error(String.format("Unable to connect to argon route %s due to %s", routeAddress, e.getMessage()), e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public void disconnect() {
        try {
            client.disconnect();
            LOGGER.info("Argon client disconnected.Argon route details[" + routeAddress + "]");
        } catch (ClientException e) {
            LOGGER.warn(String.format("Problem disconnection from argonRoute %s", routeAddress), e);
        }
    }

    @Override
    public MessageReceiver receiver(ReceiverType type) {
        try {
            Receiver receiver = client.createReceiver(streamList);
            return getMessageReceiver(receiver, type);
        } catch (ClientException e) {
            LOGGER.warn("Exception encountered whilst trying to create argon receiver", e);
            throw new RuntimeException(e);
        }
    }

    private MessageReceiver getMessageReceiver(Receiver receiver, ReceiverType type) {
        switch (type) {
            case SINGLE:
                return new SingleMessageReceiver(receiver);
            case MESSAGE_SET:
                return new MessageSetReceiver(receiver, 60000L);
            case ANY:
                return new AnyMessageReceiver((MessageSetReceiver) getMessageReceiver(receiver, ReceiverType.MESSAGE_SET),
                        (SingleMessageReceiver) getMessageReceiver(receiver, ReceiverType.SINGLE));
            default:
                throw new IllegalArgumentException(String.format("Unmapped ReceiverType : %s ", type));
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public MessageSender sender(SenderType type, String messageType) {
        try {
            Sender sender = client.createSender(messageType);
            return getMessageSender(sender, type);
        } catch (ClientException e) {
            LOGGER.warn("Exception encountered whilst trying to create MessageSender", e);
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    private MessageSender getMessageSender(Sender sender, SenderType type) {
        switch (type) {
            case XML:
                return new XMLMessageSender(sender);
            case FTP:
                return new FtpMessageSender(sender);
            default:
                throw new IllegalArgumentException(String.format("Unmapped ReceiverType : %s ", type));
        }
    }

    @Override
    public String getRouteAddress() {
        return routeAddress;
    }
}
