package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.common.parser.TdxFeed;
import com.tdx.client.api.streams.TDXDatasetStreamEvent;

/**
 * Created by kamraaa on 11/8/17.
 */
public class TdxEventDataProcessorImpl extends AbstractTdxEventDataProcessor {


    public TdxEventDataProcessorImpl(SourceMessageListener listener, TdxFeed tdxFeed) {
        super(listener, tdxFeed);
    }

    @Override
    protected void process(TDXDatasetStreamEvent event) {
        process(event, false);
    }

    @Override
    public void onError(Throwable throwable) {
        LOGGER.fatal("Error while consuming from async api: ", throwable);
        //TDX eats up the exception. Need to shutdown Automapper here.
        System.exit(1);
    }
}
