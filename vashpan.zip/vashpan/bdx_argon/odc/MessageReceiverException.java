package com.rbs.odc.vest.core.feed.argon;

public class MessageReceiverException extends Exception {

    public MessageReceiverException(Exception cause) {
        super(cause);
    }
}
