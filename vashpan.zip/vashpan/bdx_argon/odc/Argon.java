package com.rbs.odc.vest.core.feed.argon;

public interface Argon {
    void connect();

    void disconnect();

    com.rbs.odc.vest.core.feed.argon.MessageReceiver receiver(
            com.rbs.odc.vest.core.feed.argon.MessageReceiver.ReceiverType type);

    @SuppressWarnings("unchecked")
    com.rbs.odc.vest.core.feed.argon.MessageSender sender(
            com.rbs.odc.vest.core.feed.argon.MessageSender.SenderType type, String messageType);

    String getRouteAddress();
}
