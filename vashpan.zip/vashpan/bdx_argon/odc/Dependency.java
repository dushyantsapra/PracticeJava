package com.rbs.odc.vest.core.feed.argon;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

class Dependency {

	private final String messageType;
	private final Long id;

	public Dependency(String messageType, Long id) {
		this.messageType = messageType;
		this.id = id;
	}

	public String getMessageType() {
		return messageType;
	}

	public Long getId() {
		return id;
	}
	
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != getClass()) {
            return false;
        }
        Dependency other = (Dependency) obj;
        return new EqualsBuilder()
        .append(this.messageType, other.messageType)
        .append(this.id, other.id)
        .isEquals();
    }
    
    @Override
    public int hashCode() {
    	return new HashCodeBuilder()
        .append(this.messageType)
        .append(this.id)
        .toHashCode();
    }
    
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this,ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
