package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.vest.core.feed.message.ArgonMessage;

public class AnyMessageReceiver implements MessageReceiver {
    private MessageReceiver active;
    private MessageReceiver other;

    public AnyMessageReceiver(MessageSetReceiver messageSetReceiver, SingleMessageReceiver singleMessageReceiver) {
        this.active = singleMessageReceiver;
        this.other = messageSetReceiver;
    }

    @Override
    public ArgonMessage receive(long timeOut) throws MessageReceiverException {
    	ArgonMessage message = active.receive(timeOut);
        if (message != null) {
            return message;
        }
        return flipReceivers().receive(timeOut);
    }

    private MessageReceiver flipReceivers() {
        MessageReceiver temp = active;
        active = other;
        other = temp;
        return active;
    }
}
