package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.core.logging.Log;
import com.rbs.odc.core.logging.LogFactory;
import com.rbsfm.argon.client.cga.ClientException;
import com.rbsfm.argon.client.cga.ID;
import com.rbsfm.argon.client.cga.Sender;

public class XMLMessageSender implements MessageSender<XMLSentMessage> {

    private static final Log LOGGER = LogFactory.getLog(XMLMessageSender.class);
    private final Sender sender;

    public XMLMessageSender(Sender sender) {
        this.sender = sender;
    }

    @Override
    public Long send(XMLSentMessage sentMessage) throws MessageSenderException {
        ID id;

        try {
            id = sender.sendXML(sentMessage.getApplicationID(), sentMessage.getMessageTypeVersion(),
                    sentMessage.getDependencyList(), sentMessage.getMessage());
            LOGGER.info("Sent message successfully Argon Id : " + id.getPersistable());
        } catch (ClientException e) {
            throw new MessageSenderException(e, sentMessage);
        }
        return new Long(id.getPersistable());
    }
}
