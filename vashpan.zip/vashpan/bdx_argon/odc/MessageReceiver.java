package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.vest.core.feed.message.ArgonMessage;

public interface MessageReceiver {
    enum ReceiverType {
        SINGLE,
        MESSAGE_SET,
        ANY
    }

    ArgonMessage receive(long timeOut) throws MessageReceiverException;

}
