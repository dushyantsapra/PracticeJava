package com.rbs.odc.vest.core.feed.argon;

import com.rbsfm.argon.client.cga.ClientException;
import com.rbsfm.argon.client.cga.DependencyList;
import com.rbsfm.argon.client.cga.ID;
import com.rbsfm.argon.client.cga.SentAssociatedFileList;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.util.ArrayList;
import java.util.List;

public class FtpSentMessage implements SentMessage {

	private final String applicationID;
	private final String messageType;
	private final int messageTypeVersion;
	private final List<String> files;
	private final List<Dependency> dependencies = new ArrayList<Dependency>();

	public FtpSentMessage(String applicationID, String messageType, int messageTypeVersion, List<String> files) {
		this.applicationID = applicationID;
		this.messageType = messageType;
		this.messageTypeVersion = messageTypeVersion;
		this.files = files;
	}

	@Override
	public String getApplicationID() {
		return applicationID;
	}

	@Override
	public String getMessageType() {
		return messageType;
	}

	@Override
	public int getMessageTypeVersion() {
		return messageTypeVersion;
	}

	public List<String> getFiles() {
		return files;
	}
	
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != getClass()) {
            return false;
        }
        FtpSentMessage other = (FtpSentMessage) obj;
        return new EqualsBuilder()
        .append(this.messageType, other.messageType)
        .append(this.messageTypeVersion, other.messageTypeVersion)
        .append(this.files, other.files)
        .append(this.dependencies, other.dependencies)
        .isEquals();
    }
    
    @Override
    public int hashCode() {
    	return new HashCodeBuilder()
        .append(this.messageType)
        .append(this.messageTypeVersion)
        .append(this.files)
        .append(this.dependencies)
        .toHashCode();
    }
    
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this,ToStringStyle.SHORT_PREFIX_STYLE);
    }

	@Override
	public void addDependency(String messageType, Long id) {
		dependencies.add(new Dependency(messageType, id));
	}
	
	public DependencyList getDependencyList()throws ClientException {
		DependencyList dependencyList = new DependencyList();
		for(Dependency d : dependencies){
		dependencyList.add(d.getMessageType(), new ID(String.valueOf(d.getId())));	
		}
		return dependencyList;
	}
	
	public SentAssociatedFileList getAssociatedFileList() throws ClientException {
		SentAssociatedFileList fileList = new SentAssociatedFileList();
		for (String file : getFiles()) {
			fileList.addAssociatedFile(file);
		}
		return fileList;
	}
}
