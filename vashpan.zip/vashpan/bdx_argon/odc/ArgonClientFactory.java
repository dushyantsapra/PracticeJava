package com.rbs.odc.vest.core.feed.argon;

import com.rbsfm.argon.client.cga.Client;

public interface ArgonClientFactory {

    Client newArgonClient();
}
