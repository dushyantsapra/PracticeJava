package com.rbs.odc.vest.core.feed.argon;

public class FailedToFetchArgonFile extends ArgonException {
    public FailedToFetchArgonFile(String message, Throwable cause) {
        super(message, cause);
    }
    
}
