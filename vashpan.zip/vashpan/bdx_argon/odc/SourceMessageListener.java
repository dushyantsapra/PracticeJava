package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.vest.core.feed.message.SourceMessage;

public interface SourceMessageListener<T extends SourceMessage> {
	void processMessage(T message);
}
