package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.core.logging.Log;
import com.rbs.odc.core.logging.LogFactory;
import com.rbsfm.argon.client.cga.ClientException;
import com.rbsfm.argon.client.cga.ID;
import com.rbsfm.argon.client.cga.Sender;

public class FtpMessageSender implements MessageSender<FtpSentMessage> {

	private static final Log LOGGER = LogFactory.getLog(FtpMessageSender.class);
	private final Sender sender;
	private final FtpMetaMessageBuilder metaMessageBuilder;

	public FtpMessageSender(Sender sender) {
		this(sender, new FtpMetaMessageBuilder());
	}

	public FtpMessageSender(Sender sender, FtpMetaMessageBuilder metaMessageBuilder) {
		this.sender = sender;
		this.metaMessageBuilder = metaMessageBuilder;
	}

	@Override
	public Long send(FtpSentMessage sentMessage) throws MessageSenderException {
		ID id;
		try {
			id = sender.sendXML(sentMessage.getApplicationID(), sentMessage.getMessageTypeVersion(),
					sentMessage.getDependencyList(), sentMessage.getAssociatedFileList(), metaMessage(sentMessage));
			LOGGER.info("Sent message successfully Argon Id : " + id.getPersistable());
		} catch (ClientException e) {
			throw new MessageSenderException(e, sentMessage);
		}
		return new Long(id.getPersistable());
	}

	private String metaMessage(FtpSentMessage sentMessage) throws MessageSenderException {
		try {
			return metaMessageBuilder.build(sentMessage.getFiles());
		} catch (Exception e) {
			throw new MessageSenderException("Unable to build the Argon Ftp Meta Message Info due to " + e.getMessage(), e);
		}
	}
}
