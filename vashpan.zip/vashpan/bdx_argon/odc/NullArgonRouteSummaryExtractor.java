package com.rbs.odc.vest.core.feed.argon;

public class NullArgonRouteSummaryExtractor implements ArgonRouteSummaryExtractor {
    @Override
    public int getPendingMessages() throws ArgonRouteSummaryException {
        return 0;
    }
}
