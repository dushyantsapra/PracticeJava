/**
 *
 */
package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.vest.core.exception.VestFeedException;
import com.rbs.odc.vest.core.feed.FeedDefinition;

public interface FeedSource {

    void subscribe(FeedDefinition definition, SourceMessageListener sourceMessageListener) throws VestFeedException;

    void subscribe(String argonRoute, SourceMessageListener listener) throws VestFeedException;

    void start();
}