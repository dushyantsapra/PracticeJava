package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.vest.core.feed.Feed;

public class ArgonRouteMappings {

    private final ArgonMappingsParser parser;

    public ArgonRouteMappings(ArgonMappingsParser parser) {
        this.parser = parser;
    }

    public String getArgonSinkRoute(Feed feed) {
        ArgonDestRouteMapping route = getParser().getArgonDestRouteMapping(feed);
        if (route != null) {
            return route.getSinkRoute();
        }
        return null;
    }

    public ArgonDestRouteMapping getArgonDestRouteMapping(Feed feed, String sourceRouteName) {
        return getParser().getArgonDestRouteMapping(feed, sourceRouteName);
    }

    private ArgonMappingsParser getParser() {
        return parser;
    }

    public String getArgonSinkRoute(String feedName) {
        return getParser().getSink(feedName);
    }
}
