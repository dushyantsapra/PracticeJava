package com.rbs.odc.vest.core.feed.argon;

public interface ArgonSender {

	void connect();

    void disconnect();
    
    Long send(SentMessage message) throws MessageSenderException;
    
    String getRouteAddress();
}
