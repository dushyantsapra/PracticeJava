package com.rbs.odc.vest.core.feed.argon;

public class ArgonAcknowledgementFailed extends ArgonException{
    public ArgonAcknowledgementFailed(Throwable cause) {
        super(cause);
    }
}
