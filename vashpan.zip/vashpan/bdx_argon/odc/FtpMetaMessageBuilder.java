package com.rbs.odc.vest.core.feed.argon;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

public class FtpMetaMessageBuilder {

    public String build(List<String> files) throws TransformerException, ParserConfigurationException {
        Document doc = newDocument();

        Element rootNode = doc.createElement("file_transfer");
        doc.appendChild(rootNode);

        for (String fileName : getFileNames(files)) {
            rootNode.appendChild(createFileNameElement(doc, fileName));
        }

        return xml(doc);
    }

    private Document newDocument() throws ParserConfigurationException {
        return DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
    }

    private Element createFileNameElement(Document doc, String fileName) {
        Element newFileElement = doc.createElement("filename");
        Text fileNameNode = doc.createTextNode(fileName);
        newFileElement.appendChild(fileNameNode);
        return newFileElement;
    }

    private String xml(Document document) throws TransformerException {
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        StringWriter stringWriter = new StringWriter();
        transformer.transform(new DOMSource(document), new StreamResult(stringWriter));
        return stringWriter.toString();
    }

    private List<String> getFileNames(List<String> filePaths) {
        List<String> fileNames = new ArrayList<String>();
        for (String filePath : filePaths) {
            fileNames.add(new File(filePath).getName());
        }
        return fileNames;
    }
}
