package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.common.api.TdxDatasetStreamProvider;
import com.rbs.odc.common.parser.TdxFeed;
import com.rbs.odc.vest.core.exception.TDXEventCompletionException;
import com.tdx.client.api.streams.TDXDatasetStreamEvent;
import com.tdx.client.core.streams.DatasetStreamNewDocumentEvent;


/**
 * Created by kamraaa on 11/8/17.
 */
public class TdxRemapEventDataProcessorImpl extends AbstractTdxEventDataProcessor {

    public TdxRemapEventDataProcessorImpl(SourceMessageListener listener, TdxFeed tdxFeed) {
        super(listener, tdxFeed);
    }

    @Override
    protected void process(TDXDatasetStreamEvent event) {
        if ((event.getClass().isAssignableFrom(DatasetStreamNewDocumentEvent.class))) {
            throw new TDXEventCompletionException("New Document received. Stopping consumer.");
        }
        process(event, true);
    }


    @Override
    public void onError(Throwable throwable) {
        if (throwable instanceof TDXEventCompletionException) {
            new TdxDatasetStreamProvider().deleteEventStream(tdxFeed);
            LOGGER.info("--------------------------Remapping completed-----------------------");
        } else {
            LOGGER.fatal("Error while consuming from async api: ", throwable);
            //TDX eats up the exception. Need to shutdown Automapper here.
            System.exit(1);
        }
    }

}
