package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.access.domain.MessageHeader;
import com.tdx.client.api.streams.TDXDatasetStreamEvent;
import com.tdx.client.api.streams.TDXDatasetStreamExistingDocumentEvent;
import com.tdx.client.api.streams.TDXDatasetStreamNewDocumentEvent;
import com.tdx.client.core.streams.DatasetStreamExistingDocumentEvent;
import com.tdx.client.core.streams.DatasetStreamNewDocumentEvent;

import java.util.Date;

import static com.rbs.odc.core.domain.builder.DomainObjectBuilders.messageHeader;

/**
 * Created by gargptr on 06-Oct-17.
 */
public class TdxMessageHeaderExtractor {

    public MessageHeader extractHeaderFromEvent(TDXDatasetStreamEvent event, boolean remap, String feedName) {
        Date validFrom = null;

        if (event.getClass().isAssignableFrom(DatasetStreamExistingDocumentEvent.class)) {
            TDXDatasetStreamExistingDocumentEvent tdxDatasetStreamExistingDocumentEvent = (TDXDatasetStreamExistingDocumentEvent) event;
            validFrom = new Date(tdxDatasetStreamExistingDocumentEvent.getDocumentCreationEpochSeconds());
        } else if (event.getClass().isAssignableFrom(DatasetStreamNewDocumentEvent.class)) {
            TDXDatasetStreamNewDocumentEvent tdxDatasetStreamNewDocumentEvent = (TDXDatasetStreamNewDocumentEvent) event;
            validFrom = new Date(tdxDatasetStreamNewDocumentEvent.getDocumentCreationEpochSeconds());
        }


        String recordId = event.getDocument().getDocumentId().getKey();
        long recordVersion = event.getDocument().getDocumentId().getVersion().getValue();

        return messageHeader()
                .withValidFrom(validFrom)
                .withRecordId(recordId)
                .withRecordVersion(recordVersion)
                .withBackFill(remap)
                .withFeedName(feedName)
                .build();
    }
}
