package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.core.logging.Log;
import com.rbs.odc.security.SsoTokenGenerator;
import com.rbs.odc.vest.core.exception.VestFeedException;
import com.rbs.odc.vest.core.feed.FeedDefinition;
import com.rbs.odc.vest.core.util.BeanFactory;
import rbs.gbm.dx.webService.impl.RdxSessionFactory;
import rbs.gbm.dx.webService.impl.rdx.SubscriptionCriteriaBuilder;
import rbs.gbm.dx.webService.interfaces.IRdxSession;
import rbs.gbm.dx.webService.interfaces.rdx.ISubscriptionCriteria;

import static com.rbs.odc.core.logging.LogFactory.getLog;

/**
 * Created by kumprak on 26/04/2018.
 */
public class RdxInstrumentFeedSource implements FeedSource {

    private static final Log LOGGER = getLog(RdxInstrumentFeedSource.class);
    private IRdxSession session;
    private ISubscriptionCriteria criteria;
    private RdxInstrumentFeedHandler rdxInstrumentFeedHandler;
    private RdxDetailsProvider rdxDetailsProvider;

    public RdxInstrumentFeedSource(RdxDetailsProvider rdxDetailsProvider) {
        this.rdxDetailsProvider = rdxDetailsProvider;
    }

    @Override
    public void subscribe(FeedDefinition definition, SourceMessageListener sourceMessageListener) throws VestFeedException {
        //Nothing to do here
    }

    @Override
    public void subscribe(String feedName, SourceMessageListener listener) throws VestFeedException {
        try {
            Long changeId = getChangeId();
            rdxInstrumentFeedHandler = new RdxInstrumentFeedHandler(listener);
            session = getRdxSession();
            SubscriptionCriteriaBuilder builder = new SubscriptionCriteriaBuilder();
            if (changeId > 0) {
                builder.setStartChangeId(changeId);
            }
            criteria = builder.buildSubscriptionCriteria();
            LOGGER.info("Subscribed to RDX api with change id: " + changeId);
        } catch (Exception e) {
            throw new VestFeedException(e.getMessage(), e);
        }
    }

    @Override
    public void start() {
        try {
            session.subscribe(criteria, rdxInstrumentFeedHandler, rdxDetailsProvider.getClientApplication());
        } catch (Exception e) {
            LOGGER.error("Error in subscribing to rdx api.", e);
        }
    }

    protected IRdxSession getRdxSession() throws Exception {
        String ssoToken = SsoTokenGenerator.getSSOToken(rdxDetailsProvider.getUserName(), rdxDetailsProvider.getPassword(), rdxDetailsProvider.getPermission());
        RdxSessionFactory factory = new RdxSessionFactory();
        return factory.createSession(rdxDetailsProvider.getClientApplication(), rdxDetailsProvider.getVersion(), rdxDetailsProvider.getEnvironment(), ssoToken);
    }

    protected Long getChangeId() {
        return BeanFactory.getRdxSequenceDAO().fetch("INSTRUMENT").getChangeId();
    }

}
