package com.rbs.odc.vest.core.feed.argon;

public interface SentMessage {

	String getApplicationID();

	String getMessageType();
	
	int getMessageTypeVersion();
	
	void addDependency(String messageType, Long id);
}
