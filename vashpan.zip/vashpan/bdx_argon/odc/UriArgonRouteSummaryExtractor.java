package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.core.xml.XMLConverter;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.DOMBuilder;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.util.List;

public class UriArgonRouteSummaryExtractor implements ArgonRouteSummaryExtractor {
    private final String uri;
    private final String route;
    private final XMLConverter xmlConverter = new XMLConverter();

    public UriArgonRouteSummaryExtractor(String uri, String route) {
        this.uri = uri;
        this.route = route;
    }

    @Override
    public int getPendingMessages() throws ArgonRouteSummaryException {
        final String xPathString = String.format("//route-summary/route[receiving-client='%s']/pending", route);
        try {
            final Document document = getDocument();
            final Element element = getElement(document, xPathString);
            return getIntegerValue(element);
        } catch (Throwable t) {
            throw new ArgonRouteSummaryException(String.format("Unable to get pending messages from '%s' for route '%s'.", uri, route), t);
        }
    }

    private Document getDocument() throws ParserConfigurationException, IOException, SAXException {
        final DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        DOMBuilder jdomBuilder = new DOMBuilder();
        return jdomBuilder.build(builder.parse(uri));
    }

    private Element getElement(Document document, String xPathString) throws XPathExpressionException, JDOMException {
        List<Element> elementList = xmlConverter.extractElements(document, xPathString);
        Element element = null;
        if (elementList != null && !elementList.isEmpty()) {
            element = elementList.get(0);// As per current impl,get the first route in case of multiple sources
        }
        if (element == null) {
            throw new XPathExpressionException(String.format("Cannot find node for xpath '%s'.", xPathString));
        }
        return element;
    }

    private int getIntegerValue(Element element) {
        final String content = element.getTextTrim();
        return ("-".equals(content)) ? 0 : Integer.valueOf(content);
    }
}
