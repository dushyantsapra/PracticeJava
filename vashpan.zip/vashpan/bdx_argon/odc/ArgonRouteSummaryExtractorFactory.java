package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.core.logging.Log;
import com.rbs.odc.core.logging.LogFactory;
import com.rbs.odc.vest.core.feed.Feed;
import com.rbs.odc.vest.core.util.VestPropertiesHelper;

import static com.rbs.odc.core.util.StringUtils.isNullOrEmpty;
import static com.rbs.odc.vest.core.Main.ARGON_SIMULATOR_PROP;
import static com.rbs.odc.vest.core.util.VestPropertiesHelper.ARGON_STATUS_URI;
import static java.lang.Boolean.getBoolean;

public class ArgonRouteSummaryExtractorFactory {
    private static final Log LOGGER = LogFactory.getLog(ArgonRouteSummaryExtractorFactory.class);
    private static ArgonRouteMappings argonRouteMappings = new ArgonRouteMappings(new ArgonMappingsParser());
    private static boolean useAgronSimulator = getBoolean(ARGON_SIMULATOR_PROP);

    public static ArgonRouteSummaryExtractor create(Feed feed) {
      return create(feed, useAgronSimulator);
    }

    // for testing purpose only, it should be never called in main flow
    public static ArgonRouteSummaryExtractor create(Feed feed, Boolean useAgronSimulator) {
        if (useAgronSimulator) {
            LOGGER.info("Using Argon simulator, pending messages will not be checked.");
            return new NullArgonRouteSummaryExtractor();
        }

        final String uri = getArgonUriForEnvironment();
        if (isNullOrEmpty(uri)) {
            LOGGER.info(
                    "Property for Argon status service (%s) has not been configured, pending messages will not be checked.",
                    ARGON_STATUS_URI);
            return new NullArgonRouteSummaryExtractor();
        }

        final String route = getArgonRouteForFeed(feed);
        if (isNullOrEmpty(route)) {
            LOGGER.error("No Argon route configured for feed '%s', pending messages will not be checked.", null, feed);
            return new NullArgonRouteSummaryExtractor();
        }

        LOGGER.info("Pending Argon messages will be checked for feed '%s' at '%s' with route '%s'.", feed, uri, route);
        return new UriArgonRouteSummaryExtractor(uri, route);
    }

    private static String getArgonUriForEnvironment() {
        return VestPropertiesHelper.argonStatusUri();
    }

    private static String getArgonRouteForFeed(Feed feed) {
        return argonRouteMappings.getArgonSinkRoute(feed);
    }

    private ArgonRouteSummaryExtractorFactory() {
    }// util class

}
