package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.core.logging.Log;
import com.rbs.odc.core.logging.LogFactory;
import com.rbs.odc.core.persistence.db.mapper.Performance;
import com.rbs.odc.vest.core.feed.message.MessageBackupCreator;
import com.rbs.odc.vest.core.feed.message.RdxInstrumentMessageImpl;
import rbs.gbm.dx.webService.interfaces.IRdxSession;
import rbs.gbm.dx.webService.interfaces.rdx.IReferenceData;
import rbs.gbm.dx.webService.interfaces.rdx.IReferenceDataStatus;
import rbs.gbm.mdx.messaging.IReferenceDataChangeHandler;
import rbs.gbm.mdx.webService.interfaces.ReferenceDataOperationType;

import java.util.Date;

/**
 * Created by kumprak on 01/05/2018.
 */
public class RdxInstrumentFeedHandler implements IReferenceDataChangeHandler {

    private static final Log LOGGER = LogFactory.getLog(RdxInstrumentFeedHandler.class);
    private SourceMessageListener listener;

    public RdxInstrumentFeedHandler(SourceMessageListener listener) {
        this.listener = listener;
    }

    @Override
    public void onRdxDocChange(final IRdxSession source,
            final Object handlerRef, final Object clientRefObject,
            final IReferenceData referenceData, ReferenceDataOperationType operationType) {
        try {
            Date date = new Date();
            Performance.start("Rdx Instrument Processing");
            LOGGER.info(
                    date.toString() + " -> A reference data update has been received with operationType = " + operationType.toString() + "\nRdx ID: " + referenceData.getRdxId() + ", Rdx Change Id: " +
                            referenceData.getRdxChangeId() + ", Rdx Series Id: " + referenceData.getRdxSeriesId());

            listener.processMessage(new RdxInstrumentMessageImpl(referenceData, new MessageBackupCreator()));
            LOGGER.info("Rdx Change Id " + referenceData.getRdxChangeId() + " processed successfully at ODC.");
            Performance.end("Rdx Instrument Processing");
        } catch (Exception e) {
            LOGGER.error("Error in processing Rdx Change Id: " + referenceData.getRdxChangeId() + ", Rdx Series Id: " + referenceData.getRdxSeriesId(), e);
        }
    }

    @Override
    public void onRdxStatusChange(final IRdxSession source, final Object handlerRef,
            final Object clientRefObject, final IReferenceDataStatus status) {
        Date date = new Date();
        LOGGER.info(date.toString() + " onRdxStatusChange clientRefObject= " + clientRefObject + " status= " + status.getStatus().toString());
        LOGGER.warn("This method should not get called as ODC is using rdx api for read-only purpose.");
    }

    @Override
    public void onSubscriptionRevoked(final IRdxSession source,
            final Object handlerRef, final Object clientRefObject) {
        LOGGER.info("Receive subscription revocation: handlerRef=" + handlerRef + ", and clientRef: " + clientRefObject);
        LOGGER.info("If this function gets called, it means that your subscription has been revoked. Please contact DX Support.");
    }

}