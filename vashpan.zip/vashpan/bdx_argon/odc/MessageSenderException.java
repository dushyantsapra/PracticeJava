package com.rbs.odc.vest.core.feed.argon;

import com.rbsfm.argon.client.cga.ClientException;

public class MessageSenderException extends Exception {
	
	public static final int VALIDATION_ERROR_MESSAGE_LOG_NUMBER = 2020;
	
    public MessageSenderException(String message, Throwable cause) {
        super(message, cause);
    }

    public MessageSenderException(ClientException cause, SentMessage sentMessage) {
        this(messageForValidationError(cause, sentMessage), cause);
    }
    
	private static String messageForValidationError(ClientException ce, SentMessage sentMessage){
		if(isValidationException(ce)){
			return "Error probably due to the missing entry in the argon_settings.xml file to disable Message Validations. " +
			"Adding the following in argon_settings.xml might help \n"
			+ missingValidationMessage(sentMessage.getMessageType(), sentMessage.getMessageTypeVersion()); 
		} else {
			return ce.getMessage();
		}
	}
	
	private static boolean isValidationException(ClientException ce){
		return ce.getLogNumber() == VALIDATION_ERROR_MESSAGE_LOG_NUMBER;
	}
	
	public static String missingValidationMessage(String messageType, int version){
		return String.format("<Type-%s>\n\t<version-%s fast=\"false\"/>\n</Type-%s>", messageType, version, messageType);
	}	
}
