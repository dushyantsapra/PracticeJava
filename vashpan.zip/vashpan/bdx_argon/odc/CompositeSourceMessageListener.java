package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.vest.core.feed.message.ArgonMessage;

public class CompositeSourceMessageListener implements SourceMessageListener<ArgonMessage> {

    private final SourceMessageListener one;
    private final SourceMessageListener two;

    public CompositeSourceMessageListener(SourceMessageListener one, SourceMessageListener two) {
        this.one = one;
        this.two = two;
        if (one == null || two == null) {
             throw new RuntimeException("Constructor args must not be null");
        }
    }

    @Override
    public void processMessage(ArgonMessage message) {
        one.processMessage(message);
        two.processMessage(message);
    }

}
