package com.rbs.odc.vest.core.feed.argon;

import com.rbsfm.argon.client.cga.Client;

public class RealArgonClientFactory implements com.rbs.odc.vest.core.feed.argon.ArgonClientFactory {
    @Override
    public Client newArgonClient() {
        return new Client();
    }
}
