package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.core.logging.Log;
import com.rbs.odc.core.logging.LogFactory;
import com.rbs.odc.core.util.Encryptor;
import com.rbs.odc.core.xml.XMLConverter;
import com.rbs.odc.vest.core.exception.SkipMessageException;
import com.rbs.odc.vest.core.feed.Feed;
import com.rbs.odc.vest.core.feed.XmlDocumentInitializer;
import com.rbs.odc.vest.core.feed.argon.MessageReceiver.ReceiverType;
import com.rbs.odc.vest.core.util.VestPropertiesHelper;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.rbs.odc.vest.core.util.VestPropertiesHelper.vestProperties;
import static java.lang.String.format;

public class ArgonMappingsParser {

    private static final Log LOG = LogFactory.getLog(ArgonMappingsParser.class);
    private final XMLConverter xmlConverter = new XMLConverter();
    private final Map<String, String> nameToSinkRoute = new ConcurrentHashMap<String, String>();
    private final Map<Feed, List<com.rbs.odc.vest.core.feed.argon.ArgonDestRouteMapping>> feedToArgonDestRouteMappings
            = new ConcurrentHashMap<Feed, List<com.rbs.odc.vest.core.feed.argon.ArgonDestRouteMapping>>();
    private final Map<String, List<com.rbs.odc.vest.core.feed.argon.ArgonDestRouteMapping>> sinkToArgonDestRouteMappings
            = new ConcurrentHashMap<String, List<com.rbs.odc.vest.core.feed.argon.ArgonDestRouteMapping>>();
    private Document doc;

    public ArgonMappingsParser() {
        init(getMappingFileStream());
    }

    public ArgonMappingsParser(InputStream stream) {
        init(stream);
    }

    private void init(InputStream stream) {
        doc = getDoc(stream);

        List<Element> sinks = extractElementsFromDoc("argon/routeMappings/sinkRoute");
        for (Element sink1 : sinks) {
            String sink = sink1.getAttributeValue("value");
            mapSink(sink);
        }
    }

    private List<Element> extractElementsFromDoc(String exprStr) {
        try {
            return xmlConverter.extractElements(doc, exprStr);
        } catch (JDOMException e) {
            throw new RuntimeException(e);
        }
    }

    public List<ArgonDestRouteMapping> getArgonDestMappings(String sinkRouteId) {
        List<ArgonDestRouteMapping> routes = sinkToArgonDestRouteMappings.get(sinkRouteId);
        if (routes == null) {
            return Collections.emptyList();
        }
        return Collections.unmodifiableList(routes);
    }

    public ArgonDestRouteMapping getArgonDestRouteMapping(Feed feed) {
        return getArgonDestRouteMapping(feed, null);
    }

    public ArgonDestRouteMapping getArgonDestRouteMapping(Feed feed, String sourceRouteName) {
        List<ArgonDestRouteMapping> routeMappings = feedToArgonDestRouteMappings.get(feed);
        if (routeMappings == null) {
            return null;
        }
        if (sourceRouteName == null || routeMappings.size() == 1) {
            return routeMappings.get(0);
        }
        return findMappingForSourceRouteName(sourceRouteName, routeMappings);
    }

    private com.rbs.odc.vest.core.feed.argon.ArgonDestRouteMapping findMappingForSourceRouteName(String sourceRouteName,
            List<com.rbs.odc.vest.core.feed.argon.ArgonDestRouteMapping> routeMappings) {
        for (com.rbs.odc.vest.core.feed.argon.ArgonDestRouteMapping routeMapping : routeMappings) {
            if (routeMapping.getSourceRoute().equals(sourceRouteName)) {
                return routeMapping;
            }
        }
        return null;
    }

    private com.rbs.odc.vest.core.feed.argon.ArgonDestRouteMapping mapSinkElements(String sink, Element sinkElement) {
        com.rbs.odc.vest.core.feed.argon.ArgonDestRouteMapping routeMapping = new
                com.rbs.odc.vest.core.feed.argon.ArgonDestRouteMapping();
        routeMapping.setSinkRoute(sink);
        try {

            Element parent = (Element) sinkElement.getParent().getParent();
            routeMapping.setName(parent.getAttributeValue("name"));
            routeMapping.setSourceRoute(xmlConverter.string(sinkElement, "routeAddress"));
            routeMapping.setMessageType(xmlConverter.string(sinkElement, "messageType"));
            routeMapping.setMessageVersion(xmlConverter.integer(sinkElement, "messageVersion"));
            routeMapping.setReceiverType(xmlConverter.string(parent, "receiverType"));
            routeMapping.setRoutePassword(Encryptor.INSTANCE.decrypt(xmlConverter.string(parent, "routePassword")));
            List<Element> feeds = xmlConverter.extractElements(parent, "feeds/feed");
            for (Element feedElement : feeds) {
                addFeedToRouteMapping(routeMapping, feedElement);
            }
        } catch (JDOMException jde) {
            throw new RuntimeException(jde);
        } catch (NumberFormatException e) {
            LOG.error(String.format("Exception occured while mapping route : %s ", routeMapping.getSinkRoute()), e);
            throw e;
        }
        return routeMapping;
    }

    private void addFeedToRouteMapping(
            com.rbs.odc.vest.core.feed.argon.ArgonDestRouteMapping routeMapping, Element feedElement) {
        Feed theFeed = toFeed(feedElement);
        if (theFeed != null) {
            routeMapping.add(theFeed);
        }
    }

    protected Feed toFeed(Element feed) {
        try {
            return Feed.getFeedByName(feed.getText().trim());
        } catch (Exception e) {
            LOG.warn("Couldn't find feed for feed name: " + feed.getText().trim());
        }
        return null;
    }

    private void mapSink(String sink) {
        List<Element> sinkElements = extractSink(sink);
        for (Element sinkElement : sinkElements) {
            ArgonDestRouteMapping route = mapSinkElements(sink, sinkElement);
            mapFeedWithArgonDestRouteMapping(route);
            mapSinkWithArgonDestRouteMapping(route);
            mapNameWithArgonDestRouteMapping(route);
        }
    }

    private List<Element> extractSink(String sinkRouteId) {
        return extractElementsFromDoc(
                format("argon/routeMappings/sinkRoute[@value='%s']/sourceRoutes/sourceRoute", sinkRouteId));
    }

    private void mapFeedWithArgonDestRouteMapping(ArgonDestRouteMapping routeMapping) {
        for (Feed feed : routeMapping.getFeeds()) {
            List<ArgonDestRouteMapping> routeMappings = feedToArgonDestRouteMappings.get(feed);
            if (routeMappings == null) {
                routeMappings = new ArrayList<ArgonDestRouteMapping>();
                feedToArgonDestRouteMappings.put(feed, routeMappings);
            }
            routeMappings.add(routeMapping);
        }
    }

    private void mapSinkWithArgonDestRouteMapping(ArgonDestRouteMapping routeMapping) {
        List<ArgonDestRouteMapping> routes = sinkToArgonDestRouteMappings.get(routeMapping.getSinkRoute());
        if (routes == null) {
            routes = new ArrayList<ArgonDestRouteMapping>();
            sinkToArgonDestRouteMappings.put(routeMapping.getSinkRoute(), routes);
        }
        routes.add(routeMapping);
    }

    private void mapNameWithArgonDestRouteMapping(ArgonDestRouteMapping routeMapping) {
        String name = routeMapping.getName();
        if (name != null) {
            if (nameToSinkRoute.containsKey(name)) {
                String existingSink = nameToSinkRoute.get(name);
                if (!existingSink.equals(routeMapping.getSinkRoute())) {
                    throw new RuntimeException(
                            "Already has name:" + name + " with different sink:" + existingSink + "!=" + routeMapping
                                    .getSinkRoute());
                }
            } else {
                nameToSinkRoute.put(name, routeMapping.getSinkRoute());
            }
        }
    }

    private Document getDoc(InputStream stream) {
        try {
            return new XmlDocumentInitializer().initializeDocument(stream);
        } catch (SkipMessageException e) {
            throw new RuntimeException(e);
        }
    }

    private InputStream getMappingFileStream() {
        String odcArgonMappings = vestProperties().getString(VestPropertiesHelper.ARGON_MAPPINGS_FILE_PATH);
        LOG.info(String.format("Loading ArgonMappingParser file from classpath : %s ", odcArgonMappings));
        return getClass().getClassLoader().getResourceAsStream(odcArgonMappings);
    }

    public ReceiverType receiverTypeFor(String sinkRouteId) {
        try {
            String receiverType = xmlConverter
                    .string(doc, format("argon/routeMappings/sinkRoute[@value='%s']/receiverType", sinkRouteId));
            if (receiverType == null) {
                return ReceiverType.SINGLE;
            }
            return ReceiverType.valueOf(receiverType.toUpperCase());
        } catch (JDOMException e) {
            throw new RuntimeException(e);
        } catch (IllegalArgumentException iae) {
            LOG.warn("Unable to convert Receiver type to valid value of SINGLE,ANY,MESSAGE_SET - defaulting to ANY",
                    iae);
            return ReceiverType.ANY;
        }
    }

    public String getSink(String routeName) {
        return nameToSinkRoute.get(routeName);
    }

    // For test purposes only
    public Map<String, String> getAllNameToSinkRouteMappings() {
        return Collections.unmodifiableMap(nameToSinkRoute);
    }

    public String routePasswordFor(String sinkRouteId) {
        try {
            String routePassword = xmlConverter
                    .string(doc, format("argon/routeMappings/sinkRoute[@value='%s']/routePassword", sinkRouteId));

            return decryptPassword(routePassword);
        } catch (JDOMException e) {
            throw new RuntimeException(e);
        } catch (IllegalArgumentException iae) {
            LOG.warn("Unable to convert Receiver type to valid value of SINGLE,ANY,MESSAGE_SET - defaulting to ANY",
                    iae);
        }
        return null;
    }

    private String decryptPassword(String enccyptedValue) {
        return Encryptor.INSTANCE.decrypt(enccyptedValue);
    }
}
