package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.vest.core.feed.FeedDefinition;

public interface ArgonReceiver {
    void connect();

    void disconnect();

    void receive();

    void addMessageListener(FeedDefinition definition, com.rbs.odc.vest.core.feed.argon.SourceMessageListener sourceMessageListener);

    /**
     * Used to override the normal feed defintion to message listener map as i just want a single message
     * listener and don't wont to have to change the world to make it work
     * @param sourceMessageListener
     */
    void setMessageListener(SourceMessageListener sourceMessageListener);
}
