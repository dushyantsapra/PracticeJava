package com.rbs.odc.vest.core.feed.argon;

import com.rbs.datafabric.domain.Record;
import com.rbs.datafabric.domain.event.RecordModifiedEvent;
import com.rbs.odc.core.logging.Log;
import com.rbs.odc.vest.core.feed.message.MessageBackupCreator;
import com.rbs.odc.vest.core.feed.message.WatcherMessageImpl;
import rx.Subscriber;

import static com.rbs.odc.core.logging.LogFactory.getLog;

/**
 * Created by kamraaa on 3/1/17.
 */
public class WatchDataProcessor extends Subscriber<RecordModifiedEvent> {
    private static final Log LOGGER = getLog(WatchDataProcessor.class);
    SourceMessageListener sourceMessageListener;

    public WatchDataProcessor(SourceMessageListener listener) {
        this.sourceMessageListener = listener;
    }

    @Override
    public void onNext(RecordModifiedEvent recordModifiedEvent) {
        Record record = null;
        try {
            record = recordModifiedEvent.getRecord();
            LOGGER.info("RecordModifiedEvent received at ODC > " + record.getId());
            sourceMessageListener.processMessage(new WatcherMessageImpl(record, new MessageBackupCreator()));
        } catch (RuntimeException e) {
        }
        LOGGER.info("RecordId " + record.getId() + " processed at ODC.");
    }
    @Override
    public void onCompleted() {

    }
    @Override
    public void onError(Throwable throwable) {

    }
}
