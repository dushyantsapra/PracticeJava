package com.rbs.odc.vest.core.feed.argon.simulator;

import com.rbs.odc.core.logging.Log;
import com.rbs.odc.vest.core.feed.argon.*;

import static com.rbs.odc.core.logging.LogFactory.getLog;

public class MessageSenderSimulator implements MessageSender {

    private static final Log LOGGER = getLog(MessageSenderSimulator.class);

    @Override
    public Long send(SentMessage sentMessage) throws MessageSenderException {

        String message = null;

        if (sentMessage instanceof XMLSentMessage) {
            XMLSentMessage xmlSentMessage = (XMLSentMessage) sentMessage;
            message = xmlSentMessage.getMessage();
        }

        if (sentMessage instanceof FtpSentMessage) {
            FtpSentMessage xmlSentMessage = (FtpSentMessage) sentMessage;
            message = xmlSentMessage.getMessageType();
        }

        LOGGER.info("Sending message ..." + message);
        System.out.println("Sending message ....." );
        System.out.println(message);

        return 0L;
    }
}
