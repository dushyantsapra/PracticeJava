package com.rbs.odc.vest.core.feed.argon.simulator;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Stack;

public class FlatteningIterator implements Iterator {

    private final Object sentinel = new Object();

    private final Stack<Iterator<?>> iterators = new Stack<Iterator<?>>();
    private Object next = sentinel;

    public FlatteningIterator(Object... objects) {
        this.iterators.push(Arrays.asList(objects).iterator());
    }

    public void remove() {
        throw new UnsupportedOperationException();
    }

    private void moveToNext() {
        if ((next == sentinel) && !this.iterators.empty()) {
            if (!iterators.peek().hasNext()) {
                iterators.pop();
                moveToNext();
            } else {
                final Object aNext = iterators.peek().next();
                if (aNext instanceof Iterator) {
                    iterators.push((Iterator<?>) aNext);
                    moveToNext();
                } else {
                    this.next = aNext;
                }
            }
        }
    }

    public Object next() {
        moveToNext();
        if (this.next == sentinel) {
            throw new NoSuchElementException();
        } else {
            Object oldNext = this.next;
            this.next = sentinel;
            return oldNext;
        }
    }

    public boolean hasNext() {
        moveToNext();
        return (this.next != sentinel);
    }
}
