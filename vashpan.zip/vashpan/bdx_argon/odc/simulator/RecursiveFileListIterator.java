package com.rbs.odc.vest.core.feed.argon.simulator;

import org.apache.commons.io.comparator.NameFileComparator;

import java.io.File;
import java.io.FileFilter;
import java.util.Arrays;
import java.util.Iterator;

/**
 * <p>Lazily iterate over all files within a directory and its sub-directories.</p>
 * <p>
 *     Within each directory all files and directories will be iterated over in alphabetical order.
 * </p>
 */
public class RecursiveFileListIterator implements Iterator<File> {
    private final FlatteningIterator flatteningIterator;

    public void remove() {
        throw new UnsupportedOperationException();
    }

    public RecursiveFileListIterator(File file, FileFilter filter) {
        this.flatteningIterator = new FlatteningIterator(new FileIterator(file, filter));
    }

    public boolean hasNext() {
        return flatteningIterator.hasNext();
    }

    public File next() {
        return (File) flatteningIterator.next();
    }

    /**
     * Iterator to iterate over all the files contained in a directory. It returns
     * a new FileIterator object for directories, and file objects for non-directories.
     */
    private static class FileIterator implements Iterator<Object> {
        private final Iterator<File> files;
        private final FileFilter filter;

        FileIterator(File file, FileFilter filter) {
            File[] fileArray = file.listFiles(filter);
            sort(fileArray);
            this.files = Arrays.asList(fileArray).iterator();
            this.filter = filter;
        }

        private void sort(File[] fileArray) {
            Arrays.sort(fileArray, NameFileComparator.NAME_COMPARATOR);
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

        public Object next() {
            File next = this.files.next();

            if (next.isDirectory()) {
                return new FileIterator(next, this.filter);
            } else {
                return next;
            }
        }

        public boolean hasNext() {
            return this.files.hasNext();
        }
    }
}