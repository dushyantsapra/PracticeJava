package com.rbs.odc.vest.core.feed.argon.simulator;

import com.rbs.odc.core.logging.Log;
import com.rbs.odc.core.logging.LogFactory;
import com.rbs.odc.vest.core.feed.argon.*;
import com.rbs.odc.vest.core.feed.message.ArgonMessage;
import com.rbs.odc.vest.core.feed.message.SimulatedArgonMessage;

import java.io.File;
import java.io.FileFilter;
import java.util.*;


public class ArgonClientSimulator implements Argon, MessageReceiver {
    private static final Log LOGGER = LogFactory.getLog(ArgonClientSimulator.class);

    private static final String APPLICATION_ID = "APPLICATION_ID";
    private static final String MESSAGE_TYPE = "MESSAGE_TYPE";
    private static final String SOURCE_ROUTE_NAME = "SOURCE_ROOT_NAME";
    public static final String ACK_MARKER = ".processed";

    private final Map<String, File> unAckedFiles;
    private final File feedPath;
    private Iterator<File> fileIterator;
    private boolean shouldInitialize = true;

    public ArgonClientSimulator(File feedPath) {
        this.feedPath = feedPath;
        this.fileIterator = Collections.<File>emptyList().iterator();
        unAckedFiles = new HashMap<String, File>();
        LOGGER.info("ArgonClientSimulator created with " + feedPath.getAbsolutePath());
    }

    @Override
    public void connect() {
        LOGGER.info("ArgonClientSimulator - Connect called");
    }

    @Override
    public void disconnect() {
        LOGGER.info("ArgonClientSimulator - Disconnect called");
    }

    public ArgonMessage receive() throws MessageReceiverException {
        return receive(0l);
    }

    @Override
    public ArgonMessage receive(long timeOut) throws MessageReceiverException {
        if (feedPath.isFile()) {
            return new SimulatedArgonMessage(feedPath, APPLICATION_ID, MESSAGE_TYPE, SOURCE_ROUTE_NAME);
        }

        if (shouldInitialize) {
            if (!feedPath.isDirectory()) {
                return null;
            }
            this.fileIterator = new RecursiveFileListIterator(feedPath, new MessageFilter());
            shouldInitialize = false;
        }

        return nextFromDirectory();
    }

    private ArgonMessage nextFromDirectory() {
        ArgonMessage feedMessage = null;
        if (hasNext()) {
            File file = fileIterator.next();
            unAckedFiles.put(file.getAbsolutePath(), file);
            feedMessage = new SimulatedArgonMessage(file, APPLICATION_ID, MESSAGE_TYPE, SOURCE_ROUTE_NAME);
        } else {
            shouldInitialize = true;
        }
        return feedMessage;
    }

    public boolean hasNext() {
        return fileIterator.hasNext();
    }

    private class MessageFilter implements FileFilter {
        @Override
        public boolean accept(File file) {
            if (file.getName().endsWith(ACK_MARKER)) {
                File originalInPlayFile = new File(file.getParent(), file.getName().replace(ACK_MARKER, ""));
                unAckedFiles.remove(originalInPlayFile.getAbsolutePath());
                return false;
            }
            if (unAckedFiles.containsKey(file.getAbsolutePath())) {
                // see if it has the same timestamp. If not then process again!
                File previousPlayed = unAckedFiles.get(file.getAbsolutePath());
                return previousPlayed.lastModified() != file.lastModified();
            }

            return true;
        }
    }

    @Override
    public MessageReceiver receiver(ReceiverType type) {
        return this;
    }

    @Override
    public MessageSender<SentMessage> sender(MessageSender.SenderType type, String messageType) {
        return new MessageSenderSimulator();
    }

    @Override
    public String getRouteAddress() {
        return "simulator";
    }

    public Collection<File> getUnAckedFiles() {
        return unAckedFiles.values();
    }

}