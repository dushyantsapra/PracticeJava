package com.rbs.odc.vest.core.feed.argon;

public interface ArgonRouteSummaryExtractor {
    int getPendingMessages() throws ArgonRouteSummaryException;
}
