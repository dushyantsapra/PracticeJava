package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.common.api.TdxDatasetStreamProvider;
import com.rbs.odc.common.exception.TdxFeedException;
import com.rbs.odc.common.parser.TDXMappingParser;
import com.rbs.odc.common.parser.TdxFeed;
import com.rbs.odc.core.logging.Log;
import com.rbs.odc.vest.core.exception.VestFeedException;
import com.rbs.odc.vest.core.feed.FeedDefinition;
import com.tdx.client.api.streams.TDXDatasetEventConsumer;

import static com.rbs.odc.core.logging.LogFactory.getLog;

/**
 * Created by srivagc on 8/2/17.
 */
public class TdxEventFeedSource implements FeedSource {

    private static final Log LOGGER = getLog(TdxEventFeedSource.class);
    private final TDXMappingParser parser;
    private final boolean remap;
    private final boolean deleteStreamOnRemap;
    private boolean remapAllVersions;
    private final TdxDatasetStreamProvider tdxDatasetStreamProvider;
    private TDXDatasetEventConsumer tdxDatasetEventConsumer;
    private final String tdxFeedName;

    public TdxEventFeedSource(TdxDatasetStreamProvider tdxDatasetStreamProvider, String tdxFeedName, TDXMappingParser parser, boolean remap, boolean deleteStreamOnRemap, boolean remapAllVersions) {
        this.tdxDatasetStreamProvider = tdxDatasetStreamProvider;
        this.tdxFeedName = tdxFeedName;
        this.parser = parser;
        this.remap = remap;
        this.deleteStreamOnRemap = deleteStreamOnRemap;
        this.remapAllVersions = remapAllVersions;
    }

    @Override
    public void subscribe(FeedDefinition definition, SourceMessageListener sourceMessageListener) throws VestFeedException {
        //Nothing to do here
    }

    @Override
    public void subscribe(String feedName, SourceMessageListener listener) throws VestFeedException {
        try {
            TdxFeed tdxFeed = parser.getMappingForFeed(tdxFeedName);
            tdxFeed.setTag(remap ? tdxFeed.getTag() + "-Remap" : tdxFeed.getTag());
            tdxDatasetStreamProvider.getDatasetEventStream(tdxFeed, remap, deleteStreamOnRemap, remapAllVersions);
            tdxDatasetEventConsumer = remap ? new TdxRemapEventDataProcessorImpl(listener, tdxFeed) : new TdxEventDataProcessorImpl(listener, tdxFeed);
            LOGGER.info("Subscribed with " + feedName);
        } catch (TdxFeedException e) {
            throw new VestFeedException(e.getMessage(),e);
        }
    }

    @Override
    public void start() {
        tdxDatasetStreamProvider.subscribe(tdxDatasetEventConsumer);
    }

}
