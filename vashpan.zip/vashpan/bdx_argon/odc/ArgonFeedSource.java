package com.rbs.odc.vest.core.feed.argon;

import com.google.common.annotations.VisibleForTesting;
import com.rbs.odc.core.logging.Log;
import com.rbs.odc.vest.core.exception.VestFeedException;
import com.rbs.odc.vest.core.feed.FeedDefinition;
import com.rbs.odc.vest.core.feed.execution.FeedSourceScheduler;
import com.rbs.odc.vest.core.util.DirectExecutor;
import com.rbs.odc.vest.core.util.VestPropertiesHelper;
import com.rbsfm.argon.client.cga.ClientException;
import com.rbsfm.argon.client.cga.ClientNodeAddress;
import com.rbsfm.argon.client.cga.StreamList;

import java.util.HashMap;
import java.util.Map;

import static com.rbs.odc.core.logging.LogFactory.getLog;
import static java.lang.String.format;

public class ArgonFeedSource implements FeedSource {
    private static final Log LOGGER = getLog(ArgonFeedSource.class);
    private final ArgonMappingsParser parser;
    private final com.rbs.odc.vest.core.feed.argon.ArgonClientFactory argonClientFactory;
    private final Map<String, com.rbs.odc.vest.core.feed.argon.ArgonReceiver> receivers
            = new HashMap<String, com.rbs.odc.vest.core.feed.argon.ArgonReceiver>();
    private final com.rbs.odc.vest.core.feed.execution.FeedSourceScheduler scheduler;
    private final com.rbs.odc.vest.core.feed.argon.ArgonRouteMappings argonRouteMappings;

    public ArgonFeedSource(FeedSourceScheduler scheduler, com.rbs.odc.vest.core.feed.argon.ArgonMappingsParser parser,
            com.rbs.odc.vest.core.feed.argon.ArgonClientFactory argonClientFactory) {
        this.scheduler = scheduler;
        this.parser = parser;
        this.argonClientFactory = argonClientFactory;
        argonRouteMappings = new com.rbs.odc.vest.core.feed.argon.ArgonRouteMappings(parser);
    }

    private StreamList getStreamList(String argonSink) throws VestFeedException {
        try {
            StreamList streamList = new StreamList();

            for (com.rbs.odc.vest.core.feed.argon.ArgonDestRouteMapping argonMapping : parser
                    .getArgonDestMappings(argonSink)) {
                LOGGER.info("Message type [" + argonMapping.getMessageType() + "]. Source route [" + argonMapping
                        .getSourceRoute() + "].");
                streamList
                        .addStream(argonMapping.getMessageType(), new ClientNodeAddress(argonMapping.getSourceRoute()));
            }

            return streamList;
        } catch (ClientException e) {
            throw new VestFeedException(e);
        }
    }

    @Override
    public void subscribe(FeedDefinition definition,
            com.rbs.odc.vest.core.feed.argon.SourceMessageListener sourceMessageListener) throws VestFeedException {
        String argonSinkRoute = argonRouteMappings.getArgonSinkRoute(definition.getFeed());
        argonRouteMappings.getArgonDestRouteMapping(definition.getFeed(), argonSinkRoute);
        if (argonSinkRoute == null) {
            throw new IllegalArgumentException(format("Unable to map feed %s to a route", definition.getFeed().name()));
        }

        com.rbs.odc.vest.core.feed.argon.ArgonReceiver receiver = getArgonInstance(argonSinkRoute);
        receiver.addMessageListener(definition, sourceMessageListener);
    }

    @Override
    public void subscribe(String feedName, com.rbs.odc.vest.core.feed.argon.SourceMessageListener listener)
            throws VestFeedException {
        String argonSinkRoute = argonRouteMappings.getArgonSinkRoute(feedName);
        if (argonSinkRoute == null) {
            throw new IllegalArgumentException(format("Unable to find source route for name %s", feedName));
        }
        ArgonReceiver receiver = getArgonInstance(argonSinkRoute);
        receiver.setMessageListener(listener);
    }

    @Override
    public void start() {
        LOGGER.info(String.format(" argon receivers %s  ", receivers.size()));
        for (ArgonReceiver receiver : receivers.values()) {
            receiver.connect();
            scheduler.schedule(receiver);
        }
    }

    private ArgonReceiver getArgonInstance(String route) throws VestFeedException {
        if (!receivers.containsKey(route)) {
            String routePassword = parser.routePasswordFor(route) != null ? parser.routePasswordFor(route) :
                                   VestPropertiesHelper.getArgonRouteDefaultPassword();
            com.rbs.odc.vest.core.feed.argon.Argon argon = new com.rbs.odc.vest.core.feed.argon.ArgonClient(route,
                    routePassword, getStreamList(route), argonClientFactory);
            receivers.put(route, new com.rbs.odc.vest.core.feed.argon.ArgonReceiverImpl(argon,
                    argon.receiver(parser.receiverTypeFor(route)), new DirectExecutor()));
        }
        return receivers.get(route);
    }

    @VisibleForTesting
    boolean hasReceiverFor(String route) {
        return receivers.containsKey(route);
    }
}