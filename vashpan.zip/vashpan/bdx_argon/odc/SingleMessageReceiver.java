package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.vest.core.feed.message.ArgonFeedMessageImpl;
import com.rbs.odc.vest.core.feed.message.ArgonMessage;
import com.rbsfm.argon.client.cga.ClientException;
import com.rbsfm.argon.client.cga.ReceivedMessage;
import com.rbsfm.argon.client.cga.Receiver;

public class SingleMessageReceiver implements MessageReceiver {

    private final Receiver receiver;

    public SingleMessageReceiver(Receiver receiver) {
        this.receiver = receiver;
    }

    @Override
    public ArgonMessage receive(long timeOut) throws MessageReceiverException {
        try {
            ReceivedMessage receivedMessage = receiver.receive(timeOut);
            if (receivedMessage != null) {
                return new ArgonFeedMessageImpl(receivedMessage);
            }
            return null;
        } catch (ClientException e) {
            throw new MessageReceiverException(e);
        }
    }

}
