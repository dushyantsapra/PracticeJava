package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.access.domain.DurableWatchSequenceId;
import com.rbs.odc.common.parser.TDXMappingParser;
import com.rbs.odc.common.parser.TdxFeed;
import com.rbs.odc.core.domain.DurableWatchSequenceIdImpl;
import com.rbs.odc.datafabric.DurableWatchProvider;
import com.rbs.odc.vest.core.exception.VestFeedException;
import com.rbs.odc.vest.core.feed.FeedDefinition;

import static com.rbs.odc.core.util.ODCPropertiesHelper.getEnvironment;

/**
 * Created by kamraaa on 3/1/17.
 */
public class WatcherFeedSource implements FeedSource {

    private final TDXMappingParser parser;
    WatchDataProcessor dataWatcher;
    private DurableWatchProvider durableWatchProvider;
    private String tdxFeedName;

    public WatcherFeedSource(DurableWatchProvider durableWatchProvider, String tdxFeedName, TDXMappingParser parser) {
        this.tdxFeedName = tdxFeedName;
        this.durableWatchProvider = durableWatchProvider;
        this.parser = parser;
    }

    @Override
    public void subscribe(FeedDefinition definition, SourceMessageListener sourceMessageListener) throws VestFeedException {
        //Nothing to do here
    }

    @Override
    public void subscribe(String feedName, SourceMessageListener listener) throws VestFeedException {
        TdxFeed feedInfo = parser.getMappingForFeed(tdxFeedName);
        dataWatcher = new WatchDataProcessor(listener);
        durableWatchProvider.createOrGetWatch(convertFeedToDFDurableWatchSequenceId(feedInfo));
    }

    @Override
    public void start() {
        durableWatchProvider.subscribe(dataWatcher);
    }

    private DurableWatchSequenceId convertFeedToDFDurableWatchSequenceId(TdxFeed feedInfo) {
        return new DurableWatchSequenceIdImpl(getEnvironment(), feedInfo.getName(), feedInfo.getEnv(), feedInfo.getCollection(), feedInfo.getDbName(), feedInfo.getWhere());
    }

}
