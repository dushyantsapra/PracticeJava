package com.rbs.odc.vest.core.feed.argon;

import com.rbs.odc.core.util.Encryptor;
import com.rbs.odc.core.util.ODCPropertiesHelper;
import org.apache.commons.lang.Validate;

/**
 * Created by kumprak on 04/05/2018.
 */
public class RdxDetailsProvider {

    private static final String RDX_PERMISSION_PROPERTY = "odc.rdx.permission";
    private static final String RDX_USERNAME_PROPERTY = "odc.rdx.userName";
    private static final String RDX_PASSWORD_PROPERTY = "odc.rdx.password";

    private static final String RDX_ENVIRONMENT_PROPERTY = "RdxEnvironment";
    private static final String RDX_VERSION_PROPERTY = "Version";

    public RdxDetailsProvider() {}

    public String getUserName() {
        return getRequiredProperty(RDX_USERNAME_PROPERTY);
    }

    public String getPassword() {
        return getRequiredProperty(RDX_PASSWORD_PROPERTY);
    }

    public String getPermission() {
        return getRequiredProperty(RDX_PERMISSION_PROPERTY);
    }

    public String getEnvironment() {
        return getRequiredProperty(RDX_ENVIRONMENT_PROPERTY);
    }

    public String getVersion() {
        return getRequiredProperty(RDX_VERSION_PROPERTY);
    }

    public String getClientApplication() {
        return "odc_"+ODCPropertiesHelper.getEnvironment();
    }

    private String getRequiredProperty(String name) {
        String value = System.getProperty(name);
        Validate.notEmpty(value, name + " property is missing or empty");
        value = Encryptor.INSTANCE.decrypt(value);
        return value;
    }


}
