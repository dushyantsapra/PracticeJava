package com.rbs.odc.vest.core.feed.argon;

public class ArgonRouteSummaryException extends Exception {
    public ArgonRouteSummaryException(String message, Throwable cause) {
        super(message, cause);
    }
}
