package com.rbs.odc.vest.core.feed.argon;

import com.rbsfm.argon.client.cga.SentMessage;

public interface MessageSender<E extends SentMessage> {

    Long send(E sentMessage) throws com.rbs.odc.vest.core.feed.argon.MessageSenderException;

    enum SenderType {
        XML,
        FTP
    }
}
